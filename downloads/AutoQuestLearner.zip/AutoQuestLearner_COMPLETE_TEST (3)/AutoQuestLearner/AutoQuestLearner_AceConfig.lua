--[[
  AceConfig-3.0 + Interface Options registration for AutoQuestLearner.
  Categories under Interface -> AddOns:
    AutoQuestLearner
      General / Questing / Map & Minimap / User Data
]]

local registered = false

local function Cfg()
  AutoQuestLearnerDB = AutoQuestLearnerDB or {}
  AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
  return AutoQuestLearnerDB.config
end

local DEFAULTS = {
  showtracker = "1", lock = "0", hideblizzardtracker = "1", navArrow = "1",
  questitembuttons = "1", routeLine = "1", clustersCurrentZoneOnly = "1",
  spawnAreaOutline = "1", syncParty = "1", syncGuild = "0", nodestyle = "combined",
  showtooltips = "1", trackerlevel = "1", questloglevel = "0",
  trackeralpha = "0", trackerfontsize = "12", trackerexpand = "0",
  trackerzonefilter = "0", trackerShowAllLog = "1", learnNotify = "1", zoneNudge = "1",
  debug = "0", showSeasonalQuests = "0",
  announcePartyChat = "0", announcePartyProgress = "0", questItemTooltip = "1",
  allquestgivers = "1", currentquestgivers = "1", showlowlevel = "0",
  showhighlevel = "0", minimapnodes = "1", focusmode = "1", spawncolors = "0",
  preferNearbyAvailable = "1", nearbyAvailablePriority = "15",
  availableQuestRadius = "30", availableQuestRadiusWhileActive = "20",
  worldmaptransp = "1.0", minimaptransp = "1.0", mouseover = "1",
  minimapbutton = "1",
  hideKilledNodes = "0",
  trackAscensionQuests = "0",
  autoAccept = "0", autoTurnIn = "0",
  townsfolkFlight = "0", townsfolkVendor = "0", townsfolkRepair = "0", townsfolkInn = "0",
  tooltipDropRate = "1",
}

local function EnsureDefaults()
  local c = Cfg()
  for k, v in pairs(DEFAULTS) do
    if c[k] == nil then c[k] = v end
  end
end

local function RefreshMapDisplay()
  -- Full rebuild so nodestyle changes are visible immediately
  if AutoQuestLearner_ClearStaticObjectiveDrawn then
    AutoQuestLearner_ClearStaticObjectiveDrawn()
  end
  if AutoQuestLearnerMap and AutoQuestLearnerMap.DeleteNode then
    AutoQuestLearnerMap:DeleteNode("AUTOQUESTLEARNER")
  end
  if AutoQuestLearner and AutoQuestLearner.questlog and AutoQuestLearner.db and AutoQuestLearner.db.SearchQuestID then
    for questid, data in pairs(AutoQuestLearner.questlog) do
      if data and data.qlogid then
        pcall(function()
          AutoQuestLearner.db:SearchQuestID(questid, { addon = "AUTOQUESTLEARNER", qlogid = data.qlogid })
        end)
      end
    end
  end
  if AutoQuestLearner_ReplayLearnedLocations then
    pcall(AutoQuestLearner_ReplayLearnedLocations, nil, { force = true })
  end
  if AutoQuestLearnerMap then
    AutoQuestLearnerMap._mmForceRebuild = true
    if AutoQuestLearnerMap.UpdateNodes then AutoQuestLearnerMap:UpdateNodes() end
    if AutoQuestLearnerMap.UpdateMinimap then AutoQuestLearnerMap:UpdateMinimap() end
  end
end

local MAP_REFRESH_KEYS = {
  nodestyle = true,
  minimapnodes = true,
  clustersCurrentZoneOnly = true,
  spawnAreaOutline = true,
  focusmode = true,
  spawncolors = true,
  allquestgivers = true,
  currentquestgivers = true,
  showlowlevel = true,
  showhighlevel = true,
}

local function GetToggle(key)
  return function() return Cfg()[key] == "1" end
end
local function SetToggle(key)
  return function(_, val)
    Cfg()[key] = val and "1" or "0"
    if AutoQuestLearnerConfig and AutoQuestLearnerConfig.UpdateConfigEntries then
      AutoQuestLearnerConfig:UpdateConfigEntries()
    end
    if MAP_REFRESH_KEYS[key] then
      RefreshMapDisplay()
    end
  end
end
local function GetText(key, default)
  return function()
    local v = Cfg()[key]
    if v == nil then return default or "" end
    return tostring(v)
  end
end
local function SetText(key)
  return function(_, val)
    Cfg()[key] = tostring(val or "")
    if AutoQuestLearnerConfig and AutoQuestLearnerConfig.UpdateConfigEntries then
      AutoQuestLearnerConfig:UpdateConfigEntries()
    end
  end
end
local function GetSelect(key, default)
  return function() return Cfg()[key] or default end
end
local function SetSelect(key)
  return function(_, val)
    Cfg()[key] = val
    if AutoQuestLearnerConfig and AutoQuestLearnerConfig.UpdateConfigEntries then
      AutoQuestLearnerConfig:UpdateConfigEntries()
    end
    if MAP_REFRESH_KEYS[key] or key == "nodestyle" then
      RefreshMapDisplay()
      if key == "nodestyle" then
        print("|cff00ff00AutoQuestLearner:|r Map Node Style → |cffffff00" .. tostring(val) .. "|r (map redrawn)")
      end
    end
  end
end

local options = {
  name = "AutoQuestLearner",
  type = "group",
  args = {
    general = {
      type = "group", name = "General", order = 1,
      args = {
        showtracker = { type = "toggle", order = 1, width = "full", name = "Enable Quest Tracker", get = GetToggle("showtracker"), set = SetToggle("showtracker") },
        lock = { type = "toggle", order = 2, width = "full", name = "Lock Tracker Position/Size", get = GetToggle("lock"), set = SetToggle("lock") },
        hideblizzardtracker = { type = "toggle", order = 3, width = "full", name = "Replace Blizzard's Quest Tracker", get = GetToggle("hideblizzardtracker"), set = SetToggle("hideblizzardtracker") },
        navArrow = { type = "toggle", order = 4, width = "full", name = "Show Navigation Arrow", get = GetToggle("navArrow"), set = SetToggle("navArrow") },
        questitembuttons = { type = "toggle", order = 5, width = "full", name = "Show Quest Item Buttons", get = GetToggle("questitembuttons"), set = SetToggle("questitembuttons") },
        routeLine = { type = "toggle", order = 6, width = "full", name = "Show Route Line", get = GetToggle("routeLine"), set = SetToggle("routeLine") },
        clustersCurrentZoneOnly = { type = "toggle", order = 7, width = "full", name = "Only Show Clusters in My Current Zone", get = GetToggle("clustersCurrentZoneOnly"), set = SetToggle("clustersCurrentZoneOnly") },
        spawnAreaOutline = { type = "toggle", order = 8, width = "full", name = "Outline Spawn Areas Instead of Dot Clusters", get = GetToggle("spawnAreaOutline"), set = SetToggle("spawnAreaOutline") },
        syncParty = { type = "toggle", order = 9, width = "full", name = "Share Newly-Learned Locations with Party/Raid", get = GetToggle("syncParty"), set = SetToggle("syncParty") },
        syncGuild = { type = "toggle", order = 10, width = "full", name = "Share Newly-Learned Locations with Guild", get = GetToggle("syncGuild"), set = SetToggle("syncGuild") },
        nodestyle = {
          type = "select", order = 11, width = "full", name = "Map Node Style",
          values = {
            simple = "Simple (cluster rings only)",
            combined = "Combined (DB + learned rings)",
            spawn = "Spawn Points (all rings only)",
          },
          get = GetSelect("nodestyle", "combined"), set = SetSelect("nodestyle"),
        },
        showtooltips = { type = "toggle", order = 12, width = "full", name = "Show Tooltips", get = GetToggle("showtooltips"), set = SetToggle("showtooltips") },
        trackerlevel = { type = "toggle", order = 13, width = "full", name = "Show Level On Quest Tracker", get = GetToggle("trackerlevel"), set = SetToggle("trackerlevel") },
        questloglevel = { type = "toggle", order = 14, width = "full", name = "Show Level On Quest Log", get = GetToggle("questloglevel"), set = SetToggle("questloglevel") },
      },
    },
    questing = {
      type = "group", name = "Questing", order = 2,
      args = {
        trackeralpha = { type = "input", order = 1, width = "full", name = "Quest Tracker Visibility", get = GetText("trackeralpha", "0"), set = SetText("trackeralpha") },
        trackerfontsize = { type = "input", order = 2, width = "full", name = "Quest Tracker Font Size", get = GetText("trackerfontsize", "12"), set = SetText("trackerfontsize") },
        trackerexpand = { type = "toggle", order = 3, width = "full", name = "Quest Tracker Unfold Objectives", get = GetToggle("trackerexpand"), set = SetToggle("trackerexpand") },
        trackerzonefilter = { type = "toggle", order = 4, width = "full", name = "Quest Tracker: Current Zone Only", get = GetToggle("trackerzonefilter"), set = SetToggle("trackerzonefilter") },
        trackerShowAllLog = {
          type = "toggle", order = 4.5, width = "full",
          name = "Quest Tracker: Show All Log Quests (ignore Track/Untrack)",
          desc = "Off (default): only quests you Track in Blizzard's quest log appear in the AQL tracker. On: show every quest in the log.",
          get = GetToggle("trackerShowAllLog"),
          set = function(_, val)
            Cfg().trackerShowAllLog = val and "1" or "0"
            if AutoQuestLearnerTracker and AutoQuestLearnerTracker.Reset then
              AutoQuestLearnerTracker.Reset()
            end
          end,
        },
        debug = {
          type = "toggle", order = 4.7, width = "full",
          name = "Debug Chat (green AutoQuestLearner Debug messages)",
          desc = "Off by default. When on, prints green debug lines on quest log updates (Update Quest Log / New Quest / etc.). Also toggled by /aql debug.",
          get = GetToggle("debug"),
          set = SetToggle("debug"),
        },
        showSeasonalQuests = {
          type = "toggle", order = 4.8, width = "full",
          name = "Show Seasonal / Holiday Quest Givers",
          desc = "Off by default. Event-only quests (Brewfest, Midsummer, Winter Veil, etc.) stay hidden until a calendar holiday is active, or until you turn this on.",
          get = GetToggle("showSeasonalQuests"),
          set = function(_, val)
            Cfg().showSeasonalQuests = val and "1" or "0"
            if AutoQuestLearnerMap and AutoQuestLearnerMap.UpdateNodes then
              AutoQuestLearnerMap:UpdateNodes()
            end
          end,
        },
        learnNotify = { type = "toggle", order = 5, width = "full", name = "Notify When Auto-Learning a New Location", get = GetToggle("learnNotify"), set = SetToggle("learnNotify") },
        zoneNudge = { type = "toggle", order = 6, width = "full", name = "Suggest Next Zone When Current One's Mostly Done", get = GetToggle("zoneNudge"), set = SetToggle("zoneNudge") },
        announcePartyChat = { type = "toggle", order = 7, width = "full", name = "Announce Quest Accept/Complete in Party Chat", get = GetToggle("announcePartyChat"), set = SetToggle("announcePartyChat") },
        announcePartyProgress = { type = "toggle", order = 8, width = "full", name = "Announce Kill/Loot Progress in Party Chat", get = GetToggle("announcePartyProgress"), set = SetToggle("announcePartyProgress") },
        questItemTooltip = { type = "toggle", order = 9, width = "full", name = "Show Quest Progress on Item Tooltips", get = GetToggle("questItemTooltip"), set = SetToggle("questItemTooltip") },
        tooltipDropRate = { type = "toggle", order = 9.5, width = "full", name = "Show Drop Rate on Item Tooltips (when known)", get = GetToggle("tooltipDropRate"), set = SetToggle("tooltipDropRate") },
        autoAccept = { type = "toggle", order = 9.6, width = "full", name = "Auto-Accept Quests (off by default)", get = GetToggle("autoAccept"), set = SetToggle("autoAccept") },
        autoTurnIn = { type = "toggle", order = 9.7, width = "full", name = "Auto-Turn-In Quests (off by default)", get = GetToggle("autoTurnIn"), set = SetToggle("autoTurnIn") },
        allquestgivers = { type = "toggle", order = 10, width = "full", name = "Display Available Quest Givers", get = GetToggle("allquestgivers"), set = SetToggle("allquestgivers") },
        preferNearbyAvailable = {
          type = "toggle", order = 10.1, width = "full",
          name = "Arrow: Prefer Nearby Available Quests",
          desc = "When an available (!) quest giver is close to you, the arrow points there even if you already have other quests. Requires Available Quest Givers on.",
          get = GetToggle("preferNearbyAvailable"),
          set = SetToggle("preferNearbyAvailable"),
        },
        currentquestgivers = { type = "toggle", order = 11, width = "full", name = "Display Current Quest Givers", get = GetToggle("currentquestgivers"), set = SetToggle("currentquestgivers") },
        showlowlevel = { type = "toggle", order = 12, width = "full", name = "Display Low Level Quest Givers", get = GetToggle("showlowlevel"), set = SetToggle("showlowlevel") },
        showhighlevel = { type = "toggle", order = 13, width = "full", name = "Display Level+3 Quest Givers", get = GetToggle("showhighlevel"), set = SetToggle("showhighlevel") },
        townsfolkHdr = { type = "header", order = 14, name = "Townsfolk on Map (current zone)" },
        townsfolkFlight = { type = "toggle", order = 15, width = "full", name = "Show Flight Masters", get = GetToggle("townsfolkFlight"), set = SetToggle("townsfolkFlight") },
        townsfolkVendor = { type = "toggle", order = 16, width = "full", name = "Show Vendors", get = GetToggle("townsfolkVendor"), set = SetToggle("townsfolkVendor") },
        townsfolkRepair = { type = "toggle", order = 17, width = "full", name = "Show Repair NPCs", get = GetToggle("townsfolkRepair"), set = SetToggle("townsfolkRepair") },
        townsfolkInn = { type = "toggle", order = 18, width = "full", name = "Show Innkeepers", get = GetToggle("townsfolkInn"), set = SetToggle("townsfolkInn") },
      },
    },
    map = {
      type = "group", name = "Map & Minimap", order = 3,
      args = {
        nodestyle = {
          type = "select", order = 0, width = "full", name = "Map Node Style (clusters)",
          desc = "Spawn Points = cluster dots only | Combined = clusters + single markers | Simple = single markers only (no clusters)",
          values = {
            simple = "Simple (cluster rings only)",
            combined = "Combined (DB + learned rings)",
            spawn = "Spawn Points (all rings only)",
          },
          get = GetSelect("nodestyle", "combined"), set = SetSelect("nodestyle"),
        },
        hideKilledNodes = {
          type = "toggle", order = 0.5, width = "full",
          name = "Hide Map Nodes After Kill/Loot (respawn timer)",
          desc = "Temporarily hide the nearest matching spawn pin when you kill that NPC. Off by default so minimap nodes stay put.",
          get = GetToggle("hideKilledNodes"), set = SetToggle("hideKilledNodes"),
        },
        minimapnodes = { type = "toggle", order = 1, width = "full", name = "Enable Minimap Nodes", get = GetToggle("minimapnodes"), set = SetToggle("minimapnodes") },
        minimapbutton = {
          type = "toggle", order = 1.5, width = "full", name = "Show Minimap Button",
          get = GetToggle("minimapbutton"),
          set = function(_, val)
            Cfg().minimapbutton = val and "1" or "0"
            if AutoQuestLearner_RefreshMinimapButton then
              AutoQuestLearner_RefreshMinimapButton()
            end
          end,
        },
        focusmode = { type = "toggle", order = 2, width = "full", name = "Focus Mode: Only show arrow-tracked quest (switches with arrow)", get = GetToggle("focusmode"), set = SetToggle("focusmode") },
        spawncolors = { type = "toggle", order = 3, width = "full", name = "Color Map Nodes By Spawn", get = GetToggle("spawncolors"), set = SetToggle("spawncolors") },
        worldmaptransp = { type = "input", order = 4, width = "full", name = "World Map Node Transparency", get = GetText("worldmaptransp", "1.0"), set = SetText("worldmaptransp") },
        minimaptransp = { type = "input", order = 5, width = "full", name = "Minimap Node Transparency", get = GetText("minimaptransp", "1.0"), set = SetText("minimaptransp") },
        mouseover = { type = "toggle", order = 6, width = "full", name = "Highlight Nodes On Mouseover", get = GetToggle("mouseover"), set = SetToggle("mouseover") },
      },
    },
    userdata = {
      type = "group", name = "User Data", order = 4,
      args = {
        note = { type = "description", order = 0, name = "Share or reset what this account has learned. Import never overwrites locations you already have." },
        exportLearned = {
          type = "execute", order = 1, width = "full", name = "Export Learned Locations",
          desc = "Opens a copyable string of your account-wide learned giver, turn-in, and objective coords (same as /aql export).",
          func = function()
            if not AutoQuestLearner_ExportLearnedLocations then
              print("|cffff0000AutoQuestLearner:|r Export not available yet.")
              return
            end
            local exportString = AutoQuestLearner_ExportLearnedLocations()
            if not StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"] then
              print("|cffff0000AutoQuestLearner:|r Export dialog missing — use /aql export.")
              return
            end
            StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"].data = exportString
            local dialog = StaticPopup_Show("AUTOQUESTLEARNER_EXPORTCOPY")
            if dialog then
              local btn = _G[dialog:GetName() .. "Button1"]
              local edit = _G[dialog:GetName() .. "WideEditBox"]
              if btn then
                btn:ClearAllPoints()
                btn:SetPoint("BOTTOM", dialog, "BOTTOM", 0, 16)
              end
              if edit and StaticPopup_EditBoxOnTextChanged then
                edit:SetScript("OnTextChanged", StaticPopup_EditBoxOnTextChanged)
              end
              dialog:SetWidth(420)
            end
          end,
        },
        importLearned = {
          type = "execute", order = 2, width = "full", name = "Import Learned Locations",
          desc = "Paste a shared export string. Only fills gaps — never replaces coords you already learned (same as /aql import).",
          func = function()
            if StaticPopupDialogs["AUTOQUESTLEARNER_IMPORTPASTE"] then
              StaticPopup_Show("AUTOQUESTLEARNER_IMPORTPASTE")
            else
              print("|cffff0000AutoQuestLearner:|r Import dialog missing — use /aql import.")
            end
          end,
        },
        divider1 = { type = "header", order = 3, name = "Reset" },
        resetconfig = {
          type = "execute", order = 4, width = "full", name = "Reset Configuration",
          func = function()
            local d = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
            if not d then return end
            d.text = "Do you really want to reset the configuration?"
            d.OnAccept = function() AutoQuestLearnerDB.config = {} ReloadUI() end
            StaticPopup_Show("AUTOQUESTLEARNER_RESET")
          end,
        },
        resethistory = {
          type = "execute", order = 5, width = "full", name = "Reset Quest History",
          func = function()
            local d = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
            if not d then return end
            d.text = "Do you really want to reset the quest history?"
            d.OnAccept = function() AutoQuestLearnerDB.history = {} ReloadUI() end
            StaticPopup_Show("AUTOQUESTLEARNER_RESET")
          end,
        },
        reseteverything = {
          type = "execute", order = 6, width = "full", name = "Reset Everything",
          func = function()
            local d = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
            if not d then return end
            d.text = "Do you really want to reset everything?"
            d.OnAccept = function()
              AutoQuestLearnerDB.config = {}
              AutoQuestLearnerDB.history = {}
              AutoQuestLearnerDB.colors = {}
              ReloadUI()
            end
            StaticPopup_Show("AUTOQUESTLEARNER_RESET")
          end,
        },
        usage = {
          type = "execute", order = 7, width = "full", name = "Open Addon Memory Usage",
          func = function()
            if AutoQuestLearner and AutoQuestLearner.Usage and AutoQuestLearner.Usage.Toggle then
              AutoQuestLearner.Usage:Toggle()
            end
          end,
        },
      },
    },
  },
}

------------------------------------------------------------
-- Native Blizzard fallback (always works even if Ace fails)
------------------------------------------------------------
local function NativeToggle(parent, label, key, y)
  local name = "AQLNativeOpt_" .. key
  local cb = CreateFrame("CheckButton", name, parent, "InterfaceOptionsCheckButtonTemplate")
  cb:SetPoint("TOPLEFT", 16, y)
  local fs = _G[name .. "Text"]
  if fs then fs:SetText(label) end
  cb:SetScript("OnShow", function()
    EnsureDefaults()
    cb:SetChecked(Cfg()[key] == "1")
  end)
  cb:SetScript("OnClick", function()
    Cfg()[key] = cb:GetChecked() and "1" or "0"
  end)
  return y - 24
end

local function RegisterNativeCategory(name, parentName, builder)
  local panel = CreateFrame("Frame", "AQLBlizz_" .. name:gsub("[^%w]", ""))
  panel.name = name
  panel.parent = parentName
  panel:Hide()
  local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 16, -16)
  title:SetText(name)
  local y = -44
  if builder then y = builder(panel, y) end
  if InterfaceOptions_AddCategory then
    InterfaceOptions_AddCategory(panel)
  end
  return panel
end

local function RegisterNativeFallback()
  RegisterNativeCategory("AutoQuestLearner", nil, function(panel, y)
    local d = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    d:SetPoint("TOPLEFT", 16, y)
    d:SetWidth(500)
    d:SetJustifyH("LEFT")
    d:SetText("Expand AutoQuestLearner with the + button for General, Questing, Map & Minimap, and User Data.\nOr type /aqlaceconfig for the AceGUI window.")
    return y - 40
  end)

  RegisterNativeCategory("General", "AutoQuestLearner", function(panel, y)
    y = NativeToggle(panel, "Enable Quest Tracker", "showtracker", y)
    y = NativeToggle(panel, "Lock Tracker Position/Size", "lock", y)
    y = NativeToggle(panel, "Replace Blizzard's Quest Tracker", "hideblizzardtracker", y)
    y = NativeToggle(panel, "Show Navigation Arrow", "navArrow", y)
    y = NativeToggle(panel, "Show Quest Item Buttons", "questitembuttons", y)
    y = NativeToggle(panel, "Show Route Line", "routeLine", y)
    y = NativeToggle(panel, "Only Show Clusters in My Current Zone", "clustersCurrentZoneOnly", y)
    y = NativeToggle(panel, "Outline Spawn Areas Instead of Dot Clusters", "spawnAreaOutline", y)
    y = NativeToggle(panel, "Share Locations with Party/Raid", "syncParty", y)
    y = NativeToggle(panel, "Share Locations with Guild", "syncGuild", y)
    y = NativeToggle(panel, "Show Tooltips", "showtooltips", y)
    y = NativeToggle(panel, "Show Level On Quest Tracker", "trackerlevel", y)
    y = NativeToggle(panel, "Show Level On Quest Log", "questloglevel", y)
    return y
  end)

  RegisterNativeCategory("Questing", "AutoQuestLearner", function(panel, y)
    y = NativeToggle(panel, "Quest Tracker Unfold Objectives", "trackerexpand", y)
    y = NativeToggle(panel, "Quest Tracker: Current Zone Only", "trackerzonefilter", y)
    y = NativeToggle(panel, "Notify When Auto-Learning a New Location", "learnNotify", y)
    y = NativeToggle(panel, "Suggest Next Zone When Mostly Done", "zoneNudge", y)
    y = NativeToggle(panel, "Announce Accept/Complete in Party", "announcePartyChat", y)
    y = NativeToggle(panel, "Announce Kill/Loot Progress in Party", "announcePartyProgress", y)
    y = NativeToggle(panel, "Show Quest Progress on Item Tooltips", "questItemTooltip", y)
    y = NativeToggle(panel, "Display Available Quest Givers", "allquestgivers", y)
    y = NativeToggle(panel, "Display Current Quest Givers", "currentquestgivers", y)
    y = NativeToggle(panel, "Display Low Level Quest Givers", "showlowlevel", y)
    y = NativeToggle(panel, "Display Level+3 Quest Givers", "showhighlevel", y)
    return y
  end)

  RegisterNativeCategory("Map & Minimap", "AutoQuestLearner", function(panel, y)
    y = NativeToggle(panel, "Enable Minimap Nodes", "minimapnodes", y)
    y = NativeToggle(panel, "Focus Mode: Only Show What Arrow Is Tracking", "focusmode", y)
    y = NativeToggle(panel, "Color Map Nodes By Spawn", "spawncolors", y)
    y = NativeToggle(panel, "Highlight Nodes On Mouseover", "mouseover", y)
    return y
  end)

  RegisterNativeCategory("User Data", "AutoQuestLearner", function(panel, y)
    local d = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    d:SetPoint("TOPLEFT", 16, y)
    d:SetText("Use /aql config floating panel or /aqlaceconfig for reset buttons.")
    return y - 30
  end)
end

------------------------------------------------------------
-- AceConfig registration
------------------------------------------------------------
local function RegisterAceConfig()
  if registered then return true end

  EnsureDefaults()

  if not LibStub then
    print("|cffff0000AutoQuestLearner|r LibStub missing -- using native Interface Options.")
    RegisterNativeFallback()
    registered = true
    return false
  end

  local AceConfig = LibStub("AceConfig-3.0", true)
  local AceConfigDialog = LibStub("AceConfigDialog-3.0", true)
  local AceGUI = LibStub("AceGUI-3.0", true)

  if not AceConfig or not AceConfigDialog or not AceGUI then
    print("|cffff0000AutoQuestLearner|r AceConfig/AceGUI not loaded -- using native Interface Options.")
    print("  AceConfig=" .. tostring(AceConfig ~= nil) .. " Dialog=" .. tostring(AceConfigDialog ~= nil) .. " GUI=" .. tostring(AceGUI ~= nil))
    RegisterNativeFallback()
    registered = true
    return false
  end

  local ok, err = pcall(function()
    AceConfig:RegisterOptionsTable("AutoQuestLearner", options)
    AceConfigDialog:AddToBlizOptions("AutoQuestLearner", "AutoQuestLearner")
    AceConfigDialog:AddToBlizOptions("AutoQuestLearner", "General", "AutoQuestLearner", "general")
    AceConfigDialog:AddToBlizOptions("AutoQuestLearner", "Questing", "AutoQuestLearner", "questing")
    AceConfigDialog:AddToBlizOptions("AutoQuestLearner", "Map & Minimap", "AutoQuestLearner", "map")
    AceConfigDialog:AddToBlizOptions("AutoQuestLearner", "User Data", "AutoQuestLearner", "userdata")
  end)

  if not ok then
    print("|cffff0000AutoQuestLearner|r AceConfig registration failed: " .. tostring(err))
    print("  Falling back to native Interface Options categories.")
    RegisterNativeFallback()
    registered = true
    return false
  end

  SLASH_AQLACECONFIG1 = "/aqlaceconfig"
  SlashCmdList["AQLACECONFIG"] = function()
    AceConfigDialog:Open("AutoQuestLearner")
  end

  registered = true
  return true
end

function AutoQuestLearner_OpenConfig()
  if not registered then RegisterAceConfig() end
  if InterfaceOptionsFrame_OpenToCategory then
    InterfaceOptionsFrame_OpenToCategory("AutoQuestLearner")
    InterfaceOptionsFrame_OpenToCategory("AutoQuestLearner")
  end
end

-- Register as soon as addon files + SV are ready; retry on login if needed
local boot = CreateFrame("Frame")
boot:RegisterEvent("ADDON_LOADED")
boot:RegisterEvent("PLAYER_LOGIN")
boot:SetScript("OnEvent", function()
  local ev = event
  if ev == "ADDON_LOADED" then
    if arg1 ~= "AutoQuestLearner" then return end
    boot:UnregisterEvent("ADDON_LOADED")
    local ok = RegisterAceConfig()
    if ok then
      -- success silent; chat spam only on failure
    end
  elseif ev == "PLAYER_LOGIN" then
    boot:UnregisterEvent("PLAYER_LOGIN")
    if not registered then
      RegisterAceConfig()
    end
    EnsureDefaults()
    -- Normalize debug: only the string "1" means on. Old installs could
    -- have true / "true" / 1 and spam green "Update Quest Log" lines.
    local c = AutoQuestLearnerDB and AutoQuestLearnerDB.config
    if c then
      if c.debug == true or c.debug == 1 or c.debug == "true" then
        c.debug = "1"
      elseif c.debug ~= "1" then
        c.debug = "0"
      end
    end
  end
end)
