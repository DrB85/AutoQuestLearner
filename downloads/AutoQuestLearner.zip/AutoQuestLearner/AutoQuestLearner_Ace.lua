--[[
  Ace3 bootstrap for AutoQuestLearner (WotLK 3.3.5 compatible Ace3 r960).

  Provides an AceAddon instance with:
    AceEvent-3.0, AceConsole-3.0, AceTimer-3.0, AceHook-3.0, AceBucket-3.0

  Does NOT take over AutoQuestLearnerDB via AceDB (existing SV layout is preserved).
  AceDB is available via LibStub for optional new modules / profile UI later.

  Existing code continues to use the global AutoQuestLearner frame table.
  This Ace object is exposed as AutoQuestLearner.Ace and global AutoQuestLearnerAce.
]]

local addonName = "AutoQuestLearner"

-- Guard: libs must be present (embeds.xml loads first)
local LibStub = _G.LibStub
if not LibStub then
  print("|cffff0000AutoQuestLearner|r Ace3 LibStub missing — embeds.xml not loaded?")
  return
end

local AceAddon = LibStub("AceAddon-3.0", true)
if not AceAddon then
  print("|cffff0000AutoQuestLearner|r AceAddon-3.0 missing — check Libs/embeds.xml")
  return
end

local Ace = AceAddon:NewAddon("AutoQuestLearnerAce",
  "AceConsole-3.0",
  "AceEvent-3.0",
  "AceTimer-3.0",
  "AceHook-3.0",
  "AceBucket-3.0"
)

AutoQuestLearnerAce = Ace

function Ace:OnInitialize()
  -- Link to legacy global if already created by other files
  if AutoQuestLearner then
    AutoQuestLearner.Ace = self
  end
  self:RegisterChatCommand("aqlace", "CmdAceStatus")
end

function Ace:OnEnable()
  if AutoQuestLearner then
    AutoQuestLearner.Ace = self
  end
end

function Ace:CmdAceStatus()
  self:Print("Ace3 embedded and running.")
  self:Print("  AceAddon: AutoQuestLearnerAce")
  self:Print("  Mixins: AceConsole, AceEvent, AceTimer, AceHook, AceBucket")
  self:Print("  Legacy frame: " .. (AutoQuestLearner and "present" or "not yet"))
  self:Print("  LibStub libs available: AceDB-3.0, AceGUI-3.0, AceConfig-3.0, AceLocale-3.0, ...")
end

-- Convenience: schedule the deferred DBC name merge via AceTimer if present
function Ace:ScheduleDbcMerge(delay)
  delay = delay or 0.5
  if AutoQuestLearner_StartDbcNameMerge then
    self:ScheduleTimer(function()
      AutoQuestLearner_StartDbcNameMerge()
    end, delay)
  end
end
