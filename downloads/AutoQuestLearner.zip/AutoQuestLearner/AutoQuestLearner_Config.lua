-- AutoQuestLearner Config Module
-- Rebranded from pfQuest config.lua

AutoQuestLearnerDB = AutoQuestLearnerDB or {}
AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
AutoQuestLearnerDB.history = AutoQuestLearnerDB.history or {}
AutoQuestLearnerDB.colors = AutoQuestLearnerDB.colors or {}

local reset = {
  config = function()
    local dialog = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
    dialog.text = "Do you really want to reset the configuration?"
    dialog.OnAccept = function()
      AutoQuestLearnerDB.config = {}
      ReloadUI()
    end

    StaticPopup_Show("AUTOQUESTLEARNER_RESET")
  end,
  history = function()
    local dialog = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
    dialog.text = "Do you really want to reset the quest history?"
    dialog.OnAccept = function()
      AutoQuestLearnerDB.history = {}
      ReloadUI()
    end

    StaticPopup_Show("AUTOQUESTLEARNER_RESET")
  end,
  everything = function()
    local dialog = StaticPopupDialogs["AUTOQUESTLEARNER_RESET"]
    dialog.text = "Do you really want to reset everything?"
    dialog.OnAccept = function()
      AutoQuestLearnerDB.config = {}
      AutoQuestLearnerDB.history = {}
      AutoQuestLearnerDB.colors = {}
      ReloadUI()
    end

    StaticPopup_Show("AUTOQUESTLEARNER_RESET")
  end,
}

-- default config
AutoQuestLearner_defconfig = {
  { text = "General",
    default = nil, type = "header" },
  { text = "Enable Quest Tracker",
    default = "1", type = "checkbox", config = "showtracker" },
  { text = "Lock Tracker Position/Size",
    default = "0", type = "checkbox", config = "lock" },
  { text = "Replace Blizzard's Quest Tracker",
    default = "1", type = "checkbox", config = "hideblizzardtracker" },
  { text = "Show Navigation Arrow (built-in, no addon required)",
    default = "1", type = "checkbox", config = "navArrow" },
  { text = "Show Quest Item Buttons (use-on-objective items, e.g. Essence Extractor)",
    default = "1", type = "checkbox", config = "questitembuttons" },
  { text = "Show Route Line (dotted path to destination)",
    default = "1", type = "checkbox", config = "routeLine" },
  { text = "Only Show Clusters in My Current Zone (hides them when browsing other zones on the map)",
    default = "0", type = "checkbox", config = "clustersCurrentZoneOnly" },
  { text = "Share Newly-Learned Locations with Party/Raid",
    default = "1", type = "checkbox", config = "syncParty" },
  { text = "Share Newly-Learned Locations with Guild",
    default = "0", type = "checkbox", config = "syncGuild" },
  { text = "Map Node Style",
    type = "cycle", config = "nodestyle",
    options = {
      { value = "spawn", label = "Spawn Points" },
      { value = "combined", label = "Combined" },
      { value = "simple", label = "Simple Markers" },
    } },
  { text = "Show Tooltips",
    default = "1", type = "checkbox", config = "showtooltips" },
  { text = "Show Level On Quest Tracker",
    default = "1", type = "checkbox", config = "trackerlevel" },
  { text = "Show Level On Quest Log",
    default = "0", type = "checkbox", config = "questloglevel" },

  { text = "Questing",
    default = nil, type = "header" },
  { text = "Quest Tracker Visibility",
    default = "0", type = "text", config = "trackeralpha" },
  { text = "Quest Tracker Font Size",
    default = "12", type = "text", config = "trackerfontsize", },
  { text = "Quest Tracker Unfold Objectives",
    default = "0", type = "checkbox", config = "trackerexpand" },
  { text = "Quest Tracker: Current Zone Only",
    default = "0", type = "checkbox", config = "trackerzonefilter" },
  { text = "Notify When Auto-Learning a New Location",
    default = "1", type = "checkbox", config = "learnNotify" },
  { text = "Suggest Next Zone When Current One's Mostly Done",
    default = "1", type = "checkbox", config = "zoneNudge" },
  { text = "Announce Quest Accept/Complete in Party Chat",
    default = "0", type = "checkbox", config = "announcePartyChat" },
  { text = "Announce Kill/Loot Progress in Party Chat",
    default = "0", type = "checkbox", config = "announcePartyProgress" },
  { text = "Show Quest Progress on Item Tooltips",
    default = "1", type = "checkbox", config = "questItemTooltip" },
  { text = "Display Available Quest Givers",
    default = "1", type = "checkbox", config = "allquestgivers" },
  { text = "Display Current Quest Givers",
    default = "1", type = "checkbox", config = "currentquestgivers" },
  { text = "Display Low Level Quest Givers",
    default = "0", type = "checkbox", config = "showlowlevel" },
  { text = "Display Level+3 Quest Givers",
    default = "0", type = "checkbox", config = "showhighlevel" },

  { text = "Map & Minimap",
    default = nil, type = "header" },
  { text = "Enable Minimap Nodes",
    default = "1", type = "checkbox", config = "minimapnodes" },
  { text = "Focus Mode: Only Show What The Arrow Is Tracking",
    default = "1", type = "checkbox", config = "focusmode" },
  { text = "Color Map Nodes By Spawn",
    default = "0", type = "checkbox", config = "spawncolors" },
  { text = "World Map Node Transparency",
    default = "1.0", type = "text", config = "worldmaptransp" },
  { text = "Minimap Node Transparency",
    default = "1.0", type = "text", config = "minimaptransp" },
  { text = "Highlight Nodes On Mouseover",
    default = "1", type = "checkbox", config = "mouseover" },

  { text = "User Data",
    default = nil, type = "header" },
  { text = "Reset Configuration",
    default = "1", type = "button", func = reset.config },
  { text = "Reset Quest History",
    default = "1", type = "button", func = reset.history },
  { text = "Reset Everything",
    default = "1", type = "button", func = reset.everything },
}

StaticPopupDialogs["AUTOQUESTLEARNER_RESET"] = {
  button1 = YES,
  button2 = NO,
  timeout = 0,
  whileDead = 1,
  hideOnEscape = 1,
}

AutoQuestLearnerConfig = CreateFrame("Frame", "AutoQuestLearnerConfig", UIParent)
AutoQuestLearnerConfig:Hide()
AutoQuestLearnerConfig:SetWidth(280)
AutoQuestLearnerConfig:SetHeight(550)
-- BUGFIX: was anchored via "CENTER", which keeps that single center
-- point fixed during a resize -- meaning the frame grows/shrinks
-- SYMMETRICALLY in all directions, not just toward the bottom-right
-- the resize grip visually implies. That made the top-left corner (and
-- everything anchored to it, like the Guide/Route/Zone/Chain buttons)
-- visibly drift away from the panel as it resized, and made shrinking
-- back down behave unpredictably. TOPLEFT keeps that corner genuinely
-- fixed -- same approach already proven working on the tracker, which
-- resizes correctly.
AutoQuestLearnerConfig:SetPoint("TOPLEFT", UIParent, "CENTER", -140, 275)
AutoQuestLearnerConfig:SetFrameStrata("HIGH")
AutoQuestLearnerConfig:SetMovable(true)
AutoQuestLearnerConfig:EnableMouse(true)
AutoQuestLearnerConfig:SetClampedToScreen(true)
AutoQuestLearnerConfig:RegisterEvent("ADDON_LOADED")
AutoQuestLearnerConfig:SetScript("OnEvent", function()
  if arg1 == "AutoQuestLearner" then
    AutoQuestLearnerConfig:LoadConfig()
    AutoQuestLearnerConfig:CreateConfigEntries(AutoQuestLearner_defconfig)

    AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
    AutoQuestLearnerDB.history = AutoQuestLearnerDB.history or {}
    AutoQuestLearnerDB.colors = AutoQuestLearnerDB.colors or {}

    -- BUGFIX: this used to unconditionally reapply the raw saved size
    -- here, AFTER CreateConfigEntries above had already correctly
    -- restored and floored it (never smaller than the content actually
    -- needs) -- completely undoing that fix by overwriting it with the
    -- stale, unfloored value. CreateConfigEntries' own sizing logic
    -- already handles this correctly on its own; this redundant,
    -- conflicting block is removed rather than duplicating the floor
    -- logic in two places that could drift out of sync again.

    -- clear quest history on new characters
    if UnitXP("player") == 0 and UnitLevel("player") == 1 then
      AutoQuestLearnerDB.history = {}
    end
  end
end)

AutoQuestLearnerConfig:SetScript("OnMouseDown", function()
  this:StartMoving()
end)

AutoQuestLearnerConfig:SetScript("OnMouseUp", function()
  this:StopMovingOrSizing()
end)

AutoQuestLearnerConfig.vpos = 58

-- Create simple backdrop
AutoQuestLearnerConfig:SetBackdrop({
  bgFile = "Interface/Tooltips/UI-Tooltip-Background",
  edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
AutoQuestLearnerConfig:SetBackdropColor(0,0,0,0.8)
AutoQuestLearnerConfig:SetBackdropBorderColor(0.2,1,0.8,1)

table.insert(UISpecialFrames, "AutoQuestLearnerConfig")

-- detect current addon path
AutoQuestLearnerConfig.path = "Interface\\AddOns\\AutoQuestLearner"

AutoQuestLearnerConfig.title = AutoQuestLearnerConfig:CreateFontString("Status", "LOW", "GameFontNormal")
AutoQuestLearnerConfig.title:SetFontObject(GameFontWhite)
AutoQuestLearnerConfig.title:SetPoint("TOP", AutoQuestLearnerConfig, "TOP", 0, -8)
AutoQuestLearnerConfig.title:SetJustifyH("LEFT")
AutoQuestLearnerConfig.title:SetFont(STANDARD_TEXT_FONT, 14)
AutoQuestLearnerConfig.title:SetText("|cff00ff00AutoQuestLearner|r Config")

AutoQuestLearnerConfig.close = CreateFrame("Button", "AutoQuestLearnerConfigClose", AutoQuestLearnerConfig)
AutoQuestLearnerConfig.close:SetPoint("TOPRIGHT", -5, -5)
AutoQuestLearnerConfig.close:SetHeight(20)
AutoQuestLearnerConfig.close:SetWidth(20)
AutoQuestLearnerConfig.close.texture = AutoQuestLearnerConfig.close:CreateTexture("AutoQuestLearnerConfigCloseTex")
AutoQuestLearnerConfig.close.texture:SetTexture("Interface/Buttons/UI-Panel-MinimizeButton-Up")
AutoQuestLearnerConfig.close.texture:ClearAllPoints()
AutoQuestLearnerConfig.close.texture:SetPoint("TOPLEFT", AutoQuestLearnerConfig.close, "TOPLEFT", 4, -4)
AutoQuestLearnerConfig.close.texture:SetPoint("BOTTOMRIGHT", AutoQuestLearnerConfig.close, "BOTTOMRIGHT", -4, 4)

AutoQuestLearnerConfig.close:SetScript("OnClick", function()
  this:GetParent():Hide()
end)

AutoQuestLearnerConfig.guideBtn = CreateFrame("Button", "AutoQuestLearnerConfigGuideBtn", AutoQuestLearnerConfig)
AutoQuestLearnerConfig.guideBtn:SetPoint("TOPLEFT", 6, -26)
AutoQuestLearnerConfig.guideBtn:SetWidth(50)
AutoQuestLearnerConfig.guideBtn:SetHeight(18)
AutoQuestLearnerConfig.guideBtn:SetBackdrop({
  bgFile = "Interface/Tooltips/UI-Tooltip-Background",
  edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 12,
  insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
AutoQuestLearnerConfig.guideBtn:SetBackdropColor(0.2, 1, 0.8, 0.25)
AutoQuestLearnerConfig.guideBtn:SetBackdropBorderColor(0.2, 1, 0.8, 1)
AutoQuestLearnerConfig.guideBtn.text = AutoQuestLearnerConfig.guideBtn:CreateFontString(nil, "OVERLAY", "GameFontWhite")
AutoQuestLearnerConfig.guideBtn.text:SetAllPoints(AutoQuestLearnerConfig.guideBtn)
AutoQuestLearnerConfig.guideBtn.text:SetFont(STANDARD_TEXT_FONT, 10)
AutoQuestLearnerConfig.guideBtn.text:SetText("Guide")
AutoQuestLearnerConfig.guideBtn:SetScript("OnClick", function()
  if AutoQuestLearner_ShowGuide then
    AutoQuestLearner_ShowGuide()
  end
end)

-- Quick-access buttons for the route/zone/chain commands -- each just
-- calls the exact same slash command handler already tested and
-- working via /aql, so there's no separate/duplicated logic to keep in
-- sync with the command versions.
local function CreateQuickCmdButton(label, command, xOffset)
  local btn = CreateFrame("Button", nil, AutoQuestLearnerConfig)
  btn:SetPoint("TOPLEFT", AutoQuestLearnerConfig.guideBtn, "TOPLEFT", xOffset, 0)
  btn:SetWidth(50)
  btn:SetHeight(18)
  btn:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
  })
  btn:SetBackdropColor(0.2, 1, 0.8, 0.25)
  btn:SetBackdropBorderColor(0.2, 1, 0.8, 1)
  btn.text = btn:CreateFontString(nil, "OVERLAY", "GameFontWhite")
  btn.text:SetAllPoints(btn)
  btn.text:SetFont(STANDARD_TEXT_FONT, 10)
  btn.text:SetText(label)
  btn:SetScript("OnClick", function()
    if SlashCmdList and SlashCmdList["AUTOQUESTLEARNER"] then
      SlashCmdList["AUTOQUESTLEARNER"](command)
    end
  end)
  return btn
end

AutoQuestLearnerConfig.routeBtn = CreateQuickCmdButton("Route", "route", 54)
AutoQuestLearnerConfig.zoneBtn = CreateQuickCmdButton("Zone", "zone", 108)
AutoQuestLearnerConfig.chainBtn = CreateQuickCmdButton("Chain", "chain", 162)

AutoQuestLearnerConfig.save = CreateFrame("Button", "AutoQuestLearnerConfigReload", AutoQuestLearnerConfig)
AutoQuestLearnerConfig.save:SetWidth(160)
AutoQuestLearnerConfig.save:SetHeight(28)
AutoQuestLearnerConfig.save:SetPoint("BOTTOM", 0, 10)
AutoQuestLearnerConfig.save:SetScript("OnClick", ReloadUI)
AutoQuestLearnerConfig.save.text = AutoQuestLearnerConfig.save:CreateFontString("Caption", "LOW", "GameFontWhite")
AutoQuestLearnerConfig.save.text:SetAllPoints(AutoQuestLearnerConfig.save)
AutoQuestLearnerConfig.save.text:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
AutoQuestLearnerConfig.save.text:SetText("Close & Reload")

-- Style the save button
AutoQuestLearnerConfig.save:SetBackdrop({
  bgFile = "Interface/Tooltips/UI-Tooltip-Background",
  edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
  tile = true, tileSize = 16, edgeSize = 16,
  insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
AutoQuestLearnerConfig.save:SetBackdropColor(0.2,1,0.8,0.3)
AutoQuestLearnerConfig.save:SetBackdropBorderColor(0.2,1,0.8,1)

function AutoQuestLearnerConfig:LoadConfig()
  if not AutoQuestLearnerDB.config then AutoQuestLearnerDB.config = {} end
  for id, data in pairs(AutoQuestLearner_defconfig) do
    if data.config and not AutoQuestLearnerDB.config[data.config] then
      AutoQuestLearnerDB.config[data.config] = data.default
    end
  end
end

local maxh, maxw = 0, 0
local width, height = 230, 22
local maxtext = 130
local configframes = {}
function AutoQuestLearnerConfig:CreateConfigEntries(config)
  local count = 1

  for _, data in pairs(config) do
    if data.type then
      local frame = CreateFrame("Frame", "AutoQuestLearnerConfig" .. count, AutoQuestLearnerConfig)
      configframes[data.text] = frame

      frame.caption = frame:CreateFontString("Status", "LOW", "GameFontWhite")
      frame.caption:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
      frame.caption:SetPoint("LEFT", 20, 0)
      frame.caption:SetJustifyH("LEFT")
      frame.caption:SetText(data.text)
      maxtext = max(maxtext, frame.caption:GetStringWidth())

      if data.type == "header" then
        frame.caption:SetPoint("LEFT", 10, 0)
        frame.caption:SetTextColor(.3,1,.8)
        frame.caption:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")

      elseif data.type == "checkbox" then
        frame.input = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
        frame.input:SetNormalTexture("")
        frame.input:SetPushedTexture("")
        frame.input:SetHighlightTexture("")
        frame.input:SetBackdrop({
          bgFile = "Interface/Tooltips/UI-Tooltip-Background",
          edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
          tile = true, tileSize = 16, edgeSize = 16,
          insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        frame.input:SetBackdropColor(0,0,0,0.5)
        frame.input:SetBackdropBorderColor(0.5,0.5,0.5,1)

        frame.input:SetWidth(16)
        frame.input:SetHeight(16)
        frame.input:SetPoint("RIGHT" , -20, 0)

        frame.input.config = data.config
        if AutoQuestLearnerDB.config[data.config] == "1" then
          frame.input:SetChecked()
        end

        frame.input:SetScript("OnClick", function ()
          if this:GetChecked() then
            AutoQuestLearnerDB.config[this.config] = "1"
          else
            AutoQuestLearnerDB.config[this.config] = "0"
          end

          if this.config == "hideblizzardtracker" and AutoQuestLearner_UpdateBlizzardTrackerVisibility then
            AutoQuestLearner_UpdateBlizzardTrackerVisibility()
          end

          if this.config == "questitembuttons" and AutoQuestLearner_UpdateQuestItemButtons then
            AutoQuestLearner_UpdateQuestItemButtons()
          end

          if this.config == "clustersCurrentZoneOnly" and AutoQuestLearnerMap then
            AutoQuestLearnerMap:UpdateNodes()
          end

          if AutoQuestLearner and AutoQuestLearner.ResetAll then
            AutoQuestLearner:ResetAll()
          end
        end)
      elseif data.type == "cycle" then
        frame.input = CreateFrame("Button", nil, frame)
        frame.input:SetWidth(120)
        frame.input:SetHeight(18)
        frame.input:SetPoint("RIGHT", -20, 0)
        frame.input:SetBackdrop({
          bgFile = "Interface/Tooltips/UI-Tooltip-Background",
          edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
          tile = true, tileSize = 16, edgeSize = 16,
          insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        frame.input:SetBackdropColor(0,0,0,0.5)
        frame.input:SetBackdropBorderColor(0.5,0.5,0.5,1)

        frame.input.text = frame.input:CreateFontString(nil, "OVERLAY")
        frame.input.text:SetAllPoints(frame.input)
        frame.input.text:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")

        frame.input.config = data.config
        frame.input.options = data.options

        local function UpdateCycleLabel(btn)
          local current = AutoQuestLearnerDB.config[btn.config]
          for _, opt in pairs(btn.options) do
            if opt.value == current then
              btn.text:SetText(opt.label)
              return
            end
          end
          btn.text:SetText(btn.options[1].label)
        end

        if not AutoQuestLearnerDB.config[data.config] then
          AutoQuestLearnerDB.config[data.config] = data.options[1].value
        end
        UpdateCycleLabel(frame.input)

        frame.input:SetScript("OnClick", function()
          local current = AutoQuestLearnerDB.config[this.config]
          local idx = 1
          for i, opt in pairs(this.options) do
            if opt.value == current then idx = i break end
          end
          local nextIdx = (idx % table.getn(this.options)) + 1
          AutoQuestLearnerDB.config[this.config] = this.options[nextIdx].value
          UpdateCycleLabel(this)

          if AutoQuestLearner and AutoQuestLearner.ResetAll then
            AutoQuestLearner:ResetAll()
          end
        end)
      elseif data.type == "text" then
        frame.input = CreateFrame("EditBox", nil, frame)
        frame.input:SetTextColor(.2,1,.8,1)
        frame.input:SetJustifyH("RIGHT")
        frame.input:SetTextInsets(5,5,5,5)
        frame.input:SetWidth(32)
        frame.input:SetHeight(16)
        frame.input:SetPoint("RIGHT", -20, 0)
        frame.input:SetFontObject(GameFontNormal)
        frame.input:SetAutoFocus(false)
        frame.input:SetScript("OnEscapePressed", function(self)
          this:ClearFocus()
        end)

        frame.input.config = data.config
        frame.input:SetText(AutoQuestLearnerDB.config[data.config])

        frame.input:SetScript("OnTextChanged", function(self)
          AutoQuestLearnerDB.config[this.config] = this:GetText()
        end)

        frame.input:SetBackdrop({
          bgFile = "Interface/Tooltips/UI-Tooltip-Background",
          edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
          tile = true, tileSize = 16, edgeSize = 16,
          insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        frame.input:SetBackdropColor(0,0,0,0.5)
        frame.input:SetBackdropBorderColor(0.5,0.5,0.5,1)
      elseif data.type == "button" and data.func then
        frame.input = CreateFrame("Button", nil, frame)
        frame.input:SetWidth(32)
        frame.input:SetHeight(16)
        frame.input:SetPoint("RIGHT", -20, 0)
        frame.input:SetScript("OnClick", data.func)
        frame.input.text = frame.input:CreateFontString("Caption", "LOW", "GameFontWhite")
        frame.input.text:SetAllPoints(frame.input)
        frame.input.text:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
        frame.input.text:SetText("OK")

        frame.input:SetBackdrop({
          bgFile = "Interface/Tooltips/UI-Tooltip-Background",
          edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
          tile = true, tileSize = 16, edgeSize = 16,
          insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        frame.input:SetBackdropColor(0.2,1,0.8,0.3)
        frame.input:SetBackdropBorderColor(0.2,1,0.8,1)
      end

      count = count + 1
    end
  end

  width = maxtext + 100
  local column, row = 1, 0

  for _, data in pairs(config) do
    if data.type then
      row = row + ( data.type == "header" and row > 1 and 2 or 1 )
      if row > 20 and data.type == "header" then
        column, row = column + 1, 1
      end

      maxw, maxh = max(maxw, column), max(maxh, row)

      local spacer = (column-1)*20
      local x, y = (column-1)*width, -(row-1)*height
      local frame = configframes[data.text]
      frame:SetWidth(width)
      frame:SetHeight(height)
      frame:SetPoint("TOPLEFT", AutoQuestLearnerConfig, "TOPLEFT", x + spacer + 10, y - 40)
    end
  end

  local spacer = (maxw-1)*20
  local neededWidth = maxw*width + spacer + 20
  local neededHeight = maxh*height + 100

  -- Always sized to fit its own content -- simple and reliable, always
  -- exactly big enough to show everything, every time. No resize
  -- capability at all now -- that feature caused enough persistent
  -- trouble across several attempts that it was removed entirely
  -- rather than kept as a source of future bugs.
  AutoQuestLearnerConfig:SetWidth(neededWidth)
  AutoQuestLearnerConfig:SetHeight(neededHeight)
end

-- Re-applies the exact same sizing logic every time the panel is
-- actually shown, not just once at addon load -- guarantees the panel
-- is correctly sized to its content at the moment that actually
-- matters (when the user sees it), regardless of anything that may
-- have touched its size while it was hidden.
function AutoQuestLearnerConfig:ApplyFloorSize()
  local neededWidth = maxw*width + (maxw-1)*20 + 20
  local neededHeight = maxh*height + 100
  AutoQuestLearnerConfig:SetWidth(neededWidth)
  AutoQuestLearnerConfig:SetHeight(neededHeight)
end

-- Replaces the earlier OnShow binding above (SetScript overwrites the
-- previous handler for the same event) -- this one can actually reach
-- ApplyFloorSize/maxw/maxh, which aren't in scope up where the first
-- OnShow binding was defined.
AutoQuestLearnerConfig:SetScript("OnShow", function()
  this:UpdateConfigEntries()
  this:ApplyFloorSize()
end)

function AutoQuestLearnerConfig:UpdateConfigEntries()
  for _, data in pairs(AutoQuestLearner_defconfig) do
    if data.type and configframes[data.text] then
      if data.type == "checkbox" then
        configframes[data.text].input:SetChecked((AutoQuestLearnerDB.config[data.config] == "1" and true or nil))
      elseif data.type == "text" then
        configframes[data.text].input:SetText(AutoQuestLearnerDB.config[data.config])
      end
    end
  end
end

-- Slash command to open config
SLASH_AUTOQUESTLEARNERCONFIG1 = "/aqlconfig"
SlashCmdList["AUTOQUESTLEARNERCONFIG"] = function(msg)
  AutoQuestLearnerConfig:Show()
end
