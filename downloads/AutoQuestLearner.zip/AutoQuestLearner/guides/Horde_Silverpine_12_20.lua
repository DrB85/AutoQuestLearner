-- AQL Leveling Guide stub: Horde Silverpine 12-20
AutoQuestLearner_RegisterGuide([[
[N 12-20 Silverpine Forest]
[GA Horde]
[D Continues after Tirisfal. Stub — expand with full quest list over time.]
[NX 20-25 Hillsbrad Foothills]

[N] Enter Silverpine from Tirisfal (south-west of Brill).
[G 45.0,21.0 Silverpine Forest]
[QA 428]
[G 44.0,20.0 Silverpine Forest]
[QT 428]
[QA 429]
[G 50.0,13.0 Silverpine Forest]
[QC 429]
[G 44.0,20.0 Silverpine Forest]
[QT 429]
[N] Work The Sepulcher hub quests; expand this file as you level.
[G 43.0,41.0 Silverpine Forest]
[N] End of Silverpine 12-20 stub.
]])
