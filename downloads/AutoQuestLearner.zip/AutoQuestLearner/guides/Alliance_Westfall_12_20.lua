-- AQL Leveling Guide stub: Alliance Westfall 12-20
AutoQuestLearner_RegisterGuide([[
[N 12-20 Westfall]
[GA Alliance]
[D Continues after Elwynn. Stub — expand with full quest list over time.]
[NX 20-25 Redridge Mountains]

[N] Enter Westfall from Elwynn (west road).
[G 60.0,19.0 Westfall]
[QA 36]
[G 56.0,31.0 Westfall]
[QT 36]
[QA 9]
[G 50.0,20.0 Westfall]
[QC 9]
[G 56.0,31.0 Westfall]
[QT 9]
[N] Sentinel Hill hub — expand this file as you level.
[G 56.3,47.5 Westfall]
[N] End of Westfall 12-20 stub.
]])
