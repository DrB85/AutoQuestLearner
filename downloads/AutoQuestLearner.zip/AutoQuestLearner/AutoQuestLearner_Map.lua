-- AutoQuestLearner Map Module
-- Rebranded from pfQuest map.lua

local nodename = "AutoQuestMiniMapPin"

local validmaps = setmetatable({},{__mode="kv"})
local rgbcache = setmetatable({},{__mode="kv"})
local _minimapSizesMerged = false
local HARD_MINIMAP_SIZES = {
  [0]={17464.04,11642.72},
  [1]={4925.0,3283.34},
  [3]={2487.5,1658.34},
  [4]={3350.0,2233.3},
  [8]={2293.75,1529.17},
  [10]={2700.003,1800.03},
  [11]={4135.417,2756.25},
  [12]={3470.84,2314.62},
  [14]={5287.5,3525.0},
  [15]={5250.0,3500.0},
  [16]={5070.84,3381.25},
  [17]={10133.34,6756.25},
  [28]={4299.997,2866.67},
  [33]={6381.25,4254.1},
  [36]={2800.003,1866.667},
  [38]={2758.33,1839.58},
  [40]={3500.003,2333.3},
  [41]={2499.997,1666.63},
  [44]={2170.84,1447.9},
  [45]={3600.003,2399.997},
  [46]={2929.163,1952.08},
  [47]={3850.0,2566.67},
  [51]={2231.253,1487.5},
  [85]={4518.75,3012.5},
  [130]={4200.0,2800.0},
  [139]={3870.83,2581.25},
  [141]={5091.66,3393.7},
  [148]={6550.0,4366.66},
  [215]={5137.5,3425.003},
  [267]={3200.0,2133.33},
  [331]={5766.67,3843.753},
  [357]={6950.0,4633.33},
  [361]={5750.0,3833.33},
  [400]={4399.997,2933.33},
  [405]={4495.83,2997.913},
  [406]={4883.33,3256.253},
  [440]={6900.0,4600.0},
  [490]={3700.003,2466.66},
  [493]={2308.33,1539.59},
  [618]={7100.003,4733.33},
  [1377]={3483.334,2322.92},
  [1497]={959.3754,640.11},
  [1519]={1344.2694,896.36},
  [1537]={790.629,527.61},
  [1637]={1402.61,935.42},
  [1638]={1043.75,695.83},
  [1657]={1058.33,705.71},
  [2597]={4237.5,2825.0},
  [3277]={1145.837,764.58},
  [3358]={1756.247,1170.83},
  [3430]={4925.0,3283.37},
  [3433]={3300.0,2200.0},
  [3483]={5164.58,3443.75},
  [3487]={1211.46,806.76},
  [3518]={5524.97,3683.3367},
  [3519]={5400.0,3600.0},
  [3520]={5500.0,3666.66},
  [3521]={5027.08,3352.09},
  [3522]={5425.0,3616.663},
  [3523]={5574.9967,3716.67},
  [3524]={4070.8,2714.58},
  [3525]={3262.5,2174.997},
  [3557]={1056.7,704.69},
  [3703]={1306.25,870.84},
  [3820]={2270.837,1514.58},
  [4080]={3327.09,2218.7}
}

local function GetMinimapSizes()
  -- Full zone yard table for EVERY zone: HARD is complete pfDB minimap
  -- (Vanilla + TBC). DB values override when present (calibrated).
  if not HARD_MINIMAP_SIZES then
    return (AutoQuestLearnerDB and AutoQuestLearnerDB.minimap) or {}
  end
  local db = AutoQuestLearnerDB and AutoQuestLearnerDB.minimap
  if not db then
    return HARD_MINIMAP_SIZES
  end
  if not _minimapSizesMerged then
    for id, dims in pairs(HARD_MINIMAP_SIZES) do
      if db[id] == nil and db[tostring(id)] == nil then
        db[id] = dims
      end
    end
    _minimapSizesMerged = true
  end
  return db
end

local unifiedcache = {}
local similar_nodes = {}

local function IsEmpty(tabl)
  for k,v in pairs(tabl) do
    return false
  end
  return true
end

local layers = {
  ["Interface\\AddOns\\AutoQuestLearner\\img\\available"]          = 1,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\available_c"]        = 2,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\complete"]           = 3,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\complete_c"]         = 4,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\icon_vendor"]        = 5,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\fav"]                = 6,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_item"]       = 9,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_mob"]        = 9,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_misc"]       = 9,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_mob_mono"]   = 9,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_item_mono"]  = 9,
  ["Interface\\AddOns\\AutoQuestLearner\\img\\cluster_misc_mono"]  = 9,
}

local function GetLayerByTexture(tex)
  if layers[tex] then return layers[tex] else return 1 end
end

-- Classic WotLK minimap zoom yards (from pfQuest). GetViewRadius() is not
-- reliable on this client; wrong scale puts every pin outside the minimap
-- circle so clusters look "missing".
-- pfQuest map.lua (github.com/shagu/pfQuest) — verified online.
-- [0]=outdoor [1]=indoor. Values are minimap view size in yards used with
-- xDraw = MinimapWidth / (mapZoom/mapWidth) / 100
local minimap_zoom = {
  [0] = { [0] = 300, [1] = 240, [2] = 180, [3] = 120, [4] = 80, [5] = 50 },
  [1] = { [0] = 466 + 2/3, [1] = 400, [2] = 333 + 1/3, [3] = 266 + 2/6, [4] = 200, [5] = 133 + 1/3 },
}


local function minimap_indoor()
  local state = 1
  if GetCVar and GetCVar("minimapZoom") == GetCVar("minimapInsideZoom") then
    if (tonumber(GetCVar("minimapInsideZoom")) or 0) >= 3 then
      state = 0
    end
  else
    local z = Minimap and Minimap:GetZoom() or 0
    if GetCVar and (tonumber(GetCVar("minimapInsideZoom")) or 0) == z then
      state = 0
    end
  end
  return state
end

-- math.mod does not exist on this client (only math.fmod, and even
-- that isn't guaranteed across all client builds) -- use a manual
-- modulo instead.
local function mod(a, b)
  return a - math.floor(a / b) * b
end

-- A small, curated set of visually distinct colors instead of hashing
-- into the full 16.7-million-color RGB space -- with many quests
-- active at once, that produced clusters in near-arbitrary, often
-- similar-looking shades that were hard to tell apart at a glance.
-- Same title/spawn text always maps to the same color as before (the
-- hash below just picks a PALETTE INDEX now instead of a raw RGB
-- value), so a given NPC's color stays consistent across sessions.
local COLOR_PALETTE = {
  { 0.64, 0.14, 0.14 }, -- dark red
  { 0.14, 0.51, 0.14 }, -- dark green
  { 0.20, 0.33, 0.64 }, -- dark blue
  { 0.48, 0.36, 0.01 }, -- dark gold
  { 0.64, 0.36, 0.08 }, -- dark orange
  { 0.01, 0.36, 0.36 }, -- dark teal
  { 0.58, 0.16, 0.38 }, -- dark pink
}

local function str2rgb(text)
  if not text then return 1, 1, 1 end
  if AutoQuestLearnerDB.colors and AutoQuestLearnerDB.colors[text] then 
    return unpack(AutoQuestLearnerDB.colors[text]) 
  end
  if rgbcache[text] then return unpack(rgbcache[text]) end
  local counter = 1
  local l = string.len(text)
  for i = 1, l, 3 do
    counter = mod(counter*8161, 4294967279) +
        (string.byte(text,i)*16776193) +
        ((string.byte(text,i+1) or (l-i+256))*8372226) +
        ((string.byte(text,i+2) or (l-i+256))*3932164)
  end
  local hash = mod(mod(counter, 4294967291),16777216)
  local paletteIndex = mod(hash, table.getn(COLOR_PALETTE)) + 1
  rgbcache[text] = COLOR_PALETTE[paletteIndex]
  return unpack(rgbcache[text])
end

local fpsmod, step
local function NodeAnimate(self, zoom, alpha, fps)
  localcur_zoom = self:GetWidth()
  local cur_alpha = self:GetAlpha()
  local change = nil
  self:EnableMouse(true)
  fpsmod = math.min(2/fps, 2)
  step = fpsmod/10

  if math.abs(cur_zoom - zoom) < 3 then
    self:SetWidth(zoom)
    self:SetHeight(zoom)
  elseif cur_zoom < zoom then
    self:SetWidth(cur_zoom + fpsmod)
    self:SetHeight(cur_zoom + fpsmod)
    change = true
  elseif cur_zoom > zoom then
    self:SetWidth(cur_zoom - fpsmod)
    self:SetHeight(cur_zoom - fpsmod)
    change = true
  end

  if math.abs(cur_alpha - alpha) < step then
    self:SetAlpha(alpha)
    if alpha < .1 then
      self:EnableMouse(nil)
    end
  elseif cur_alpha < alpha then
    self:SetAlpha(cur_alpha + step)
    change = true
  elseif cur_alpha > alpha then
    self:SetAlpha(cur_alpha - step)
    change = true
  end

  return change
end

AutoQuestLearnerMap = CreateFrame("Frame", "AutoQuestLearnerMap", WorldFrame)
AutoQuestLearnerMap.str2rgb = str2rgb
AutoQuestLearnerMap.tooltips = {}
AutoQuestLearnerMap.nodes = {}
AutoQuestLearnerMap.pins = {}
-- Pool of small dot textures used to trace a dotted polygon outline
-- around an objective spawn area (see DrawSpawnAreaOutline below) --
-- same pooling pattern as AutoQuestLearnerMap.pins above, reused
-- across redraws instead of creating/destroying textures every time.
AutoQuestLearnerMap.outlineDots = {}
-- Separate pool for the shaded FILL tiles (see DrawSpawnAreaFill) --
-- kept apart from outlineDots above since fill tiles use a different
-- texture, layer, and size than the edge dots, and pooling them
-- together would mean reconfiguring every property on every reuse
-- instead of just position/color.
AutoQuestLearnerMap.outlineFillDots = {}
AutoQuestLearnerMap.mpins = {}
AutoQuestLearnerMap.drawlayer = Minimap
AutoQuestLearnerMap.unifiedcache = unifiedcache

function AutoQuestLearnerMap:GetMinimapSizes()
  return GetMinimapSizes()
end

AutoQuestLearnerMap.tooltip = CreateFrame("Frame" , "AutoQuestLearnerMapTooltip", GameTooltip)
AutoQuestLearnerMap.tooltip:SetScript("OnShow", function()
  local focus = GetMouseFocus()
  if focus and focus.title then return end
  if AutoQuestLearnerDB.config.showtooltips == "0" then return end

  local name = getglobal("GameTooltipTextLeft1") and getglobal("GameTooltipTextLeft1"):GetText() or "__NONE__"
  local zone = AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())

  name = string.gsub(name, "|c%x%x%x%x%x%x%x%x", "")
  name = string.gsub(name, "|r", "")

  -- Intentionally do NOT merge every quest that shares this spawn name.
  -- That caused unrelated quest titles (e.g. Orgrimmar delivery text) to
  -- appear on minimap bag/sword nodes for different objectives.
  -- Pin-specific tooltips are handled entirely in NodeEnter.
end)

function AutoQuestLearnerMap:HasMinimap()
  return true
end

function AutoQuestLearnerMap.tooltip:GetColor(min, max)
  local max = max or 1
  local min = min or max or 1

  local perc = min / max
  local r1, g1, b1, r2, g2, b2
  if perc <= 0.5 then
    perc = perc * 2
    r1, g1, b1 = 1, 0, 0
    r2, g2, b2 = 1, 1, 0
  else
    perc = perc * 2 - 1
    r1, g1, b1 = 1, 1, 0
    r2, g2, b2 = 0, 1, 0
  end
  r = r1 + (r2 - r1)*perc
  g = g1 + (g2 - g1)*perc
  b = b1 + (b2 - b1)*perc

  return r, g, b
end

function AutoQuestLearnerMap:ShowTooltip(meta, tooltip)
  local tooltip = tooltip or GameTooltip
  if not meta then return end

  -- Prefer explicit quest title on the node; fall back to legacy "quest" field.
  local questTitle = meta["title"] or meta["quest"]
  local questID = meta["questid"]

  if questTitle then
    local matchedLog = false
    for qid = 1, GetNumQuestLogEntries() do
      local qtitle, _, _, _, _, complete = AutoQuestLearner_GetQuestLogTitle(qid)
      local logQuestID = nil
      if AutoQuestLearner_GetQuestIDFromLogIndex then
        logQuestID = AutoQuestLearner_GetQuestIDFromLogIndex(qid)
      end
      local titleMatch = qtitle and (qtitle == questTitle)
      local idMatch = questID and logQuestID and (tonumber(logQuestID) == tonumber(questID))
      if titleMatch or idMatch then
        matchedLog = true
        local objectives = GetNumQuestLeaderBoards(qid)
        local symbol = (complete or objectives == 0) and "|cff555555[|cffffcc00?|cff555555]|r " or "|cff555555[|cffffcc00!|cff555555]|r "
        tooltip:AddLine(symbol .. qtitle, 1, 1, 0)
        if objectives and objectives > 0 then
          for i = 1, objectives do
            local text, _, finished = GetQuestLogLeaderBoard(i, qid)
            if text then
              local color = finished and "|cff555555" or "|cffaaaaaa"
              tooltip:AddLine(color .. "- |r" .. text, 1, 1, 1)
            end
          end
        end
        break
      end
    end
    if not matchedLog then
      tooltip:AddLine("|cff555555[|cffffcc00!|cff555555]|r " .. questTitle, 1, 1, .7)
    end
  end

  -- Objective / spawn label (only for THIS pin)
  if meta["spawn"] and meta["spawn"] ~= questTitle then
    tooltip:AddLine(meta["spawn"], .3, 1, .8)
  end

  tooltip:Show()
end

-- Reverse-lookup: given a zone NAME, find its numeric ID in pfDB's own
-- zone-ID scheme (the AutoQuestLearnerData.zones["loc"][id] = "Name"
-- table). This is the missing piece that makes GetMapID() actually
-- useful -- see the comment on GetMapID below.
local mapNameToID = {}
local mapNameToIDBuilt = false
local function GetMapIDByName(search)
  if not search then return nil end

  if not mapNameToIDBuilt and AutoQuestLearnerData and AutoQuestLearnerData.zones
      and AutoQuestLearnerData.zones["loc"] then
    for id, name in pairs(AutoQuestLearnerData.zones["loc"]) do
      mapNameToID[name] = id
    end
    -- Only mark as built once zone data actually exists -- if the
    -- database hasn't finished loading yet, we want to retry instead
    -- of permanently caching an empty table.
    if next(mapNameToID) then
      mapNameToIDBuilt = true
    end
  end

  return mapNameToID[search]
end

-- A handful of special-case zones (like Alterac Valley) that don't
-- resolve cleanly through the name lookup above, keyed by whatever
-- GetMapInfo() reports while standing in them.
local customMapIDs = {
  ["AlteracValley"] = 2597,
}

-- Starting-zone alias: translates a dedicated starting sub-zone's own
-- ID to the parent continent zone ID the bundled database actually
-- uses for NPCs physically located there. Every faction's starting
-- area has its own independently-zoomable world map (unlike
-- Northshire, which is rendered as part of Elwynn Forest's map and
-- needs no translation), but the bundled coordinate data tags NPCs in
-- these specific sub-zones with the PARENT zone instead -- verified
-- directly against real named NPCs: Durnan Furcutter (Coldridge
-- Valley) tagged zone 1/Dun Morogh instead of 132; Zureetha Fargaze
-- and Kaltunk (Valley of Trials) tagged 14/Durotar instead of 363;
-- Baine Bloodhoof and Grull Hawkwind (Camp Narache) tagged 215/Mulgore
-- instead of 221; Chief Hawkwind, Seer Graytongue, and Greatmother
-- Hawkwind (Red Cloud Mesa) tagged 215/Mulgore instead of 220.
-- Independently cross-checked against a third-party WoW Classic quest
-- dataset's own sub-area/zone field pairings, which confirmed every
-- one of these (plus caught Red Cloud Mesa, which the first pass
-- missed) and confirmed Northshire genuinely needs no alias. Without
-- this, every coordinate lookup for any of these zones -- the arrow,
-- map nodes, minimap, available quest givers -- silently matched
-- nothing the entire time a fresh character is in their starting zone.
local STARTING_ZONE_ALIASES = {
  [132] = 1,   -- Coldridge Valley -> Dun Morogh
  [363] = 14,  -- Valley of Trials -> Durotar
  [221] = 215, -- Camp Narache -> Mulgore
  [220] = 215, -- Red Cloud Mesa -> Mulgore
  [188] = 141, -- Shadowglen -> Teldrassil
  [154] = 85,  -- Deathknell -> Tirisfal Glades
}

function AutoQuestLearnerMap:GetMapID(cid, mid, skipAlias)
  cid = cid or GetCurrentMapContinent()
  mid = mid or GetCurrentMapZone()

  local list = { GetMapZones(cid) }
  local name = list[mid]

  -- IMPORTANT: this must return the SAME numeric ID space that pfDB's
  -- coordinate data uses (e.g. coord[3] in units/objects coords, and
  -- quests[id].start/end/obj entries once resolved to a spawn). A
  -- previous version of this function returned the raw zone-NAME
  -- string instead, which meant it could never match anything stored
  -- via the database-driven node paths (SearchQuestID, SearchQuests),
  -- and (after an earlier fix routed learned locations through this
  -- same function) the auto-learned nodes too -- nothing in either
  -- path was ever being looked up under the key it was stored under.
  local id = GetMapIDByName(name)
  if not id and type(GetMapInfo) == "function" then
    id = customMapIDs[GetMapInfo()]
  end

  -- Standalone fallback: without pfQuest, AutoQuestLearnerData.zones.loc
  -- is empty, so GetMapIDByName() can never resolve anything, and this
  -- would otherwise return nil for every zone -- which would silently
  -- reject every node the addon tries to draw via AddNode() (it
  -- requires meta["zone"] to be truthy), including everything from the
  -- addon's own independent learning system, which has nothing to do
  -- with pfDB at all. Rather than depend on pfDB's translation table,
  -- fall back to a simple key built directly from Blizzard's own
  -- continent/zone-index pair -- always available, no external data
  -- needed. This key space won't match pfDB's own numeric IDs, but
  -- that's fine: database-driven nodes only exist when pfDB is present
  -- anyway, in which case the real translated ID above is used
  -- instead, and storage/lookup stay consistent either way since both
  -- always go through this same function.
  if not id then
    id = "C" .. tostring(cid) .. "Z" .. tostring(mid)
  end

  -- Starting-zone alias: see the STARTING_ZONE_ALIASES table above.
  -- skipAlias returns the raw sub-zone ID instead -- needed for
  -- minimap calibration (see AutoQuestLearner_CalibrateMinimapZone),
  -- which needs to know it's SPECIFICALLY in e.g. Shadowglen (188) to
  -- calibrate that sub-area's own local scale, not "somewhere in the
  -- much larger parent zone Teldrassil (141)" that the alias collapses
  -- it to for every other purpose (quest/NPC coordinate lookup, which
  -- genuinely does need the parent ID since that's how the bundled
  -- data is tagged).
  if not skipAlias then
    id = STARTING_ZONE_ALIASES[id] or id
  end

  return id
end

function AutoQuestLearnerMap:AddNode(meta)
  if not meta then return end
  if not meta["zone"] then return end
  if not meta["title"] then return end

  local addon = meta["addon"] or "AUTOQLDB"
  local map = meta["zone"]
  local coords = meta["x"] .. "|" .. meta["y"]
  local title = meta["title"]
  local layer = GetLayerByTexture(meta["texture"])
  local spawn = meta["spawn"]
  local item = meta["item"]

  local sindex = string.format("%s:%s:%s:%s:%s:%s",
    (addon or ""), (map or ""), (coords or ""), (title or ""), (layer or ""), (spawn or ""), (item or ""))

  if layer >= 9 and meta["priority"] then
    layer = layer + (10 - min(meta["priority"], 10))
  end

  if not AutoQuestLearnerMap.nodes[addon] then AutoQuestLearnerMap.nodes[addon] = {} end
  if not AutoQuestLearnerMap.nodes[addon][map] then AutoQuestLearnerMap.nodes[addon][map] = {} end
  if not AutoQuestLearnerMap.nodes[addon][map][coords] then AutoQuestLearnerMap.nodes[addon][map][coords] = {} end

  if AutoQuestLearnerMap.nodes[addon][map][coords][title] then
    if AutoQuestLearnerMap.nodes[addon][map][coords][title].layer and layer and
     AutoQuestLearnerMap.nodes[addon][map][coords][title].layer >= layer then
      return
    end
  end

  if not similar_nodes[sindex] then
    similar_nodes[sindex] = {}
    for key, val in pairs(meta) do similar_nodes[sindex][key] = val end
    similar_nodes[sindex].item = { [1] = item }
  end

  AutoQuestLearnerMap.nodes[addon][map][coords][title] = similar_nodes[sindex]

  if spawn and title then
    AutoQuestLearnerMap.tooltips[spawn] = AutoQuestLearnerMap.tooltips[spawn] or {}
    AutoQuestLearnerMap.tooltips[spawn][title] = AutoQuestLearnerMap.tooltips[spawn][title] or {}
    AutoQuestLearnerMap.tooltips[spawn][title][map] = AutoQuestLearnerMap.tooltips[spawn][title][map] or similar_nodes[sindex]
  end
  -- Minimap rebuild is throttled on a timer; do not force every AddNode
end

function AutoQuestLearnerMap:DeleteNode(addon, title)
  if not addon then
    AutoQuestLearnerMap.tooltips = {}
  else
    for mk, mv in pairs(AutoQuestLearnerMap.tooltips) do
      for tk, tv in pairs(mv) do
        if ( title and tk == title ) or ( not title and tv.addon == addon ) then
          AutoQuestLearnerMap.tooltips[mk][tk] = nil
        end
      end
    end
  end

  if not addon then
    AutoQuestLearnerMap.nodes = {}
  elseif not title then
    AutoQuestLearnerMap.nodes[addon] = {}
  elseif AutoQuestLearnerMap.nodes[addon] then
    for map, foo in pairs(AutoQuestLearnerMap.nodes[addon]) do
      for coords, node in pairs(AutoQuestLearnerMap.nodes[addon][map]) do
        if AutoQuestLearnerMap.nodes[addon][map][coords][title] then
          AutoQuestLearnerMap.nodes[addon][map][coords][title] = nil
          if IsEmpty(AutoQuestLearnerMap.nodes[addon][map][coords]) then
            AutoQuestLearnerMap.nodes[addon][map][coords] = nil
          end
        end
      end
    end
  end
end

-- Removes every node under `addon` whose stored questid matches,
-- regardless of the title string it was drawn under. Title-string
-- matching (the plain DeleteNode above) can miss nodes when the same
-- quest got drawn under more than one title spelling -- e.g. the
-- bundled database's title, the live quest-log title, and a
-- gossip/quest-dialog title aren't always byte-identical -- which is
-- how a quest's nodes could survive being removed from the log and
-- linger on the map/minimap indefinitely. Call this alongside (not
-- instead of) DeleteNode() for a belt-and-suspenders cleanup whenever
-- a quest is fully done with (turned in or abandoned).
-- BUGFIX: previously matched ONLY by tab.questid == questID, the same
-- fragility already found and fixed in DeleteObjectiveNodes below (see
-- its comment) -- the questID resolved at deletion time doesn't always
-- match the form it was tagged with when the node was created (numeric
-- vs. title-string, depending on GetQuestIDs/GetQuestLink timing). This
-- is the function that actually runs when a quest is turned in or
-- abandoned, so that mismatch is exactly what let completed quests'
-- clusters -- objective clouds included, this function doesn't
-- distinguish node types -- linger on the map indefinitely instead of
-- clearing. Now also accepts an optional questTitle and matches on
-- that as a fallback, same as DeleteObjectiveNodes already does.
-- Marks the ONE known spawn point closest to (x, y) on mapID, among
-- nodes carrying the given highlightKey (the same per-target identity
-- already used for coloring/hover-grouping -- for a static per-NPC
-- objective node this is just that NPC's unit ID as a string, which is
-- exactly what a kill event gives us), as temporarily hidden for
-- `duration` seconds. Used so a spawn cluster's dot for the specific
-- mob you just killed disappears until it would plausibly have
-- respawned, instead of the whole cluster staying static regardless of
-- what's actually alive right now. Approximate by necessity: this
-- client has no way to know the killed mob's exact death location (see
-- the UnitPosition unavailability noted elsewhere), only the player's
-- own position, so "closest known point to where I'm standing" is the
-- best available proxy for "which point was this". Returns true if a
-- node was found and hidden.
-- Query counterpart to HideNearestNode: is there a currently-hidden
-- node at this exact spot with this highlightKey? Exposed so the
-- arrow's own target selection (AutoQuestLearner.lua, a completely
-- separate candidate-gathering system that reads raw spawn data
-- directly rather than the map's node cache) can skip a point that
-- was just killed instead of continuing to point at it -- confirmed
-- real gap: hiding a node only ever affected what the MAP drew, the
-- arrow had no way to know and could keep aiming at a cleared spot
-- indefinitely.
function AutoQuestLearnerMap:IsHidden(mapID, x, y, highlightKey)
  if not mapID or not x or not y or not highlightKey then return false end
  local bucket = AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"] and AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"][mapID]
  if not bucket then return false end
  local coords = x .. "|" .. y
  local titles = bucket[coords]
  if not titles then return false end
  for title, tab in pairs(titles) do
    if tab.highlightKey == highlightKey and tab.hiddenUntil and GetTime() < tab.hiddenUntil then
      return true
    end
  end
  return false
end

function AutoQuestLearnerMap:HideNearestNode(mapID, x, y, highlightKey, duration)
  if not mapID or not x or not y or not highlightKey then return false end
  local bucket = AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"] and AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"][mapID]
  if not bucket then return false end

  local bestTab, bestDist = nil, nil
  for coords, titles in pairs(bucket) do
    for title, tab in pairs(titles) do
      -- Personally-learned objective pins must stay visible on map/minimap;
      -- only hide static database cluster dots for the kill/respawn timer.
      if tab.isLearned then
        -- skip
      elseif tab.highlightKey == highlightKey and not (tab.hiddenUntil and GetTime() < tab.hiddenUntil) then
        local _, _, cx, cy = strfind(coords, "(.*)|(.*)")
        cx, cy = tonumber(cx), tonumber(cy)
        if cx and cy then
          local dx, dy = cx - x, cy - y
          local dist = dx * dx + dy * dy
          if not bestDist or dist < bestDist then
            bestDist = dist
            bestTab = tab
          end
        end
      end
    end
  end

  if bestTab then
    -- Learn the real respawn interval for this NPC, when possible.
    -- bestTab.lastHiddenAt (set below, persists on this session-local
    -- node object across repeated hides) is only present if THIS EXACT
    -- spot was hidden before and has since become visible again --
    -- meaning it respawned and got killed again. The elapsed time
    -- between those two events is a genuine observed respawn interval,
    -- not just "time since any kill of this NPC type" (which would be
    -- wildly wrong while actively farming several spawns of the same
    -- creature back to back -- confirmed this distinction matters,
    -- since consecutive kills of DIFFERENT points of the same NPC type
    -- can be seconds apart while the real respawn is minutes).
    local npcID = tonumber(highlightKey)
    local now = GetTime()
    if npcID and bestTab.lastHiddenAt then
        local interval = now - bestTab.lastHiddenAt
        -- Sanity range: under 10s is almost certainly noise (a
        -- double-trigger, or the same kill's PARTY_KILL and UNIT_DIED
        -- both landing on this call), over 1 hour is more likely a
        -- reload/alt-tab/logout gap than a real respawn timer -- reject
        -- both rather than let outliers skew the running average.
        if interval >= 10 and interval <= 3600 then
            AutoQuestLearnerDB.respawnTimers = AutoQuestLearnerDB.respawnTimers or {}
            local rt = AutoQuestLearnerDB.respawnTimers[npcID]
            if not rt then
                AutoQuestLearnerDB.respawnTimers[npcID] = { avg = interval, samples = 1 }
            else
                -- Simple running average for the first several samples,
                -- then switch to exponential smoothing so it stays
                -- responsive to the server's actual respawn rate
                -- changing (event modifiers, etc.) instead of getting
                -- stuck on a long-run average that can no longer move.
                if rt.samples < 10 then
                    rt.avg = (rt.avg * rt.samples + interval) / (rt.samples + 1)
                    rt.samples = rt.samples + 1
                else
                    rt.avg = rt.avg * 0.8 + interval * 0.2
                end
            end
        end
    end
    bestTab.lastHiddenAt = now

    -- Three-tier duration preference: personally-learned (most
    -- accurate, reflects THIS server's actual behavior) beats a real
    -- vanilla-sourced per-NPC default (better than a flat guess, but
    -- vanilla data can differ from whatever Ascension customized)
    -- beats the flat generic guess (used only when neither exists).
    local effectiveDuration = duration
    if npcID and AutoQuestLearnerVanillaRespawnDefaults and AutoQuestLearnerVanillaRespawnDefaults[npcID] then
        effectiveDuration = AutoQuestLearnerVanillaRespawnDefaults[npcID]
    end
    if npcID and AutoQuestLearnerDB.respawnTimers and AutoQuestLearnerDB.respawnTimers[npcID] then
        effectiveDuration = AutoQuestLearnerDB.respawnTimers[npcID].avg
    end

    bestTab.hiddenUntil = now + effectiveDuration
    AutoQuestLearnerMap:UpdateNodes()
    -- BUGFIX: UpdateNodes() only refreshes the world map -- the
    -- minimap has its own entirely separate update function that
    -- doesn't get triggered by it at all, so a killed NPC's dot could
    -- sit visible on the minimap well after correctly vanishing from
    -- the world map.
    if AutoQuestLearnerMap.UpdateMinimap then
        AutoQuestLearnerMap:UpdateMinimap()
    end
    if AutoQuestLearner_KillDebug then
        local learnedNote
        if npcID and AutoQuestLearnerDB.respawnTimers and AutoQuestLearnerDB.respawnTimers[npcID] then
            learnedNote = string.format(" (learned, %d sample%s)", AutoQuestLearnerDB.respawnTimers[npcID].samples,
                AutoQuestLearnerDB.respawnTimers[npcID].samples == 1 and "" or "s")
        elseif npcID and AutoQuestLearnerVanillaRespawnDefaults and AutoQuestLearnerVanillaRespawnDefaults[npcID] then
            learnedNote = " (real vanilla-server default, not yet personally observed)"
        else
            learnedNote = " (flat generic guess, no data at all)"
        end
        print(string.format("|cff00ff00AutoQuestLearner:|r [kill debug] hid a node matching key '%s' on mapID %s until %.0fs from now%s.",
            tostring(highlightKey), tostring(mapID), effectiveDuration, learnedNote))
    end
    return true
  end
  if AutoQuestLearner_KillDebug then
      print(string.format("|cffff8800AutoQuestLearner:|r [kill debug] no matching visible node found for key '%s' on mapID %s.",
          tostring(highlightKey), tostring(mapID)))
  end
  return false
end

function AutoQuestLearnerMap:DeleteNodeByQuestID(addon, questID, questTitle)
  if not addon or not questID then return end
  if not AutoQuestLearnerMap.nodes[addon] then return end

  for map, _ in pairs(AutoQuestLearnerMap.nodes[addon]) do
    for coords, node in pairs(AutoQuestLearnerMap.nodes[addon][map]) do
      for title, tab in pairs(node) do
        if tab.questid == questID or (questTitle and title == questTitle) then
          node[title] = nil
        end
      end
      if IsEmpty(AutoQuestLearnerMap.nodes[addon][map][coords]) then
        AutoQuestLearnerMap.nodes[addon][map][coords] = nil
      end
    end
  end

  for spawn, titles in pairs(AutoQuestLearnerMap.tooltips) do
    for title, tv in pairs(titles) do
      if tv.questid == questID or (questTitle and title == questTitle) then
        AutoQuestLearnerMap.tooltips[spawn][title] = nil
      end
    end
  end
end

-- Removes only the objective ("cloud of dots") nodes for a quest,
-- leaving its start/turn-in markers alone. Nodes are matched via the
-- isObjective flag set when they were created (see DrawObjectiveNode /
-- SearchQuestID in the other files). Intended to be called once a
-- quest's objectives are fully done (ready for turn-in) or once the
-- quest is removed from the log entirely -- objective spawn clouds are
-- only useful while you're actively working on that objective.
--
-- BUGFIX: matched ONLY by tab.questid == questID, which silently failed
-- whenever the questID resolved at deletion time (via GetQuestIDs, which
-- can return either a numeric ID or a raw title string depending on
-- GetQuestLink's timing-dependent availability -- see the alias-lookup
-- notes in AutoQuestLearner.lua) didn't match whichever form was
-- resolved when the node was originally created. A 100%-complete quest
-- could sit there with its objective clusters never clearing, because
-- the delete call was silently searching for the wrong key with no
-- error. Now also accepts an optional questTitle and matches on that as
-- a fallback -- the node's OUTER key already IS the quest's title
-- string, which is far more stable than the resolved ID.
-- zoneID is optional -- when given, only searches that one zone's
-- nodes instead of every zone this addon has ever registered a node
-- for. A quest's active objective nodes are overwhelmingly likely to
-- be in the player's current zone (that's where they're actively
-- killing/looting), so scoping to it turns this from an unbounded
-- scan of the whole node table into a scan of just the relevant slice
-- -- meaningful given how large that table can get with this addon's
-- own expanded bundled coordinate database.
function AutoQuestLearnerMap:DeleteObjectiveNodes(addon, questID, questTitle, zoneID)
  if not addon or not questID then return end
  if not AutoQuestLearnerMap.nodes[addon] then return end

  local function purgeZone(map)
    for coords, node in pairs(AutoQuestLearnerMap.nodes[addon][map]) do
      for title, tab in pairs(node) do
        -- Only remove this quest's objective nodes. Prefer questid;
        -- title match alone used to risk wiping unrelated pins when
        -- titles collided or questid was a stringified title.
        local sameQuest = (tab.questid and tab.questid == questID)
          or (questTitle and title == questTitle and tab.questid == nil)
        if tab.isObjective and sameQuest then
          node[title] = nil
        end
      end
      if IsEmpty(AutoQuestLearnerMap.nodes[addon][map][coords]) then
        AutoQuestLearnerMap.nodes[addon][map][coords] = nil
      end
    end
  end

  if zoneID and AutoQuestLearnerMap.nodes[addon][zoneID] then
    purgeZone(zoneID)
  elseif not zoneID then
    for map, _ in pairs(AutoQuestLearnerMap.nodes[addon]) do
      purgeZone(map)
    end
  end
end

-- Removes only the objective nodes for ONE specific sub-objective within
-- a quest (matched by name, since the bundled/live objective data
-- doesn't preserve a direct link from a specific leaderboard line to
-- the exact NPC/object/item-source ID it corresponds to) -- leaving any
-- OTHER still-incomplete sub-objectives' nodes untouched. Matching is a
-- case-insensitive substring check in both directions between the
-- node's resolved name (e.g. "Prairie Wolf") and the leaderboard's
-- objective text (e.g. "Prairie Wolf Heart: 1/1", already stripped to
-- "Prairie Wolf Heart" by the caller) -- covers the common case where a
-- quest item's name is built from the creature's name. Deliberately
-- does nothing (no false cull) when no match is found, rather than
-- guessing and risking removing a node a different, still-incomplete
-- objective still needs.
function AutoQuestLearnerMap:DeleteObjectiveNodesByName(addon, questID, nameHint, questTitle)
  if not addon or not questID or not nameHint or nameHint == "" then return end
  if not AutoQuestLearnerMap.nodes[addon] then return end

  local needle = strlower(nameHint)
  -- Ignore tiny needles ("a", "of", "loot") -- they substring-match almost
  -- every spawn label and wiped unrelated clusters on the minimap.
  if string.len(needle) < 4 then return end

  for map, _ in pairs(AutoQuestLearnerMap.nodes[addon]) do
    for coords, node in pairs(AutoQuestLearnerMap.nodes[addon][map]) do
      for title, tab in pairs(node) do
        -- Prefer questid match. Title-only match is a last resort and only
        -- when questid is missing/non-numeric (legacy nodes).
        local sameQuest = (tab.questid and tab.questid == questID)
          or (not tab.questid and questTitle and title == questTitle)
        if tab.isObjective and tab.spawn and sameQuest then
          local spawnLower = strlower(tab.spawn)
          if strfind(needle, spawnLower, 1, true) or strfind(spawnLower, needle, 1, true) then
            node[title] = nil
          end
        end
      end
      if IsEmpty(AutoQuestLearnerMap.nodes[addon][map][coords]) then
        AutoQuestLearnerMap.nodes[addon][map][coords] = nil
      end
    end
  end
end

function AutoQuestLearnerMap:NodeClick()
  if IsShiftKeyDown() then
    -- Objective clusters: hide THIS static source only (NPC/object id),
    -- not every pin for the whole quest. Persists account-wide until
    -- /aql unhide.
    if this.isObjective and this.questid and this.highlightKey then
      AutoQuestLearnerDB.hiddenStaticSources = AutoQuestLearnerDB.hiddenStaticSources or {}
      local key = tostring(this.questid) .. ":" .. tostring(this.highlightKey)
      AutoQuestLearnerDB.hiddenStaticSources[key] = true
      if AutoQuestLearnerMap.DeleteNodesByHighlightKey then
        AutoQuestLearnerMap:DeleteNodesByHighlightKey("AUTOQUESTLEARNER", this.questid, this.highlightKey)
      end
      AutoQuestLearnerMap:UpdateNodes()
      if AutoQuestLearnerMap.UpdateMinimap then AutoQuestLearnerMap:UpdateMinimap() end
      local label = this.spawn or this.highlightKey
      print("|cff00ff00AutoQuestLearner:|r Hid static source |cffffcc00" .. tostring(label) ..
        "|r for this quest. Use |cffffcc00/aql unhide|r to restore all hidden sources.")
      return
    end

    if this.questid and this.texture and this.layer < 5 then
      AutoQuestLearnerDB.history = AutoQuestLearnerDB.history or {}
      AutoQuestLearnerDB.history[this.questid] = { time(), UnitLevel("player") }
    end

    if this.node and this.title and this.node[this.title] then
      AutoQuestLearnerMap:DeleteNode(this.node[this.title].addon, this.title)
    end
  else
    if AutoQuestLearnerDB.colors then
      AutoQuestLearnerDB.colors[this.color] = { str2rgb(this.color .. GetTime()) }
    end
  end
end

-- Remove objective nodes matching questid + highlightKey (one NPC/object source).
function AutoQuestLearnerMap:DeleteNodesByHighlightKey(addon, questID, highlightKey)
  if not addon or not questID or not highlightKey then return end
  if not AutoQuestLearnerMap.nodes[addon] then return end
  local keyStr = tostring(highlightKey)
  for map, _ in pairs(AutoQuestLearnerMap.nodes[addon]) do
    for coords, node in pairs(AutoQuestLearnerMap.nodes[addon][map]) do
      for title, tab in pairs(node) do
        if tab.isObjective and tab.questid == questID and tab.highlightKey and tostring(tab.highlightKey) == keyStr then
          node[title] = nil
        end
      end
      if IsEmpty(AutoQuestLearnerMap.nodes[addon][map][coords]) then
        AutoQuestLearnerMap.nodes[addon][map][coords] = nil
      end
    end
  end
end

function AutoQuestLearnerMap:NodeEnter()
  -- Defensive guard: 'this' should always be one of our own pin frames
  -- here (this only fires as a genuine mouseover OnEnter on one), but a
  -- known class of WoW addon interaction can occasionally invoke frame
  -- scripts with the shared global 'this' pointing at something else
  -- entirely -- observed in practice as 'this' being GameTooltip itself,
  -- which crashes GameTooltip:SetOwner(GameTooltip, ...) with "Can't set
  -- owner to self". this.node is only ever set on our own pin frames
  -- (see BuildNode/UpdateNode), so its absence is a reliable signal this
  -- wasn't actually a real pin mouseover.
  if not this or not this.node or this == GameTooltip or this == WorldMapTooltip then
    return
  end

  local tooltip = this:GetParent() == WorldMapButton and WorldMapTooltip or GameTooltip
  tooltip:SetOwner(this, "ANCHOR_LEFT")
  this.spawn = this.spawn or "Unknown"

  -- ONLY this pin's quest/meta. Iterating all titles at the same
  -- coordinates mixed unrelated quests into one tooltip (e.g. a Feralas
  -- bag node showing an Orgrimmar delivery quest that also had a pin
  -- registered under a shared spawn label).
  local meta = nil
  if this.node and this.title and this.node[this.title] then
    meta = this.node[this.title]
  elseif this.node then
    -- fallback: first entry only
    for _, m in pairs(this.node) do meta = m break end
  end

  -- Header = this pin's objective/NPC/object label only
  tooltip:SetText(this.spawn, .3, 1, .8)
  if meta then
    AutoQuestLearnerMap:ShowTooltip(meta, tooltip)
  end

  if AutoQuestLearnerDB.config.mouseover == "1" then
    if this.isObjective then
      tooltip:AddLine("Shift-Click: hide this NPC/object source for the quest", .6, .6, .6)
      tooltip:AddLine("/aql unhide restores hidden sources", .5, .5, .5)
    else
      tooltip:AddLine("Use <Shift>-Click To Remove Nodes", .6, .6, .6)
    end
    tooltip:Show()
  end

  AutoQuestLearnerMap.highlight = AutoQuestLearnerDB.config.mouseover == "1" and (this.highlightMatchKey or this.title)

  -- Cross-highlight the matching tracker line, so hovering a specific
  -- colored cluster shows exactly which objective it belongs to
  -- without having to read/guess from the map alone. this.spawn is
  -- the objective's label text (e.g. "Prairie Wolf"), already set
  -- above for the tooltip -- reused here rather than needing a new
  -- field.
  if this.isObjective and this.questid and AutoQuestLearner_HighlightTrackerObjective then
    AutoQuestLearner_HighlightTrackerObjective(this.questid, this.spawn)
  end
end

function AutoQuestLearnerMap:NodeLeave()
  if not this or not this.GetParent then
    GameTooltip:Hide()
    if AutoQuestLearner_ClearTrackerHighlight then AutoQuestLearner_ClearTrackerHighlight() end
    return
  end
  local tooltip = this:GetParent() == WorldMapButton and WorldMapTooltip or GameTooltip
  tooltip:Hide()
  AutoQuestLearnerMap.highlight = nil
  if AutoQuestLearner_ClearTrackerHighlight then AutoQuestLearner_ClearTrackerHighlight() end
end

function AutoQuestLearnerMap:BuildNode(name, parent)
  local f = CreateFrame("Button", name, parent)

  if parent == WorldMapButton then
    f.defalpha = tonumber(AutoQuestLearnerDB.config.worldmaptransp) or 1
    f.defsize = 16
  else
    f.defalpha = tonumber(AutoQuestLearnerDB.config.minimaptransp) or 1
    f.defsize = 16
    f.minimap = true
  end

  f:SetWidth(f.defsize)
  f:SetHeight(f.defsize)

  f.Animate = NodeAnimate
  f:SetScript("OnEnter", AutoQuestLearnerMap.NodeEnter)
  f:SetScript("OnLeave", AutoQuestLearnerMap.NodeLeave)

  f.tex = f:CreateTexture(nil, "BACKGROUND")
  f.tex:SetAllPoints(f)

  f.hl = f:CreateTexture(nil, "BORDER")
  f.hl:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\track")
  f.hl:SetPoint("TOPLEFT", f, "TOPLEFT", -5, 5)
  f.hl:SetWidth(12)
  f.hl:SetHeight(12)
  -- BUGFIX: this was never hidden, so every single node on the map got
  -- a permanent white pushpin badge in its top-left corner, regardless
  -- of mouseover state -- it's supposed to be a highlight indicator
  -- shown only for the currently-moused-over node (see the `highlight`
  -- check in UpdateNode below, which previously computed the flag but
  -- never actually used it to show/hide this texture).
  f.hl:Hide()

  -- Count badge for merged/clustered spawn points -- see
  -- AutoQuestLearnerMap:ClusterNodePositions. Only shown when several
  -- nearby spawns get merged into one marker (SetText/:Show() called
  -- from the drawing loop, never automatically).
  f.countBadge = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.countBadge:SetPoint("CENTER", f, "CENTER", 0, 0)
  f.countBadge:SetTextColor(1, 1, 1, 1)
  f.countBadge:Hide()

  return f
end

AutoQuestLearnerMap.highlightdb = {}
function AutoQuestLearnerMap:UpdateNode(frame, node, color, obj)
  if AutoQuestLearnerMap.highlightdb[frame] then
    for k,v in pairs(AutoQuestLearnerMap.highlightdb[frame]) do
      AutoQuestLearnerMap.highlightdb[frame][k] = nil
    end
  else
    AutoQuestLearnerMap.highlightdb[frame] = {}
  end

  frame.layer = 0
  local claimedThisPass = false

  for title, tab in pairs(node) do
    -- Temporarily hidden (this specific spawn point's NPC was just
    -- killed -- see HideNearestNode/AutoQuestLearner's kill-tracking
    -- below). Skip entirely: don't count toward highlight grouping,
    -- don't let it become the frame's displayed spawn. Once hiddenUntil
    -- passes, this naturally starts counting again on the very next
    -- refresh -- no separate timer/callback needed to "bring it back".
    if tab.hiddenUntil and GetTime() < tab.hiddenUntil then
      -- skip this entry
    else

    -- BUGFIX: hover-highlighting previously grouped purely by `title`,
    -- which is the QUEST name -- shared by every objective cluster on
    -- that quest regardless of which specific NPC/object each one
    -- actually is. Confirmed real: a two-objective quest ("Poison
    -- Water") with two differently-colored spawn clusters highlighted
    -- BOTH clusters no matter which one was actually moused over. When
    -- a node carries a highlightKey (see DrawObjectiveNode in the main
    -- addon file), fold it into the grouping key so only nodes sharing
    -- the SAME specific target group together; nodes without one
    -- (quest giver/turn-in candidates, which SHOULD still group by
    -- quest as before) fall back to the plain title, unchanged.
    local groupKey = tab.highlightKey and (title .. "\1" .. tostring(tab.highlightKey)) or title
    AutoQuestLearnerMap.highlightdb[frame][groupKey] = true

    tab.layer = GetLayerByTexture(tab.texture)

    if tab.cluster and tab.priority then
      tab.layer = tab.layer + (10 - min(tab.priority , 10))
    end

    if tab.spawn and ( tab.layer > frame.layer or not frame.spawn ) then
      claimedThisPass = true
      frame.updateTexture = (frame.texture ~= tab.texture)
      frame.updateVertex = (frame.vertex ~= tab.vertex )
      frame.updateColor = (frame.color ~= tab.color)
      frame.updateLayer = (frame.layer ~= tab.layer)

      frame.layer       = tab.layer
      frame.spawn       = tab.spawn
      frame.spawnid     = tab.spawnid
      frame.spawntype   = tab.spawntype
      frame.respawn     = tab.respawn
      frame.level       = tab.level
      frame.questid     = tab.questid
      frame.isObjective = tab.isObjective
      frame.texture     = tab.texture
      frame.vertex      = tab.vertex
      frame.title       = title
      -- Deliberately NOT frame.title -- frame.title is also used by
      -- the shift-click "remove this node" feature to look up
      -- this.node[this.title], which is keyed by the plain title only.
      -- Changing frame.title itself here would silently break that
      -- lookup for every objective node.
      frame.highlightMatchKey = groupKey
      frame.func        = tab.func
      frame.cluster     = tab.cluster
      frame.description = tab.description
      frame.priority    = tab.priority
      frame.quest       = tab.quest
      frame.qlvl        = tab.qlvl
      frame.itemreq     = tab.itemreq
      frame.arrow       = tab.arrow

      if AutoQuestLearnerDB.config.spawncolors == "1" then
        frame.color = tab.spawn or tab.title
      else
        frame.color = tab.title
      end
    end
    end
  end

  if not claimedThisPass then
    -- Every tab for this node is currently hidden (killed, respawn
    -- pending) -- without this, the frame would just keep showing
    -- whatever it last successfully rendered, since nothing below here
    -- resets frame.spawn/texture on its own.
    frame.spawn = nil
    frame.texture = nil
    frame:Hide()
    return
  end

  if frame.texture then
    if frame.updateTexture or not frame.tex:GetTexture() then
      frame.tex:SetTexture(frame.texture)
      if not frame.tex:GetTexture() or frame.tex:GetTexture() == "" then
        frame.tex:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\node_ring")
      end
    end
    if frame.vertex and frame.vertex[1] then
      frame.tex:SetVertexColor(frame.vertex[1], frame.vertex[2] or 1, frame.vertex[3] or 1, 1)
    elseif frame.color then
      local r,g,b = str2rgb(frame.color)
      frame.tex:SetVertexColor(r, g, b, 1)
    else
      frame.tex:SetVertexColor(0.3, 0.85, 0.4, 1)
    end
  elseif frame.color then
    local r,g,b = str2rgb(frame.color)
    frame.tex:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\node_ring")
    frame.tex:SetVertexColor(r,g,b,1)
  end

  if frame.updateLayer then
    frame:SetFrameLevel((obj == "minimap" and 4 or 112) + frame.layer)
  end

  if frame.updateTexture or frame.updateVertex or frame.updateColor or frame.updateLayer then
    frame:SetScript("OnClick", (frame.func or AutoQuestLearnerMap.NodeClick))
  end

  local highlight = frame.texture and AutoQuestLearnerMap.highlightdb[frame][AutoQuestLearnerMap.highlight] and true or nil

  -- Reduced from 22 -- with rings (as opposed to the old solid dots),
  -- a dense cluster of many overlapping nodes got visually crowded at
  -- the larger size.
  -- Minimap gets its own, smaller cluster size -- the same absolute
  -- pixel size takes up proportionally more space on the much smaller
  -- minimap circle than it does on the full world map.
  -- Clusters were 3px (invisible on minimap). Use readable sizes.
  if frame.cluster or frame.layer == 4 or (frame.layer and frame.layer >= 9) then
    -- Cluster badges: readable on minimap and world map
    frame.defsize = frame.minimap and 14 or 12
  else
    -- Spawn dots: larger on minimap so they match world-map visibility
    frame.defsize = frame.minimap and 12 or 10
  end

  if not highlight then
    frame:SetWidth(frame.defsize)
    frame:SetHeight(frame.defsize)
  end

  if highlight then
    frame.hl:Show()
  else
    frame.hl:Hide()
  end

  frame.node = node
end

-- Groups a flat list of {x=, y=, ...} items into clusters by screen
-- proximity (simple greedy clustering: each item joins the nearest
-- existing group within mergeRadius pixels, or starts a new one).
-- Returns a list of { x=, y=, items={...} } groups, where x/y is the
-- group's running-average centroid. Used to merge many overlapping
-- spawn points into a single marker with a count badge, rather than
-- drawing dozens of individually-tiny, fully-overlapping rings.
function AutoQuestLearnerMap:ClusterNodePositions(items, mergeRadius)
    local groups = {}
    for _, item in ipairs(items) do
        -- Minimap path stores map-% as mx/my; world map stores pixel x/y.
        local ix = item.x or item.mx
        local iy = item.y or item.my
        if not ix or not iy then
            -- skip malformed entries rather than error
        else
        local matched = nil
        local bestDist = nil
        if mergeRadius and mergeRadius > 0 then
          for _, g in ipairs(groups) do
            if g.groupKey == item.groupKey then
                local dx = ix - g.seedX
                local dy = iy - g.seedY
                local dist = math.sqrt(dx * dx + dy * dy)
                if dist <= mergeRadius and (not bestDist or dist < bestDist) then
                    matched = g
                    bestDist = dist
                end
            end
          end
        end
        if matched then
            table.insert(matched.items, item)
            local n = table.getn(matched.items)
            matched.x = matched.x + (ix - matched.x) / n
            matched.y = matched.y + (iy - matched.y) / n
        else
            table.insert(groups, { x = ix, y = iy, seedX = ix, seedY = iy, groupKey = item.groupKey, items = { item } })
        end
        end
    end
    return groups
end

-- FEATURE (per user request): outline mode for objective spawn areas.
-- Rather than a cloud of individual/clustered dots for a quest
-- objective's kill/loot spawn points, this traces a dotted polygon
-- around the outer boundary of those points instead -- giving a "the
-- mobs spawn somewhere in this area" outline rather than a pile of
-- overlapping markers. Quest giver/turn-in NPCs are NOT affected by
-- this at all -- they keep the existing single-marker/cluster pin
-- behavior unconditionally, since a boundary outline doesn't make
-- sense for a single fixed NPC. World map only: the minimap is a
-- small circular viewport with hard edge-clipping, and a polygon
-- outline traced against that circular boundary would be both a lot
-- more complex to get right and barely legible at that size -- the
-- minimap keeps its existing dot-cluster rendering unconditionally.
--
-- Standard Andrew's monotone chain convex hull. `points` is an array
-- of {x=, y=} in WorldMapButton pixel space (same space `items` in
-- UpdateNodes already computes). Mutates/sorts `points` in place (its
-- caller already treats it as scratch data, same as the rest of this
-- codebase's clustering pass). Returns the hull vertices in
-- counter-clockwise order, or the input unchanged if there are fewer
-- than 3 unique points (not enough to form a real polygon).
--
-- Hardening:
-- 1. Exact/near-duplicate points (same spawn learned many times, or
--    floating-point jitter under ~1.5 px) are collapsed before the
--    scan -- duplicates create zero-length edges and can make the
--    collinear check discard real vertices, leaving a degenerate hull
--    that silently falls back to pins even when the visual area is fine.
-- 2. Guard against empty lower/upper after endpoint removal (all
--    remaining points collinear) so we never return a 0- or 1-vertex
--    "hull" that the outline drawer treats as valid.
local function ConvexHull(points)
    local n = table.getn(points)
    if n < 3 then return points end

    table.sort(points, function(a, b)
        if a.x == b.x then return a.y < b.y end
        return a.x < b.x
    end)

    -- Collapse exact and near-duplicates after sort (adjacent only).
    local DEDUPE_EPS = 1.5
    local unique = { points[1] }
    for i = 2, n do
        local prev = unique[table.getn(unique)]
        local p = points[i]
        local dx = p.x - prev.x
        local dy = p.y - prev.y
        if (dx * dx + dy * dy) > (DEDUPE_EPS * DEDUPE_EPS) then
            table.insert(unique, p)
        end
    end
    points = unique
    n = table.getn(points)
    if n < 3 then return points end

    local function cross(o, a, b)
        return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)
    end

    local lower = {}
    for i = 1, n do
        while table.getn(lower) >= 2 and cross(lower[table.getn(lower) - 1], lower[table.getn(lower)], points[i]) <= 0 do
            table.remove(lower)
        end
        table.insert(lower, points[i])
    end

    local upper = {}
    for i = n, 1, -1 do
        while table.getn(upper) >= 2 and cross(upper[table.getn(upper) - 1], upper[table.getn(upper)], points[i]) <= 0 do
            table.remove(upper)
        end
        table.insert(upper, points[i])
    end

    -- Endpoints are shared between lower and upper; drop one copy each.
    -- If everything was collinear, a chain may only have 2 points and
    -- removing the shared end leaves a single vertex -- treat that as
    -- "no real polygon" so the caller falls back to normal pins.
    if table.getn(lower) < 2 or table.getn(upper) < 2 then
        return points
    end
    table.remove(lower)
    table.remove(upper)

    local hull = {}
    for _, p in ipairs(lower) do table.insert(hull, p) end
    for _, p in ipairs(upper) do table.insert(hull, p) end
    if table.getn(hull) < 3 then return points end
    return hull
end

-- Traces `hull` (a closed polygon, already in WorldMapButton pixel
-- space) as a dotted EDGE, appending textures into the shared
-- AutoQuestLearnerMap.outlineDots pool starting at index `startIndex`.
-- Drawn on top of DrawSpawnAreaFill's shaded interior (below) to give
-- the shape a defined boundary. Uses the same small textured-dot
-- approach as DrawRouteLine (proven to work on this client already)
-- rather than a rotated solid-line texture -- avoids depending on
-- Texture:SetRotation behaving consistently across every WotLK 3.3.5a
-- client build.
-- Returns the new pool index after this hull's dots, and whether it
-- actually drew anything -- a hull can legitimately come back with
-- fewer than 3 vertices even from a group with 3+ real points, if
-- those points happen to be collinear (e.g. mobs patrolling in a
-- straight line); the caller needs to know so it can fall back to
-- normal pin rendering for that group instead of silently drawing
-- nothing.
local function DrawSpawnAreaOutline(startIndex, hull, r, g, b)
    local hullSize = table.getn(hull)
    if hullSize < 3 then return startIndex, false end

    local index = startIndex
    for i = 1, hullSize do
        local p1 = hull[i]
        local p2 = hull[(i % hullSize) + 1]
        local dx, dy = p2.x - p1.x, p2.y - p1.y
        local segLen = math.sqrt(dx * dx + dy * dy)
        -- ~6px dot spacing -- tighter than the route line's 8px (that
        -- one covers open ground between two far-apart points; this is
        -- tracing a boundary, where a crisper line reads better).
        local totalDots = max(2, ceil(segLen / 6))
        for j = 0, totalDots - 1 do
            local t = j / totalDots
            local xpos = p1.x + dx * t
            local ypos = p1.y + dy * t

            index = index + 1
            local tex = AutoQuestLearnerMap.outlineDots[index]
            if not tex then
                tex = WorldMapButton:CreateTexture(nil, "OVERLAY")
                tex:SetWidth(3)
                tex:SetHeight(3)
                tex:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\route")
                AutoQuestLearnerMap.outlineDots[index] = tex
            end
            tex:SetVertexColor(r, g, b, 1)
            tex:ClearAllPoints()
            tex:SetPoint("CENTER", WorldMapButton, "TOPLEFT", xpos, -ypos)
            tex:Show()
        end
    end
    return index, true
end

-- Standard ray-casting point-in-polygon test. `poly` is a closed
-- polygon (array of {x=, y=}, same winding either direction works).
-- Used by DrawSpawnAreaFill below to decide which grid samples fall
-- inside the hull.
local function PointInPolygon(px, py, poly)
    local inside = false
    local n = table.getn(poly)
    local j = n
    for i = 1, n do
        local xi, yi = poly[i].x, poly[i].y
        local xj, yj = poly[j].x, poly[j].y
        if ((yi > py) ~= (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi) + xi) then
            inside = not inside
        end
        j = i
    end
    return inside
end

-- Fills the interior of `hull` (closed polygon, WorldMapButton pixel
-- space) with a grid of small semi-transparent tinted squares, giving
-- a genuinely shaded area rather than just an outline -- matching
-- pfQuest/Questie's own "zone highlight" look. WoW's UI has no native
-- arbitrary-polygon fill primitive on this client, so this rasterizes
-- the hull instead: sample a grid across its bounding box, keep only
-- the samples that land inside the polygon (PointInPolygon above), and
-- draw a small tile at each one, sized to slightly overlap its
-- neighbors so the grid reads as one continuous wash of color rather
-- than a lattice of visible gaps. Interface\Buttons\WHITE8X8 is
-- Blizzard's own plain white 1x1-effective texture, the standard tool
-- every WoW addon uses for solid-color fills -- responds cleanly to
-- SetVertexColor tinting with no baked-in shape of its own.
-- Grid spacing is chosen adaptively so total sample count stays
-- bounded regardless of how large the hull's bounding box is (a hull
-- spanning half the map shouldn't cost 100x what a small one does).
-- Drawn on the BACKGROUND layer, same parent (WorldMapButton) as
-- everything else here -- child textures render above their parent's
-- own map art regardless of layer, and BACKGROUND specifically means
-- this sits below the OVERLAY-layer edge dots and pins, matching the
-- reference look (pins clearly visible on top of the shaded area, not
-- buried under it).
local function DrawSpawnAreaFill(startIndex, hull, r, g, b)
    local hullSize = table.getn(hull)
    if hullSize < 3 then return startIndex end

    local minX, maxX, minY, maxY = hull[1].x, hull[1].x, hull[1].y, hull[1].y
    for _, p in ipairs(hull) do
        if p.x < minX then minX = p.x end
        if p.x > maxX then maxX = p.x end
        if p.y < minY then minY = p.y end
        if p.y > maxY then maxY = p.y end
    end

    local boxW, boxH = maxX - minX, maxY - minY
    if boxW <= 0 or boxH <= 0 then return startIndex end

    local MAX_FILL_SAMPLES = 400
    local spacing = math.sqrt((boxW * boxH) / MAX_FILL_SAMPLES)
    if spacing < 8 then spacing = 8 end

    local index = startIndex
    local y = minY + spacing / 2
    while y < maxY do
        local x = minX + spacing / 2
        while x < maxX do
            if PointInPolygon(x, y, hull) then
                index = index + 1
                local tex = AutoQuestLearnerMap.outlineFillDots[index]
                if not tex then
                    tex = WorldMapButton:CreateTexture(nil, "BACKGROUND")
                    tex:SetTexture("Interface\\Buttons\\WHITE8X8")
                    AutoQuestLearnerMap.outlineFillDots[index] = tex
                end
                -- +2px so adjacent tiles overlap slightly rather than
                -- leaving hairline gaps between them.
                tex:SetWidth(spacing + 2)
                tex:SetHeight(spacing + 2)
                tex:SetVertexColor(r, g, b, 0.28)
                tex:ClearAllPoints()
                tex:SetPoint("CENTER", WorldMapButton, "TOPLEFT", x, -y)
                tex:Show()
            end
            x = x + spacing
        end
        y = y + spacing
    end
    return index
end

local _updateNodesLast = 0
local _updateNodesQueued = false
-- ONE shared defer frame — never CreateFrame per throttle (memory leak).
local _updateNodesDeferFrame = CreateFrame("Frame")
_updateNodesDeferFrame:Hide()
_updateNodesDeferFrame:SetScript("OnUpdate", function(self, elapsed)
  self._t = (self._t or 0) + (elapsed or 0)
  if self._t < 1.0 then return end
  self._t = 0
  self:Hide()
  _updateNodesQueued = false
  _updateNodesLast = GetTime and GetTime() or 0
  if AutoQuestLearnerMap and AutoQuestLearnerMap.UpdateNodes then
    AutoQuestLearnerMap:UpdateNodes()
  end
end)

function AutoQuestLearnerMap:UpdateNodes()
  -- Throttle hard: full world-map rebuild freezes the client for a beat
  -- when stacked on kill/loot/accept/turn-in. Coalesce to ≤1 rebuild/sec.
  local now = GetTime and GetTime() or 0
  local MIN_GAP = 1.0
  if (now - _updateNodesLast) < MIN_GAP then
    if not _updateNodesQueued then
      _updateNodesQueued = true
      _updateNodesDeferFrame._t = 0
      _updateNodesDeferFrame:Show()
    end
    return
  end
  _updateNodesLast = now
  _updateNodesQueued = false
  _updateNodesDeferFrame:Hide()
  if AutoQuestLearner_FlickerDebug and AutoQuestLearner_FlickerDebug.active then
    local c = AutoQuestLearner_FlickerDebug.counts
    c["Map_UpdateNodes"] = (c["Map_UpdateNodes"] or 0) + 1
    -- Capture which specific call site triggered this -- there are 18
    -- different places in this addon that can call UpdateNodes(), and
    -- guessing among them one at a time hasn't worked, so let the
    -- debugger identify the actual source directly.
    local ok, stack = pcall(debugstack, 2, 3, 0)
    if ok and stack then
      local clean = string.gsub(stack, "Interface\\AddOns\\AutoQuestLearner\\", "")
      clean = string.gsub(clean, "\n", " <- ")
      clean = string.gsub(clean, "%s+", " ")
      if string.len(clean) > 150 then
        clean = string.sub(clean, 1, 150)
      end
      local key = "UpdateNodes_caller: " .. clean
      c[key] = (c[key] or 0) + 1
    else
      c["UpdateNodes_caller_UNAVAILABLE"] = (c["UpdateNodes_caller_UNAVAILABLE"] or 0) + 1
    end
  end
  local color = AutoQuestLearnerDB.config.spawncolors == "1" and "spawn" or "title"
  local map = AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
  local i = 1

  if AutoQuestLearner.tracker then
    AutoQuestLearner.tracker.Reset()
  end

  -- STRICT focus: only the quest the arrow is tracking right now.
  -- When the arrow switches, old spawns depop and the new quest's populate.
  -- (Config still allows turning this off to show everything.)
  local focusModeEnabled = (not AutoQuestLearnerDB.config) or AutoQuestLearnerDB.config.focusmode ~= "0"
  local focusQuestID = AutoQuestLearner_GetTrackedQuestID and AutoQuestLearner_GetTrackedQuestID()
  local focusTitle = nil
  if focusQuestID and AutoQuestLearner.questlog then
    local e = AutoQuestLearner.questlog[focusQuestID] or AutoQuestLearner.questlog[tonumber(focusQuestID)]
    if e then focusTitle = e.title end
  end
  if not focusTitle and type(focusQuestID) == "string" then
    focusTitle = focusQuestID
  end

  -- "Only Show Clusters in My Current Zone"
  local hideAllForThisZone = AutoQuestLearnerDB.config.clustersCurrentZoneOnly == "1"
      and AutoQuestLearner_LastKnownPlayerZone
      and map ~= AutoQuestLearner_LastKnownPlayerZone
      and tostring(map) ~= tostring(AutoQuestLearner_LastKnownPlayerZone)
      and tonumber(map) ~= tonumber(AutoQuestLearner_LastKnownPlayerZone)

  local function nodeMatchesFocus(node)
    if not focusQuestID or not node then return false end
    local fq = tonumber(focusQuestID) or focusQuestID
    local fqStr = tostring(focusQuestID)
    for title, entry in pairs(node) do
      local qid = entry and entry.questid
      local nqid = tonumber(qid)
      if qid == focusQuestID or nqid == fq or tostring(qid) == fqStr or qid == fq then
        return true
      end
      if focusTitle and (title == focusTitle or (entry and entry.title == focusTitle)
          or (entry and entry.quest == focusTitle)) then
        return true
      end
    end
    return false
  end

  -- Pass 1: collect every node that should be shown.
  -- Dual-key map lookup (number vs string) — nodes often stored under
  -- numeric pfDB ids while GetMapID returns a different type.
  local items = {}
  local function worldZoneBuckets(data)
    local buckets, seen = {}, {}
    if not data then return buckets end
    local function add(key)
      if key == nil then return end
      local z = data[key]
      if z and not seen[z] then seen[z] = true; table.insert(buckets, z) end
    end
    add(map)
    add(tonumber(map))
    add(tostring(map))
    return buckets
  end
  for addon, data in pairs(AutoQuestLearnerMap.nodes) do
    if not hideAllForThisZone then
    for _, zoneData in ipairs(worldZoneBuckets(data)) do
      for coords, node in pairs(zoneData) do
        local showThis = true
        if focusModeEnabled then
          -- Only the arrow-tracked quest. No target → no clusters.
          showThis = focusQuestID and nodeMatchesFocus(node) or false
        end

        -- A node whose only tab(s) are all currently hidden (recently
        -- killed, respawn pending -- see HideNearestNode) needs to be
        -- excluded HERE, before clustering, not just at render time --
        -- clustering only looks at group.items[1]'s node table to
        -- decide what a merged pin shows, so a hidden point left in
        -- the item list could either wrongly blank out an otherwise-
        -- visible cluster (if it happened to land as item 1) or get
        -- silently absorbed with no visible effect (if it didn't).
        -- Filtering here instead means every cluster's centroid/count
        -- badge naturally reflects only the currently-visible subset.
        if showThis then
            local anyVisible = false
            for _, tab in pairs(node) do
                if not (tab.hiddenUntil and GetTime() < tab.hiddenUntil) then
                    anyVisible = true
                    break
                end
            end
            if not anyVisible then
                showThis = false
            end
        end

        if showThis then
          local _, _, xPct, yPct = strfind(coords, "(.*)|(.*)")
          local x = xPct / 100 * WorldMapButton:GetWidth()
          local y = yPct / 100 * WorldMapButton:GetHeight()
          -- Same key UpdateNode uses to pick a color (tab.spawn, the
          -- NPC/target name, falling back to the title) -- clustering
          -- is scoped to this so two different creature types never
          -- get merged into one marker just because they're close,
          -- which would silently hide one of their colors.
          local groupKey = nil
          local isObjective, highlightKey, objectiveSourceType, questid = nil, nil, nil, nil
          for title, tab in pairs(node) do
            groupKey = tab.spawn or title
            isObjective = tab.isObjective
            highlightKey = tab.highlightKey
            objectiveSourceType = tab.objectiveSourceType
            questid = tab.questid
            break
          end
          table.insert(items, { node = node, x = x, y = y, groupKey = groupKey, isObjective = isObjective, highlightKey = highlightKey, objectiveSourceType = objectiveSourceType, questid = questid })
        end
      end -- coords
    end -- zoneData buckets
    end -- not hideAllForThisZone
  end -- addon

  -- FEATURE (per user request): "Outline Spawn Areas" -- instead of a
  -- cluster of dots/pins for a quest objective's kill/loot spawn
  -- points, shade the outer boundary of those points as a filled area
  -- instead (matching pfQuest/Questie's own "zone highlight" look).
  -- Quest giver/turn-in NPCs are deliberately excluded from this
  -- entirely and always keep the normal single-marker/cluster-pin
  -- behavior below -- a shaded area doesn't mean anything for a single
  -- fixed NPC. Off by default; Ctrl still reveals every individual
  -- point (bypassing the fill, same established convention as the
  -- merge-radius override above) since a shaded area alone can't show
  -- exactly where each point is.
  --
  -- BUGFIX/FEATURE (per user report): restricted to ONLY the quest the
  -- arrow is currently tracking (AutoQuestLearner_GetTrackedQuestID(),
  -- this addon's own definition of "the quest you're working on right
  -- now" -- auto-selected by the arrow's normal priority logic, or
  -- whichever quest is manually pinned via Alt+Right-Click). Every
  -- other quest's objectives keep the normal pin/cluster look
  -- regardless of this setting -- a shaded area is a much heavier,
  -- more attention-grabbing visual than a small dot, so showing one for
  -- every quest with objectives in the current zone at once would be
  -- far more cluttered than the dot clusters it's meant to replace,
  -- not less. If nothing is currently tracked, nothing gets shaded at
  -- all -- every objective just falls back to its normal pin/cluster
  -- rendering below, same as if this setting were off.
  local outlineSpawnAreas = AutoQuestLearnerDB.config.spawnAreaOutline == "1"
      and not (IsControlKeyDown and IsControlKeyDown())

  local pinItems = items
  local outlineDotsUsed, outlineFillUsed = 0, 0
  if outlineSpawnAreas then
    pinItems = {}
    local objectiveGroups = {}
    for _, item in ipairs(items) do
      -- Shaded "quest area" for mob hunt objectives in the log (not
      -- fixed object nodes). Restored for all log quests — not only
      -- the arrow target — so the area does not vanish when the arrow
      -- switches to a giver/available quest.
      local qid = item.questid and (tonumber(item.questid) or item.questid)
      local inLog = qid and AutoQuestLearner.questlog and (
          AutoQuestLearner.questlog[qid] or AutoQuestLearner.questlog[item.questid])
      if item.isObjective and item.objectiveSourceType ~= "object" and (inLog or not AutoQuestLearner.questlog) then
        local key = tostring(qid or item.questid or "?") .. ":" .. tostring(item.highlightKey or item.groupKey or "?")
        objectiveGroups[key] = objectiveGroups[key] or {}
        table.insert(objectiveGroups[key], item)
      else
        table.insert(pinItems, item)
      end
    end

    for key, group in pairs(objectiveGroups) do
      if table.getn(group) >= 3 then
        local hullPoints = {}
        for _, item in ipairs(group) do
          table.insert(hullPoints, { x = item.x, y = item.y })
        end
        local hull = ConvexHull(hullPoints)
        local r, g, b = str2rgb(tostring(key))
        local newEdgeIndex, drew = DrawSpawnAreaOutline(outlineDotsUsed, hull, r, g, b)
        if drew then
          outlineDotsUsed = newEdgeIndex
          outlineFillUsed = DrawSpawnAreaFill(outlineFillUsed, hull, r, g, b)
        else
          -- Degenerate hull (points came back collinear, e.g. a
          -- straight patrol line) -- fall back to normal pin
          -- rendering for this group rather than drawing nothing.
          for _, item in ipairs(group) do
            table.insert(pinItems, item)
          end
        end
      else
        -- Not enough points yet to trace a meaningful boundary --
        -- fall back to the normal pin/cluster rendering for this
        -- handful so it still shows SOMETHING instead of silently
        -- disappearing until a third point is learned.
        for _, item in ipairs(group) do
          table.insert(pinItems, item)
        end
      end
    end
  end

  for j = outlineDotsUsed + 1, table.getn(AutoQuestLearnerMap.outlineDots) do
    AutoQuestLearnerMap.outlineDots[j]:Hide()
  end
  for j = outlineFillUsed + 1, table.getn(AutoQuestLearnerMap.outlineFillDots) do
    AutoQuestLearnerMap.outlineFillDots[j]:Hide()
  end

  -- Pass 2: merge nodes that would visually overlap into a single
  -- marker (avoids dozens of fully-overlapping dots reading as one
  -- indistinguishable blob), then draw one pin per group.
  -- Merge radius increased from 8 to 18 -- live diagnostic data (two
  -- separate samples) showed multiple visually-overlapping groups
  -- sitting at ~9-10 units apart, just barely missing the old
  -- threshold and staying as separate, still-overlapping markers.
  -- Hold Ctrl to temporarily see every individual spawn point instead
  -- of the merged view -- matches pfQuest's own established
  -- convention for this exact interaction.
  local mergeRadius = 0  -- never merge: each spawn stays a separate pin
  local groups = AutoQuestLearnerMap:ClusterNodePositions(pinItems, mergeRadius)
  if AutoQuestLearner_ClusterDebug then
    print(string.format("|cff00ff00AutoQuestLearner:|r [worldmap cluster debug] items=%d groups=%d WorldMapButton size=%.0fx%.0f",
        table.getn(pinItems), table.getn(groups), WorldMapButton:GetWidth(), WorldMapButton:GetHeight()))
    for gi, g in ipairs(groups) do
      if gi <= 5 then
        print(string.format("    group %d: (%.1f, %.1f) size=%d", gi, g.x, g.y, table.getn(g.items)))
      end
    end
  end

  for _, group in ipairs(groups) do
    if not AutoQuestLearnerMap.pins[i] then
      AutoQuestLearnerMap.pins[i] = AutoQuestLearnerMap:BuildNode("AutoQuestLearnerMapPin" .. i, WorldMapButton)
    end
    local pin = AutoQuestLearnerMap.pins[i]

    AutoQuestLearnerMap:UpdateNode(pin, group.items[1].node, color)

    if AutoQuestLearner.tracker then
      for _, item in ipairs(group.items) do
        for title, entryNode in pairs(item.node) do
          AutoQuestLearner.tracker.ButtonAdd(title, entryNode)
        end
      end
    end

    local groupSize = table.getn(group.items)
    pin.countBadge:Hide()

    pin:ClearAllPoints()
    pin:SetPoint("CENTER", WorldMapButton, "TOPLEFT", group.x, -group.y)
    pin:Show()

    i = i + 1
  end

  for j=i, table.getn(AutoQuestLearnerMap.pins) do
    if AutoQuestLearnerMap.pins[j] then AutoQuestLearnerMap.pins[j]:Hide() end
  end
end

-- UpdateNodes() is event-driven, not on a timer, so pressing/releasing
-- Ctrl while the world map is open wouldn't trigger a redraw on its
-- own -- this small ticker watches specifically for that state change
-- and forces one, so the un-merge preview feels instant.
local ctrlWatchFrame = CreateFrame("Frame")
local ctrlWatchElapsed = 0
local ctrlWatchLastState = nil
ctrlWatchFrame:SetScript("OnUpdate", function(self, elapsed)
    if not (WorldMapFrame and WorldMapFrame:IsVisible()) then
        ctrlWatchLastState = nil
        return
    end
    ctrlWatchElapsed = ctrlWatchElapsed + (elapsed or 0)
    if ctrlWatchElapsed < 0.1 then return end
    ctrlWatchElapsed = 0
    local down = IsControlKeyDown and IsControlKeyDown()
    if down ~= ctrlWatchLastState then
        ctrlWatchLastState = down
        AutoQuestLearnerMap:UpdateNodes()
    end
end)

local coord_cache = {}
local rotationWarningShown = false

-- Modern map IDs → classic pfDB minimap size keys (Ascension / clients
-- that report 1413 for Barrens while sizes table still uses 17).
local MINIMAP_SIZE_ALIASES = {
  [1413] = 17, [1411] = 14, [1412] = 215, [1414] = 141, [1415] = 148,
  [1416] = 1, [1417] = 3, [1418] = 4, [1419] = 8, [1420] = 10,
  [1421] = 11, [1422] = 12, [1423] = 15, [1424] = 16, [1425] = 28,
  [1426] = 33, [1427] = 36, [1428] = 38, [1429] = 40, [1430] = 41,
  [1431] = 44, [1432] = 45, [1433] = 46, [1434] = 47, [1435] = 51,
  [1436] = 85, [1437] = 130, [1438] = 139, [1439] = 331, [1440] = 357,
  [1441] = 361, [1442] = 400, [1443] = 405, [1444] = 406, [1445] = 440,
  [1446] = 490, [1447] = 493, [1448] = 618, [1449] = 1377,
}


-- Always-available yard sizes (pfDB minimap.lua). Used when
-- AutoQuestLearnerDB.minimap is missing an entry — never fall back to
-- Barrens dimensions for Feralas/etc (that put every pin in the wrong place).


local function AQL_ResolveMinimapYards(mapID)
  local function pick_from(tbl, id)
    if not tbl or not id then return nil end
    local s = tbl[id] or tbl[tonumber(id)] or tbl[tostring(id)]
    if s and s[1] and s[1] > 0 and s[2] and s[2] > 0 then
      return s[1], s[2]
    end
    return nil
  end
  local sizes = GetMinimapSizes()
  local w, h = pick_from(sizes, mapID)
  if w then return w, h end
  local alias = MINIMAP_SIZE_ALIASES[tonumber(mapID) or -1]
  w, h = pick_from(sizes, alias)
  if w then return w, h end
  -- Hardcoded pfDB sizes (Feralas 357 = 6950x4633, never Barrens default)
  w, h = pick_from(HARD_MINIMAP_SIZES, mapID)
  if w then return w, h end
  w, h = pick_from(HARD_MINIMAP_SIZES, alias)
  if w then return w, h end
  -- Live zone name → id (covers every named zone / many subzones)
  if AutoQuestLearnerData and AutoQuestLearnerData.zones and AutoQuestLearnerData.zones.loc then
    local zt = GetRealZoneText and GetRealZoneText()
    if zt and zt ~= "" then
      for id, name in pairs(AutoQuestLearnerData.zones.loc) do
        if name == zt then
          local ww, hh = pick_from(HARD_MINIMAP_SIZES, id)
          if ww then return ww, hh end
          ww, hh = pick_from(GetMinimapSizes and GetMinimapSizes() or {}, id)
          if ww then return ww, hh end
        end
      end
    end
  end
  local cal = AutoQuestLearnerDB and AutoQuestLearnerDB.calibratedMinimap
  if cal then
    local c = cal[mapID] or cal[tonumber(mapID)] or (alias and cal[alias])
    if c and c[1] and c[1] > 0 then return c[1], c[2] end
  end
  return 10133.34, 6756.25
end

-- Terrain-locked minimap pins (pfQuest map.lua math, nothing else).
-- item.mx/my are FIXED map-% from the node table. Only xPlayer/yPlayer
-- change while walking. Scale is recomputed only on zoom/map change.
-- Do NOT use GetViewRadius or GetEffectiveScale here — both skewed the
-- scale on Ascension and made pins crawl across the terrain.
-- ============================================================
-- MINIMAP: clean pfQuest-style placement (github.com/shagu/pfQuest)
-- Node coords are FIXED map-% (never change while walking).
-- Only player origin + zoom change; pins are re-pointed, not rebuilt.
-- ============================================================
function AutoQuestLearnerMap:UpdateMinimap()
  if AutoQuestLearnerDB.config.minimapnodes == "0" then
    return
  end

  if not rotationWarningShown and GetCVar and GetCVar("rotateMinimap") == "1" then
    rotationWarningShown = true
    print("|cff00ff00AutoQuestLearner:|r Your minimap is set to rotate with your facing. This addon's minimap pins assume a fixed north-up minimap and will drift/swing as you turn while rotation is on. For accurate pin positions, disable it: Interface Options > Minimap > uncheck 'Rotate Minimap' (or /console rotateMinimap 0). This doesn't affect the world map or the 3D arrow, which are unaffected by this setting.")
  end

  local xPlayer, yPlayer = GetPlayerMapPosition("player")
  -- BUGFIX: (0,0) is often a transient "map not synced" reading right after
  -- quest-log / learn / SetMapToCurrentZone work -- NOT "player left the
  -- world". Hiding every minimap pin on that frame made all spawn clusters
  -- vanish the moment a loot/kill progress tick learned a new point, and
  -- they only came back (if at all) on a later successful read. Skip the
  -- update and keep existing pins visible instead of wiping them.
  if not xPlayer or not yPlayer or (xPlayer == 0 and yPlayer == 0) then
    return
  end

  local mZoom = Minimap:GetZoom()
  xPlayer, yPlayer = xPlayer * 100, yPlayer * 100
  local ctrlDown = IsControlKeyDown and IsControlKeyDown()
  local ctrlChanged = this.ctrlDown ~= ctrlDown
  this.ctrlDown = ctrlDown

  if not ctrlChanged and this.xPlayer == xPlayer and this.yPlayer == yPlayer and this.mZoom == mZoom then
    if ( this.stationaryTick or 1) > GetTime() then return else this.stationaryTick = GetTime() + 1 end
  end

  this.xPlayer, this.yPlayer, this.mZoom = xPlayer, yPlayer, mZoom
  local minimap_sizes = GetMinimapSizes()
  local color = AutoQuestLearnerDB.config.spawncolors == "1" and "spawn" or "title"
  local mapID = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap()) or AutoQuestLearnerMap:GetMapID()
  -- Client-true radius when available (why 8-24 backup did not slide).
  -- Fallback to pfQuest outdoor/indoor table if GetViewRadius missing.
  local mapZoom
  if Minimap.GetViewRadius then
    local ok, r = pcall(function() return Minimap:GetViewRadius() end)
    if ok and r and r > 0 then
      mapZoom = r * 2
    end
  end
  if not mapZoom then
    local indoor = minimap_indoor and minimap_indoor() or 0
    mapZoom = minimap_zoom[indoor] and minimap_zoom[indoor][mZoom] or 200
  end

  -- Prefer a self-calibrated dimension (see
  -- AutoQuestLearner_UpdateMinimapCalibration in AutoQuestLearner.lua)
  -- over the static bundled data -- for the handful of starting-zone
  -- sub-areas this exists for, the bundled data only ever has the much
  -- larger PARENT zone's dimension (no external database has ever had
  -- the real value; it's unique to this client), so a calibrated value
  -- is always more accurate than the fallback once one exists. Looked
  -- up by the RAW sub-zone ID (skipAlias=true) since that's what
  -- calibration itself is keyed by -- the node LOOKUP below still uses
  -- the aliased mapID, since that's where nodes are actually stored.
  --
  -- Middle tier: real DBC-derived dimensions for these same zones
  -- (see bundled-db/starting-zone-dimensions.lua) -- computed from a
  -- modern retail client's data, not Ascension's own, but a much
  -- better starting estimate than the old parent-zone fallback while
  -- self-calibration is still collecting samples. Self-calibration
  -- stays fully active regardless and will override this the moment
  -- it has enough real, client-measured samples.
  local rawZoneID = AutoQuestLearnerMap:GetMapID(nil, nil, true)
  local calibrated = AutoQuestLearnerDB.calibratedMinimap and AutoQuestLearnerDB.calibratedMinimap[rawZoneID]
  local dbcDerived = AutoQuestLearnerStartingZoneDimensions and AutoQuestLearnerStartingZoneDimensions[rawZoneID]
  local mapWidth = (calibrated and calibrated[1]) or (dbcDerived and dbcDerived[1]) or (minimap_sizes[mapID] and minimap_sizes[mapID][1] or 0)
  local mapHeight = (calibrated and calibrated[2]) or (dbcDerived and dbcDerived[2]) or (minimap_sizes[mapID] and minimap_sizes[mapID][2] or 0)
  -- Fallback: full HARD/pfDB sizes for every zone (backup-compatible path)
  if (mapWidth == 0 or mapHeight == 0) and AQL_ResolveMinimapYards then
    local w, h = AQL_ResolveMinimapYards(mapID)
    if w and w > 0 then mapWidth, mapHeight = w, h end
  end

  if mapWidth == 0 or mapHeight == 0 then
    return
  end

  local xScale = mapZoom / mapWidth
  local yScale = mapZoom / mapHeight

  local xDraw = Minimap:GetWidth() / xScale / 100
  local yDraw = Minimap:GetHeight() / yScale / 100

  local i = 1
  local focusModeEnabled = AutoQuestLearnerDB.config.focusmode == "1"
  local focusQuestID = focusModeEnabled
      and AutoQuestLearner_GetTrackedQuestID and AutoQuestLearner_GetTrackedQuestID()

  -- Pass 1: collect every node that's actually within the visible
  -- minimap circle, with its real pixel position, before drawing.
  --
  -- BUGFIX: do not require minimap_sizes[mapID] to be present when we
  -- already resolved mapWidth/mapHeight via calibration or DBC fallbacks
  -- above. Requiring the static table made HasMinimap zones with only
  -- calibrated dimensions draw zero pins after a map-id blip during
  -- learn ticks (looked like "all clusters deleted").
  local items = {}
  local canDrawMinimap = (mapWidth > 0 and mapHeight > 0) and AutoQuestLearnerMap:HasMinimap(mapID)
  for addon, data in pairs(AutoQuestLearnerMap.nodes) do
    if data[mapID] and canDrawMinimap then
      for coords, node in pairs(data[mapID]) do
        local showThis = true
        if focusModeEnabled then
          if focusQuestID then
            showThis = false
            for _, entry in pairs(node) do
              if entry.questid == focusQuestID then
                showThis = true
                break
              end
            end
          else
            -- Same reasoning as the world map: focus mode on but
            -- nothing tracked in-zone should mean "show nothing", not
            -- "show everything".
            showThis = false
          end
        end

        if showThis then
            local anyVisible = false
            for _, tab in pairs(node) do
                if not (tab.hiddenUntil and GetTime() < tab.hiddenUntil) then
                    anyVisible = true
                    break
                end
            end
            if not anyVisible then
                showThis = false
            end
        end

        if showThis then
          local x, y
          if coord_cache[coords] then
            x, y = coord_cache[coords][1], coord_cache[coords][2]
          else
            local _, _, strx, stry = strfind(coords, "(.*)|(.*)")
            x, y = strx + 0, stry + 0
            coord_cache[coords] = { x, y }
          end

          local xPos = ( x - xPlayer) * xDraw
          local yPos = -( y - yPlayer) * yDraw
          local distance = sqrt(xPos * xPos + yPos * yPos)

          if distance + 8 < Minimap:GetWidth() / 2 then
            local groupKey = nil
            for title, tab in pairs(node) do
              groupKey = tab.spawn or title
              break
            end
            table.insert(items, { node = node, x = xPos, y = yPos, groupKey = groupKey })
          end
        end
      end
    end
  end

  -- Pass 2: merge nodes that would visually overlap into a single
  -- marker, then draw one pin per group. Smaller merge radius than the
  -- world map's, since minimap pins are already much smaller.
  -- Hold Ctrl to temporarily see every individual spawn point instead
  -- of the merged view -- matches pfQuest's own established
  -- convention for this exact interaction (also matches pfQuest's
  -- separate "hold Ctrl over the minimap" convention for hiding nodes
  -- entirely, though this addon uses it for un-merging instead).
  local mergeRadius = (IsControlKeyDown and IsControlKeyDown()) and 0 or 5
  local groups = AutoQuestLearnerMap:ClusterNodePositions(items, mergeRadius)

  for _, group in ipairs(groups) do
    if not AutoQuestLearnerMap.mpins[i] then
      AutoQuestLearnerMap.mpins[i] = AutoQuestLearnerMap:BuildNode("AutoQuestMiniMapPin" .. i, Minimap)
    end
    local pin = AutoQuestLearnerMap.mpins[i]

    AutoQuestLearnerMap:UpdateNode(pin, group.items[1].node, color, "minimap")

    -- Resize based on current minimap zoom -- WoW's Minimap zoom
    -- level runs from 0 (fully zoomed out) up to
    -- GetZoomLevels()-1 (fully zoomed in), so this scales from
    -- 0.6x at minimum zoom up to 1.4x at maximum zoom, keeping
    -- cluster dots visually proportionate to everything else on
    -- the minimap instead of staying a fixed pixel size
    -- regardless of how zoomed in/out the view currently is.
    if pin.defsize and (pin.cluster or pin.layer == 4) then
      local zoomLevel = Minimap.GetZoom and Minimap:GetZoom() or 0
      local maxZoom = math.max((Minimap.GetZoomLevels and Minimap:GetZoomLevels() or 5) - 1, 1)
      local zoomRatio = zoomLevel / maxZoom
      -- Inverted from the initial assumption -- this client's
      -- zoom level convention runs opposite to the usual "0 =
      -- fully zoomed out" default, confirmed by it looking
      -- backwards in practice.
      local sizeMultiplier = 1.4 - zoomRatio * 0.8
      local scaledSize = pin.defsize * sizeMultiplier
      pin:SetWidth(scaledSize)
      pin:SetHeight(scaledSize)
    end

    local groupSize = table.getn(group.items)
    pin.countBadge:Hide()

    pin:ClearAllPoints()
    pin:SetPoint("CENTER", Minimap, "CENTER", group.x, group.y)
    pin:Show()

    i = i + 1
  end

  for j=i, table.getn(AutoQuestLearnerMap.mpins) do
    if AutoQuestLearnerMap.mpins[j] then AutoQuestLearnerMap.mpins[j]:Hide() end
  end
end

AutoQuestLearnerMap:SetScript("OnUpdate", function()
  if ( this.updateTick or 0.1) > GetTime() then return else this.updateTick = GetTime() + 0.1 end
  AutoQuestLearnerMap:UpdateMinimap()
end)

-- Drop node tables for zones the player is not in. SearchQuests /
-- SearchQuestID rebuild the current zone on the next UpdateNodes.

function AutoQuestLearnerMap:PruneInactiveZoneNodes(keepMapID)
  if not AutoQuestLearnerMap.nodes then return end
  local keepNum = tonumber(keepMapID)
  local keepStr = keepMapID and tostring(keepMapID) or nil
  local function isKeep(id)
    if keepMapID == nil then return false end
    return id == keepMapID or id == keepNum or tostring(id) == keepStr
  end
  for addon, maps in pairs(AutoQuestLearnerMap.nodes) do
    if type(maps) == "table" then
      local drop = {}
      for mapID, _ in pairs(maps) do
        if not isKeep(mapID) then
          table.insert(drop, mapID)
        end
      end
      for _, mapID in ipairs(drop) do
        maps[mapID] = nil
      end
    end
  end
  -- similar_nodes grows unbounded with every AddNode ever done this
  -- session — primary memory leak report source. Rebuild is cheap.
  similar_nodes = {}
  -- tooltips cache: drop entries for pruned maps
  if AutoQuestLearnerMap.tooltips then
    for spawn, titles in pairs(AutoQuestLearnerMap.tooltips) do
      if type(titles) == "table" then
        for title, maps in pairs(titles) do
          if type(maps) == "table" then
            for mid, _ in pairs(maps) do
              if not isKeep(mid) then maps[mid] = nil end
            end
            if IsEmpty(maps) then titles[title] = nil end
          end
        end
        if IsEmpty(titles) then AutoQuestLearnerMap.tooltips[spawn] = nil end
      end
    end
  end
  -- unified cluster cache
  if unifiedcache then
    for k in pairs(unifiedcache) do unifiedcache[k] = nil end
  end
end

-- Register events for map updates

-- Periodic light prune: clear inactive zone nodes every 90s while playing.
local AQL_MemHygiene = CreateFrame("Frame")
AQL_MemHygiene._t = 0
AQL_MemHygiene:SetScript("OnUpdate", function(self, elapsed)
  self._t = self._t + (elapsed or 0)
  if self._t < 90 then return end
  self._t = 0
  if not AutoQuestLearnerMap or not AutoQuestLearnerMap.PruneInactiveZoneNodes then return end
  local keep = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap())
      or (AutoQuestLearnerMap.GetMapID and AutoQuestLearnerMap:GetMapID())
  if keep then
    pcall(function() AutoQuestLearnerMap:PruneInactiveZoneNodes(keep) end)
  end
  if collectgarbage then
    collectgarbage("step", 100)
  end
end)

AutoQuestLearnerMap:RegisterEvent("WORLD_MAP_UPDATE")
AutoQuestLearnerMap:RegisterEvent("ZONE_CHANGED")
AutoQuestLearnerMap:RegisterEvent("ZONE_CHANGED_NEW_AREA")
AutoQuestLearnerMap:RegisterEvent("PLAYER_ENTERING_WORLD")
AutoQuestLearnerMap:RegisterEvent("QUEST_LOG_UPDATE")
AutoQuestLearnerMap:RegisterEvent("QUEST_WATCH_UPDATE")
AutoQuestLearnerMap:SetScript("OnEvent", function()
  if event == "WORLD_MAP_UPDATE" and not WorldMapFrame:IsShown() then
    -- BUGFIX: WORLD_MAP_UPDATE is specifically about the World Map UI's
    -- own display, and fires far more often than its name implies --
    -- including constantly while the map isn't even open, where there's
    -- nothing for it to usefully refresh. It was still triggering a
    -- full tracker rebuild every time regardless (UpdateNodes() draws
    -- both the map's pins AND resets the tracker as a side effect),
    -- which is what /aql flickerdebug's call-stack capture caught.
    -- Throttling this alone brought the rebuild rate way down but
    -- didn't eliminate the visible pulse entirely, since each
    -- individual unnecessary rebuild was still happening, just less
    -- often -- this addresses why it fires at all while the map is
    -- closed, not just how frequently.
    if AutoQuestLearner_FlickerDebug and AutoQuestLearner_FlickerDebug.active then
      local c = AutoQuestLearner_FlickerDebug.counts
      c["MapEvent_WORLD_MAP_UPDATE_skipped_closed"] = (c["MapEvent_WORLD_MAP_UPDATE_skipped_closed"] or 0) + 1
    end
    return
  end

  if event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED" then
    AutoQuestLearnerMap._mmForceRebuild = true
    AutoQuestLearnerMap._mmMapSynced = nil
    AutoQuestLearnerMap._mmFrozenMapID = nil
    AutoQuestLearnerMap._mmXDraw = nil
    AutoQuestLearnerMap._mmYDraw = nil
    AutoQuestLearnerMap._mmScaleKey = nil
    local keep = AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
    AutoQuestLearnerMap:PruneInactiveZoneNodes(keep)
    availableGiverCache = nil -- force rebuild; may be local in other file
    if AutoQuestLearner_RefreshAvailableGiverCache then
      AutoQuestLearner_RefreshAvailableGiverCache(true)
    end
  end

  if event == "WORLD_MAP_UPDATE" or event == "ZONE_CHANGED"
      or event == "ZONE_CHANGED_NEW_AREA" or event == "QUEST_LOG_UPDATE"
      or event == "QUEST_WATCH_UPDATE" then
    if AutoQuestLearner_FlickerDebug and AutoQuestLearner_FlickerDebug.active then
      local c = AutoQuestLearner_FlickerDebug.counts
      local key = "MapEvent_" .. event
      c[key] = (c[key] or 0) + 1
    end
    -- QUEST_LOG_UPDATE fires in bursts on accept/turn-in/progress —
    -- never rebuild the full map more than once every 5s from these events.
    if (this.lastQuestEventUpdate or 0) < GetTime() then
      AutoQuestLearnerMap:UpdateNodes() -- already 1s-throttled internally
      this.lastQuestEventUpdate = GetTime() + 5
    end
  elseif event == "PLAYER_ENTERING_WORLD" then
    -- Delay slightly on login/reload so the quest log and saved
    -- variables are fully populated before we build tracker buttons.
    local f = CreateFrame("Frame")
    local elapsedTotal = 0
    f:SetScript("OnUpdate", function(self, elapsed)
      elapsedTotal = elapsedTotal + elapsed
      if elapsedTotal >= 1 then
        self:SetScript("OnUpdate", nil)
        AutoQuestLearnerMap:UpdateNodes()
      end
    end)
  end
end)

-- make global available
AutoQuestLearner = AutoQuestLearner or CreateFrame("Frame")
AutoQuestLearner.map = AutoQuestLearnerMap

