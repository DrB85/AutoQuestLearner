#!/usr/bin/env python3
"""
Import quests / NPCs / objects / items from the Questie-X plugin addons
(Questie-X-CoADB and Questie-X-AscensionDB) into AutoQuestLearner's
bundled-db/ascension/coadb-*.lua layers ("data-coadb" / "loc-coadb").

Usage:
  python tools/questie_coa_importer.py <folder containing the Questie-X-* addon folders> [--addon <AutoQuestLearner folder>]

Only content that is NEW to AutoQuestLearner is written (IDs that already
have data in bundled-db are left alone), so CoA-realm rewrites of vanilla
quests never override the Ascension data you already have. NPCs/objects that
a new quest references are always included.
"""
import argparse
import json
import re
import sys
from pathlib import Path

# --------------------------------------------------------------------------
# Minimal Lua table-literal parser (numbers, strings, nil, booleans, tables)
# --------------------------------------------------------------------------


class LuaParser:
    def __init__(self, text: str):
        self.s = text
        self.i = 0

    def ws(self):
        s, n = self.s, len(self.s)
        while self.i < n:
            c = s[self.i]
            if c in " \t\r\n":
                self.i += 1
            elif s.startswith("--", self.i):
                j = s.find("\n", self.i)
                self.i = n if j < 0 else j + 1
            else:
                break

    def value(self):
        self.ws()
        s = self.s
        c = s[self.i]
        if c == "{":
            return self.table()
        if c in "\"'":
            return self.string(c)
        m = re.compile(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?").match(s, self.i)
        if m:
            self.i = m.end()
            t = m.group()
            return float(t) if ("." in t or "e" in t.lower()) else int(t)
        for word, val in (("nil", None), ("true", True), ("false", False)):
            if s.startswith(word, self.i):
                self.i += len(word)
                return val
        raise ValueError("bad lua value at %d: %r" % (self.i, s[self.i:self.i + 40]))

    def string(self, q):
        s = self.s
        self.i += 1
        out = []
        while s[self.i] != q:
            if s[self.i] == "\\":
                self.i += 1
                e = s[self.i]
                out.append({"n": "\n", "t": "\t", "r": "\r"}.get(e, e))
            else:
                out.append(s[self.i])
            self.i += 1
        self.i += 1
        return "".join(out)

    def table(self):
        s = self.s
        self.i += 1
        res: dict = {}
        pos = 1
        while True:
            self.ws()
            if s[self.i] == "}":
                self.i += 1
                return res
            if s[self.i] == "[":
                self.i += 1
                key = self.value()
                self.ws()
                assert s[self.i] == "]"
                self.i += 1
                self.ws()
                assert s[self.i] == "="
                self.i += 1
                val = self.value()
                if val is not None:
                    res[key] = val
            else:
                m = re.compile(r"[A-Za-z_]\w*\s*=").match(s, self.i)
                if m:
                    key = m.group()[:-1].strip()
                    self.i = m.end()
                    val = self.value()
                    if val is not None:
                        res[key] = val
                else:
                    val = self.value()
                    if val is not None:
                        res[pos] = val
                    pos += 1
            self.ws()
            if s[self.i] in ",;":
                self.i += 1


def parse_records(path: Path) -> dict:
    """Return {id: parsed_table} for `d[ID]={...}` and `[ID]={...},` records."""
    text = path.read_text(encoding="utf-8", errors="replace")
    out = {}
    pat = re.compile(r"^\s*(?:d|addonTable\.\w+)?\[(\d+)\]\s*=\s*(?=\{)", re.M)
    for m in pat.finditer(text):
        p = LuaParser(text)
        p.i = m.end()
        try:
            out[int(m.group(1))] = p.value()
        except Exception as e:  # keep going on a bad row
            print("  skip %s[%s]: %s" % (path.name, m.group(1), e))
    return out


def top_level_ids(path: Path) -> dict:
    """{id: has_data} for the top-level [ID]= keys of a pfDB-style data table."""
    text = path.read_text(encoding="utf-8", errors="replace")
    ids = {}
    depth, i, n = 0, 0, len(text)
    while i < n:
        c = text[i]
        if c == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        elif c == "[" and depth == 1:
            m = re.compile(r"\[(\d+)\]\s*=\s*(\{?)").match(text, i)
            if m:
                ids[int(m.group(1))] = True
        i += 1
    return ids


# --------------------------------------------------------------------------


def lua_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ") + '"'


def ids_of(v):
    """Flatten Questie id lists ({1,2,3} or {{id,..},{id,..}}) into ints."""
    out = []
    if isinstance(v, dict):
        for k in sorted(k for k in v if isinstance(k, int)):
            x = v[k]
            if isinstance(x, dict):
                first = x.get(1)
                if isinstance(first, int):
                    out.append(first)
            elif isinstance(x, int):
                out.append(x)
    return out


def sub(v, idx):
    return v.get(idx) if isinstance(v, dict) else None


def coords_of(spawns, rate=0):
    res = []
    if not isinstance(spawns, dict):
        return res
    for zone, pts in spawns.items():
        if not isinstance(zone, int) or not isinstance(pts, dict):
            continue
        for k in sorted(k for k in pts if isinstance(k, int)):
            pt = pts[k]
            if isinstance(pt, dict) and isinstance(pt.get(1), (int, float)) and isinstance(pt.get(2), (int, float)):
                if pt[1] >= 0 and pt[2] >= 0:
                    res.append((round(float(pt[1]), 2), round(float(pt[2]), 2), zone, rate))
    return res


def convert_quest(qid, q):
    out = {}
    start_u = ids_of(sub(sub(q, 2), 1))
    start_o = ids_of(sub(sub(q, 2), 2))
    end_u = ids_of(sub(sub(q, 3), 1))
    end_o = ids_of(sub(sub(q, 3), 2))
    if start_u or start_o:
        out["start"] = {}
        if start_u:
            out["start"]["U"] = start_u
        if start_o:
            out["start"]["O"] = start_o
    if end_u or end_o:
        out["end"] = {}
        if end_u:
            out["end"]["U"] = end_u
        if end_o:
            out["end"]["O"] = end_o
    lvl, mn = q.get(5), q.get(4)
    if isinstance(lvl, int) and lvl > 0:
        out["lvl"] = lvl
    if isinstance(mn, int) and mn >= 0:
        out["min"] = mn
    obj = {}
    o = q.get(10)
    if isinstance(o, dict):
        u = ids_of(o.get(1))
        ob = ids_of(o.get(2))
        it = ids_of(o.get(3))
        kc = o.get(5)
        if isinstance(kc, dict):
            for k in sorted(k for k in kc if isinstance(k, int)):
                row = kc[k]
                if isinstance(row, dict) and isinstance(row.get(2), int):
                    u.append(row[2])
        u = [x for x in dict.fromkeys(u) if x > 0]
        if u:
            obj["U"] = u
        ob = [abs(x) for x in dict.fromkeys(ob)]
        if ob:
            obj["O"] = ob
        if it:
            obj["I"] = list(dict.fromkeys(it))
    if obj:
        out["obj"] = obj
    pre = q.get(13)
    pre_ids = [x for x in (pre.values() if isinstance(pre, dict) else []) if isinstance(x, int)]
    if not pre_ids:
        grp = q.get(12)
        pre_ids = [x for x in (grp.values() if isinstance(grp, dict) else []) if isinstance(x, int)]
    if pre_ids:
        out["pre"] = pre_ids
    if isinstance(q.get(6), int) and q[6] > 0:
        out["race"] = q[6]
    if isinstance(q.get(7), int) and q[7] > 0:
        out["class"] = q[7]
    return out


def lua_list(v):
    return "{" + ",".join(str(x) for x in v) + "}"


def emit_quest(qid, d):
    parts = []
    for f in ("start", "end"):
        if f in d:
            sub_ = ",".join('["%s"]=%s' % (k, lua_list(v)) for k, v in d[f].items())
            parts.append('["%s"]={%s}' % (f, sub_))
    for f in ("lvl", "min", "race", "class"):
        if f in d:
            parts.append('["%s"]=%d' % (f, d[f]))
    if "obj" in d:
        sub_ = ",".join('["%s"]=%s' % (k, lua_list(v)) for k, v in d["obj"].items())
        parts.append('["obj"]={%s}' % sub_)
    if "pre" in d:
        parts.append('["pre"]=%s' % lua_list(d["pre"]))
    return "[%d]={%s}" % (qid, ",".join(parts))


def write_layer(path: Path, header: str, cat: str, entries: list, loc_entries: list, loc_is_string=False):
    lines = ["-- " + header.replace("\n", "\n-- ")]
    lines += [
        'pfDB["%s"] = pfDB["%s"] or {}' % (cat, cat),
        'pfDB["%s"]["data-coadb"] = pfDB["%s"]["data-coadb"] or {}' % (cat, cat),
        'pfDB["%s"]["loc-coadb"] = pfDB["%s"]["loc-coadb"] or {}' % (cat, cat),
        "local data = {",
    ]
    lines.append(",\n".join(entries))
    lines.append("}")
    lines.append("local loc = {")
    lines.append(",\n".join(loc_entries))
    lines.append("}")
    lines.append('for k,v in pairs(data) do pfDB["%s"]["data-coadb"][k]=v end' % cat)
    lines.append('for k,v in pairs(loc) do pfDB["%s"]["loc-coadb"][k]=v end' % cat)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", help="folder containing Questie-X-CoADB and/or Questie-X-AscensionDB")
    ap.add_argument("--addon", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--all", action="store_true",
                    help="also include IDs the addon already has data for (default: only new ones)")
    args = ap.parse_args()
    src, addon = Path(args.source), Path(args.addon)
    bdb = addon / "bundled-db"

    # existing IDs (anything that already has a data layer)
    existing = {"units": {}, "objects": {}, "quests": {}, "items": {}}
    if not args.all:
        for name, cat in (("units", "units"), ("objects", "objects"), ("quests", "quests"), ("items", "items")):
            for f in list(bdb.glob("%s*.lua" % name)) + list((bdb / "ascension").glob("*%s*.lua" % name)) \
                    + list((bdb / "wowhead").glob("*%s*.lua" % name.rstrip("s"))):
                if "coadb" in f.name:
                    continue
                try:
                    existing[cat].update(top_level_ids(f))
                except Exception as e:
                    print("  could not scan", f.name, e)
        # quests: also scan the quest-specific layers
        for f in list(bdb.glob("quests*.lua")) + list((bdb / "ascension").glob("*quest*.lua")) + list((bdb / "wowhead").glob("*quest*.lua")):
            if "coadb" not in f.name:
                existing["quests"].update(top_level_ids(f))

    # gather Questie data (Ascension first, CoA second so CoA wins on clashes of NEW ids)
    raw = {"npc": {}, "obj": {}, "quest": {}, "item": {}}
    files = []
    for pat, key in (("*NpcDB*_1.lua", "npc"), ("*ObjectDB*_1.lua", "obj"),
                     ("*QuestDB*_1.lua", "quest"), ("*ItemDB*_1.lua", "item")):
        for addon_dir in ("Questie-X-AscensionDB", "Questie-X-CoADB"):
            for f in sorted((src / addon_dir).rglob(pat)):
                files.append((key, f))
    for key, f in files:
        recs = parse_records(f)
        print("%-60s %5d records" % (f.relative_to(src), len(recs)))
        raw[key].update(recs)

    # --- quests: only genuinely new, named quests --------------------------
    quests, quest_names = {}, {}
    for qid, q in raw["quest"].items():
        if not isinstance(q.get(1), str):
            continue  # field-only override of an existing quest
        if qid in existing["quests"]:
            continue
        d = convert_quest(qid, q)
        if d.get("start") or d.get("end") or d.get("obj"):
            quests[qid] = d
            quest_names[qid] = q[1]

    need_units, need_objects, need_items = set(), set(), set()
    for d in quests.values():
        for f in ("start", "end", "obj"):
            for k, v in d.get(f, {}).items():
                if k == "U":
                    need_units.update(v)
                elif k == "O":
                    need_objects.update(v)
                elif k == "I":
                    need_items.update(v)

    # --- units -----------------------------------------------------------
    units, unit_names = {}, {}
    for uid, n in raw["npc"].items():
        if not isinstance(n.get(1), str):
            continue
        cs = coords_of(n.get(7))
        if not cs:
            continue
        if uid in existing["units"] and uid not in need_units:
            continue
        u = {"coords": cs}
        fac = n.get(13)
        if isinstance(fac, str) and fac:
            u["fac"] = fac
        if isinstance(n.get(4), int) and n[4] > 0:
            u["lvl"] = str(n[4])
        units[uid] = u
        unit_names[uid] = n[1]

    # --- objects ---------------------------------------------------------
    objects, object_names = {}, {}
    for oid, o in raw["obj"].items():
        if not isinstance(o.get(1), str):
            continue
        cs = coords_of(o.get(4))
        if not cs:
            continue
        if oid in existing["objects"] and oid not in need_objects:
            continue
        objects[oid] = {"coords": cs}
        object_names[oid] = o[1]

    # --- items (drop sources + names) -----------------------------------------
    items, item_names = {}, {}
    for iid, it in raw["item"].items():
        if not isinstance(it.get(1), str):
            continue
        if iid in existing["items"] and iid not in need_items:
            continue
        item_names[iid] = it[1]
        src_u = [x for x in (it.get(2) or {}).values() if isinstance(x, int)] if isinstance(it.get(2), dict) else []
        src_o = [x for x in (it.get(3) or {}).values() if isinstance(x, int)] if isinstance(it.get(3), dict) else []
        if src_u or src_o:
            items[iid] = {"U": src_u, "O": src_o}

    # --- write ----------------------------------------------------------------
    out_dir = bdb / "ascension"
    out_dir.mkdir(parents=True, exist_ok=True)
    hdr = ("Converted from Questie-X-CoADB / Questie-X-AscensionDB (new content only).\n"
           "Generated by tools/questie_coa_importer.py -- re-run it to refresh; do not edit.")

    def coords_lua(cs):
        return "{" + ",".join("{%s,%s,%d,%d}" % (repr(c[0]), repr(c[1]), c[2], c[3]) for c in cs) + "}"

    def unit_entry(uid, u):
        s = '[%d]={["coords"]=%s' % (uid, coords_lua(u["coords"]))
        if "fac" in u:
            s += ',["fac"]=%s' % lua_str(u["fac"])
        if "lvl" in u:
            s += ',["lvl"]=%s' % lua_str(u["lvl"])
        return s + "}"

    write_layer(out_dir / "coadb-units.lua", hdr, "units",
                [unit_entry(k, v) for k, v in sorted(units.items())],
                ['[%d]={["T"]=%s}' % (k, lua_str(v)) for k, v in sorted(unit_names.items()) if k in units])
    write_layer(out_dir / "coadb-objects.lua", hdr, "objects",
                ['[%d]={["coords"]=%s}' % (k, coords_lua(v["coords"])) for k, v in sorted(objects.items())],
                ['[%d]={["T"]=%s}' % (k, lua_str(v)) for k, v in sorted(object_names.items()) if k in objects])
    write_layer(out_dir / "coadb-quests.lua", hdr, "quests",
                [emit_quest(k, v) for k, v in sorted(quests.items())],
                ['[%d]={["T"]=%s}' % (k, lua_str(v)) for k, v in sorted(quest_names.items())])

    # These quests exist on the CoA/Ascension servers: keep them when the
    # "restrict to server quests" filter is on.
    wl = sorted(quests)
    with open(out_dir / "coadb-quests.lua", "a", encoding="utf-8") as fh:
        fh.write("AutoQuestLearnerServerQuestIDs = AutoQuestLearnerServerQuestIDs or {}\n")
        for i in range(0, len(wl), 20):
            fh.write("".join("AutoQuestLearnerServerQuestIDs[%d]=true;" % q for q in wl[i:i + 20]) + "\n")

    def item_entry(iid, v):
        u = ",".join("[%d]=50" % x for x in v["U"])
        o = ",".join("[%d]=50" % x for x in v["O"])
        parts = []
        if u:
            parts.append('["U"]={%s}' % u)
        if o:
            parts.append('["O"]={%s}' % o)
        return "[%d]={%s}" % (iid, ",".join(parts))

    write_layer(out_dir / "coadb-items.lua", hdr, "items",
                [item_entry(k, v) for k, v in sorted(items.items())],
                ['[%d]=%s' % (k, lua_str(v)) for k, v in sorted(item_names.items())])

    print("Wrote bundled-db/ascension/coadb-{units,objects,quests,items}.lua")
    print("  quests=%d units=%d objects=%d items(with sources)=%d item names=%d" % (
        len(quests), len(units), len(objects), len(items), len(item_names)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
