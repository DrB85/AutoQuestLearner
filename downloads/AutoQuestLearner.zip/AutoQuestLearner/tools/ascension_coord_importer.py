#!/usr/bin/env python3
"""
Import quest start/end NPC (and object) coordinates from db.ascension.gg
for quests that exist on the server but lack usable coords in the AQL bundle.

Reads:
  bundled-db/ascension/server_quest_ids.json
  (optional) previous progress JSON

Writes:
  bundled-db/ascension/imported-quest-coords.lua   -- quest start/end + loc titles
  bundled-db/ascension/imported-unit-coords.lua    -- unit id → coords
  bundled-db/ascension/imported-object-coords.lua  -- object id → coords
  tools/coord_import_progress.json                 -- resume state

Usage:
  python3 ascension_coord_importer.py              # all missing server quests
  python3 ascension_coord_importer.py --limit 200  # first 200 only
  python3 ascension_coord_importer.py --resume
  python3 ascension_coord_importer.py --fix-units 1665,1515  # just NPCs
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

UA = {"User-Agent": "Mozilla/5.0 (compatible; AQL-CoordImporter/1.0)"}
BASE = "https://db.ascension.gg"


def fetch(url: str, retries: int = 3) -> str:
    err = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=40) as r:
                return r.read().decode("utf-8", "replace")
        except Exception as e:
            err = e
            time.sleep(0.4 * (i + 1))
    raise RuntimeError(f"{url}: {err}")


def parse_power_map(power: str) -> tuple[str | None, list[tuple[float, float]], int | None]:
    """Return name, [(x,y),...], zone from WowheadPower blob."""
    name = None
    m = re.search(r'"name_enus":\s*"([^"]+)"', power)
    if m:
        name = m.group(1)
    zone = None
    m = re.search(r'"zone":\s*(\d+)', power)
    if m:
        zone = int(m.group(1))
    coords: list[tuple[float, float]] = []
    # Nested arrays: "coords": [ [ [x,y], [x,y] ] ]
    m = re.search(r'"coords"\s*:\s*(\[[\s\S]*?\])\s*\n?\s*\}', power)
    if m:
        try:
            arr = json.loads(m.group(1))
            def walk(node):
                if isinstance(node, list):
                    if len(node) >= 2 and isinstance(node[0], (int, float)) and isinstance(node[1], (int, float)):
                        coords.append((float(node[0]), float(node[1])))
                    else:
                        for child in node:
                            walk(child)
            walk(arr)
        except json.JSONDecodeError:
            for xm, ym in re.findall(r"\[\s*(\d+\.?\d*)\s*,\s*(\d+\.?\d*)\s*\]", m.group(1)):
                coords.append((float(xm), float(ym)))
    # dedupe
    seen = set()
    uniq = []
    for x, y in coords:
        key = (round(x, 1), round(y, 1))
        if key not in seen:
            seen.add(key)
            uniq.append((x, y))
    return name, uniq, zone


def parse_mapper_data(html: str) -> dict[int, list[tuple[float, float]]]:
    """zone -> coords from g_mapperData."""
    out: dict[int, list[tuple[float, float]]] = {}
    m = re.search(r"var g_mapperData\s*=\s*(\{.*?\});\s*\n", html, re.S)
    if not m:
        return out
    raw = m.group(1)
    # {"85":[{"coords":[[60.5,51.7,{...}],[...]],"count":2}]}
    for zm in re.finditer(r'"(\d+)"\s*:\s*\[\s*\{\s*"coords"\s*:\s*\[', raw):
        zone = int(zm.group(1))
        # take a window after this match
        start = zm.end()
        chunk = raw[start : start + 4000]
        pts = []
        for xm, ym in re.findall(r"\[\s*(\d+\.?\d*)\s*,\s*(\d+\.?\d*)\s*,", chunk):
            pts.append((float(xm), float(ym)))
        if pts:
            out[zone] = pts
    return out


def parse_quest_page(quest_id: int) -> dict:
    html = fetch(f"{BASE}/?quest={quest_id}")
    power = fetch(f"{BASE}/?quest={quest_id}&power=true")
    time.sleep(0.12)

    name = None
    m = re.search(r'"name_enus":\s*"([^"]+)"', power)
    if m:
        name = m.group(1)
    if not name:
        m = re.search(r"<title>([^<-]+)", html)
        if m:
            name = m.group(1).strip()

    start_npcs: list[int] = []
    end_npcs: list[int] = []
    start_objs: list[int] = []
    end_objs: list[int] = []
    obj_npcs: list[int] = []

    # Markup infobox: Start / End
    for mm in re.finditer(r'Markup\.printHtml\("([^"]*)"', html):
        s = mm.group(1).replace("\\/", "/").replace('\\"', '"')
        if "quest_start" in s or "Start:" in s:
            start_npcs += [int(x) for x in re.findall(r"\[npc=(\d+)\]", s)]
            start_objs += [int(x) for x in re.findall(r"\[object=(\d+)\]", s)]
        if "quest_end" in s or "End:" in s:
            end_npcs += [int(x) for x in re.findall(r"\[npc=(\d+)\]", s)]
            end_objs += [int(x) for x in re.findall(r"\[object=(\d+)\]", s)]

    # Fallback: all npc/object links on page
    all_npcs = [int(x) for x in re.findall(r"\?npc=(\d+)", html)]
    all_objs = [int(x) for x in re.findall(r"\?object=(\d+)", html)]
    if not start_npcs and not start_objs and all_npcs:
        # Heuristic: first is often giver when markup missing
        start_npcs = list(dict.fromkeys(all_npcs))[:3]
        end_npcs = list(dict.fromkeys(all_npcs))[:3]
    if not start_objs and all_objs:
        start_objs = list(dict.fromkeys(all_objs))[:5]
        if not end_objs:
            end_objs = start_objs[:]

    # Objective NPCs from g_npcs block
    m = re.search(r"var _ = g_npcs;([^;]+);", html)
    if m:
        obj_npcs = [int(x) for x in re.findall(r"_\[(\d+)\]", m.group(1))]

    # Level from power tooltip text
    lvl = None
    m = re.search(r"Level\s+(\d+)", power)
    if m:
        lvl = int(m.group(1))

    def uniq(seq):
        return list(dict.fromkeys(seq))

    return {
        "id": quest_id,
        "name": name,
        "lvl": lvl,
        "start_u": uniq(start_npcs),
        "end_u": uniq(end_npcs) or uniq(start_npcs),
        "start_o": uniq(start_objs),
        "end_o": uniq(end_objs) or uniq(start_objs),
        "obj_u": uniq(obj_npcs),
    }


def fetch_unit_coords(unit_id: int) -> dict:
    power = fetch(f"{BASE}/?npc={unit_id}&power=true")
    time.sleep(0.1)
    name, coords, zone = parse_power_map(power)
    if not coords or not zone:
        try:
            html = fetch(f"{BASE}/?npc={unit_id}")
            time.sleep(0.1)
            mapper = parse_mapper_data(html)
            if mapper:
                zone = next(iter(mapper.keys()))
                coords = mapper[zone]
            if not name:
                m = re.search(r'"name_enus":\s*"([^"]+)"', html)
                if m:
                    name = m.group(1)
        except Exception:
            pass
    return {"id": unit_id, "name": name, "zone": zone, "coords": coords or []}


def fetch_object_coords(obj_id: int) -> dict:
    power = fetch(f"{BASE}/?object={obj_id}&power=true")
    time.sleep(0.1)
    name, coords, zone = parse_power_map(power)
    if not coords or not zone:
        try:
            html = fetch(f"{BASE}/?object={obj_id}")
            time.sleep(0.1)
            mapper = parse_mapper_data(html)
            if mapper:
                zone = next(iter(mapper.keys()))
                coords = mapper[zone]
        except Exception:
            pass
    return {"id": obj_id, "name": name, "zone": zone, "coords": coords or []}


def load_bundle_quest_ids(bundle_root: Path) -> set[int]:
    ids: set[int] = set()
    for f in bundle_root.rglob("*.lua"):
        if "quest" not in f.name.lower() and "seed" not in f.name.lower():
            continue
        text = f.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"\[(\d{1,7})\]\s*=\s*\{", text):
            ids.add(int(m.group(1)))
    return ids


def lua_coords(coords: list[tuple[float, float]], zone: int) -> str:
    parts = []
    for i, (x, y) in enumerate(coords[:12], 1):
        parts.append(f"[{i}]={{{x:.2f},{y:.2f},{zone},0}}")
    return "{" + ",".join(parts) + "}"


def emit_lua(
    quests: dict[int, dict],
    units: dict[int, dict],
    objects: dict[int, dict],
    out_dir: Path,
) -> None:
    # Quests
    q_lines = [
        "-- Auto-generated by tools/ascension_coord_importer.py",
        "-- Quest start/end linkage from db.ascension.gg",
        "pfDB = pfDB or {}",
        'pfDB["quests"] = pfDB["quests"] or {}',
        'pfDB["quests"]["data-imported"] = pfDB["quests"]["data-imported"] or {}',
        'pfDB["quests"]["loc-imported"] = pfDB["quests"]["loc-imported"] or {}',
        "local data = pfDB[\"quests\"][\"data-imported\"]",
        "local loc = pfDB[\"quests\"][\"loc-imported\"]",
    ]
    for qid, q in sorted(quests.items()):
        parts = []
        if q.get("start_u"):
            parts.append(
                '["start"]={["U"]={' + ",".join(str(x) for x in q["start_u"]) + "},}"
            )
        if q.get("end_u"):
            parts.append(
                '["end"]={["U"]={' + ",".join(str(x) for x in q["end_u"]) + "},}"
            )
        if q.get("start_o"):
            # merge into start
            so = ",".join(str(x) for x in q["start_o"])
            if q.get("start_u"):
                # rewrite start with O
                parts = [p for p in parts if not p.startswith('["start"]')]
                u = ",".join(str(x) for x in q["start_u"])
                parts.insert(0, f'[\"start\"]={{[\"U\"]={{{u}}},[\"O\"]={{{so}}},}}')
            else:
                parts.append(f'[\"start\"]={{[\"O\"]={{{so}}},}}')
        if q.get("end_o"):
            eo = ",".join(str(x) for x in q["end_o"])
            if q.get("end_u"):
                parts = [p for p in parts if not p.startswith('["end"]')]
                u = ",".join(str(x) for x in q["end_u"])
                parts.append(f'[\"end\"]={{[\"U\"]={{{u}}},[\"O\"]={{{eo}}},}}')
            else:
                parts.append(f'[\"end\"]={{[\"O\"]={{{eo}}},}}')
        if q.get("obj_u"):
            parts.append(
                '["obj"]={["U"]={' + ",".join(str(x) for x in q["obj_u"][:20]) + "},}"
            )
        if q.get("lvl"):
            parts.append(f'[\"lvl\"]={q["lvl"]}')
        if parts:
            q_lines.append(f"data[{qid}]={{{','.join(parts)}}}")
        if q.get("name"):
            safe = q["name"].replace("\\", "\\\\").replace('"', '\\"')
            q_lines.append(f'loc[{qid}]={{["T"]="{safe}"}}')
    q_lines.append("")
    (out_dir / "imported-quest-coords.lua").write_text(
        "\n".join(q_lines) + "\n", encoding="utf-8"
    )

    # Units
    u_lines = [
        "-- Auto-generated unit coords from db.ascension.gg",
        "pfDB = pfDB or {}",
        'pfDB["units"] = pfDB["units"] or {}',
        'pfDB["units"]["data-imported"] = pfDB["units"]["data-imported"] or {}',
        'pfDB["units"]["loc-imported"] = pfDB["units"]["loc-imported"] or {}',
        "local data = pfDB[\"units\"][\"data-imported\"]",
        "local loc = pfDB[\"units\"][\"loc-imported\"]",
    ]
    for uid, u in sorted(units.items()):
        if u.get("coords") and u.get("zone"):
            u_lines.append(
                f"data[{uid}]={{[\"coords\"]={lua_coords(u['coords'], u['zone'])}}}"
            )
        if u.get("name"):
            safe = u["name"].replace("\\", "\\\\").replace('"', '\\"')
            u_lines.append(f'loc[{uid}]={{["T"]="{safe}"}}')
    u_lines.append("")
    (out_dir / "imported-unit-coords.lua").write_text(
        "\n".join(u_lines) + "\n", encoding="utf-8"
    )

    # Objects
    o_lines = [
        "-- Auto-generated object coords from db.ascension.gg",
        "pfDB = pfDB or {}",
        'pfDB["objects"] = pfDB["objects"] or {}',
        'pfDB["objects"]["data-imported"] = pfDB["objects"]["data-imported"] or {}',
        'pfDB["objects"]["loc-imported"] = pfDB["objects"]["loc-imported"] or {}',
        "local data = pfDB[\"objects\"][\"data-imported\"]",
        "local loc = pfDB[\"objects\"][\"loc-imported\"]",
        ]
    for oid, o in sorted(objects.items()):
        if o.get("coords") and o.get("zone"):
            o_lines.append(
                f"data[{oid}]={{[\"coords\"]={lua_coords(o['coords'], o['zone'])}}}"
            )
        if o.get("name"):
            safe = o["name"].replace("\\", "\\\\").replace('"', '\\"')
            o_lines.append(f'loc[{oid}]={{["T"]="{safe}"}}')
    o_lines.append("")
    (out_dir / "imported-object-coords.lua").write_text(
        "\n".join(o_lines) + "\n", encoding="utf-8"
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--fix-units", type=str, default="")
    ap.add_argument("--fix-quests", type=str, default="")
    args = ap.parse_args()

    tools = Path(__file__).resolve().parent
    addon = tools.parent
    out_dir = addon / "bundled-db" / "ascension"
    out_dir.mkdir(parents=True, exist_ok=True)
    progress_path = tools / "coord_import_progress.json"

    progress = {
        "quests": {},
        "units": {},
        "objects": {},
        "done_quests": [],
        "failed_quests": [],
    }
    if args.resume and progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding="utf-8"))
        print(f"Resumed: {len(progress.get('done_quests', []))} quests already done")

    # Force unit path
    if args.fix_units:
        for uid in [int(x) for x in args.fix_units.split(",") if x.strip()]:
            print(f"Unit {uid} ...")
            try:
                progress["units"][str(uid)] = fetch_unit_coords(uid)
                print(" ", progress["units"][str(uid)])
            except Exception as e:
                print("  FAIL", e)
        emit_lua(
            {int(k): v for k, v in progress["quests"].items()},
            {int(k): v for k, v in progress["units"].items()},
            {int(k): v for k, v in progress["objects"].items()},
            out_dir,
        )
        progress_path.write_text(json.dumps(progress), encoding="utf-8")
        return 0

    server_path = out_dir / "server_quest_ids.json"
    if not server_path.exists():
        print("Run ascension_quest_importer.py first (need server_quest_ids.json)")
        return 1
    server_ids = set(json.loads(server_path.read_text(encoding="utf-8")))
    bundle_ids = load_bundle_quest_ids(addon / "bundled-db")
    # Prefer missing, but also re-import known bad classic coords for force list
    targets = sorted(server_ids - bundle_ids)
    if args.fix_quests:
        targets = [int(x) for x in args.fix_quests.split(",") if x.strip()]
    # Always include a few high-value classic fixes when doing full run
    priority = [372, 371, 370, 254053, 254054]
    targets = [q for q in priority if q in server_ids] + [
        q for q in targets if q not in priority
    ]

    done = set(progress.get("done_quests") or [])
    targets = [q for q in targets if q not in done]
    if args.limit > 0:
        targets = targets[: args.limit]

    print(f"Importing coords for {len(targets)} quests ...")
    for i, qid in enumerate(targets, 1):
        try:
            q = parse_quest_page(qid)
            progress["quests"][str(qid)] = q
            progress["done_quests"].append(qid)
            # fetch units/objects
            for uid in (q.get("start_u") or []) + (q.get("end_u") or []) + (q.get("obj_u") or []):
                if str(uid) not in progress["units"]:
                    try:
                        progress["units"][str(uid)] = fetch_unit_coords(uid)
                    except Exception as e:
                        progress["units"][str(uid)] = {"id": uid, "error": str(e)}
            for oid in (q.get("start_o") or []) + (q.get("end_o") or []):
                if str(oid) not in progress["objects"]:
                    try:
                        progress["objects"][str(oid)] = fetch_object_coords(oid)
                    except Exception as e:
                        progress["objects"][str(oid)] = {"id": oid, "error": str(e)}
            if i % 10 == 0 or i == 1:
                print(
                    f"  [{i}/{len(targets)}] quest {qid} "
                    f"{q.get('name')} start_u={q.get('start_u')} coords_units="
                    f"{sum(1 for u in progress['units'].values() if u.get('coords'))}"
                )
                progress_path.write_text(json.dumps(progress), encoding="utf-8")
                emit_lua(
                    {int(k): v for k, v in progress["quests"].items()},
                    {int(k): v for k, v in progress["units"].items()},
                    {int(k): v for k, v in progress["objects"].items()},
                    out_dir,
                )
        except Exception as e:
            progress.setdefault("failed_quests", []).append({"id": qid, "err": str(e)})
            print(f"  FAIL quest {qid}: {e}")
            progress_path.write_text(json.dumps(progress), encoding="utf-8")

    emit_lua(
        {int(k): v for k, v in progress["quests"].items()},
        {int(k): v for k, v in progress["units"].items()},
        {int(k): v for k, v in progress["objects"].items()},
        out_dir,
    )
    progress_path.write_text(json.dumps(progress), encoding="utf-8")
    print(
        f"Done. Quests={len(progress['quests'])} "
        f"Units={len(progress['units'])} Objects={len(progress['objects'])} "
        f"Failed={len(progress.get('failed_quests') or [])}"
    )
    print(f"Wrote {out_dir}/imported-*-coords.lua")
    return 0


if __name__ == "__main__":
    sys.exit(main())
