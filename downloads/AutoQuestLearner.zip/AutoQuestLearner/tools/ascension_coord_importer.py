#!/usr/bin/env python3
"""
AscensionDB  ->  AutoQuestLearner NPC / object COORDINATE importer

Source (the site's "Creatures" search):
  https://ascension-db.ascension-archive.workers.dev/#search?kind=npc

Reads the archive's NPC records (each lists Map | Area | Coords | Spawns rows
with real AreaTable ids) and writes:
  bundled-db/wowhead/imported-unit-coords.lua     unit id -> coords (+ names)
  bundled-db/wowhead/imported-object-coords.lua   object id -> coords (+ names)
  tools/coord_import_progress.json                resume state
(the .toc already loads the imported-*.lua files).

Quest givers/objectives come from ascension_quest_importer.py --emit-quests
(the site's kind=quest search). Run that one after this if you want both; they
write different files.

Default maps: Eastern Kingdoms + Kalimdor (the server is vanilla-locked).
Add --include-expansion for Outland + Northrend. Instance maps are skipped
(the archive's instance coordinates are unverified).

Usage (from the tools dir):
  python3 ascension_coord_importer.py
  python3 ascension_coord_importer.py --resume            # merge with earlier run
  python3 ascension_coord_importer.py --no-objects        # NPCs only
  python3 ascension_coord_importer.py --limit 2000        # quick test
  python3 ascension_coord_importer.py --out-dir ./test    # don't touch addon files
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import multi_source_importer as msi


def main() -> int:
    ap = argparse.ArgumentParser(description="Import NPC/object coordinates from AscensionDB")
    ap.add_argument("--resume", action="store_true",
                    help="Merge with the previous run's progress file")
    ap.add_argument("--no-objects", action="store_true", help="NPCs only")
    ap.add_argument("--include-expansion", action="store_true",
                    help="Also import Outland + Northrend")
    ap.add_argument("--limit", type=int, default=0,
                    help="Only read the first N NPC records (testing)")
    ap.add_argument("--out-dir", type=Path, default=None,
                    help="Write Lua here instead of bundled-db/wowhead")
    ap.add_argument("--site", default=msi.ADB_SITE, help="AscensionDB site URL")
    ap.add_argument("--adb-base", default="", help="Override data snapshot URL")
    args = ap.parse_args()

    tools = Path(__file__).resolve().parent
    addon = tools.parent
    out_dir = args.out_dir or (addon / "bundled-db" / "wowhead")
    out_dir.mkdir(parents=True, exist_ok=True)
    progress_path = tools / "coord_import_progress.json"

    progress = {"quests": {}, "units": {}, "objects": {},
                "done_quests": [], "failed_quests": [], "source": "ascensiondb"}
    if args.resume and progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding="utf-8"))
        print(f"Resumed ({len(progress.get('units', {}))} units in progress file)")

    # `args` doubles as the namespace run_ascensiondb expects
    args.adb_site = args.site
    args.mode = "units"
    args.only = {"units"} if args.no_objects else {"units", "objects"}
    print("=== AscensionDB coordinate importer (kind=npc) ===")
    return msi.run_ascensiondb(args, addon, out_dir, progress, progress_path)


if __name__ == "__main__":
    sys.exit(main())
