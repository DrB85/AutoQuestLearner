AutoQuestLearner data importers
================================

Wowhead (Classic + TBC + WotLK) — recommended now that Ascension DB is down
---------------------------------------------------------------------------
cd to your tools folder, then:

  python multi_source_importer.py --source wowhead --client all --force-units 1665,1515,1660

  # Bulk (if you have server_quest_ids.json):
  python multi_source_importer.py --source wowhead --client all --mode coords --ids-file ..\bundled-db\ascension\server_quest_ids.json --resume

--client all   = pulls classic + tbc + wotlk dataEnv and merges coords (default)
--client classic | tbc | wotlk | cata  = single expansion only

Outputs: bundled-db/ascension/imported-*-coords.lua
Then copy addon to Interface/AddOns and /reload in game.

The two dedicated importers (run from this tools folder)
--------------------------------------------------------
QUESTS  - site search  .../#search?kind=quest
  python ascension_quest_importer.py                 whitelist + cross-check report
  python ascension_quest_importer.py --emit-quests   also quest givers/objectives
  Writes bundled-db/ascension/server-quest-whitelist.lua (+ .json, + report) and,
  with --emit-quests, bundled-db/wowhead/imported-quest-coords.lua.
  The whitelist is MERGED with your existing one so quests from earlier live-server
  harvests are not dropped; add --replace-whitelist to use the archive list only.

COORDS  - site search  .../#search?kind=npc
  python ascension_coord_importer.py                 NPC + object coordinates
  python ascension_coord_importer.py --no-objects    NPCs only
  python ascension_coord_importer.py --include-expansion   add Outland/Northrend
  Writes bundled-db/wowhead/imported-unit-coords.lua and imported-object-coords.lua.
  Default maps: Eastern Kingdoms + Kalimdor (vanilla-locked). Instances are skipped.

Both accept --limit N (quick test), --out-dir DIR (don't touch addon files).
Each takes roughly 1-2 minutes. multi_source_importer.py (below) does both in one go.

AscensionDB preservation archive  (NEW - no id list needed)
-----------------------------------------------------------
Source: https://ascension-db.ascension-archive.workers.dev/
(community archive of Exiles DB, addon observations and client captures;
data published at github.com/hertigservices/ascension-data)

  python multi_source_importer.py            (default source = this site)
  python multi_source_importer.py --source ascensiondb --mode coords

  --mode coords   NPC + object coordinates, quest start/end givers and
                  objectives (creature / object / item requirements)
  --mode units    NPC + object coordinates only
  --mode quests   write the archive's quest id list (server whitelist)
  --limit N       test run: first N atlas zones / N quests
  --out-dir DIR   write Lua here instead of bundled-db/wowhead
  --adb-base URL  force a data snapshot (e.g. the GitHub Pages mirror
                  https://hertigservices.github.io/ascension-data/)
  --resume        keep earlier results and merge new coordinates into them

How it works: reads the same snapshot the website uses (config.json ->
catalog/current.json -> atlas-manifest.json.gz, atlas/*.json.gz and the
Exiles quest records). Outdoor zones only (percent coordinates); each spawn is
tagged with its own zone id, so NPCs that appear in several zones keep all of
them. Zone names are mapped to ids using bundled-db/enUS/zones*.lua; atlas
zones with no match (mostly WotLK) are listed at the end and skipped.
Coordinates are archive "claims" (Exiles DB website data), whole-percent
precision - same quality as the db.exil.es scrape. Takes about 2 minutes.

Outputs: bundled-db/wowhead/imported-{quest,unit,object}-coords.lua (already
in the .toc). Same files/namespace as the Wowhead source, so run one source at a
time or use --resume to combine.

AoWoW (other private server DBs still online)
---------------------------------------------
  python multi_source_importer.py --source aowow --base https://THEIR-DB-URL --mode quests
  python multi_source_importer.py --source aowow --base https://THEIR-DB-URL --mode coords --resume
