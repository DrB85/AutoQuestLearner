#!/usr/bin/env python3
"""
Multi-source quest/NPC coordinate importer for AutoQuestLearner.

Sources:
  aowow     – Any AoWoW-style site (Ascension, private-server DBs, etc.)
  wowhead   – Wowhead via nether.wowhead.com tooltip JSON (Classic/TBC/WotLK)
  ascensiondb – AscensionDB preservation archive
              (https://ascension-db.ascension-archive.workers.dev/): Exiles DB
              NPC/object coordinates, quest givers and objectives. No id list needed.

Icy Veins is a *guide* site (articles), not a structured quest/NPC coordinate
database — it is not a supported bulk source.

Examples:
  # Last days of Ascension – finish harvesting their AoWoW
  python multi_source_importer.py --source aowow --base https://db.ascension.gg --mode quests
  python multi_source_importer.py --source aowow --base https://db.ascension.gg --mode coords --limit 200

  # After Ascension – stock classic/WotLK coords from Wowhead
  python multi_source_importer.py --source wowhead --client wotlk --mode coords --limit 200
  python multi_source_importer.py --source wowhead --client classic --force-units 1665,1515,1660

  # Another private server running AoWoW
  python multi_source_importer.py --source aowow --base https://their-db.example.com --mode quests

Outputs (under bundled-db/wowhead/):
  server-quest-whitelist.lua / server_quest_ids.json   (mode=quests)
  imported-quest-coords.lua, imported-unit-coords.lua,
  imported-object-coords.lua                           (mode=coords)
  tools/coord_import_progress.json                     (resume)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

UA = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
}

# Wowhead nether tooltip dataEnv (observed; may shift over time)
WOWHEAD_DATAENV = {
    "classic": 2,   # Era / classic stock
    "tbc": 3,
    "wotlk": 4,     # Wrath-era data (best default for 3.3.5 private servers)
    "cata": 5,
}

def data_envs_for_client(client: str) -> list[tuple[str, int]]:
    """Return (label, dataEnv) pairs to query."""
    if client == "all":
        # Classic + TBC + WotLK (skip cata unless explicitly requested)
        return [("classic", WOWHEAD_DATAENV["classic"]),
                ("tbc", WOWHEAD_DATAENV["tbc"]),
                ("wotlk", WOWHEAD_DATAENV["wotlk"])]
    return [(client, WOWHEAD_DATAENV[client])]


def merge_unit_results(results: list[dict]) -> dict:
    """Merge multi-env unit fetches: prefer first non-empty name/zone, union coords."""
    out = {"id": None, "name": None, "zone": None, "coords": [], "envs": []}
    seen = set()
    for r in results:
        if not r:
            continue
        out["id"] = r.get("id") or out["id"]
        if r.get("name") and not out["name"]:
            out["name"] = r["name"]
        if r.get("zone") and not out["zone"]:
            out["zone"] = r["zone"]
        if r.get("env"):
            out["envs"].append(r["env"])
        for x, y in (r.get("coords") or []):
            key = (round(float(x), 1), round(float(y), 1))
            if key not in seen:
                seen.add(key)
                out["coords"].append((float(x), float(y)))
    return out


def wowhead_fetch_unit_multi(unit_id: int, client: str) -> dict:
    results = []
    for label, env in data_envs_for_client(client):
        try:
            u = wowhead_fetch_unit(unit_id, env)
            u["env"] = label
            results.append(u)
        except Exception:
            pass
    return merge_unit_results(results)


def wowhead_fetch_object_multi(obj_id: int, client: str) -> dict:
    results = []
    for label, env in data_envs_for_client(client):
        try:
            o = wowhead_fetch_object(obj_id, env)
            o["env"] = label
            results.append(o)
        except Exception:
            pass
    return merge_unit_results(results)


def wowhead_parse_quest_multi(quest_id: int, client: str) -> dict:
    best = None
    for label, env in data_envs_for_client(client):
        try:
            q = wowhead_parse_quest(quest_id, env)
            q["env"] = label
            if q.get("name"):
                best = q
                if q.get("lvl"):
                    break
        except Exception:
            continue
    return best or {"id": quest_id, "name": None, "lvl": None, "exp": "classic",
                    "start_u": [], "end_u": [], "start_o": [], "end_o": [], "obj_u": []}


AOWOW_CATEGORY_PATHS = [
    "?quests", "?quests=0", "?quests=1", "?quests=2", "?quests=3",
    "?quests=4", "?quests=5", "?quests=6", "?quests=7", "?quests=8",
    "?quests=9", "?quests=-2",
]
AOWOW_LEVEL_BANDS = [
    (1, 10), (11, 20), (21, 30), (31, 40), (41, 50),
    (51, 55), (56, 60), (61, 63), (64, 66), (67, 68), (69, 70),
    (71, 72), (73, 74), (75, 76), (77, 78), (79, 80),
]


def fetch(url: str, retries: int = 3) -> str:
    err: Exception | None = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=45) as resp:
                return resp.read().decode("utf-8", "replace")
        except Exception as e:
            err = e
            time.sleep(0.5 * (i + 1))
    raise RuntimeError(f"{url}: {err}")


def fetch_json(url: str) -> dict:
    return json.loads(fetch(url))


def quest_expansion(lvl) -> str:
    try:
        lvl = int(lvl)
    except (TypeError, ValueError):
        return "classic"
    if lvl >= 71:
        return "wotlk"
    if lvl >= 61:
        return "tbc"
    return "classic"


# ---------------------------------------------------------------------------
# AoWoW source
# ---------------------------------------------------------------------------

def aowow_extract_listview_ids(html: str) -> set[int]:
    ids: set[int] = set()
    for m in re.finditer(
        r'\{[^{}]*"id":(\d+)[^{}]*"name":"[^"]*"[^{}]*\}', html
    ):
        qid = int(m.group(1))
        if qid > 0:
            ids.add(qid)
    if not ids:
        for m in re.finditer(r'"id":(\d+)', html):
            qid = int(m.group(1))
            if 1 <= qid <= 9_999_999:
                ids.add(qid)
    return ids


def aowow_harvest_quest_ids(base: str, verbose: bool = True) -> set[int]:
    base = base.rstrip("/")
    all_ids: set[int] = set()
    for path in AOWOW_CATEGORY_PATHS:
        url = f"{base}/{path}"
        try:
            found = aowow_extract_listview_ids(fetch(url))
            if verbose:
                print(f"  {path}: {len(found)}")
            all_ids |= found
            time.sleep(0.25)
        except Exception as e:
            if verbose:
                print(f"  {path}: SKIP ({e})")
    for lo, hi in AOWOW_LEVEL_BANDS:
        url = f"{base}/?quests&filter=minle={lo};maxle={hi}"
        try:
            found = aowow_extract_listview_ids(fetch(url))
            if verbose:
                print(f"  levels {lo}-{hi}: {len(found)}")
            all_ids |= found
            time.sleep(0.25)
        except Exception as e:
            if verbose:
                print(f"  levels {lo}-{hi}: SKIP ({e})")
    return all_ids


def aowow_parse_power_map(power: str):
    name = None
    m = re.search(r'"name_enus":\s*"([^"]+)"', power)
    if m:
        name = m.group(1)
    zone = None
    m = re.search(r'"zone":\s*(\d+)', power)
    if m:
        zone = int(m.group(1))
    coords: list[tuple[float, float]] = []
    m = re.search(r'"coords"\s*:\s*(\[[\s\S]*?\])\s*\n?\s*\}', power)
    if m:
        try:
            arr = json.loads(m.group(1))

            def walk(node):
                if isinstance(node, list):
                    if (
                        len(node) >= 2
                        and isinstance(node[0], (int, float))
                        and isinstance(node[1], (int, float))
                    ):
                        coords.append((float(node[0]), float(node[1])))
                    else:
                        for c in node:
                            walk(c)

            walk(arr)
        except json.JSONDecodeError:
            for xm, ym in re.findall(
                r"\[\s*(\d+\.?\d*)\s*,\s*(\d+\.?\d*)\s*\]", m.group(1)
            ):
                coords.append((float(xm), float(ym)))
    seen, uniq = set(), []
    for x, y in coords:
        key = (round(x, 1), round(y, 1))
        if key not in seen:
            seen.add(key)
            uniq.append((x, y))
    return name, uniq, zone


def aowow_fetch_unit(base: str, unit_id: int) -> dict:
    base = base.rstrip("/")
    power = fetch(f"{base}/?npc={unit_id}&power=true")
    time.sleep(0.12)
    name, coords, zone = aowow_parse_power_map(power)
    return {"id": unit_id, "name": name, "zone": zone, "coords": coords or []}


def aowow_fetch_object(base: str, obj_id: int) -> dict:
    base = base.rstrip("/")
    power = fetch(f"{base}/?object={obj_id}&power=true")
    time.sleep(0.12)
    name, coords, zone = aowow_parse_power_map(power)
    return {"id": obj_id, "name": name, "zone": zone, "coords": coords or []}


def aowow_parse_quest(base: str, quest_id: int) -> dict:
    base = base.rstrip("/")
    html = fetch(f"{base}/?quest={quest_id}")
    power = fetch(f"{base}/?quest={quest_id}&power=true")
    time.sleep(0.12)
    name = None
    m = re.search(r'"name_enus":\s*"([^"]+)"', power)
    if m:
        name = m.group(1)
    lvl = None
    m = re.search(r"Level\s+(\d+)", power)
    if m:
        lvl = int(m.group(1))
    start_npcs, end_npcs, start_objs, end_objs = [], [], [], []
    for mm in re.finditer(r'Markup\.printHtml\("([^"]*)"', html):
        s = mm.group(1).replace("\\/", "/")
        if "quest_start" in s or "Start:" in s:
            start_npcs += [int(x) for x in re.findall(r"\[npc=(\d+)\]", s)]
            start_objs += [int(x) for x in re.findall(r"\[object=(\d+)\]", s)]
        if "quest_end" in s or "End:" in s:
            end_npcs += [int(x) for x in re.findall(r"\[npc=(\d+)\]", s)]
            end_objs += [int(x) for x in re.findall(r"\[object=(\d+)\]", s)]
    all_npcs = [int(x) for x in re.findall(r"\?npc=(\d+)", html)]
    if not start_npcs and all_npcs:
        start_npcs = list(dict.fromkeys(all_npcs))[:3]
        end_npcs = start_npcs[:]
    def uniq(s):
        return list(dict.fromkeys(s))
    return {
        "id": quest_id,
        "name": name,
        "lvl": lvl,
        "exp": quest_expansion(lvl),
        "start_u": uniq(start_npcs),
        "end_u": uniq(end_npcs) or uniq(start_npcs),
        "start_o": uniq(start_objs),
        "end_o": uniq(end_objs) or uniq(start_objs),
        "obj_u": [],
    }


# ---------------------------------------------------------------------------
# Wowhead (nether tooltip JSON)
# ---------------------------------------------------------------------------

def wowhead_tooltip(kind: str, entity_id: int, data_env: int) -> dict:
    url = (
        f"https://nether.wowhead.com/tooltip/{kind}/{entity_id}"
        f"?dataEnv={data_env}&locale=0"
    )
    return fetch_json(url)


def wowhead_parse_map(blob: dict) -> tuple[list[tuple[float, float]], int | None]:
    m = blob.get("map") or {}
    zone = m.get("zone")
    if zone is not None:
        zone = int(zone)
    coords: list[tuple[float, float]] = []
    raw = m.get("coords") or {}
    # {"0": [[x,y], ...], "1": ...} or nested lists
    if isinstance(raw, dict):
        for _floor, pts in raw.items():
            if isinstance(pts, list):
                for p in pts:
                    if isinstance(p, list) and len(p) >= 2:
                        coords.append((float(p[0]), float(p[1])))
    elif isinstance(raw, list):
        def walk(node):
            if isinstance(node, list):
                if (
                    len(node) >= 2
                    and isinstance(node[0], (int, float))
                    and isinstance(node[1], (int, float))
                ):
                    coords.append((float(node[0]), float(node[1])))
                else:
                    for c in node:
                        walk(c)
        walk(raw)
    seen, uniq = set(), []
    for x, y in coords:
        key = (round(x, 1), round(y, 1))
        if key not in seen:
            seen.add(key)
            uniq.append((x, y))
    return uniq, zone


def wowhead_fetch_unit(unit_id: int, data_env: int) -> dict:
    blob = wowhead_tooltip("npc", unit_id, data_env)
    time.sleep(0.12)
    coords, zone = wowhead_parse_map(blob)
    return {
        "id": unit_id,
        "name": blob.get("name"),
        "zone": zone,
        "coords": coords,
    }


def wowhead_fetch_object(obj_id: int, data_env: int) -> dict:
    blob = wowhead_tooltip("object", obj_id, data_env)
    time.sleep(0.12)
    coords, zone = wowhead_parse_map(blob)
    return {
        "id": obj_id,
        "name": blob.get("name"),
        "zone": zone,
        "coords": coords,
    }


def wowhead_parse_quest(quest_id: int, data_env: int) -> dict:
    blob = wowhead_tooltip("quest", quest_id, data_env)
    time.sleep(0.12)
    name = blob.get("name")
    tip = blob.get("tooltip") or ""
    lvl = None
    m = re.search(r"Level\s+(\d+)", tip)
    if m:
        lvl = int(m.group(1))
    # Tooltip rarely has numeric NPC ids; name-only objectives
    return {
        "id": quest_id,
        "name": name,
        "lvl": lvl,
        "exp": quest_expansion(lvl),
        "start_u": [],
        "end_u": [],
        "start_o": [],
        "end_o": [],
        "obj_u": [],
        "tooltip": re.sub(r"<[^>]+>", " ", tip)[:200],
    }


# ---------------------------------------------------------------------------
# Lua emitters (shared)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# AscensionDB preservation archive source
#   https://ascension-db.ascension-archive.workers.dev/
#
# The site is a static single-page app; it reads gzip-compressed JSON snapshots
# published by the archive (config.json -> catalog/current.json -> manifest).
# We read the same files directly:
#   atlas-manifest.json.gz      list of map zones (space: percent/reported/...)
#   atlas/<hash>.json.gz        per-zone coordinate observations (NPCs/objects)
#   records/<fid>/<n>.json.gz   500 raw records per part (quests, NPCs, ...)
# Coordinates are Exiles DB "claims" plus addon observations: community
# evidence, not verified live-game spawns, so they are labelled as such.
# ---------------------------------------------------------------------------

ADB_SITE = "https://ascension-db.ascension-archive.workers.dev/"
ADB_FALLBACK_DATA = "https://hertigservices.github.io/ascension-data/"
# Layers holding NPC / object positions. Loot-pin layers (worldforged, mystic,
# other-loot) are player positions when a loot window opened, not spawns.
ADB_ATLAS_LAYERS = {
    "npc-claims", "quest-givers", "vendors", "creatures", "objects",
}
# Atlas zone names that differ from the addon's zone-name tables.
ADB_ZONE_ALIASES = {
    "ogrimmar": "orgrimmar",
    "aszhara": "azshara",
    "hrothgarslanding": "hrothgar'slanding",
    "hilsbrad": "hillsbradfoothills",
    "darnassis": "darnassus",
}


def fetch_bytes(url: str, retries: int = 3) -> bytes:
    err: Exception | None = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.read()
        except urllib.error.HTTPError as e:
            if e.code in (404, 410):
                raise
            err = e
        except Exception as e:
            err = e
        time.sleep(0.5 * (i + 1))
    raise RuntimeError(f"{url}: {err}")


def adb_gz_json(base: str, path: str):
    import gzip
    raw = fetch_bytes(base + path)
    try:
        raw = gzip.decompress(raw)
    except OSError:
        pass  # already decompressed by the transport
    return json.loads(raw.decode("utf-8"))


def adb_resolve_base(site: str, override: str = "") -> str:
    """Find the current published snapshot, mirroring what the web app does."""
    if override:
        return override.rstrip("/") + "/"
    try:
        cfg = fetch_json(site.rstrip("/") + "/config.json")
        service = (cfg.get("catalogService") or "").rstrip("/") + "/"
        if cfg.get("catalogService"):
            cur = fetch_json(service + "catalog/current.json")
            if cur.get("schema") == "ascension-current-1" and cur.get("prefix"):
                base = service + cur["prefix"]
                fetch_bytes(base + "manifest.json")  # reachable?
                return base
        if cfg.get("dataBase"):
            return cfg["dataBase"].rstrip("/") + "/"
    except Exception as e:
        print(f"  (catalog lookup failed: {e}; using GitHub Pages mirror)")
    return ADB_FALLBACK_DATA


def _adb_norm(name: str) -> str:
    return re.sub(r"[^a-z0-9']", "", (name or "").lower().replace("’", "'"))


def adb_zone_name_map(addon: Path) -> dict[str, int]:
    """Zone name -> AreaTable id from the addon's own bundled zone tables."""
    out: dict[str, int] = {}
    for rel in ("bundled-db/enUS/zones.lua", "bundled-db/enUS/zones-tbc.lua"):
        p = addon / rel
        if not p.exists():
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r'\[(\d+)\]="((?:[^"\\]|\\.)*)"', text):
            zid = int(m.group(1))
            key = _adb_norm(m.group(2).replace("\\'", "'"))
            if key and (key not in out or zid < out[key]):
                out[key] = zid  # duplicates: lowest id is the outdoor zone
    return out


def adb_collect_atlas(base: str, zone_ids: dict[str, int], limit: int = 0,
                      maps: set | None = None, entities: set | None = None):
    """Return (units, objects, report) built from the atlas coordinate layers."""
    atlas = adb_gz_json(base, "atlas-manifest.json.gz")
    units: dict[int, dict] = {}
    objects: dict[int, dict] = {}
    skipped: dict[str, int] = {}
    zones = [
        z for z in atlas.get("zones", [])
        if z.get("space") == "percent" and z.get("file")
        and set((z.get("layers") or {}).keys()) & ADB_ATLAS_LAYERS
        and (maps is None or str(z.get("map")) in maps)
    ]
    if limit > 0:
        zones = zones[:limit]
    print(f"Atlas: {len(zones)} outdoor zones with NPC/object layers")
    for n, z in enumerate(zones, 1):
        key = _adb_norm(z.get("name"))
        key = ADB_ZONE_ALIASES.get(key, key)
        zid = zone_ids.get(key)
        if not zid:
            skipped[z.get("name") or "?"] = z.get("count", 0)
            continue
        try:
            rows = adb_gz_json(base, z["file"])
        except Exception as e:
            print(f"  FAIL zone {z.get('name')}: {e}")
            continue
        for r in rows:
            if r.get("layer") not in ADB_ATLAS_LAYERS:
                continue
            ent = r.get("entity")
            if entities is not None and ent not in entities:
                continue
            if ent == "npc":
                bucket = units
            elif ent == "gameobject":
                bucket = objects
            else:
                continue
            try:
                eid = int(r["id"])
                x, y = float(r["x"]), float(r["y"])
            except (KeyError, TypeError, ValueError):
                continue
            if not (0 <= x <= 100 and 0 <= y <= 100):
                continue
            rec = bucket.setdefault(
                eid, {"id": eid, "name": r.get("name"), "zone": zid,
                      "coords": [], "src": set()}
            )
            if not rec.get("name"):
                rec["name"] = r.get("name")
            pt = (round(x, 1), round(y, 1), zid)
            if pt not in rec["coords"]:
                rec["coords"].append(pt)
            rec["src"].add(r.get("source") or "")
        if n % 25 == 0:
            print(f"  [{n}/{len(zones)}] units={len(units)} objects={len(objects)}")
    for rec in list(units.values()) + list(objects.values()):
        rec["src"] = sorted(rec["src"])
        # most common zone first, so the single "zone" field stays meaningful
        zc: dict[int, int] = {}
        for c in rec["coords"]:
            zc[c[2]] = zc.get(c[2], 0) + 1
        rec["zone"] = max(zc, key=zc.get)
    return units, objects, skipped


ADB_VANILLA_MAPS = {"Eastern Kingdoms", "Kalimdor"}
ADB_EXPANSION_MAPS = {"Outland", "Northrend"}
ADB_SERVER_MAP_IDS = {"Eastern Kingdoms": "0", "Kalimdor": "1",
                      "Outland": "530", "Northrend": "571"}


def adb_collect_npcs(base: str, manifest: dict, maps: set, limit: int = 0) -> dict[int, dict]:
    """Spawn coordinates from the archive's NPC records (site: #search?kind=npc).

    Each NPC page lists 'Map | Area | Coords | Spawns' rows; the area names
    link to real AreaTable ids through the record's references, so no zone-name
    guessing is needed. Only the given world maps are kept (instance maps hold
    unverified floor coordinates and are skipped).
    """
    fid = adb_find_file(manifest, "npcs.jsonl.gz")
    if not fid:
        print("  npc file not found in manifest")
        return {}
    units: dict[int, dict] = {}
    seen_rows = 0
    for row in adb_iter_records(base, fid):
        seen_rows += 1
        if limit > 0 and seen_rows > limit:
            break
        try:
            uid = int(row[0])
        except (TypeError, ValueError):
            continue
        d = row[5] if len(row) > 5 and isinstance(row[5], dict) else {}
        st = d.get("structure") if isinstance(d.get("structure"), dict) else d
        areas = {}
        for ref in (st.get("references") or d.get("references") or []):
            if ref.get("type") == "area" and str(ref.get("key", "")).isdigit():
                areas[ref.get("label")] = int(ref["key"])
        for tbl in (st.get("tables") or d.get("tables") or []):
            if (tbl.get("header") or [])[:3] != ["Map", "Area", "Coords"]:
                continue
            for tr in tbl.get("rows") or []:
                if len(tr) < 3 or tr[0] not in maps:
                    continue
                zid = areas.get(tr[1])
                m = re.match(r"\s*([\d.]+)\s*,\s*([\d.]+)", tr[2] or "")
                if not zid or not m:
                    continue
                x, y = float(m.group(1)), float(m.group(2))
                if not (0 <= x <= 100 and 0 <= y <= 100):
                    continue
                rec = units.setdefault(
                    uid, {"id": uid, "name": row[1], "zone": zid, "coords": []})
                pt = (round(x, 1), round(y, 1), zid)
                if pt not in rec["coords"]:
                    rec["coords"].append(pt)
        if seen_rows % 10000 == 0:
            print(f"  npc records read: {seen_rows}, with coords: {len(units)}")
    for rec in units.values():
        zc: dict[int, int] = {}
        for c in rec["coords"]:
            zc[c[2]] = zc.get(c[2], 0) + 1
        rec["zone"] = max(zc, key=zc.get)
    return units


def adb_find_file(manifest: dict, suffix: str) -> str | None:
    for fid, f in manifest.get("files", {}).items():
        p = f.get("path", "")
        if "exiles-db" in p and p.endswith(suffix):
            return fid
    return None


def adb_iter_records(base: str, fid: str):
    part = 0
    while True:
        try:
            rows = adb_gz_json(base, f"records/{fid}/{part}.json.gz")
        except urllib.error.HTTPError as e:
            if e.code in (404, 410):
                return  # past the last part
            raise
        for r in rows:
            yield r
        part += 1


def adb_parse_quest(row: list) -> dict | None:
    """Turn one archive quest record into the importer's quest dict."""
    try:
        qid = int(row[0])
    except (TypeError, ValueError):
        return None
    data = row[5] if len(row) > 5 and isinstance(row[5], dict) else {}
    q: dict = {"id": qid, "name": row[1]}
    for k, v in data.get("meta") or []:
        if k == "Level":
            m = re.search(r"\d+", str(v))
            if m:
                q["lvl"] = int(m.group())
    q["exp"] = quest_expansion(q.get("lvl"))

    start_txt, end_txt = "", ""
    for f in data.get("fields") or []:
        if f.get("field") == "quest-page__giver":
            t = f.get("text") or ""
            if t.startswith("Start:"):
                start_txt += t[6:] + "|"
            elif t.startswith("End:"):
                end_txt += t[4:] + "|"
    refs = data.get("references") or []
    for ref in refs:
        rtype = ref.get("type")
        try:
            rid = int(ref.get("key"))
        except (TypeError, ValueError):
            continue
        label = ref.get("label") or ""
        if rtype in ("npc", "creature"):
            su, eu = "start_u", "end_u"
        elif rtype in ("object", "gameobject"):
            su, eu = "start_o", "end_o"
        else:
            continue
        if label and label in start_txt:
            q.setdefault(su, []).append(rid)
        if label and label in end_txt:
            q.setdefault(eu, []).append(rid)

    # Objectives: latest value of each requirement field in the change history
    # (these come from the TrinityCore 3.3.5 world DB the archive recorded).
    latest: dict[str, str] = {}
    for h in data.get("history") or []:
        if h.get("field") in ("req_npc_or_go", "req_items"):
            latest[h["field"]] = h.get("new")
    try:
        for t in json.loads(latest.get("req_npc_or_go") or "[]"):
            tid = int(t.get("target", 0))
            if tid > 0:
                q.setdefault("obj_u", []).append(tid)
            elif tid < 0:
                q.setdefault("obj_o", []).append(-tid)
    except (ValueError, TypeError):
        pass
    try:
        for t in json.loads(latest.get("req_items") or "[]"):
            iid = int(t.get("id", 0))
            if iid > 0:
                q.setdefault("obj_i", []).append(iid)
    except (ValueError, TypeError):
        pass
    return q


def adb_collect_quests(base: str, manifest: dict, limit: int = 0) -> dict[int, dict]:
    fid = adb_find_file(manifest, "quests.jsonl.gz")
    if not fid:
        print("  quest file not found in manifest")
        return {}
    quests: dict[int, dict] = {}
    for row in adb_iter_records(base, fid):
        q = adb_parse_quest(row)
        if q:
            quests[q["id"]] = q
        if limit > 0 and len(quests) >= limit:
            break
        if len(quests) % 2000 == 0 and quests:
            print(f"  quests parsed: {len(quests)}")
    return quests


def run_ascensiondb(args, addon: Path, out_dir: Path, progress: dict,
                    progress_path: Path) -> int:
    print(f"AscensionDB archive: {args.adb_site}")
    base = adb_resolve_base(args.adb_site, args.adb_base)
    manifest = json.loads(fetch_bytes(base + "manifest.json").decode("utf-8"))
    rev = (manifest.get("revision") or "?")[:8]
    source_tag = f"ascensiondb:{rev}"
    print(f"Snapshot {rev}, built {manifest.get('built_at')}, base {base}")

    if args.mode == "quests":
        quests = adb_collect_quests(base, manifest, args.limit)
        emit_whitelist(set(quests), out_dir, source_tag)
        print(f"Wrote whitelist: {len(quests)} quests (archive quest ids)")
        return 0

    maps = set(ADB_VANILLA_MAPS)
    if getattr(args, "include_expansion", False):
        maps |= ADB_EXPANSION_MAPS
    print(f"World maps: {', '.join(sorted(maps))}")
    only = getattr(args, "only", None)
    units, objects, skipped = {}, {}, {}
    if only is None or "units" in only:
        units = adb_collect_npcs(base, manifest, maps, args.limit)
    if only is None or "objects" in only:
        zone_ids = adb_zone_name_map(addon)
        _, objects, skipped = adb_collect_atlas(
            base, zone_ids, args.limit, {ADB_SERVER_MAP_IDS[m] for m in maps},
            {"gameobject"})
    for uid, u in units.items():
        old = progress["units"].get(str(uid))
        if old and old.get("coords"):
            seen = {tuple(c) for c in u["coords"]}
            for c in old["coords"]:
                c = tuple(c) if len(c) == 3 else (c[0], c[1], old.get("zone"))
                if c not in seen and c[2]:
                    u["coords"].append(c)
        progress["units"][str(uid)] = u
    for oid, o in objects.items():
        progress["objects"][str(oid)] = o
    if args.mode == "coords" and (only is None or "quests" in only):
        quests = adb_collect_quests(base, manifest, args.limit)
        for qid, q in quests.items():
            progress["quests"][str(qid)] = q
        progress["done_quests"] = sorted(set(progress.get("done_quests", [])) | set(quests))
    progress["source"] = source_tag

    emit_lua(
        {int(k): v for k, v in progress["quests"].items()},
        {int(k): v for k, v in progress["units"].items()},
        {int(k): v for k, v in progress["objects"].items()},
        out_dir,
        source_tag,
        only,
    )
    progress_path.write_text(json.dumps(progress), encoding="utf-8")
    print(
        f"Done. units={len(units)} objects={len(objects)} "
        f"quests={len(progress['quests'])} -> {out_dir}"
    )
    if skipped:
        top = sorted(skipped.items(), key=lambda kv: -kv[1])[:12]
        print(f"Skipped {len(skipped)} object zones with no matching addon zone id: "
              + ", ".join(f"{n}({c})" for n, c in top))
    return 0


def lua_coords(coords, zone: int) -> str:
    parts = []
    for i, c in enumerate(coords[:40], 1):
        # (x, y) uses the record's zone; (x, y, zone) carries its own
        x, y = c[0], c[1]
        z = c[2] if len(c) > 2 and c[2] else zone
        parts.append(f"[{i}]={{{x:.2f},{y:.2f},{z},0}}")
    return "{" + ",".join(parts) + "}"


def emit_lua(quests: dict, units: dict, objects: dict, out_dir: Path, source_tag: str,
             only: set | None = None):
    """Write imported-*.lua. `only` = subset of {"quests","units","objects"}."""
    def _want(k):
        return only is None or k in only

    q_lines = [
        f"-- Auto-generated by multi_source_importer.py ({source_tag})",
        "pfDB = pfDB or {}",
        'pfDB["quests"] = pfDB["quests"] or {}',
        'pfDB["quests"]["data-imported"] = pfDB["quests"]["data-imported"] or {}',
        'pfDB["quests"]["loc-imported"] = pfDB["quests"]["loc-imported"] or {}',
        'local data = pfDB["quests"]["data-imported"]',
        'local loc = pfDB["quests"]["loc-imported"]',
    ]
    for qid, q in sorted(quests.items()):
        parts = []

        def _ids(key):
            return ",".join(str(x) for x in dict.fromkeys(q.get(key) or []))

        def _tbl(name, spec):
            inner = ",".join(
                f'["{sub}"]={{{_ids(key)}}}' for sub, key in spec if q.get(key)
            )
            if inner:
                parts.append(f'["{name}"]={{{inner}}}')

        _tbl("start", (("U", "start_u"), ("O", "start_o")))
        _tbl("end", (("U", "end_u"), ("O", "end_o")))
        _tbl("obj", (("U", "obj_u"), ("O", "obj_o"), ("I", "obj_i")))
        if q.get("lvl"):
            parts.append(f'["lvl"]={q["lvl"]}')
        exp = q.get("exp") or "classic"
        parts.append(f'["exp"]="{exp}"')
        if parts:
            q_lines.append(f"data[{qid}]={{{','.join(parts)}}}")
        if q.get("name"):
            safe = str(q["name"]).replace("\\", "\\\\").replace('"', '\\"')
            q_lines.append(f'loc[{qid}]={{["T"]="{safe}"}}')
    if _want("quests"):
        (out_dir / "imported-quest-coords.lua").write_text(
            "\n".join(q_lines) + "\n", encoding="utf-8"
        )

    u_lines = [
        f"-- Auto-generated unit coords ({source_tag})",
        "pfDB = pfDB or {}",
        'pfDB["units"] = pfDB["units"] or {}',
        'pfDB["units"]["data-imported"] = pfDB["units"]["data-imported"] or {}',
        'pfDB["units"]["loc-imported"] = pfDB["units"]["loc-imported"] or {}',
        'local data = pfDB["units"]["data-imported"]',
        'local loc = pfDB["units"]["loc-imported"]',
    ]
    for uid, u in sorted(units.items()):
        if u.get("coords") and u.get("zone"):
            u_lines.append(
                f"data[{uid}]={{[\"coords\"]={lua_coords(u['coords'], u['zone'])}}}"
            )
        if u.get("name"):
            safe = str(u["name"]).replace("\\", "\\\\").replace('"', '\\"')
            u_lines.append(f'loc[{uid}]={{["T"]="{safe}"}}')
    if _want("units"):
        (out_dir / "imported-unit-coords.lua").write_text(
            "\n".join(u_lines) + "\n", encoding="utf-8"
        )

    o_lines = [
        f"-- Auto-generated object coords ({source_tag})",
        "pfDB = pfDB or {}",
        'pfDB["objects"] = pfDB["objects"] or {}',
        'pfDB["objects"]["data-imported"] = pfDB["objects"]["data-imported"] or {}',
        'pfDB["objects"]["loc-imported"] = pfDB["objects"]["loc-imported"] or {}',
        'local data = pfDB["objects"]["data-imported"]',
        'local loc = pfDB["objects"]["loc-imported"]',
    ]
    for oid, o in sorted(objects.items()):
        if o.get("coords") and o.get("zone"):
            o_lines.append(
                f"data[{oid}]={{[\"coords\"]={lua_coords(o['coords'], o['zone'])}}}"
            )
        if o.get("name"):
            safe = str(o["name"]).replace("\\", "\\\\").replace('"', '\\"')
            o_lines.append(f'loc[{oid}]={{["T"]="{safe}"}}')
    if _want("objects"):
        (out_dir / "imported-object-coords.lua").write_text(
            "\n".join(o_lines) + "\n", encoding="utf-8"
        )


def emit_whitelist(ids: set[int], out_dir: Path, meta: str):
    sorted_ids = sorted(ids)
    lines = [
        f"-- Auto-generated by multi_source_importer.py ({meta})",
        f"-- Quest count: {len(sorted_ids)}",
        "AutoQuestLearnerServerQuestIDs = AutoQuestLearnerServerQuestIDs or {}",
        "local t = AutoQuestLearnerServerQuestIDs",
    ]
    chunk = []
    for i, qid in enumerate(sorted_ids, 1):
        chunk.append(f"t[{qid}]=true")
        if i % 20 == 0:
            lines.append(";".join(chunk))
            chunk = []
    if chunk:
        lines.append(";".join(chunk))
    (out_dir / "server-quest-whitelist.lua").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    (out_dir / "server_quest_ids.json").write_text(
        json.dumps(sorted_ids), encoding="utf-8"
    )


def load_id_list(path: Path) -> list[int]:
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".json":
        return [int(x) for x in json.loads(text)]
    return [int(x) for x in re.findall(r"\d+", text)]


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Import quests/coords from AoWoW or Wowhead"
    )
    ap.add_argument(
        "--source",
        choices=("aowow", "wowhead", "ascensiondb"),
        default="ascensiondb",
        help="Data source (default: ascensiondb = ascension-db.ascension-archive.workers.dev)",
    )
    ap.add_argument(
        "--base",
        default="https://db.ascension.gg",
        help="AoWoW site base URL (source=aowow)",
    )
    ap.add_argument(
        "--client",
        choices=tuple(list(WOWHEAD_DATAENV.keys()) + ["all"]),
        default="all",
        help="Wowhead dataEnv: classic|tbc|wotlk|cata|all (default: all = classic+tbc+wotlk)",
    )
    ap.add_argument(
        "--mode",
        choices=("quests", "coords", "units"),
        default="coords",
        help="quests=whitelist harvest; coords=quest+npc pins; units=NPC only",
    )
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--force-units", default="", help="Comma NPC ids")
    ap.add_argument("--force-quests", default="", help="Comma quest ids")
    ap.add_argument(
        "--ids-file",
        type=Path,
        default=None,
        help="JSON/text list of quest or NPC ids (required for wowhead bulk)",
    )
    ap.add_argument(
        "--adb-site",
        default=ADB_SITE,
        help="AscensionDB archive site (source=ascensiondb)",
    )
    ap.add_argument(
        "--adb-base",
        default="",
        help="Override data snapshot URL (source=ascensiondb), e.g. the GitHub Pages mirror",
    )
    ap.add_argument(
        "--include-expansion",
        action="store_true",
        help="ascensiondb: also import Outland + Northrend (default: Eastern Kingdoms + Kalimdor only)",
    )
    ap.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="Write Lua output here instead of bundled-db/wowhead (useful for testing)",
    )
    args = ap.parse_args()

    tools = Path(__file__).resolve().parent
    addon = tools.parent
    out_dir = args.out_dir or (addon / "bundled-db" / "wowhead")
    out_dir.mkdir(parents=True, exist_ok=True)
    progress_path = tools / "coord_import_progress.json"

    progress = {
        "quests": {},
        "units": {},
        "objects": {},
        "done_quests": [],
        "failed_quests": [],
        "source": args.source,
    }
    if args.resume and progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding="utf-8"))
        print(f"Resumed ({len(progress.get('done_quests', []))} quests done)")

    if args.source == "ascensiondb":
        return run_ascensiondb(args, addon, out_dir, progress, progress_path)

    if args.client == "all":
        data_env = WOWHEAD_DATAENV["wotlk"]  # fallback single-env callers
    else:
        data_env = WOWHEAD_DATAENV[args.client]
    source_tag = f"{args.source}:{args.client if args.source == 'wowhead' else args.base}"

    # --- mode: quests (AoWoW listviews only) ---
    if args.mode == "quests":
        if args.source != "aowow":
            print(
                "Quest ID harvest only works for AoWoW listviews.\n"
                "For Wowhead, export IDs from your existing server_quest_ids.json "
                "or a text file of quest ids, then use --mode coords --ids-file ..."
            )
            return 1
        print(f"Harvesting quest IDs from {args.base} ...")
        ids = aowow_harvest_quest_ids(args.base)
        emit_whitelist(ids, out_dir, source_tag)
        print(f"Wrote whitelist: {len(ids)} quests")
        return 0

    # --- force units ---
    if args.force_units or args.mode == "units":
        ids = []
        if args.force_units:
            ids = [int(x) for x in args.force_units.split(",") if x.strip()]
        elif args.ids_file:
            ids = load_id_list(args.ids_file)
        if not ids:
            print("Provide --force-units or --ids-file")
            return 1
        for uid in ids:
            print(f"Unit {uid} ...")
            try:
                if args.source == "wowhead":
                    progress["units"][str(uid)] = wowhead_fetch_unit_multi(uid, args.client)
                else:
                    progress["units"][str(uid)] = aowow_fetch_unit(args.base, uid)
                print(" ", progress["units"][str(uid)].get("name"),
                      progress["units"][str(uid)].get("coords"))
            except Exception as e:
                print("  FAIL", e)
        emit_lua(
            {int(k): v for k, v in progress["quests"].items()},
            {int(k): v for k, v in progress["units"].items()},
            {int(k): v for k, v in progress["objects"].items()},
            out_dir,
            source_tag,
        )
        progress_path.write_text(json.dumps(progress), encoding="utf-8")
        print(f"Wrote {out_dir}/imported-unit-coords.lua")
        return 0

    # --- mode: coords ---
    targets: list[int] = []
    if args.force_quests:
        targets = [int(x) for x in args.force_quests.split(",") if x.strip()]
    elif args.ids_file:
        targets = load_id_list(args.ids_file)
    else:
        cache = out_dir / "server_quest_ids.json"
        if not cache.exists():
            cache = addon / "bundled-db" / "ascension" / "server_quest_ids.json"
        if cache.exists():
            targets = load_id_list(cache)
            print(f"Using {len(targets)} ids from {cache}")
        else:
            print(
                "No quest id list found.\n"
                "  1) While Ascension is up:\n"
                "       python multi_source_importer.py --source aowow --mode quests\n"
                "  2) Then coords:\n"
                "       python multi_source_importer.py --source aowow --mode coords --resume\n"
                "  Or after shutdown, use Wowhead with an ids file:\n"
                "       python multi_source_importer.py --source wowhead --mode coords "
                "--ids-file server_quest_ids.json --resume"
            )
            return 1

    done = set(progress.get("done_quests") or [])
    targets = [q for q in targets if q not in done]
    if args.limit > 0:
        targets = targets[: args.limit]

    print(f"Importing coords for {len(targets)} quests via {source_tag} ...")
    for i, qid in enumerate(targets, 1):
        try:
            if args.source == "wowhead":
                q = wowhead_parse_quest_multi(qid, args.client)
            else:
                q = aowow_parse_quest(args.base, qid)
            progress["quests"][str(qid)] = q
            progress["done_quests"].append(qid)
            for uid in (q.get("start_u") or []) + (q.get("end_u") or []) + (q.get("obj_u") or []):
                if str(uid) not in progress["units"]:
                    try:
                        if args.source == "wowhead":
                            progress["units"][str(uid)] = wowhead_fetch_unit_multi(uid, args.client)
                        else:
                            progress["units"][str(uid)] = aowow_fetch_unit(args.base, uid)
                    except Exception as e:
                        progress["units"][str(uid)] = {"id": uid, "error": str(e)}
            for oid in (q.get("start_o") or []) + (q.get("end_o") or []):
                if str(oid) not in progress["objects"]:
                    try:
                        if args.source == "wowhead":
                            progress["objects"][str(oid)] = wowhead_fetch_object_multi(oid, args.client)
                        else:
                            progress["objects"][str(oid)] = aowow_fetch_object(args.base, oid)
                    except Exception as e:
                        progress["objects"][str(oid)] = {"id": oid, "error": str(e)}
            if i % 10 == 0 or i == 1:
                print(f"  [{i}/{len(targets)}] {qid} {q.get('name')}")
                progress_path.write_text(json.dumps(progress), encoding="utf-8")
                emit_lua(
                    {int(k): v for k, v in progress["quests"].items()},
                    {int(k): v for k, v in progress["units"].items()},
                    {int(k): v for k, v in progress["objects"].items()},
                    out_dir,
                    source_tag,
                )
        except Exception as e:
            progress.setdefault("failed_quests", []).append({"id": qid, "err": str(e)})
            print(f"  FAIL {qid}: {e}")
            progress_path.write_text(json.dumps(progress), encoding="utf-8")

    emit_lua(
        {int(k): v for k, v in progress["quests"].items()},
        {int(k): v for k, v in progress["units"].items()},
        {int(k): v for k, v in progress["objects"].items()},
        out_dir,
        source_tag,
    )
    progress_path.write_text(json.dumps(progress), encoding="utf-8")
    print(
        f"Done. quests={len(progress['quests'])} units={len(progress['units'])} "
        f"failed={len(progress.get('failed_quests') or [])}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
