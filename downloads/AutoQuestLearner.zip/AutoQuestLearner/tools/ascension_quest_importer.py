#!/usr/bin/env python3
"""
Ascension DB ↔ AutoQuestLearner quest importer / cross-check

Pulls quest IDs (and optional detail) from https://db.ascension.gg
(AoWoW-style site) and compares them to the addon's bundled quest tables.

Goals:
  1. Build a server-truth whitelist of quests that exist on Ascension.
  2. Report quests that exist only in our classic/pfDB bundle (noise on
     this private server — wrong givers, spawns, available suggestions).
  3. Report Ascension-only quests we don't ship yet.
  4. Emit Lua the addon can load as AutoQuestLearnerServerQuestIDs.

Usage (from repo / tools dir):
  python3 ascension_quest_importer.py
  python3 ascension_quest_importer.py --details 50
  python3 ascension_quest_importer.py --out-dir ../bundled-db/ascension

Requires: Python 3.8+, network access. No third-party packages.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

UA = {"User-Agent": "Mozilla/5.0 (compatible; AQL-Importer/1.0; +AutoQuestLearner)"}
BASE = "https://db.ascension.gg"

# Category / section pages that host quest listviews on Ascension DB.
CATEGORY_PATHS = [
    "?quests",
    "?quests=0",
    "?quests=1",
    "?quests=2",
    "?quests=3",
    "?quests=4",
    "?quests=5",
    "?quests=6",
    "?quests=7",
    "?quests=8",
    "?quests=9",
    "?quests=-2",
]

LEVEL_BANDS = [
    (1, 10), (11, 20), (21, 30), (31, 40),
    (41, 50), (51, 55), (56, 60), (61, 65),
    (66, 70), (71, 75), (76, 80),
]


def fetch(url: str, retries: int = 3) -> str:
    last_err: Exception | None = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=45) as resp:
                return resp.read().decode("utf-8", "replace")
        except Exception as e:
            last_err = e
            time.sleep(0.5 * (attempt + 1))
    raise RuntimeError(f"fetch failed {url}: {last_err}")


def extract_quest_ids_from_listview(html: str) -> set[int]:
    """Parse AoWoW Listview JSON embedded in the page."""
    ids: set[int] = set()
    # Prefer objects that look like quest rows (have name + id).
    for m in re.finditer(
        r'\{[^{}]*"id":(\d+)[^{}]*"name":"[^"]*"[^{}]*\}',
        html,
    ):
        qid = int(m.group(1))
        if qid > 0:
            ids.add(qid)
    if ids:
        return ids
    # Fallback: any id field in a reasonable range.
    for m in re.finditer(r'"id":(\d+)', html):
        qid = int(m.group(1))
        if 1 <= qid <= 9_999_999:
            ids.add(qid)
    return ids


def harvest_quest_ids(verbose: bool = True) -> set[int]:
    all_ids: set[int] = set()

    for path in CATEGORY_PATHS:
        url = f"{BASE}/{path}"
        try:
            html = fetch(url)
            found = extract_quest_ids_from_listview(html)
            if verbose:
                print(f"  {path}: {len(found)} ids")
            all_ids |= found
            time.sleep(0.25)
        except Exception as e:
            if verbose:
                print(f"  {path}: SKIP ({e})")

    for lo, hi in LEVEL_BANDS:
        url = f"{BASE}/?quests&filter=minle={lo};maxle={hi}"
        try:
            html = fetch(url)
            found = extract_quest_ids_from_listview(html)
            if verbose:
                print(f"  levels {lo}-{hi}: {len(found)} ids")
            all_ids |= found
            time.sleep(0.25)
        except Exception as e:
            if verbose:
                print(f"  levels {lo}-{hi}: SKIP ({e})")

    return all_ids


def fetch_quest_detail(quest_id: int) -> dict:
    """Best-effort detail from power tooltip + HTML npc links."""
    out: dict = {"id": quest_id, "name": None, "npcs": [], "tooltip": None}
    try:
        power = fetch(f"{BASE}/?quest={quest_id}&power=true")
        m = re.search(r'"name_enus":\s*"([^"]+)"', power)
        if m:
            out["name"] = m.group(1)
        m = re.search(r'"tooltip_enus":\s*"((?:\\.|[^"\\])*)"', power)
        if m:
            tip = m.group(1).encode("utf-8").decode("unicode_escape", "replace")
            out["tooltip"] = re.sub(r"<[^>]+>", " ", tip)
            out["tooltip"] = re.sub(r"\s+", " ", out["tooltip"]).strip()
    except Exception as e:
        out["power_error"] = str(e)

    try:
        html = fetch(f"{BASE}/?quest={quest_id}")
        # npc links near start/objective sections
        npcs = re.findall(r"\?npc=(\d+)[^>]*>([^<]+)", html)
        seen = set()
        for nid, name in npcs:
            nid_i = int(nid)
            if nid_i not in seen:
                seen.add(nid_i)
                out["npcs"].append({"id": nid_i, "name": name.strip()})
    except Exception as e:
        out["html_error"] = str(e)

    time.sleep(0.15)
    return out


def load_bundled_quest_ids(bundle_root: Path) -> set[int]:
    """Collect quest IDs from AutoQuestLearner bundled-db Lua sources."""
    ids: set[int] = set()
    patterns = [
        "quests*.lua",
        "**/questiex-quests.lua",
        "**/community-seed.lua",
        "**/live-verified-quest-fixes.lua",
        "**/cmangos-quest-fixes.lua",
        "**/repurposed-quest-overrides.lua",
        "questchain.lua",
    ]
    files: list[Path] = []
    for pat in patterns:
        files.extend(bundle_root.glob(pat))

    # Also scan enUS quest locales if present
    files.extend(bundle_root.glob("enUS/quests*.lua"))
    files.extend(bundle_root.glob("**/quests-*.lua"))

    seen_files = set()
    for f in files:
        if f in seen_files or not f.is_file():
            continue
        seen_files.add(f)
        text = f.read_text(encoding="utf-8", errors="replace")
        # [12345]={...} table keys in quest data
        for m in re.finditer(r"\[(\d{1,7})\]\s*=\s*\{", text):
            ids.add(int(m.group(1)))
        # community-seed style [123]={giver=
        for m in re.finditer(r"\[(\d{1,7})\]\s*=\s*\{[^\n]*giver", text):
            ids.add(int(m.group(1)))

    return ids


def emit_lua_whitelist(ids: set[int], out_path: Path, meta: dict) -> None:
    """Write addon-loadable whitelist."""
    sorted_ids = sorted(ids)
    lines = [
        "-- Auto-generated by tools/ascension_quest_importer.py",
        "-- Source: https://db.ascension.gg quest listviews",
        f"-- Generated: {meta.get('generated', '')}",
        f"-- Quest count: {len(sorted_ids)}",
        "--",
        "-- When AutoQuestLearnerDB.config.restrictToServerQuests == \"1\",",
        "-- available suggestions / static pins ignore quest IDs not in this set.",
        "",
        "AutoQuestLearnerServerQuestIDs = AutoQuestLearnerServerQuestIDs or {}",
        "local t = AutoQuestLearnerServerQuestIDs",
    ]
    # Chunk assignments for readable file size / parse speed
    chunk: list[str] = []
    for i, qid in enumerate(sorted_ids, 1):
        chunk.append(f"t[{qid}]=true")
        if i % 20 == 0:
            lines.append(";".join(chunk))
            chunk = []
    if chunk:
        lines.append(";".join(chunk))
    lines.append("")
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def emit_report(
    server_ids: set[int],
    bundle_ids: set[int],
    out_dir: Path,
    details: list[dict] | None,
) -> dict:
    only_bundle = sorted(bundle_ids - server_ids)
    only_server = sorted(server_ids - bundle_ids)
    both = sorted(server_ids & bundle_ids)

    report = {
        "server_count": len(server_ids),
        "bundle_count": len(bundle_ids),
        "in_both": len(both),
        "only_in_bundle": len(only_bundle),
        "only_on_server": len(only_server),
        "only_in_bundle_sample": only_bundle[:100],
        "only_on_server_sample": only_server[:100],
        "only_in_bundle_ids": only_bundle,
        "only_on_server_ids": only_server,
        "details": details or [],
    }

    (out_dir / "ascension_quest_crosscheck.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    # Human-readable summary
    summary = [
        "Ascension DB ↔ AQL Bundle Cross-Check",
        "=" * 50,
        f"Server (db.ascension.gg) quests : {len(server_ids)}",
        f"Bundled AQL quest keys          : {len(bundle_ids)}",
        f"In both                         : {len(both)}",
        f"Only in bundle (filter these)   : {len(only_bundle)}",
        f"Only on server (missing in AQL) : {len(only_server)}",
        "",
        "Only-in-bundle means: our classic/seed data has this quest ID but",
        "Ascension's DB list did not. Those often cause wrong available !,",
        "givers, and spawn pins on this private server.",
        "",
        "Sample only-in-bundle (first 40):",
    ]
    summary.extend(f"  {qid}" for qid in only_bundle[:40])
    summary.append("")
    summary.append("Sample only-on-server (first 40):")
    summary.extend(f"  {qid}" for qid in only_server[:40])
    (out_dir / "ascension_quest_crosscheck.txt").write_text(
        "\n".join(summary) + "\n", encoding="utf-8"
    )
    return report


def main() -> int:
    ap = argparse.ArgumentParser(description="Import/cross-check Ascension quests")
    ap.add_argument(
        "--bundle-root",
        type=Path,
        default=None,
        help="Path to AutoQuestLearner/bundled-db (default: ../bundled-db)",
    )
    ap.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="Output directory (default: bundled-db/ascension)",
    )
    ap.add_argument(
        "--details",
        type=int,
        default=0,
        help="Fetch detail tooltips for N sample server-only quests",
    )
    ap.add_argument(
        "--skip-fetch",
        action="store_true",
        help="Reuse previous server_quest_ids.json if present",
    )
    args = ap.parse_args()

    tools_dir = Path(__file__).resolve().parent
    addon_root = tools_dir.parent
    bundle_root = args.bundle_root or (addon_root / "bundled-db")
    out_dir = args.out_dir or (bundle_root / "ascension")
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=== Ascension quest importer ===")
    print(f"Bundle root: {bundle_root}")
    print(f"Output dir : {out_dir}")

    cache_path = out_dir / "server_quest_ids.json"
    if args.skip_fetch and cache_path.exists():
        server_ids = set(json.loads(cache_path.read_text(encoding="utf-8")))
        print(f"Loaded cached server IDs: {len(server_ids)}")
    else:
        print("Harvesting quest IDs from db.ascension.gg ...")
        server_ids = harvest_quest_ids(verbose=True)
        cache_path.write_text(
            json.dumps(sorted(server_ids)), encoding="utf-8"
        )
        print(f"Server quest IDs: {len(server_ids)} (cached → {cache_path.name})")

    print("Scanning bundled quest tables ...")
    bundle_ids = load_bundled_quest_ids(bundle_root)
    print(f"Bundle quest IDs: {len(bundle_ids)}")

    details: list[dict] = []
    if args.details > 0:
        only_server = sorted(server_ids - bundle_ids)[: args.details]
        print(f"Fetching details for {len(only_server)} server-only quests ...")
        for qid in only_server:
            details.append(fetch_quest_detail(qid))
            print(f"  {qid}: {details[-1].get('name')}")

    meta = {"generated": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())}
    report = emit_report(server_ids, bundle_ids, out_dir, details)

    lua_path = out_dir / "server-quest-whitelist.lua"
    emit_lua_whitelist(server_ids, lua_path, meta)
    print(f"Wrote whitelist: {lua_path}")
    print(f"Wrote report  : {out_dir / 'ascension_quest_crosscheck.txt'}")
    print()
    print(
        f"Summary: both={report['in_both']}  "
        f"only_bundle={report['only_in_bundle']}  "
        f"only_server={report['only_on_server']}"
    )
    print(
        "Enable in-game with config restrictToServerQuests=1 "
        "(wired when whitelist file is in TOC)."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
