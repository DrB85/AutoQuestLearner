--[[
  AutoQuestLearner_Usage.lua
  Per-addon memory panel -- same API pattern as ElvUI System datatext.
  /aql usage  /aql mem  /aqlusage  /aqlmem
]]

AutoQuestLearner = AutoQuestLearner or CreateFrame("Frame")

local Usage = {}
AutoQuestLearner.Usage = Usage

local SORT_MEM = "mem"
local SORT_NAME = "name"
local sortMode = SORT_MEM
local showDisabled = false
local frame, scrollChild, statusText, titleText
local rowPool = {}

-- Prebuilt rows: { index, title, memKB } -- filled like ElvUI memoryTable
local memoryTable = {}
local tableBuilt = false

local function StripColors(s)
  if not s then return "" end
  s = string.gsub(s, "|c%x%x%x%x%x%x%x%x", "")
  s = string.gsub(s, "|r", "")
  return s
end

local function FormatMem(memory)
  -- memory in KB (same as ElvUI formatMem)
  if not memory or memory <= 0 then
    return "0 kb"
  end
  if memory > 999 then
    return string.format("%.2f mb", memory / 1024)
  end
  return string.format("%d kb", memory)
end

local function BuildMemoryTable()
  memoryTable = {}
  local n = GetNumAddOns() or 0
  for i = 1, n do
    local name, title, notes, enabled, loadable = GetAddOnInfo(i)
    local loaded = IsAddOnLoaded(i)
    if loaded or (showDisabled and enabled) or (showDisabled and not enabled) then
      if loaded or showDisabled then
        table.insert(memoryTable, {
          index = i,
          name = name or ("Addon" .. i),
          title = StripColors(title or name or ("Addon" .. i)),
          enabled = enabled and true or false,
          loaded = loaded and true or false,
          mem = 0,
        })
      end
    end
  end
  tableBuilt = true
end

-- Ascension / modern clients gate per-addon memory behind a CVar.
-- When allowAddonMemoryUsage is 0, GetAddOnMemoryUsage always returns 0.
-- ElvUI shows the same hint: /cvar allowAddonMemoryUsage 1
local function EnableMemoryReporting()
  local enabled = false
  if GetCVar then
    local v = GetCVar("allowAddonMemoryUsage")
    if v == "1" or v == 1 then
      enabled = true
    end
  end
  if not enabled and SetCVar then
    pcall(SetCVar, "allowAddonMemoryUsage", "1")
    if GetCVar and (GetCVar("allowAddonMemoryUsage") == "1") then
      enabled = true
    end
  end
  -- Some clients expose C_CVar
  if not enabled and C_CVar then
    if C_CVar.SetCVar then pcall(C_CVar.SetCVar, "allowAddonMemoryUsage", "1") end
    if C_CVar.GetBool and C_CVar.GetBool("allowAddonMemoryUsage") then
      enabled = true
    end
  end
  return enabled
end

local function IsMemoryReportingEnabled()
  if GetCVar and GetCVar("allowAddonMemoryUsage") == "1" then return true end
  if C_CVar and C_CVar.GetBool and C_CVar.GetBool("allowAddonMemoryUsage") then return true end
  -- Older 3.3.5 without the cvar: assume API should work if present
  if GetCVar and GetCVar("allowAddonMemoryUsage") == nil then return true end
  return false
end

-- ElvUI-identical update path:
--   UpdateAddOnMemoryUsage()
--   GetAddOnMemoryUsage(index)  -- returns KB
local function UpdateMemory()
  EnableMemoryReporting()

  if not tableBuilt or table.getn(memoryTable) == 0 then
    BuildMemoryTable()
  end

  -- Rebuild membership in case addons loaded/unloaded
  BuildMemoryTable()

  if UpdateAddOnMemoryUsage then
    UpdateAddOnMemoryUsage()
  end

  local totalMemory = 0
  for i = 1, table.getn(memoryTable) do
    local entry = memoryTable[i]
    local mem = 0
    if GetAddOnMemoryUsage then
      mem = GetAddOnMemoryUsage(entry.index) or 0
    end
    entry.mem = mem
    totalMemory = totalMemory + mem
  end

  if sortMode == SORT_MEM then
    table.sort(memoryTable, function(a, b)
      if a.mem == b.mem then
        return (a.title or "") < (b.title or "")
      end
      return a.mem > b.mem
    end)
  else
    table.sort(memoryTable, function(a, b)
      return (a.title or "") < (b.title or "")
    end)
  end

  return totalMemory
end

local function TotalLuaMemoryKB()
  if collectgarbage then
    local ok, n = pcall(collectgarbage, "count")
    if ok and type(n) == "number" then return n end
  end
  if gcinfo then
    local ok, n = pcall(gcinfo)
    if ok and type(n) == "number" then return n end
  end
  return 0
end

local function AcquireRow(i)
  if rowPool[i] then return rowPool[i] end
  local row = CreateFrame("Frame", nil, scrollChild)
  row:SetHeight(16)
  row:SetWidth(440)

  row.nameFS = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.nameFS:SetPoint("LEFT", row, "LEFT", 4, 0)
  row.nameFS:SetWidth(260)
  row.nameFS:SetJustifyH("LEFT")

  row.memFS = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.memFS:SetPoint("LEFT", row.nameFS, "RIGHT", 6, 0)
  row.memFS:SetWidth(90)
  row.memFS:SetJustifyH("RIGHT")

  row.stateFS = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  row.stateFS:SetPoint("LEFT", row.memFS, "RIGHT", 8, 0)
  row.stateFS:SetWidth(40)
  row.stateFS:SetJustifyH("LEFT")

  rowPool[i] = row
  return row
end

local function RefreshPanel()
  if not frame or not frame:IsShown() then return end

  local totalMemory = UpdateMemory()
  local luaTotal = TotalLuaMemoryKB()
  local perAddonWorks = totalMemory > 0

  if perAddonWorks then
    titleText:SetText("Addon Memory  |  Total: " .. FormatMem(totalMemory) .. "  |  Lua: " .. FormatMem(luaTotal))
    statusText:SetText("Per-addon memory enabled. Green = AutoQuestLearner.")
  else
    titleText:SetText("Addon Memory  |  Per-addon: 0  |  Lua: " .. FormatMem(luaTotal))
    local cvar = GetCVar and GetCVar("allowAddonMemoryUsage")
    if cvar == "0" or cvar == 0 then
      statusText:SetText("CVar allowAddonMemoryUsage is OFF. Run: /console allowAddonMemoryUsage 1   then /reload")
    else
      statusText:SetText("API still 0. Try: /console allowAddonMemoryUsage 1  then /reload  (same as ElvUI requires)")
    end
  end

  local y = -2
  local shown = 0
  for i = 1, table.getn(memoryTable) do
    local info = memoryTable[i]
    if info.loaded or showDisabled then
      shown = shown + 1
      local row = AcquireRow(shown)
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, y)
      row:Show()

      local label = info.title
      if string.len(label) > 38 then
        label = string.sub(label, 1, 35) .. "..."
      end
      if info.name == "AutoQuestLearner" then
        row.nameFS:SetText("|cff00ff00" .. label .. "|r")
      elseif info.loaded then
        row.nameFS:SetText(label)
      else
        row.nameFS:SetText("|cff888888" .. label .. "|r")
      end

      if perAddonWorks then
        local memStr = FormatMem(info.mem)
        if info.mem >= 20 * 1024 then
          row.memFS:SetText("|cffff4444" .. memStr .. "|r")
        elseif info.mem >= 5 * 1024 then
          row.memFS:SetText("|cffffff00" .. memStr .. "|r")
        else
          row.memFS:SetText(memStr)
        end
      else
        row.memFS:SetText(info.loaded and "|cffaaaaaa--|r" or "|cff666666-|r")
      end

      if info.loaded then
        row.stateFS:SetText("|cff00ff00on|r")
      elseif info.enabled then
        row.stateFS:SetText("|cffffff00lod|r")
      else
        row.stateFS:SetText("|cff888888off|r")
      end

      y = y - 16
    end
  end

  for i = shown + 1, table.getn(rowPool) do
    if rowPool[i] then rowPool[i]:Hide() end
  end

  scrollChild:SetHeight(math.max(200, shown * 16 + 8))
end

local function CreatePanel()
  if frame then return frame end

  frame = CreateFrame("Frame", "AutoQuestLearnerUsageFrame", UIParent)
  frame:SetWidth(520)
  frame:SetHeight(440)
  frame:SetPoint("CENTER")
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function() this:StartMoving() end)
  frame:SetScript("OnDragStop", function() this:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 },
  })
  frame:SetBackdropColor(0, 0, 0, 0.9)
  frame:Hide()
  tinsert(UISpecialFrames, "AutoQuestLearnerUsageFrame")

  titleText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  titleText:SetPoint("TOP", frame, "TOP", 0, -14)
  titleText:SetText("Addon Memory")

  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
  close:SetScript("OnClick", function() frame:Hide() end)

  local colBar = CreateFrame("Frame", nil, frame)
  colBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -36)
  colBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -16, -36)
  colBar:SetHeight(20)

  local bName = CreateFrame("Button", nil, colBar, "UIPanelButtonTemplate")
  bName:SetWidth(80)
  bName:SetHeight(18)
  bName:SetPoint("LEFT", colBar, "LEFT", 0, 0)
  bName:SetText("Name")
  bName:SetScript("OnClick", function() sortMode = SORT_NAME RefreshPanel() end)

  local bMem = CreateFrame("Button", nil, colBar, "UIPanelButtonTemplate")
  bMem:SetWidth(80)
  bMem:SetHeight(18)
  bMem:SetPoint("LEFT", bName, "RIGHT", 8, 0)
  bMem:SetText("Memory")
  bMem:SetScript("OnClick", function() sortMode = SORT_MEM RefreshPanel() end)

  local bRef = CreateFrame("Button", nil, colBar, "UIPanelButtonTemplate")
  bRef:SetWidth(70)
  bRef:SetHeight(18)
  bRef:SetPoint("RIGHT", colBar, "RIGHT", 0, 0)
  bRef:SetText("Refresh")
  bRef:SetScript("OnClick", function()
    tableBuilt = false
    RefreshPanel()
  end)

  local scroll = CreateFrame("ScrollFrame", "AutoQuestLearnerUsageScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -60)
  scroll:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -36, 48)

  scrollChild = CreateFrame("Frame", nil, scroll)
  scrollChild:SetWidth(460)
  scrollChild:SetHeight(400)
  scroll:SetScrollChild(scrollChild)

  statusText = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  statusText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 16, 28)
  statusText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -16, 28)
  statusText:SetJustifyH("LEFT")

  local bToggleDis = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  bToggleDis:SetWidth(120)
  bToggleDis:SetHeight(20)
  bToggleDis:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 16, 10)
  bToggleDis:SetText("Show disabled")
  bToggleDis:SetScript("OnClick", function()
    showDisabled = not showDisabled
    bToggleDis:SetText(showDisabled and "Hide disabled" or "Show disabled")
    tableBuilt = false
    RefreshPanel()
  end)

  local bGc = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  bGc:SetWidth(100)
  bGc:SetHeight(20)
  bGc:SetPoint("LEFT", bToggleDis, "RIGHT", 8, 0)
  bGc:SetText("GC + Refresh")
  bGc:SetScript("OnClick", function()
    if collectgarbage then collectgarbage("collect") end
    tableBuilt = false
    RefreshPanel()
  end)

  frame:SetScript("OnUpdate", function()
    if not frame:IsShown() then return end
    this._elapsed = (this._elapsed or 0) + (arg1 or 0)
    if this._elapsed >= 3 then
      this._elapsed = 0
      RefreshPanel()
    end
  end)

  return frame
end

function Usage:Toggle()
  CreatePanel()
  if frame:IsShown() then
    frame:Hide()
  else
    tableBuilt = false
    frame:Show()
    RefreshPanel()
  end
end

function Usage:Show()
  CreatePanel()
  tableBuilt = false
  frame:Show()
  RefreshPanel()
end

function Usage:PrintChatSummary(topN)
  topN = topN or 15
  local totalMemory = UpdateMemory()
  local luaTotal = TotalLuaMemoryKB()

  if totalMemory > 0 then
    print("|cff00ff00AutoQuestLearner|r Addon memory (total " .. FormatMem(totalMemory) .. "):")
    local limit = math.min(topN, table.getn(memoryTable))
    for i = 1, limit do
      local info = memoryTable[i]
      if info.loaded then
        local line = string.format("  %2d. %-30s %10s", i, string.sub(info.title, 1, 30), FormatMem(info.mem))
        if info.name == "AutoQuestLearner" then
          line = "|cff00ff00" .. line .. "|r"
        end
        print(line)
      end
    end
  else
    print("|cff00ff00AutoQuestLearner|r Per-addon memory is disabled by the client.")
    print("  Type: |cffffcc00/console allowAddonMemoryUsage 1|r")
    print("  Then |cffffcc00/reload|r and open this panel again.")
    print("  (ElvUI needs the same CVar -- see its tooltip when memory is hidden.)")
    print("  Lua collectgarbage total: " .. FormatMem(luaTotal))
  end
end

AutoQuestLearner.Usage = Usage

SLASH_AQLUSAGE1 = "/aqlusage"
SLASH_AQLUSAGE2 = "/aqlmem"
SlashCmdList["AQLUSAGE"] = function()
  Usage:Toggle()
  Usage:PrintChatSummary(12)
end
