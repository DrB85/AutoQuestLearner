-- AutoQuestLearner Minimap Button
-- Classic / 3.3.5 compatible (no LibDBIcon dependency).
-- Left-click: open config panel
-- Right-click: dropdown menu (config, tracker, guide, scan, etc.)
-- Shift+drag: move the button around the minimap edge

local BUTTON_NAME = "AutoQuestLearnerMinimapButton"

local function Cfg()
  AutoQuestLearnerDB = AutoQuestLearnerDB or {}
  AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
  return AutoQuestLearnerDB.config
end

local function IsButtonEnabled()
  local c = Cfg()
  if c.minimapbutton == nil then return true end
  return c.minimapbutton == "1"
end

-- Angle in degrees around the minimap (0 = right, 90 = top, etc.)
local function GetAngle()
  local c = Cfg()
  return tonumber(c.minimapbuttonAngle) or 220
end

local function SetAngle(deg)
  Cfg().minimapbuttonAngle = tostring(math.floor(deg + 0.5) % 360)
end

local function UpdatePosition(btn)
  if not btn then return end
  local angle = math.rad(GetAngle())
  local x = math.cos(angle) * 80
  local y = math.sin(angle) * 80
  btn:ClearAllPoints()
  btn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function CreateButton()
  if _G[BUTTON_NAME] then return _G[BUTTON_NAME] end

  local btn = CreateFrame("Button", BUTTON_NAME, Minimap)
  btn:SetFrameStrata("MEDIUM")
  btn:SetWidth(31)
  btn:SetHeight(31)
  btn:SetFrameLevel(8)
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  btn:RegisterForDrag("LeftButton")
  btn:SetMovable(true)

  -- Border (standard minimap button ring)
  local overlay = btn:CreateTexture(nil, "OVERLAY")
  overlay:SetWidth(53)
  overlay:SetHeight(53)
  overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  overlay:SetPoint("TOPLEFT", 0, 0)

  -- Icon: AQL badge (logo_minimap preferred, then logo)
  local icon = btn:CreateTexture(nil, "BACKGROUND")
  icon:SetWidth(20)
  icon:SetHeight(20)
  icon:SetPoint("CENTER", 0, 1)
  icon:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\logo_minimap")
  if not icon:GetTexture() then
    icon:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\logo")
  end
  if not icon:GetTexture() then
    icon:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
  end
  btn.icon = icon

  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("|cff00ff00AutoQuestLearner|r", 1, 1, 1)
    GameTooltip:AddLine("Left-click: Open settings", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("Right-click: Quick menu", 0.8, 0.8, 0.8)
    GameTooltip:AddLine("Shift-drag: Move button", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function()
    GameTooltip:Hide()
  end)

  btn:SetScript("OnClick", function(self, button)
    if button == "LeftButton" and not IsShiftKeyDown() then
      if AutoQuestLearner_OpenConfig then
        AutoQuestLearner_OpenConfig()
      elseif SlashCmdList and SlashCmdList["AQLACECONFIG"] then
        SlashCmdList["AQLACECONFIG"]()
      else
        print("|cff00ff00AutoQuestLearner:|r Type |cffffcc00/aql config|r to open settings.")
      end
    elseif button == "RightButton" then
      ToggleDropDownMenu(1, nil, AutoQuestLearnerMinimapMenu, self, 0, 0)
    end
  end)

  btn:SetScript("OnDragStart", function(self)
    if IsShiftKeyDown() then
      self.dragging = true
      self:LockHighlight()
    end
  end)

  btn:SetScript("OnDragStop", function(self)
    self.dragging = false
    self:UnlockHighlight()
  end)

  btn:SetScript("OnUpdate", function(self)
    if not self.dragging then return end
    local mx, my = GetCursorPosition()
    local cx, cy = Minimap:GetCenter()
    local scale = Minimap:GetEffectiveScale()
    mx, my = mx / scale, my / scale
    local dx, dy = mx - cx, my - cy
    local angle = math.deg(math.atan2(dy, dx))
    if angle < 0 then angle = angle + 360 end
    SetAngle(angle)
    UpdatePosition(self)
  end)

  UpdatePosition(btn)
  return btn
end

-- Dropdown menu
local function MenuInitialize(self, level)
  if not level then return end
  local info = UIDropDownMenu_CreateInfo()

  info.text = "|cff00ff00AutoQuestLearner|r"
  info.isTitle = true
  info.notCheckable = true
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = "Open Settings"
  info.notCheckable = true
  info.func = function()
    if AutoQuestLearner_OpenConfig then AutoQuestLearner_OpenConfig() end
  end
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = "Toggle Tracker"
  info.notCheckable = true
  info.func = function()
    if SlashCmdList and SlashCmdList["AUTOQUESTLEARNER"] then
      SlashCmdList["AUTOQUESTLEARNER"]("tracker")
    else
      print("|cff00ff00AutoQuestLearner:|r Type |cffffcc00/aql tracker|r")
    end
  end
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = "How-to Guide"
  info.notCheckable = true
  info.func = function()
    if SlashCmdList and SlashCmdList["AUTOQUESTLEARNER"] then
      SlashCmdList["AUTOQUESTLEARNER"]("guide")
    else
      print("|cff00ff00AutoQuestLearner:|r Type |cffffcc00/aql guide|r")
    end
  end
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = "Force Scan"
  info.notCheckable = true
  info.func = function()
    if SlashCmdList and SlashCmdList["AUTOQUESTLEARNER"] then
      SlashCmdList["AUTOQUESTLEARNER"]("scan")
    end
  end
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = " "
  info.disabled = true
  info.notCheckable = true
  UIDropDownMenu_AddButton(info, level)

  info = UIDropDownMenu_CreateInfo()
  info.text = "Hide Minimap Button"
  info.notCheckable = true
  info.func = function()
    Cfg().minimapbutton = "0"
    local b = _G[BUTTON_NAME]
    if b then b:Hide() end
    print("|cff00ff00AutoQuestLearner:|r Minimap button hidden. Re-enable with |cffffcc00/aql minimap|r or in Settings.")
  end
  UIDropDownMenu_AddButton(info, level)
end

local function EnsureMenu()
  if AutoQuestLearnerMinimapMenu then return end
  local menu = CreateFrame("Frame", "AutoQuestLearnerMinimapMenu", UIParent, "UIDropDownMenuTemplate")
  UIDropDownMenu_Initialize(menu, MenuInitialize, "MENU")
end

local function ShowOrHide()
  local btn = CreateButton()
  EnsureMenu()
  if IsButtonEnabled() then
    btn:Show()
    UpdatePosition(btn)
  else
    btn:Hide()
  end
end

-- Public helpers
function AutoQuestLearner_ToggleMinimapButton()
  local c = Cfg()
  if c.minimapbutton == "0" then
    c.minimapbutton = "1"
  else
    c.minimapbutton = "0"
  end
  ShowOrHide()
  print("|cff00ff00AutoQuestLearner:|r Minimap button " .. (c.minimapbutton == "1" and "shown" or "hidden") .. ".")
end

function AutoQuestLearner_RefreshMinimapButton()
  ShowOrHide()
end

-- Boot
local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:RegisterEvent("ADDON_LOADED")
boot:SetScript("OnEvent", function(self, event, arg1)
  if event == "ADDON_LOADED" and arg1 ~= "AutoQuestLearner" then return end
  -- Delay slightly so SavedVariables and config defaults are ready
  if event == "PLAYER_LOGIN" or (event == "ADDON_LOADED" and arg1 == "AutoQuestLearner") then
    self:UnregisterEvent("ADDON_LOADED")
    -- PLAYER_LOGIN is the reliable moment for Minimap existence + SV
    if event == "PLAYER_LOGIN" then
      ShowOrHide()
      self:UnregisterEvent("PLAYER_LOGIN")
    end
  end
end)

-- Slash convenience (also reachable via /aql minimap if main slash routes it)
SLASH_AQLMINIMAP1 = "/aqlminimap"
SlashCmdList["AQLMINIMAP"] = function()
  AutoQuestLearner_ToggleMinimapButton()
end
