-- AutoQuestLearner: learned quest-item drop rates.
--
-- While you play, every corpse you loot is checked against the item
-- objectives in your quest log. For each still-needed quest item we count
--   tries = corpses of that mob looted while the item was still needed
--   got   = how many of those corpses actually had the item
-- Hovering the same kind of mob later shows e.g.
--   AQL: Grizzled Bear Heart - 41% (learned 12/29)
-- Mobs the bundled database already lists as a source of a needed item also
-- show the database rate when nothing has been learned yet.
--
-- Data lives in AutoQuestLearnerDB.dropStats[npcID][itemName] = {t=, g=}
-- (account-wide, same as the rest of the learned data).

local function Cfg()
  return (AutoQuestLearnerDB and AutoQuestLearnerDB.config) or {}
end

local function Enabled()
  return Cfg().tooltipDropRate ~= "0"
end

local function Stats()
  if not AutoQuestLearnerDB then return nil end
  AutoQuestLearnerDB.dropStats = AutoQuestLearnerDB.dropStats or {}
  return AutoQuestLearnerDB.dropStats
end

-- creature entry from a 3.3.5 GUID: 0x + type(4) + entry(6) + counter(6)
local function NpcIDFromGUID(guid)
  if type(guid) ~= "string" then return nil end
  local kind = string.sub(guid, 3, 6)
  if kind ~= "F130" and kind ~= "F150" then return nil end
  return tonumber(string.sub(guid, 7, 12), 16)
end

-- Item objectives of the quest log: name -> { quest = title, done = bool }
local function NeededItems()
  local needed = {}
  local entries = GetNumQuestLogEntries and GetNumQuestLogEntries() or 0
  for i = 1, entries do
    local title, _, _, _, isHeader = GetQuestLogTitle(i)
    if title and not isHeader then
      local num = GetNumQuestLeaderBoards(i) or 0
      for j = 1, num do
        local text, objType, finished = GetQuestLogLeaderBoard(j, i)
        if objType == "item" and text then
          local name = string.match(text, "^(.-):%s*%d+%s*/%s*%d+")
          if name then
            local cur = needed[name]
            if not cur or (cur.done and not finished) then
              needed[name] = { quest = title, done = finished and true or false }
            end
          end
        end
      end
    end
  end
  return needed
end

-- item name -> itemID from the bundled item names (cached; one scan per name)
local idCache = {}
local function ItemIDByName(name)
  if idCache[name] ~= nil then return idCache[name] or nil end
  local found = false
  local loc = AutoQuestLearnerData and AutoQuestLearnerData.items and AutoQuestLearnerData.items["loc"]
  if loc then
    local lower = string.lower(name)
    for id, entry in pairs(loc) do
      local n = type(entry) == "table" and (entry.T or entry[1]) or entry
      if n and string.lower(n) == lower then found = id break end
    end
  end
  idCache[name] = found
  return found or nil
end

-- database rate (percent) for itemName dropping from npcID, or nil
local function StaticRate(itemName, npcID)
  local id = ItemIDByName(itemName)
  if not id then return nil end
  local d = AutoQuestLearnerData.items["data"] and AutoQuestLearnerData.items["data"][id]
  local U = d and d["U"]
  if not U then return nil end
  local r = U[npcID] or U[tostring(npcID)]
  if r == nil then return nil end
  r = tonumber(r)
  if not r or r <= 0 then return nil end
  if r <= 1 then r = r * 100 end
  if r > 100 then r = 100 end
  return r
end

------------------------------------------------------------
-- Learning
------------------------------------------------------------
local lastDeadGUID
local seenLoot, seenCount = {}, 0

local function LootSourceGUID()
  local units = { "target", "mouseover" }
  for _, u in ipairs(units) do
    if UnitExists(u) and UnitIsDead(u) and not UnitIsPlayer(u) then
      local g = UnitGUID(u)
      if NpcIDFromGUID(g) then return g end
    end
  end
  return lastDeadGUID
end

local function OnLoot()
  local stats = Stats()
  if not stats then return end
  local guid = LootSourceGUID()
  local npcID = NpcIDFromGUID(guid)
  if not npcID then return end
  if seenLoot[guid] then return end
  seenLoot[guid] = true
  seenCount = seenCount + 1
  if seenCount > 300 then seenLoot, seenCount = { [guid] = true }, 1 end

  local needed = NeededItems()
  if next(needed) == nil then return end

  local inLoot = {}
  for slot = 1, (GetNumLootItems() or 0) do
    local link = GetLootSlotLink and GetLootSlotLink(slot)
    if link then
      local name = GetItemInfo(link)
      if name then inLoot[name] = true end
    end
  end

  local npcStats = stats[npcID]
  for name, info in pairs(needed) do
    if not info.done then
      local e = npcStats and npcStats[name]
      if inLoot[name] then
        npcStats = npcStats or {}
        stats[npcID] = npcStats
        e = e or { t = 0, g = 0 }
        npcStats[name] = e
        e.t = e.t + 1
        e.g = e.g + 1
      elseif e or StaticRate(name, npcID) then
        npcStats = npcStats or {}
        stats[npcID] = npcStats
        e = e or { t = 0, g = 0 }
        npcStats[name] = e
        e.t = e.t + 1
      end
    end
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("LOOT_OPENED")
ev:RegisterEvent("PLAYER_TARGET_CHANGED")
ev:SetScript("OnEvent", function(self, event)
  if event == "PLAYER_TARGET_CHANGED" then
    if UnitExists("target") and UnitIsDead("target") and not UnitIsPlayer("target") then
      lastDeadGUID = UnitGUID("target")
    end
  else
    pcall(OnLoot)
  end
end)

------------------------------------------------------------
-- Tooltip
------------------------------------------------------------
local function AddUnitLines(tip)
  if not Enabled() then return end
  local _, unit = tip:GetUnit()
  if not unit or UnitIsPlayer(unit) then return end
  local npcID = NpcIDFromGUID(UnitGUID(unit))
  if not npcID then return end
  local stats = Stats()
  local npcStats = stats and stats[npcID]
  local needed = NeededItems()

  local lines, shown = {}, {}
  if npcStats then
    for name, e in pairs(npcStats) do
      if e.t and e.t > 0 then
        local pct = e.g / e.t * 100
        local info = needed[name]
        local tail = ""
        if info and info.done then tail = " |cff888888(done)|r" end
        table.insert(lines, string.format("|cff00ff99AQL|r |cffffffff%s|r - %d%% |cffaaaaaa(learned %d/%d)|r%s",
          name, math.floor(pct + 0.5), e.g, e.t, tail))
        shown[name] = true
      end
    end
  end
  for name, info in pairs(needed) do
    if not shown[name] and not info.done then
      local r = StaticRate(name, npcID)
      if r then
        table.insert(lines, string.format("|cff00ff99AQL|r |cffffffff%s|r - ~%.0f%% |cffaaaaaa(database)|r", name, r))
      end
    end
  end
  if table.getn(lines) == 0 then return end
  table.sort(lines)
  tip:AddLine(" ")
  for _, l in ipairs(lines) do tip:AddLine(l) end
  tip:Show()
end

GameTooltip:HookScript("OnTooltipSetUnit", function(self)
  pcall(AddUnitLines, self)
end)

------------------------------------------------------------
-- /aqldrops [reset]
------------------------------------------------------------
SLASH_AQLDROPS1 = "/aqldrops"
SlashCmdList["AQLDROPS"] = function(msg)
  local stats = Stats()
  if not stats then return end
  if msg and string.find(msg, "reset") then
    AutoQuestLearnerDB.dropStats = {}
    print("|cff00ff00AutoQuestLearner:|r learned drop rates cleared.")
    return
  end
  local mobs, items = 0, 0
  for _, t in pairs(stats) do
    mobs = mobs + 1
    for _ in pairs(t) do items = items + 1 end
  end
  print(string.format("|cff00ff00AutoQuestLearner:|r learned drop rates for %d quest items across %d mobs. "
    .. "Hover a mob to see them. /aqldrops reset clears them.", items, mobs))
end
