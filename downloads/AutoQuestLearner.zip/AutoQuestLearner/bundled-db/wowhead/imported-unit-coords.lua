-- Auto-generated unit coords (wowhead:all)
pfDB = pfDB or {}
pfDB["units"] = pfDB["units"] or {}
pfDB["units"]["data-imported"] = pfDB["units"]["data-imported"] or {}
pfDB["units"]["loc-imported"] = pfDB["units"]["loc-imported"] or {}
local data = pfDB["units"]["data-imported"]
local loc = pfDB["units"]["loc-imported"]
data[1515]={["coords"]={[1]={60.40,51.80,85,0},[2]={60.60,52.00,85,0},[3]={60.60,51.80,85,0}}}
loc[1515]={["T"]="Executor Zygand"}
data[1660]={["coords"]={[1]={79.40,25.40,85,0},[2]={79.40,25.60,85,0},[3]={79.60,25.20,85,0},[4]={79.40,26.00,85,0},[5]={79.40,26.60,85,0},[6]={79.60,26.20,85,0},[7]={79.60,26.80,85,0}}}
loc[1660]={["T"]="Scarlet Bodyguard"}
data[1665]={["coords"]={[1]={79.40,25.40,85,0},[2]={79.40,25.60,85,0},[3]={79.40,27.20,85,0},[4]={79.60,25.40,85,0},[5]={79.60,25.60,85,0},[6]={79.60,27.40,85,0},[7]={79.40,26.00,85,0},[8]={79.40,26.60,85,0},[9]={79.60,25.20,85,0},[10]={79.60,26.20,85,0},[11]={79.60,26.80,85,0}}}
loc[1665]={["T"]="Captain Melrache"}
