-- Auto-generated object coords (wowhead:all)
pfDB = pfDB or {}
pfDB["objects"] = pfDB["objects"] or {}
pfDB["objects"]["data-imported"] = pfDB["objects"]["data-imported"] or {}
pfDB["objects"]["loc-imported"] = pfDB["objects"]["loc-imported"] or {}
local data = pfDB["objects"]["data-imported"]
local loc = pfDB["objects"]["loc-imported"]
