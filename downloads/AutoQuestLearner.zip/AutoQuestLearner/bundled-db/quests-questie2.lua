-- Small set of quest start/end NPC gaps found by cross-referencing
-- this addon's existing bundled quest data against Questie's Classic
-- database, user-supplied. Only entries where our own data was
-- genuinely missing a start or end NPC that Questie had are included
-- here -- checked 4237 overlapping quests between the two databases;
-- this is the small remainder (13 entries) where ours had a real gap,
-- not a wholesale replacement of anything already present.
pfDB["quests"]["data-questie2"] = pfDB["quests"]["data-questie2"] or {}
local data = {
[8793]={["start"]={["U"]={15703}},["end"]={["U"]={15700}}},
[2985]={["start"]={["U"]={3173}}},
[2986]={["start"]={["U"]={3066}},["end"]={["U"]={5901}}},
[5927]={["start"]={["U"]={3060}}},
[8797]={["start"]={["U"]={15709}}},
[8796]={["start"]={["U"]={15708}}},
[8794]={["start"]={["U"]={15704}},["end"]={["U"]={15700}}},
[8579]={["start"]={["U"]={15503}},["end"]={["U"]={15503}}},
[9165]={["end"]={["U"]={16212}}}
}
for k,v in pairs(data) do pfDB["quests"]["data-questie2"][k]=v end
