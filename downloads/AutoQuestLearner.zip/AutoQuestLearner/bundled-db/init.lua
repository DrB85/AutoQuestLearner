-- Bundled copy of pfQuest's db/init.lua, made idempotent so it merges
-- safely with an existing pfDB global instead of overwriting it, in
-- case pfQuest is also installed separately alongside AutoQuestLearner.
pfDB = pfDB or {}
pfDB["areatrigger"] = pfDB["areatrigger"] or {}
pfDB["items"] = pfDB["items"] or {}
pfDB["meta"] = pfDB["meta"] or {}
pfDB["meta-tbc"] = pfDB["meta-tbc"] or {}
pfDB["minimap"] = pfDB["minimap"] or {}
pfDB["minimap-tbc"] = pfDB["minimap-tbc"] or {}
pfDB["objects"] = pfDB["objects"] or {}
pfDB["professions"] = pfDB["professions"] or {}
pfDB["quests"] = pfDB["quests"] or {}
pfDB["quests-itemreq"] = pfDB["quests-itemreq"] or {}
pfDB["refloot"] = pfDB["refloot"] or {}
pfDB["units"] = pfDB["units"] or {}
pfDB["zones"] = pfDB["zones"] or {}
