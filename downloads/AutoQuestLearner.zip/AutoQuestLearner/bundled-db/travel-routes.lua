-- Verified overland travel directions into zones that have no nearby
-- flight point (or where the flight point itself is hard to reach
-- without already knowing the way in) -- for the cross-zone arrow
-- message, alongside FindFlightSuggestion in AutoQuestLearner.lua.
--
-- Same rule as the flight-path system this sits next to: only real,
-- source-checked routes get added here, never a guess. Missing a zone
-- just means the arrow falls back to the generic "Fly or travel
-- there." message instead of giving wrong directions.
--
-- Keyed by destination zone mapID (this addon's own numbering, cross-
-- checked against bundled-db/zones.lua). Sources: Warcraft Wiki /
-- Wowpedia (Classic sections), cross-referenced against multiple
-- independent guides where possible.
AutoQuestLearnerTravelRoutes = AutoQuestLearnerTravelRoutes or {}

local data = {
  -- The Hinterlands (mapID 47). Sources: warcraft.wiki.gg/wiki/Hinterlands_(Classic),
  -- classic-wow-archive.fandom.com/wiki/Hinterlands
  -- Has one precise, sourced coordinate (the mountain pass) -- a
  -- one-point chain for now. Could be extended with more checkpoints
  -- (e.g. Tarren Mill/Southshore as a starting anchor) if a second
  -- verified coordinate turns up; a single real point is still better
  -- than a straight line with none.
  [47] = {
    text = "From Hillsbrad Foothills: head to Tarren Mill (Horde) or Southshore (Alliance), then " ..
      "go northeast until you find a break in the mountains near [84, 32] (northeast of Durnholde " ..
      "Keep) -- that pass leads into the Hinterlands.",
    waypoints = {
      { x = 84, y = 32, mapID = 267, label = "Mountain pass into the Hinterlands" },
    },
  },

  -- Un'Goro Crater (mapID 490). Sources: wowpedia.fandom.com/wiki/Un'Goro_Crater,
  -- warcraft.wiki.gg/wiki/Un'Goro_Crater, classic-wow-archive.fandom.com/wiki/Un'Goro_Crater
  -- (all three independently agree on this coordinate). Also reachable
  -- from Silithus to the west, but no precise coordinate found for
  -- that side yet.
  [490] = {
    text = "From Tanaris: head to the southwesternmost point of the zone, Thistleshrub Valley, " ..
      "near [27, 56] -- there's a path between two dark-grey stone pillars leading down into " ..
      "the crater.",
    waypoints = {
      { x = 27, y = 56, mapID = 440, label = "Stone pillar path down into Un'Goro Crater" },
    },
  },

  -- Searing Gorge (mapID 51). Source: stealthoptional.com/article/how-to-access-searing-gorge-in-wow-classic
  -- NOTE: single-sourced, not independently cross-verified like the
  -- other entries here -- treat with a bit less confidence. If this
  -- turns out to be off, it's a good candidate to /aql learn over and
  -- let me know so the entry can be corrected or removed.
  [51] = {
    text = "The simplest route: find the entrance on the western border of the Badlands, near " ..
      "[5.82, 60.44], and walk/fly straight in.",
    waypoints = {
      { x = 5.82, y = 60.44, mapID = 3, label = "Searing Gorge entrance from the Badlands" },
    },
  },

  -- Silithus (mapID 1377). Sources: warcraft.wiki.gg/wiki/Silithus_(Classic),
  -- classic-wow-archive.fandom.com/wiki/Silithus
  -- No precise coordinate found for "the NW corner of Un'Goro" across
  -- sources -- text only until one's verified, rather than guessing.
  [1377] = {
    text = "Only reachable by land through the northwestern corner of Un'Goro Crater -- a wide " ..
      "path leads out of the crater directly into Silithus.",
  },

  -- Winterspring (mapID 618). Sources: wowpedia.fandom.com/wiki/Winterspring_(Classic),
  -- warcrafttavern.com/wow-classic/guides/how-to-get-to-winterspring
  [618] = {
    text = "Through the Timbermaw Hold tunnel at the northeastern tip of Felwood -- you'll need " ..
      "at least Unfriendly reputation with the Timbermaw furbolgs to pass without being attacked " ..
      "(a couple of early Felwood quests get you there). Inside the tunnel, take the east/southeast " ..
      "branch (the north branch leads to Moonglade instead).",
  },

  -- Moonglade (mapID 493). Sources: warcraft.wiki.gg/wiki/Azshara_(Classic) [sic, see below],
  -- classic-wow-archive.fandom.com/wiki/Moonglade, warcrafttavern.com/wow-classic/guides/how-to-get-to-moonglade
  -- Druids can just cast Teleport: Moonglade. For everyone else there are two real routes:
  [493] = {
    text = "Non-Druids: easiest is Darkshore -- follow the coast to the far northeastern tip, then " ..
      "swim/hug the coastline northeast then east until you get a 'Discovered: Moonglade' message, " ..
      "then die (drown or let a mob kill you) -- your spirit gets pulled to the Moonglade graveyard " ..
      "to resurrect there. Alternatively, take the Timbermaw Hold tunnel from northeastern Felwood " ..
      "(needs Unfriendly+ Timbermaw reputation) and take the north branch instead of the " ..
      "east/southeast one that leads to Winterspring. Druids can just cast Teleport: Moonglade.",
  },

  -- Azshara (mapID 16). Sources: warcraft.wiki.gg/wiki/Azshara_(Classic),
  -- classic-wow-archive.fandom.com/wiki/Azshara
  [16] = {
    text = "Follow the road east through Ashenvale to its far eastern edge, then cross the bridge " ..
      "over the river. Alliance: from Forest Song, the outpost Talrendis Point is just over the " ..
      "river. Horde: from Splintertree Post, the encampment Valormok is north of the ruined " ..
      "Haldarr Encampment. It's a long run either way -- worth grabbing every flight point along " ..
      "the road through Ashenvale first if you don't have them yet.",
  },
}

for k, v in pairs(data) do
  AutoQuestLearnerTravelRoutes[k] = v
end
