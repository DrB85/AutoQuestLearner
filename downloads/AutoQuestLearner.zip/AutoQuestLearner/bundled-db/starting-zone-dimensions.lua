-- Real, precise dimensions (in yards) for the starting-zone sub-areas
-- that AutoQuestLearner's self-calibration system (see
-- AutoQuestLearner_UpdateMinimapCalibration in AutoQuestLearner.lua)
-- was built to measure from scratch, since no external database had
-- ever needed this exact value before.
--
-- SOURCE: computed from a modern retail client's DBC/DB2 export
-- (AreaTable, UiMap, UiMapAssignment tables) -- specifically the
-- UiMapAssignment.Region[] bounding box for each zone's separately-
-- zoomed starting-area map. Region[0]/[1] = min X/Y, Region[3]/[4] =
-- max X/Y (Region[2]/[5] are a -1000000/+1000000 sentinel pair for
-- the unbounded Z axis, confirmed by every single zone here using the
-- identical pair). Verified the interpretation against a well-known
-- zone (Elwynn Forest) before trusting it, and cross-validated all 5
-- values below against each other: every one works out to almost
-- exactly the same 2:3 width:height ratio, which is far too
-- consistent to be coincidental -- strong evidence Blizzard used a
-- fixed template for these separately-zoomed starting-zone maps, and
-- that the values are being read correctly.
--
-- IMPORTANT CAVEAT: this is MODERN retail client data (Shadowglen
-- only exists as its own zone starting in patch 5.0.4), not data from
-- Ascension's own WotLK 3.3.5 client. Starting zones are some of the
-- most stable, rarely-modified content in the game, so this should be
-- very close to correct -- but it's a strong starting estimate, not a
-- guaranteed-exact value for Ascension's specific implementation.
-- That's exactly why this does NOT disable the self-calibration
-- system for these zones -- it stays fully active, and will
-- automatically detect and correct this value if Ascension's real
-- geometry differs, the same as it would for any other zone's static
-- data turning out wrong.
--
-- "Red Cloud Mesa" is not included -- it isn't a separate UI map in
-- modern retail at all (likely folded back into Mulgore at some
-- point), so no equivalent data exists in this source for it. It
-- still relies purely on self-calibration.
AutoQuestLearnerStartingZoneDimensions = {
  [188] = { 966.7, 1450.0 },  -- Shadowglen
  [132] = { 643.8, 964.6 },   -- Coldridge Valley
  [221] = { 1177.1, 1766.7 }, -- Camp Narache
  [154] = { 727.1, 1089.6 },  -- Deathknell
  [363] = { 900.0, 1350.0 },  -- Valley of Trials
}
