-- Real, documented bug fixes for specific quest fields. Two sources so
-- far, each entry documents which:
--
-- (1) The cmangos project's own changelog (community-maintained
-- vanilla server emulation core, same database lineage our bundled
-- quest data itself comes from) -- only RequiredRaces (-> this
-- addon's "race" field) fixes confirmed to match our CURRENT bundled
-- value are included (i.e. we verified our data actually has the
-- exact "before" state each patch describes fixing), not applied
-- blindly just because a patch exists somewhere in the changelog. A
-- parallel set of PrevQuestId (-> "pre"/prerequisite) fixes was found
-- in the same changelog, but none of their "before" values matched
-- what our bundled data actually has for those quest IDs -- suggesting
-- our "pre" field is derived differently than a raw PrevQuestId
-- column, not a direct correspondence. Prerequisite data is
-- high-stakes (a wrong value can wrongly suppress OR wrongly suggest a
-- quest), so those were left out rather than guessed at.
--
-- (2) Ascension's own live public database (db.ascension.gg) --
-- "start" (giver) corrections for quest IDs where the bundled data's
-- assumed giver was directly checked against Ascension's own current
-- database page for that exact quest ID and found to be a different
-- NPC. Every entry's replacement NPC was independently confirmed to
-- already have real coordinate data elsewhere in this addon's bundled
-- database (from other, unrelated quest associations), so these are
-- immediately navigable, not just a corrected ID with nowhere to
-- point the arrow.
--
-- Applied in AutoQuestLearner_Database.lua, once, right after all
-- bundled quest data sources have merged -- see
-- AutoQuestLearner_ApplyQuestFieldFixes.
AutoQuestLearnerQuestFieldFixes = {
    -- "Deviate Hides" -- was Horde-only (690), actually available to
    -- both factions (255). https://www.wowhead.com/tbc/quest=1486
    [1486] = { race = 255 },
    -- Horde-only (690) in our bundled data; the cmangos patch batch
    -- that also fixed 1486 corrects this one to Alliance-only (2).
    [3088] = { race = 2 },

    -- Bundled data expected Neeru Fireblade (npc 3216). Ascension's own
    -- database confirms the actual giver is Xerash Fireblade (npc
    -- 36208) instead -- a thematically related, differently-named NPC,
    -- suggesting this specific quest chain was reworked rather than
    -- moved to something unrelated.
    [3122] = { start = { U = {36208} } },
    -- Bundled data listed 5 possible givers (Sorek, Christoph Walker,
    -- Kelv Sternhammer, Wu Shen, Darnath Bladesinger), none of which
    -- Ascension's own database confirms -- the actual current giver is
    -- Torm Ragetotem (npc 3041).
    [8417] = { start = { U = {3041} } },
    -- Bundled data expected Officer Gothena (npc 15768). Ascension's
    -- own database confirms the actual giver is a different but
    -- similar-flavor NPC, Officer Thunderstrider (npc 15767).
    [8817] = { start = { U = {15767} } },

    -- "Salve via Skinning" -- bundled data expected Maybess Riverbreeze
    -- (npc 9529). Ascension's own database confirms the actual (and
    -- only -- no other alternate listed) giver is Arathandris Silversky
    -- (npc 9528).
    [4111] = { start = { U = {9528} } },
    -- "Frostfire Shoulderpads" -- bundled data expected Archmage Angela
    -- Dosantos (npc 16116), which matches neither of the two valid
    -- alternates Ascension's own database actually lists for this raid
    -- quest (npc 16114 "Scarlet Commander Marjhan" or npc 79025) --
    -- used 16114 since it's the one with existing coordinate data.
    [9098] = { start = { U = {16114} } },
}
