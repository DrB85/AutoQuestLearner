-- Real, documented bug fixes for specific quest fields, sourced from the
-- cmangos project's own changelog (community-maintained vanilla server
-- emulation core, same database lineage our bundled quest data itself
-- comes from). Only the ones confirmed to match our CURRENT bundled
-- value (i.e. we verified our data actually has the exact "before"
-- state each patch describes fixing) are included -- not applied
-- blindly just because a patch exists somewhere in the changelog.
--
-- Deliberately narrow in scope: only RequiredRaces (-> this addon's
-- "race" field) fixes are applied here. A parallel set of PrevQuestId
-- (-> "pre"/prerequisite) fixes was found in the same changelog, but
-- none of their "before" values matched what our bundled data actually
-- has for those quest IDs -- suggesting our "pre" field is derived
-- differently than a raw PrevQuestId column, not a direct
-- correspondence. Prerequisite data is high-stakes (a wrong value can
-- wrongly suppress OR wrongly suggest a quest), so those were left out
-- rather than guessed at.
--
-- Applied in AutoQuestLearner_Database.lua, once, right after all
-- bundled quest data sources have merged -- see
-- AutoQuestLearner_ApplyQuestFieldFixes.
AutoQuestLearnerQuestFieldFixes = {
    -- "Deviate Hides" -- was Horde-only (690), actually available to
    -- both factions (255). https://www.wowhead.com/tbc/quest=1486
    [1486] = { race = 255 },
    -- Horde-only (690) in our bundled data; the cmangos patch batch
    -- that also fixed 1486 corrects this one to Alliance-only (2).
    [3088] = { race = 2 },
}
