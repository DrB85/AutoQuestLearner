-- Quest OBJECTIVE spawn-location linkage (which NPC/object to find for
-- each quest's mid-quest objective, as opposed to the giver/turn-in NPC).
--
-- Converted from Xurkon/Questie-X-AscensionDB (Bronzebeard realm data,
-- MIT licensed: https://github.com/Xurkon/Questie-X-AscensionDB), using
-- Questie's own documented quest-objective schema (creatureObjective,
-- objectObjective, killCreditObjective -- see Questie/Database/questDB.lua
-- for the authoritative field layout this was decoded against). Only
-- entries where the referenced NPC/object ID ALSO has real spawn
-- coordinates elsewhere in this addon's own bundled units/objects data are
-- included -- item-collection and reputation/spell objectives are skipped
-- entirely rather than guessed, since there's no reliable drop-source data
-- for Ascension's custom item IDs to resolve them to a location.
--
-- NOTE: this is Bronzebeard-realm data specifically -- no realm-specific
-- data for other Ascension realms (Rexxar included) was available upstream
-- at the time this was bundled. Ascension realms mostly share the same
-- underlying quest world, so this should still be broadly correct there,
-- but treat it as a starting point: this addon's own learned-location
-- system (see AutoQuestLearner.lua's RecordLocation) will silently
-- self-correct any entry that's actually wrong for your realm the moment
-- you personally complete that objective, same as it does for giver/
-- turn-in locations.
pfDB["quests"]["data-questiex-obj"] = pfDB["quests"]["data-questiex-obj"] or {}
local data = {
[17000]={["obj"]={["O"]={96000}}},
[100073]={["obj"]={["O"]={9900730}}},
[100466]={["obj"]={["O"]={4673875}}},
[254015]={["obj"]={["U"]={254016},["O"]={5777365}}},
[254053]={["obj"]={["O"]={192380,254678}}},
[254054]={["obj"]={["U"]={254936,254937,254938}}},
[254057]={["obj"]={["O"]={254679}}},
[254064]={["obj"]={["U"]={254584},["O"]={2306601,2306602,2306603,2306604}}},
[500006]={["obj"]={["U"]={76555}}},
[1660003]={["obj"]={["O"]={999005,999006,999007,999008}}},
[1660004]={["obj"]={["O"]={999010,999011,999012}}},
[1660005]={["obj"]={["U"]={161736,161716}}},
[1660007]={["obj"]={["O"]={5401381}}},
[1660009]={["obj"]={["U"]={161775},["O"]={5883992}}},
[1660011]={["obj"]={["O"]={5888887}}},
[1660012]={["obj"]={["U"]={161787},["O"]={5166357}}},
[1660013]={["obj"]={["O"]={5861249}}},
[1660015]={["obj"]={["O"]={5005829}}},
[1660016]={["obj"]={["O"]={2300513,5911478}}},
[1660017]={["obj"]={["O"]={2300526,5943833}}},
[1660019]={["obj"]={["O"]={2036820}}},
[1660021]={["obj"]={["O"]={6649507}}},
[1660022]={["obj"]={["U"]={161790}}},
[1660023]={["obj"]={["U"]={161807}}},
[1660025]={["obj"]={["U"]={161762,161763,161764,161765}}},
[1660027]={["obj"]={["U"]={161757}}},
[1660029]={["obj"]={["U"]={161743,161752,161749}}},
[1660031]={["obj"]={["O"]={5976414}}},
[1660033]={["obj"]={["U"]={161816},["O"]={1942447}}},
[1660034]={["obj"]={["U"]={161850,161851,161852},["O"]={2300527,2300533,2300534}}},
[1660037]={["obj"]={["U"]={161854,161855,161856}}},
[1660038]={["obj"]={["U"]={161712}}},
[1660039]={["obj"]={["U"]={161835}}},
[1660040]={["obj"]={["U"]={161832}}},
[1660041]={["obj"]={["U"]={161833,161793,161792}}},
[1660042]={["obj"]={["U"]={161836}}},
[1660043]={["obj"]={["U"]={161834}}},
[1660052]={["obj"]={["U"]={162857,162853,162854}}},
[1660053]={["obj"]={["U"]={162859,162860,162861}}},
[1660054]={["obj"]={["O"]={5093560}}},
[1660057]={["obj"]={["O"]={9000057}}},
[1660058]={["obj"]={["O"]={2300579}}},
[1660060]={["obj"]={["U"]={162943}}},
[1660061]={["obj"]={["O"]={9070546}}},
[1660062]={["obj"]={["U"]={162834,162835,162916}}},
[1660064]={["obj"]={["U"]={162836}}},
[1660065]={["obj"]={["O"]={5954015}}},
[1660067]={["obj"]={["O"]={5195713,5195711}}},
[1660068]={["obj"]={["U"]={162907}}},
[1660070]={["obj"]={["O"]={5299566}}},
[1660072]={["obj"]={["U"]={162856,162870,162871,162872,162873}}},
[1660073]={["obj"]={["U"]={162925},["O"]={5388202}}},
[1660074]={["obj"]={["U"]={162876,162877}}},
[1660075]={["obj"]={["O"]={5399902}}},
[1660078]={["obj"]={["U"]={162888,162889,162890}}},
[1660079]={["obj"]={["U"]={162917}}},
[1660080]={["obj"]={["O"]={5855933}}},
[1660085]={["obj"]={["O"]={5405229}}},
[1903520]={["obj"]={["O"]={9905201,9905202}}},
[1903540]={["obj"]={["O"]={9903540}}},
[1903556]={["obj"]={["O"]={9903556}}},
[1903557]={["obj"]={["O"]={9903556}}},
[4420430]={["obj"]={["O"]={9942043}}},
[4420432]={["obj"]={["O"]={9942043}}},
[4420434]={["obj"]={["O"]={9942043}}},
[4420435]={["obj"]={["O"]={9942043}}},
[4420437]={["obj"]={["O"]={9942043}}},
[4420439]={["obj"]={["O"]={9942043}}},
}
for k,v in pairs(data) do pfDB["quests"]["data-questiex-obj"][k]=v end
