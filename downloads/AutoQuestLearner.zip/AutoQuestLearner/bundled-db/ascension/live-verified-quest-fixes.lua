-- FEATURE (per user request): quests confirmed to have ZERO giver/
-- turn-in coverage anywhere in this addon's bundled database at all
-- (not even a title), cross-checked directly against Ascension's own
-- live public database (db.ascension.gg) rather than a vanilla-era
-- SQL dump -- so unlike the vanilla-derived sources this session
-- already investigated and declined to merge (see the earlier
-- calibration-transform investigation), this data reflects Ascension's
-- ACTUAL current server state directly, not a guessed/transformed
-- vanilla position.
--
-- Every entry here was individually verified: the quest's "Start"
-- field was read directly from Ascension's own database page for that
-- exact quest ID, and (for the 5 npc/object-start entries) the
-- resulting npcID/objectID was confirmed to already have real
-- coordinate data elsewhere in this addon's bundled database from
-- other, unrelated quest associations -- meaning the arrow can
-- navigate to these immediately, with no new coordinate guessing
-- involved at all.
--
-- Three quests deliberately NOT included here despite being found in
-- the same investigation (IDs 4, 43, 81244 -- "Spirit Wars: Reclaiming
-- Auchindoun", and "Dungeon Diving"): all three are dungeon-instance
-- content, and their giver NPCs have no coordinate data anywhere,
-- including on Ascension's own site -- consistent with this addon's
-- established position that dungeon interiors aren't something its
-- coordinate system can respond to reliably (see the dungeon-routing
-- discussion this session). Left out rather than guessed at.
--
-- The two "Learn to Ride" entries are item-triggered starts (no NPC/
-- object location at all -- the quest begins from having the item),
-- so only the item-start link is added; there's no location for the
-- arrow to point to for these, which is expected and correct for how
-- this quest type actually works.
pfDB["quests"] = pfDB["quests"] or {}
pfDB["quests"]["data-livesourced"] = pfDB["quests"]["data-livesourced"] or {}
pfDB["quests"]["loc-livesourced"] = pfDB["quests"]["loc-livesourced"] or {}

local data = pfDB["quests"]["data-livesourced"]
local loc = pfDB["quests"]["loc-livesourced"]

-- Kill 'Em With Sleep Deprivation -- giver: Evonice Sootsmoker (npc 14628)
data[7702] = { ["start"] = { ["U"] = {14628} } }
loc[7702] = { ["T"] = "Kill 'Em With Sleep Deprivation" }

-- Toxic Tolerance -- giver: Mor'vek (npc 11701)
data[13850] = { ["start"] = { ["U"] = {11701} } }
loc[13850] = { ["T"] = "Toxic Tolerance" }

-- They Grow Up So Fast -- giver: Mor'vek (npc 11701)
data[13906] = { ["start"] = { ["U"] = {11701} } }
loc[13906] = { ["T"] = "They Grow Up So Fast" }

-- Prestige: Open World -- giver: Sten Stoutarm (npc 658)
data[80956] = { ["start"] = { ["U"] = {658} } }
loc[80956] = { ["T"] = "Prestige: Open World" }

-- Attack on Camp Narache -- giver: Dirt-stained Map (object 3076)
data[24857] = { ["start"] = { ["O"] = {3076} } }
loc[24857] = { ["T"] = "Attack on Camp Narache" }

-- Learn to Ride in Elwynn Forest -- item-triggered start (item 46875),
-- no NPC/object location involved.
data[14079] = { ["start"] = { ["I"] = {46875} } }
loc[14079] = { ["T"] = "Learn to Ride in Elwynn Forest" }

-- Learn to Ride in Tirisfal Glades -- item-triggered start (item 46881),
-- no NPC/object location involved.
data[14089] = { ["start"] = { ["I"] = {46881} } }
loc[14089] = { ["T"] = "Learn to Ride in Tirisfal Glades" }
