-- Confirmed-repurposed quest IDs (Ascension reused a real vanilla
-- quest ID for entirely unrelated custom content -- see
-- questIDIsRepurposed in AutoQuestLearner.lua) where the CORRECT
-- objective target has been manually researched and verified, so the
-- addon isn't left with zero usable data just because the vanilla
-- quest's own bundled data (which is wrong for this ID on Ascension)
-- gets correctly suppressed.
--
-- Same shape as a normal quest's ["obj"] field (["U"]/["O"]/["I"]
-- arrays of creature/object/item IDs). Only add an entry here once
-- BOTH of these are true: (1) the ID is confirmed repurposed (live
-- title doesn't match bundled title), and (2) the correct target has
-- been independently verified, not guessed.
--
-- [246] = "Serena's Head" (Barrens, live) vs bundled "Assessing the
-- Threat" (Redridge Mountains, vanilla) -- confirmed repurposed.
-- Correct target: Serena Bloodfeather, creature 3452 -- confirmed via
-- the creature's own name directly matching the objective item name
-- ("Serena's Head"), and its bundled coordinate (39.2, 12.2, zone 17)
-- independently matching the same northwestern Barrens harpy camp
-- already cross-validated earlier for the Witchwing Talon/Harpy
-- Raiders quest (867) -- the same creature family, same real camp.
AutoQuestLearnerRepurposedQuestOverrides = {
    [246] = { ["U"] = {3452} },
}
