-- New NPC spawn coordinates sourced from db.exil.es (coa-db)
-- Cross-referenced against bundled pfQuest/Questie-X database - these IDs were NOT previously present.
-- Vanilla-relevant only (Eastern Kingdoms/Kalimdor outdoor zones + classic instances).
-- Coordinates are 0-100 percentage format, zone IDs from AreaTable.
pfDB["units"]["data-coa-exiles"] = pfDB["units"]["data-coa-exiles"] or {}
local data = pfDB["units"]["data-coa-exiles"]

data[723] = { ["coords"] = { [1] = { 50.0, 31.0, 33, 0 } } } -- Mosh'Ogg Butcher
data[1001] = { ["coords"] = { [1] = { 45.0, 66.0, 10, 0 } } } -- Watcher Hutchins
data[1203] = { ["coords"] = { [1] = { 19.0, 41.0, 41, 0 } } } -- Watcher Sarys
data[1204] = { ["coords"] = { [1] = { 14.0, 43.0, 41, 0 } } } -- Watcher Corwin
data[1436] = { ["coords"] = { [1] = { 45.0, 67.0, 10, 0 } } } -- Watcher Cutford
data[1475] = { ["coords"] = { [1] = { 8.0, 57.0, 11, 0 } } } -- Menethil Guard
data[1849] = { ["coords"] = { [1] = { 1.0, 73.0, 139, 0 } } } -- Dreadwhisper
data[1892] = { ["coords"] = { [1] = { 46.0, 75.0, 130, 0 } } } -- Moonrage Watcher
data[1893] = { ["coords"] = { [1] = { 43.0, 73.0, 130, 0 } } } -- Moonrage Sentry
data[1896] = { ["coords"] = { [1] = { 48.0, 74.0, 130, 0 } } } -- Moonrage Elder
data[1983] = { ["coords"] = { [1] = { 45.0, 21.0, 130, 0 } } } -- Nightlash
data[2188] = { ["coords"] = { [1] = { 59.0, 3.0, 148, 0 } } } -- Deep Sea Threshadon
data[2302] = { ["coords"] = { [1] = { 59.0, 37.0, 1657, 0 } } } -- Aethalas
data[2602] = { ["coords"] = { [1] = { 18.0, 69.0, 45, 0 } } } -- Ruul Onestone
data[2603] = { ["coords"] = { [1] = { 95.0, 74.0, 267, 0 } } } -- Kovork
data[2604] = { ["coords"] = { [1] = { 53.0, 80.0, 45, 0 } } } -- Molok the Crusher
data[2605] = { ["coords"] = { [1] = { 67.0, 80.0, 45, 0 } } } -- Zalas Witherbark
data[2606] = { ["coords"] = { [1] = { 65.0, 74.0, 45, 0 } } } -- Nimar the Slayer
data[3094] = { ["coords"] = { [1] = { 4.0, 64.0, 41, 0 } } } -- Unseen
data[3529] = { ["coords"] = { [1] = { 46.0, 72.0, 130, 0 } } } -- Moonrage Armorer
data[3531] = { ["coords"] = { [1] = { 47.0, 72.0, 130, 0 } } } -- Moonrage Tailor
data[3533] = { ["coords"] = { [1] = { 44.0, 74.0, 130, 0 } } } -- Moonrage Leatherworker
data[3652] = { ["coords"] = { [1] = { 56.0, 45.0, 718, 0 } } } -- Trigore the Lasher
data[3996] = { ["coords"] = { [1] = { 74.0, 4.0, 406, 0 } } } -- Faldreas Goeth'Shael
data[4528] = { ["coords"] = { [1] = { 56.0, 70.0, 491, 0 } } } -- Summoned Earth Guardian
data[4535] = { ["coords"] = { [1] = { 62.0, 74.0, 491, 0 } } } -- Tamed Battleboar
data[5194] = { ["coords"] = { [1] = { 69.0, 12.0, 1637, 0 } } } -- Black Riding Wolf
data[5348] = { ["coords"] = { [1] = { 14.0, 71.0, 8, 0 } } } -- Dreamwatcher Forktongue
data[5470] = { ["coords"] = { [1] = { 37.0, 79.0, 440, 0 } } } -- Raging Dune Smasher
data[6071] = { ["coords"] = { [1] = { 21.0, 5.0, 14, 0 } } } -- Legion Hound
data[6495] = { ["coords"] = { [1] = { 80.0, 76.0, 400, 0 } } } -- Riznek
data[7135] = { ["coords"] = { [1] = { 41.0, 41.0, 361, 0 } } } -- Infernal Bodyguard
data[7228] = { ["coords"] = { [1] = { 38.0, 77.0, 1337, 0 } } } -- Ironaya
data[8257] = { ["coords"] = { [1] = { 41.0, 76.0, 1477, 0 } } } -- Summoned Oozeling
data[8336] = { ["coords"] = { [1] = { 16.0, 63.0, 1477, 0 } } } -- Hakkari Sapper
data[8387] = { ["coords"] = { [1] = { 74.0, 2.0, 14, 0 } } } -- Horizon Scout First Mate
data[8388] = { ["coords"] = { [1] = { 74.0, 2.0, 14, 0 } } } -- Horizon Scout Cook
data[8389] = { ["coords"] = { [1] = { 74.0, 2.0, 14, 0 } } } -- Horizon Scout Engineer
data[8394] = { ["coords"] = { [1] = { 74.0, 2.0, 14, 0 } } } -- Roland Geardabbler
data[8478] = { ["coords"] = { [1] = { 51.0, 73.0, 357, 0 } } } -- Second Mate Shandril
data[8506] = { ["coords"] = { [1] = { -46.0, 163.0, 2257, 0 } } } -- Eranikus the Chained
data[8888] = { ["coords"] = { [1] = { 50.0, 57.0, 25, 0 } } } -- Franclorn Forgewright
data[8917] = { ["coords"] = { [1] = { 15.0, 12.0, 25, 0 } } } -- Quarry Slave
data[8924] = { ["coords"] = { [1] = { 19.0, 17.0, 25, 0 } } } -- The Behemoth
data[8964] = { ["coords"] = { [1] = { 46.0, 37.0, 25, 0 } } } -- Blackrock Drake
data[9026] = { ["coords"] = { [1] = { 33.0, 28.0, 25, 0 } } } -- Overmaster Pyron
data[9496] = { ["coords"] = { [1] = { 82.0, 31.0, 540, 0 } } } -- Gorishi Egg
data[9541] = { ["coords"] = { [1] = { 48.0, 50.0, 1584, 0 } } } -- Blackbreath Crony
data[9708] = { ["coords"] = { [1] = { 35.0, 60.0, 1583, 0 } } } -- Enslaved Imp
data[10236] = { ["coords"] = { [1] = { 74.0, 48.0, 405, 0 } } } -- Wep
data[10238] = { ["coords"] = { [1] = { 73.0, 73.0, 405, 0 } } } -- Staggon
data[10261] = { ["coords"] = { [1] = { 67.0, 54.0, 1583, 0 } } } -- Burning Felhound
data[10442] = { ["coords"] = { [1] = { 48.0, 17.0, 1583, 0 } } } -- Chromatic Whelp
data[10447] = { ["coords"] = { [1] = { 45.0, 59.0, 1583, 0 } } } -- Chromatic Dragonspawn
data[10603] = { ["coords"] = { [1] = { 94.0, 93.0, 363, 0 } } } -- Hallucination
data[10988] = { ["coords"] = { [1] = { 48.0, 60.0, 405, 0 } } } -- Kodo Spirit
data[11258] = { ["coords"] = { [1] = { 28.0, 27.0, 2057, 0 } } } -- Frail Skeleton
data[11285] = { ["coords"] = { [1] = { 19.0, 11.0, 47, 0 } } } -- Rory
data[11447] = { ["coords"] = { [1] = { 63.0, 31.0, 357, 0 } } } -- Mushgog
data[11497] = { ["coords"] = { [1] = { 63.0, 29.0, 357, 0 } } } -- The Razza
data[11498] = { ["coords"] = { [1] = { 19.0, 100.0, 215, 0 } } } -- Skarr the Unbreakable
data[11560] = { ["coords"] = { [1] = { 65.0, 91.0, 405, 0 } } } -- Magrami Spectre
data[13431] = { ["coords"] = { [1] = { 42.0, 55.0, 1638, 0 } } } -- Whulwert Copperpinch
data[13533] = { ["coords"] = { [1] = { 49.0, 20.0, 2100, 0 } } } -- Spewed Larva
data[14233] = { ["coords"] = { [1] = { 38.0, 50.0, 15, 0 } } } -- Ripscale
data[14236] = { ["coords"] = { [1] = { 78.0, 10.0, 400, 0 } } } -- Lord Angler
data[14387] = { ["coords"] = { [1] = { 39.0, 39.0, 25, 0 } } } -- Lothos Riftwaker
data[14395] = { ["coords"] = { [1] = { 62.0, 30.0, 357, 0 } } } -- Griniblix the Spectator
data[14396] = { ["coords"] = { [1] = { 18.0, 71.0, 2557, 0 } } } -- Eye of Immol'thar
data[14482] = { ["coords"] = { [1] = { 18.0, 72.0, 2557, 0 } } } -- Xorothian Imp
data[14483] = { ["coords"] = { [1] = { 19.0, 79.0, 2557, 0 } } } -- Dread Guard
data[14504] = { ["coords"] = { [1] = { 15.0, 79.0, 2557, 0 } } } -- Dreadsteed Spirit
data[14566] = { ["coords"] = { [1] = { 35.0, 77.0, 2557, 0 } } } -- Ancient Equine Spirit
data[14842] = { ["coords"] = { [1] = { 32.0, 78.0, 1537, 0 } } } -- Melnan Darkstone
data[14843] = { ["coords"] = { [1] = { 53.0, 66.0, 1637, 0 } } } -- Kruban Darkblade
data[14887] = { ["coords"] = { [1] = { 9.0, 60.0, 16, 0 } } } -- Ysondre
data[14888] = { ["coords"] = { [1] = { 63.0, 28.0, 47, 0 } } } -- Lethon
data[14889] = { ["coords"] = { [1] = { 3.0, 76.0, 215, 0 } } } -- Emeriss
data[14890] = { ["coords"] = { [1] = { 45.0, 40.0, 10, 0 } } } -- Taerar
data[15199] = { ["coords"] = { [1] = { 50.0, 57.0, 267, 0 } } } -- Sergeant Hartman
data[15428] = { ["coords"] = { [1] = { 44.0, 60.0, 3429, 0 } } } -- Sand Vortex
data[15587] = { ["coords"] = { [1] = { 63.0, 31.0, 357, 0 } } } -- Elder Mistwalker
data[15724] = { ["coords"] = { [1] = { 28.0, 77.0, 33, 0 } } } -- Drunken Bruiser
data[15745] = { ["coords"] = { [1] = { 33.0, 65.0, 1537, 0 } } } -- Greatfather Winter's Helper
data[15746] = { ["coords"] = { [1] = { 52.0, 69.0, 1637, 0 } } } -- Great-father Winter's Helper
data[15989] = { ["coords"] = { [1] = { 3522.0, -5237.0, 3456, 0 } } } -- Sapphiron
data[16031] = { ["coords"] = { [1] = { 46.0, 13.0, 2017, 0 } } } -- Ysida Harmon
data[16033] = { ["coords"] = { [1] = { 27.0, 32.0, 25, 0 } } } -- Bodley
data[16070] = { ["coords"] = { [1] = { 50.0, 14.0, 1537, 0 } } } -- Garel Redrock
data[16123] = { ["coords"] = { [1] = { 28.0, 77.0, 33, 0 } } } -- Gremnik Rizzlesprang
data[16226] = { ["coords"] = { [1] = { 74.0, 52.0, 139, 0 } } } -- Guard Didier
data[16232] = { ["coords"] = { [1] = { 75.0, 52.0, 139, 0 } } } -- Caravan Mule
data[17066] = { ["coords"] = { [1] = { 44.0, 88.0, 8, 0 } } } -- Ribbon Pole Debug Target
data[17231] = { ["coords"] = { [1] = { 54.0, 65.0, 3456, 0 } } } -- Garden Gas
data[23193] = { ["coords"] = { [1] = { 1309.0, 1663.0, 153, 0 } } } -- Lordaeron Citizen (Jesse)
data[24364] = { ["coords"] = { [1] = { 97.0, 88.0, 136, 0 } } } -- Flynn Firebrew
data[24495] = { ["coords"] = { [1] = { 44.0, 18.0, 14, 0 } } } -- Blix Fixwidget
data[24527] = { ["coords"] = { [1] = { 48.0, 28.0, 14, 0 } } } -- Bok Dropcertain
data[24818] = { ["coords"] = { [1] = { 32.0, 1.0, 25, 0 } } } -- Anvilrage Taskmaster
data[24819] = { ["coords"] = { [1] = { 33.0, 19.0, 25, 0 } } } -- Anvilrage Enforcer
data[26166] = { ["coords"] = { [1] = { 40.0, 30.0, 405, 0 } } } -- Heretic Crystal Guard
data[27216] = { ["coords"] = { [1] = { 45.0, 17.0, 14, 0 } } } -- Bizzle Quicklift
data[28987] = { ["coords"] = { [1] = { 45.0, 66.0, 10, 0 } } } -- Watcher Blomberg
data[29144] = { ["coords"] = { [1] = { 35.0, 40.0, 1519, 0 } } } -- Refurbished Steam Tank
data[29346] = { ["coords"] = { [1] = { 32.0, 37.0, 1637, 0 } } } -- Apothecary Karlov
data[29865] = { ["coords"] = { [1] = { 17.0, 93.0, 1941, 0 } } } -- Stratholme Citizen Specimen
data[29866] = { ["coords"] = { [1] = { 17.0, 93.0, 1941, 0 } } } -- Stratholme Resident Specimen
data[29867] = { ["coords"] = { [1] = { 21.0, 91.0, 1941, 0 } } } -- Lordaeron Footman Specimen
data[29868] = { ["coords"] = { [1] = { 22.0, 89.0, 1941, 0 } } } -- Stratholme Child Specimen
data[29873] = { ["coords"] = { [1] = { 54.0, 77.0, 1941, 0 } } } -- Cat Specimen
data[30083] = { ["coords"] = { [1] = { 30.0, 15.0, 3456, 0 } } } -- Marauding Geist
data[30578] = { ["coords"] = { [1] = { 83.0, 34.0, 1519, 0 } } } -- Bethany Aldire
data[30579] = { ["coords"] = { [1] = { 70.0, 89.0, 1537, 0 } } } -- Marga Bearbrawn
data[30582] = { ["coords"] = { [1] = { 80.0, 31.0, 1637, 0 } } } -- Ufuda Giant-Slayer
data[30583] = { ["coords"] = { [1] = { 56.0, 85.0, 1497, 0 } } } -- Sarah Forthright
data[30590] = { ["coords"] = { [1] = { 58.0, 77.0, 1638, 0 } } } -- Godo Cloudcleaver
data[30617] = { ["coords"] = { [1] = { 31.0, 49.0, 493, 0 } } } -- Nightmare Aberration
data[30627] = { ["coords"] = { [1] = { 35.0, 44.0, 493, 0 } } } -- Nightmare Figment
data[32823] = { ["coords"] = { [1] = { 47.0, 15.0, 14, 0 } } } -- Bountiful Table
data[33068] = { ["coords"] = { [1] = { 100.0, 88.0, 405, 0 } } } -- Darkmoon Faire - Cannon Target Bunny
data[34435] = { ["coords"] = { [1] = { 39.0, 61.0, 12, 0 } } } -- Cheerful Human Spirit
data[34476] = { ["coords"] = { [1] = { 68.0, 15.0, 1497, 0 } } } -- Cheerful Forsaken Spirit
data[34477] = { ["coords"] = { [1] = { 47.0, 18.0, 14, 0 } } } -- Cheerful Orc Spirit
data[34479] = { ["coords"] = { [1] = { 76.0, 26.0, 1657, 0 } } } -- Cheerful Night Elf Spirit
data[34480] = { ["coords"] = { [1] = { 57.0, 18.0, 1638, 0 } } } -- Cheerful Tauren Spirit
data[34482] = { ["coords"] = { [1] = { 47.0, 18.0, 14, 0 } } } -- Cheerful Troll Spirit
data[34562] = { ["coords"] = { [1] = { 49.0, 58.0, 267, 0 } } } -- [DND] Stink Bomb Target
data[34565] = { ["coords"] = { [1] = { 51.0, 59.0, 267, 0 } } } -- Innocuous Townsman
data[34644] = { ["coords"] = { [1] = { 12.0, 98.0, 1537, 0 } } } -- Edward Winslow
data[34645] = { ["coords"] = { [1] = { 12.0, 96.0, 1537, 0 } } } -- Elizabeth Barker Winslow
data[34653] = { ["coords"] = { [1] = { 79.0, 97.0, 1519, 0 } } } -- Bountiful Table Hostess
data[34654] = { ["coords"] = { [1] = { 65.0, 8.0, 1497, 0 } } } -- Bountiful Feast Hostess
data[34675] = { ["coords"] = { [1] = { 79.0, 97.0, 1519, 0 } } } -- Gregory Tabor
data[34676] = { ["coords"] = { [1] = { 65.0, 36.0, 1657, 0 } } } -- Isaac Allerton
data[34677] = { ["coords"] = { [1] = { 64.0, 10.0, 1497, 0 } } } -- Miles Standish
data[34678] = { ["coords"] = { [1] = { 31.0, 67.0, 1638, 0 } } } -- Dokin Farplain
data[34679] = { ["coords"] = { [1] = { 46.0, 15.0, 14, 0 } } } -- Francis Eaton
data[34681] = { ["coords"] = { [1] = { 66.0, 36.0, 1657, 0 } } } -- Ikaneba Summerset
data[34682] = { ["coords"] = { [1] = { 78.0, 96.0, 1519, 0 } } } -- Wilmina Holbeck
data[34683] = { ["coords"] = { [1] = { 64.0, 10.0, 1497, 0 } } } -- Rose Standish
data[34684] = { ["coords"] = { [1] = { 31.0, 67.0, 1638, 0 } } } -- Laha Farplain
data[34685] = { ["coords"] = { [1] = { 46.0, 15.0, 14, 0 } } } -- Dalni Tallgrass
data[34708] = { ["coords"] = { [1] = { 12.0, 97.0, 1537, 0 } } } -- Caitrin Ironkettle
data[34710] = { ["coords"] = { [1] = { 79.0, 97.0, 1519, 0 } } } -- Ellen Moore
data[34711] = { ["coords"] = { [1] = { 67.0, 33.0, 1657, 0 } } } -- Mary Allerton
data[34712] = { ["coords"] = { [1] = { 63.0, 9.0, 1497, 0 } } } -- Roberta Carter
data[34713] = { ["coords"] = { [1] = { 46.0, 14.0, 14, 0 } } } -- Ondani Greatmill
data[34714] = { ["coords"] = { [1] = { 30.0, 67.0, 1638, 0 } } } -- Mahara Goldwheat
data[34744] = { ["coords"] = { [1] = { 79.0, 98.0, 1519, 0 } } } -- Jasper Moore
data[34768] = { ["coords"] = { [1] = { 64.0, 9.0, 1497, 0 } } } -- William Mullins
data[35020] = { ["coords"] = { [1] = { 58.0, 77.0, 1638, 0 } } } -- Deathscreamer Gura
data[35021] = { ["coords"] = { [1] = { 56.0, 85.0, 1497, 0 } } } -- Marog
data[35023] = { ["coords"] = { [1] = { 59.0, 37.0, 1657, 0 } } } -- Terrance Matterly
data[35024] = { ["coords"] = { [1] = { 83.0, 34.0, 1519, 0 } } } -- Dracien Flanning
data[35244] = { ["coords"] = { [1] = { 64.0, 8.0, 1497, 0 } } } -- Ghostly Forsaken Celebrant
data[35249] = { ["coords"] = { [1] = { 39.0, 61.0, 12, 0 } } } -- Ghostly Human Celebrant
data[35250] = { ["coords"] = { [1] = { 78.0, 26.0, 1657, 0 } } } -- Ghostly Night Elf Celebrant
data[35251] = { ["coords"] = { [1] = { 47.0, 18.0, 14, 0 } } } -- Ghostly Orc Celebrant
data[35252] = { ["coords"] = { [1] = { 57.0, 19.0, 1638, 0 } } } -- Ghostly Tauren Celebrant
data[35253] = { ["coords"] = { [1] = { 47.0, 18.0, 14, 0 } } } -- Ghostly Troll Celebrant
data[35477] = { ["coords"] = { [1] = { 70.0, 72.0, 1519, 0 } } } -- Little Adeline
data[35599] = { ["coords"] = { [1] = { 57.0, 37.0, 1657, 0 } } } -- Arcanist Dulial
data[37172] = { ["coords"] = { [1] = { 51.0, 66.0, 1637, 0 } } } -- Detective Snap Snagglebolt
data[37214] = { ["coords"] = { [1] = { 29.0, 66.0, 12, 0 } } } -- Crown Lackey
data[37671] = { ["coords"] = { [1] = { 57.0, 94.0, 1637, 0 } } } -- Crown Supply Guard
data[37917] = { ["coords"] = { [1] = { 55.0, 62.0, 130, 0 } } } -- Crown Thug
data[37984] = { ["coords"] = { [1] = { 28.0, 38.0, 267, 0 } } } -- Crown Duster
data[38006] = { ["coords"] = { [1] = { 62.0, 39.0, 15, 0 } } } -- Crown Hoodlum
data[38016] = { ["coords"] = { [1] = { 21.0, 53.0, 47, 0 } } } -- Crown Agent
data[38288] = { ["coords"] = { [1] = { 39.0, 64.0, 1519, 0 } } } -- Love Guard Perfume Bunny
data[38295] = { ["coords"] = { [1] = { 64.0, 37.0, 1497, 0 } } } -- Junior Detective
data[38328] = { ["coords"] = { [1] = { 59.0, 53.0, 1637, 0 } } } -- Roka
data[40176] = { ["coords"] = { [1] = { 58.0, 74.0, 14, 0 } } } -- Sen'jin Frog
data[40187] = { ["coords"] = { [1] = { 58.0, 73.0, 14, 0 } } } -- Vanira's Sentry Totem
data[40204] = { ["coords"] = { [1] = { 99.0, 93.0, 363, 0 } } } -- Handler Marnlek
data[40218] = { ["coords"] = { [1] = { 69.0, 81.0, 14, 0 } } } -- Spy Frog Credit
data[40222] = { ["coords"] = { [1] = { 64.0, 76.0, 14, 0 } } } -- Scout Bat
data[40253] = { ["coords"] = { [1] = { 58.0, 73.0, 14, 0 } } } -- Champion Uru'zin
data[40301] = { ["coords"] = { [1] = { 60.0, 83.0, 14, 0 } } } -- Tiger Matriarch Credit
data[40352] = { ["coords"] = { [1] = { 99.0, 89.0, 363, 0 } } } -- Witch Doctor Hez'tok
data[40356] = { ["coords"] = { [1] = { 57.0, 74.0, 14, 0 } } } -- Ritual Dancer
data[40361] = { ["coords"] = { [1] = { 57.0, 74.0, 14, 0 } } } -- Troll Dance Leader
data[40387] = { ["coords"] = { [1] = { 99.0, 89.0, 363, 0 } } } -- Omen Event Credit
data[40416] = { ["coords"] = { [1] = { 60.0, 76.0, 14, 0 } } } -- Darkspear Scout
data[40441] = { ["coords"] = { [1] = { 42.0, 43.0, 1657, 0 } } } -- Battered Brewmaster
data[40492] = { ["coords"] = { [1] = { 64.0, 74.0, 14, 0 } } } -- Zild'jian
data[41839] = { ["coords"] = { [1] = { 67.0, 84.0, 14, 0 } } } -- [DND] Controller

-- Manually verified entries (ambiguous names resolved via direct site checks)
-- Each candidate ID was individually confirmed against its Locations/Quests data
-- to ensure it is genuinely vanilla-era content, not phased WotLK/Cataclysm content
-- sharing the same NPC name.
data[19932] = { ["coords"] = { [1] = { 3, 86, 1941, 0 } } } -- Andormu
data[20130] = { ["coords"] = { [1] = { 8, 56, 1941, 0 } } } -- Andormu
data[10440] = { ["coords"] = { [1] = { 46, 13, 2017, 0 } } } -- Baron Rivendare
data[7937] = { ["coords"] = { [1] = { 69, 49, 1537, 0 } } } -- High Tinker Mekkatorque
data[6929] = { ["coords"] = { [1] = { 54, 68, 1637, 0 } } } -- Innkeeper Gryshka
data[10181] = { ["coords"] = { [1] = { 58, 92, 1497, 0 } } } -- Lady Sylvanas Windrunner
data[14392] = { ["coords"] = { [1] = { 52, 75, 1637, 0 } } } -- Overlord Runthak
data[4949] = { ["coords"] = { [1] = { 32, 38, 1637, 0 } } } -- Thrall
data[40184] = { ["coords"] = { [1] = { 58, 73, 14, 0 } } } -- Vanira
data[10540] = { ["coords"] = { [1] = { 34, 36, 1637, 0 } } } -- Vol'jin
data[19175] = { ["coords"] = { [1] = { 46, 71, 1637, 0 }, [2] = { 52, 71, 1637, 0 }, [3] = { 52, 72, 1637, 0 } } } -- Orc Commoner
