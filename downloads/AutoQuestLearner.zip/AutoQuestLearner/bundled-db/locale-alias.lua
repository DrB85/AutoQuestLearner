-- Merges the bundled TBC-suffixed data into the base tables, and
-- aliases the resulting English text into the generic "loc" key that
-- both pfQuest's own code and AutoQuestLearner expect. This replicates
-- pfQuest's own database.lua merge step exactly:
--   - pfDB[db]["data-tbc"] gets merged into pfDB[db]["data"]
--   - pfDB[db]["enUS-tbc"] gets merged into pfDB[db]["enUS"]
--   - pfDB[db]["loc"] = pfDB[db]["enUS"] (or left alone if already set,
--     e.g. by pfQuest itself also being installed with a different
--     detected locale)
-- patchtable() matches pfQuest's own semantics: a value of the string
-- "_" means "delete this key" rather than "set it to the string _".
local function patchtable(base, diff)
  for k, v in pairs(diff) do
    if v == "_" then
      base[k] = nil
    else
      base[k] = v
    end
  end
end

local dbs = { "quests", "objects", "units", "zones" }

for _, db in pairs(dbs) do
  if pfDB[db] then
    if pfDB[db]["data-tbc"] then
      pfDB[db]["data"] = pfDB[db]["data"] or {}
      patchtable(pfDB[db]["data"], pfDB[db]["data-tbc"])
    end
    if pfDB[db]["enUS-tbc"] then
      pfDB[db]["enUS"] = pfDB[db]["enUS"] or {}
      patchtable(pfDB[db]["enUS"], pfDB[db]["enUS-tbc"])
    end
  end
end

for _, db in pairs(dbs) do
  if pfDB[db] then
    if not pfDB[db]["loc"] or not next(pfDB[db]["loc"]) then
      pfDB[db]["loc"] = pfDB[db]["enUS"] or {}
    end
  end
end
