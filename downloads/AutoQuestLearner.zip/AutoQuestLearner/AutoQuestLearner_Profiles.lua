-- AutoQuestLearner: separate learned data per database.
--
-- Ascension and Conquest of AzerothCore place quest givers, turn-ins and
-- spawns differently, so what you learn on one must not leak into the
-- other. Everything the addon learns while playing (givers, turn-ins,
-- spawn points, rep/pvp gates, unavailable quests, ...) is kept per
-- profile: "asc" (Ascension) or "coa:<realm>" (one per Conquest of
-- AzerothCore realm, e.g. "coa:rexxar"). The
-- active profile is picked from the Conquest of AzerothCore setting
-- (/aql coa on|off|auto) every time the addon loads.
--
-- The live tables stay at AutoQuestLearnerDB.<key> so the rest of the addon
-- needs no changes; this file just swaps them in at load and parks them in
-- AutoQuestLearnerDB.profiles[<mode>] when the other profile is active.
-- This file must load before AutoQuestLearner.lua so its ADDON_LOADED
-- handler runs first.

local KEYS = {
  "learned", "knownUnavailable", "repRequired", "pvpRequired",
  "townsfolkSeen", "floorHints", "floorHintGroups", "snoozed",
  "seedVersionApplied", "dropStats",
}

-- Conquest of AzerothCore realms (CoA, Wildcard, Warcraft Reborn, Rexxar and
-- test realms) each keep their own learned data: "coa:<realm name>".
local function ActiveMode()
  if AutoQuestLearner_IsCoaServer and AutoQuestLearner_IsCoaServer() then
    local realm = string.lower(GetRealmName and GetRealmName() or "")
    realm = string.gsub(realm, "^%s+", "")
    realm = string.gsub(realm, "%s+$", "")
    if realm == "" then realm = "unknown" end
    return "coa:" .. realm
  end
  return "asc"
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGOUT")
frame:SetScript("OnEvent", function(self, event, name)
  local DB = AutoQuestLearnerDB
  if not DB then return end
  if event == "ADDON_LOADED" then
    if name ~= "AutoQuestLearner" then return end
    DB.config = DB.config or {}
    DB.profiles = DB.profiles or {}
    local P = DB.profiles
    local prev = DB.activeProfile or "asc"
    local mode = ActiveMode()
    P[prev] = P[prev] or {}
    P[mode] = P[mode] or {}
    -- 1. what is at the top level right now belongs to the previous profile
    for _, k in ipairs(KEYS) do
      if DB[k] ~= nil then P[prev][k] = DB[k] end
    end
    -- 1b. one-time: data learned before per-realm profiles ("coa") belongs to
    -- the live realm, Rexxar.
    if mode == "coa:rexxar" and P["coa"] and not P["coa:rexxar"] then
      P["coa:rexxar"] = P["coa"]
      P["coa"] = nil
    end
    P[mode] = P[mode] or {}
    -- 2. load the profile we are about to run
    for _, k in ipairs(KEYS) do
      DB[k] = P[mode][k]
    end
    DB.activeProfile = mode
    DB.profileSwitchedFrom = (prev ~= mode) and prev or nil
  elseif event == "PLAYER_LOGOUT" then
    -- The live tables are saved at the top level; drop the duplicate copy
    -- in the active profile so nothing is written twice.
    local P = DB.profiles
    local mode = DB.activeProfile
    if P and mode and P[mode] then
      for _, k in ipairs(KEYS) do P[mode][k] = nil end
    end
  end
end)

SLASH_AQLPROFILE1 = "/aqlprofile"
SlashCmdList["AQLPROFILE"] = function()
  local DB = AutoQuestLearnerDB or {}
  local mode = DB.activeProfile or "asc"
  local n = 0
  local L = DB.learned
  if L and L.quests then for _ in pairs(L.quests) do n = n + 1 end end
  print(string.format("|cff00ff00AutoQuestLearner:|r learned data profile: %s (%d quests learned in it). "
    .. "Switching Conquest of AzerothCore mode swaps profiles after /reload; each keeps its own learned data.",
    string.sub(mode, 1, 4) == "coa:" and ("Conquest of AzerothCore - " .. string.sub(mode, 5)) or "Ascension", n))
end
