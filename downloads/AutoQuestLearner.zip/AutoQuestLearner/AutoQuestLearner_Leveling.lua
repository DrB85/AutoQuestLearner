--[[
  AutoQuestLearner_Leveling.lua
  Guide Mode engine: ordered steps, arrow lock, minimal UI.

  When Guide Mode is ON, the arrow prefers the current guide step target
  instead of free FindClosestQuestDestination logic.

  Slash:
    /aql guide mode on|off
    /aql guide list
    /aql guide load <name substring>
    /aql guide next | skip | prev
    /aql guide ui
]]

AutoQuestLearner_Guides = AutoQuestLearner_Guides or {}
AutoQuestLearner_Leveling = AutoQuestLearner_Leveling or {}

local L = AutoQuestLearner_Leveling
L.guides = AutoQuestLearner_Guides
L.currentName = nil
L.steps = nil
L.index = 1
L.ui = nil

local function Cfg()
  AutoQuestLearnerDB = AutoQuestLearnerDB or {}
  AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
  local c = AutoQuestLearnerDB.config
  if c.guideMode == nil then c.guideMode = "0" end
  if c.guideName == nil then c.guideName = "" end
  if c.guideIndex == nil then c.guideIndex = 1 end
  return c
end


-- ---------------------------------------------------------------------------
-- Waypoint navigation (built-in AQL arrow only — no TomTom)
-- ---------------------------------------------------------------------------
--- Point the AQL arrow at the current guide step coordinates.
function L:SetWaypointForStep(step)
  -- Guide override in main file reads step via GetArrowTarget().
  -- Force an immediate arrow retarget.
  AutoQuestLearner_ForceArrowRefresh = true
  if step and step.x and step.y then
    local x, y = step.x, step.y
    if x <= 1 and y <= 1 then
      x, y = x * 100, y * 100
    end
    -- Stash for arrow/UI diagnostics
    L._navX, L._navY, L._navTitle = x, y, step.label or "Guide"
  else
    L._navX, L._navY, L._navTitle = nil, nil, nil
  end
end

function L:NavigateToCurrent()
  local step = self:GetCurrentStep()
  if step then
    -- Normalize coords once
    if step.x and step.y and step.x <= 1 and step.y <= 1 then
      step.x, step.y = step.x * 100, step.y * 100
    end
  end
  self:SetWaypointForStep(step)
end


local function Print(msg)
  if DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00AQL Guide|r: " .. tostring(msg))
  end
end

local function PlayerFaction()
  local f = UnitFactionGroup and UnitFactionGroup("player")
  if f == "Alliance" or f == "Horde" then return f end
  return nil
end

-- ---------------------------------------------------------------------------
-- Parse Guidelime-like tags into step table
-- ---------------------------------------------------------------------------
local function parseGuideText(text)
  local steps = {}
  local meta = { name = "Unnamed", faction = nil, next = nil, desc = nil }
  if not text then return meta, steps end

  for line in string.gmatch(text, "[^\r\n]+") do
    line = strtrim and strtrim(line) or line:match("^%s*(.-)%s*$")
    if line and line ~= "" and not line:match("^%-%-") then
      local step = {
        text = line,
        type = "note",
        qid = nil,
        obj = nil,
        x = nil,
        y = nil,
        zone = nil,
      }

      local n = line:match("%[N%s+([%d%.]+%-%s*[%d%.]+%s+[^%]]+)%]")
        or line:match("%[N%s+([^%]]+)%]")
      if n and line:match("%[N%s+[%d]") then
        meta.name = strtrim and strtrim(n) or n
      end
      local ga = line:match("%[GA%s+([^%]]+)%]")
      if ga then
        meta.faction = strtrim and strtrim(ga) or ga
      end
      local nx = line:match("%[NX%s+([^%]]+)%]")
      if nx then
        meta.next = strtrim and strtrim(nx) or nx
      end
      local d = line:match("%[D%s+([^%]]+)%]")
      if d then
        meta.desc = d
      end

      local qa = line:match("%[QA%s+(%d+)%]")
      local qt = line:match("%[QT%s+(%d+)%]")
      local qc, qco = line:match("%[QC%s+(%d+),(%d+)%]")
      local qcOnly = line:match("%[QC%s+(%d+)%]")
      local gx, gy, gz = line:match("%[G%s*([%d%.]+)%s*,%s*([%d%.]+)%s+([^%]]+)%]")
      if not gx then
        gx, gy = line:match("%[G%s*([%d%.]+)%s*,%s*([%d%.]+)%]")
      end

      if qa then
        step.type = "accept"
        step.qid = tonumber(qa)
      elseif qt then
        step.type = "turnin"
        step.qid = tonumber(qt)
      elseif qc then
        step.type = "complete"
        step.qid = tonumber(qc)
        step.obj = tonumber(qco)
      elseif qcOnly then
        step.type = "complete"
        step.qid = tonumber(qcOnly)
      elseif gx and gy then
        step.type = "goto"
      elseif line:match("%[N%]") or (line:match("%[N%s") and not line:match("%[N%s+[%d]")) then
        step.type = "note"
      end

      if gx and gy then
        step.x = tonumber(gx)
        step.y = tonumber(gy)
        if gz then step.zone = strtrim and strtrim(gz) or gz end
      end

      -- Skip pure header lines from the step list
      local isHeader = line:match("^%[N%s+[%d]") or line:match("^%[GA") or line:match("^%[NX") or line:match("^%[D")
      if not isHeader then
        -- Human-readable label
        local label = line:gsub("%[[^%]]+%]", "")
        label = (strtrim and strtrim(label) or label:match("^%s*(.-)%s*$")) or ""
        if label == "" then
          if step.type == "accept" then label = "Accept quest " .. tostring(step.qid)
          elseif step.type == "turnin" then label = "Turn in quest " .. tostring(step.qid)
          elseif step.type == "complete" then label = "Complete quest " .. tostring(step.qid)
          elseif step.type == "goto" then label = string.format("Go to %.1f, %.1f", step.x or 0, step.y or 0)
          else label = "Note" end
        end
        step.label = label
        table.insert(steps, step)
      end
    end
  end
  return meta, steps
end

function AutoQuestLearner_RegisterGuide(text)
  local meta, steps = parseGuideText(text)
  if not meta.name or meta.name == "" then
    meta.name = "Guide " .. tostring((#L.guides) + 1)
  end
  L.guides[meta.name] = {
    name = meta.name,
    faction = meta.faction,
    next = meta.next,
    desc = meta.desc,
    steps = steps,
    raw = text,
  }
end

-- ---------------------------------------------------------------------------
-- Progress / completion
-- ---------------------------------------------------------------------------
local function QuestInLog(qid)
  if not qid or not GetNumQuestLogEntries then return false, false end
  for i = 1, GetNumQuestLogEntries() do
    local title, _, _, _, isHeader, _, isComplete, _, questID = GetQuestLogTitle(i)
    if not isHeader then
      local id = questID
      if not id and GetQuestLogIndexByID then
        -- 3.3.5 may only expose title; skip id match
      end
      if id and tonumber(id) == tonumber(qid) then
        return true, isComplete == 1 or isComplete == true
      end
      -- Fallback: SelectQuestLogEntry + GetQuestLogQuestText not ideal; keep title path weak
    end
  end
  return false, false
end

local function QuestCompletedEver(qid)
  if not qid then return false end
  if GetQuestsCompleted then
    local t = GetQuestsCompleted()
    if type(t) == "table" and t[qid] then return true end
  end
  return false
end

function L:IsStepComplete(step)
  if not step then return true end
  if step.type == "accept" then
    local inLog = QuestInLog(step.qid)
    return inLog or QuestCompletedEver(step.qid)
  elseif step.type == "turnin" then
    return QuestCompletedEver(step.qid)
  elseif step.type == "complete" then
    local inLog, done = QuestInLog(step.qid)
    return (inLog and done) or QuestCompletedEver(step.qid)
  elseif step.type == "goto" then
    -- Manual or proximity
    if step._manual then return true end
    local px, py = GetPlayerMapPosition and GetPlayerMapPosition("player")
    if px and py and step.x and step.y then
      local dx = (px * 100) - step.x
      local dy = (py * 100) - step.y
      if (dx * dx + dy * dy) < (4 * 4) then -- ~4% map radius
        return true
      end
    end
    return false
  else
    return step._manual == true
  end
end

function L:GetCurrentStep()
  if not self.steps or #self.steps == 0 then return nil end
  local i = self.index or 1
  if i < 1 then i = 1 end
  if i > #self.steps then i = #self.steps end
  return self.steps[i], i
end

function L:AdvancePastCompleted()
  if not self.steps then return end
  local before = self.index
  while self.index <= #self.steps and self:IsStepComplete(self.steps[self.index]) do
    self.index = self.index + 1
  end
  if self.index > #self.steps then
    self.index = #self.steps
  end
  Cfg().guideIndex = self.index
  if self.index ~= before then
    self:NavigateToCurrent()
  end
end

function L:Next()
  if not self.steps then return end
  local step = self.steps[self.index]
  if step then step._manual = true end
  if self.index < #self.steps then
    self.index = self.index + 1
  else
    if self:TryLoadNextGuide() then return end
  end
  Cfg().guideIndex = self.index
  self:NavigateToCurrent()
  self:RefreshUI()
  Print(string.format("Step %d/%d: %s", self.index, #self.steps, (self.steps[self.index] and self.steps[self.index].label) or "?"))
end

function L:Skip()
  self:Next()
end

function L:Prev()
  if not self.steps then return end
  if self.index > 1 then
    self.index = self.index - 1
    local step = self.steps[self.index]
    if step then step._manual = nil end
  end
  Cfg().guideIndex = self.index
  self:NavigateToCurrent()
  self:RefreshUI()
end

function L:Load(name)
  local g = self.guides[name]
  if not g then
    -- substring match
    local lower = string.lower(name or "")
    for k, v in pairs(self.guides) do
      if string.find(string.lower(k), lower, 1, true) then
        g = v
        name = k
        break
      end
    end
  end
  if not g then
    Print("Guide not found: " .. tostring(name))
    return false
  end
  self.currentName = name
  self.steps = g.steps
  self.index = 1
  Cfg().guideName = name
  Cfg().guideIndex = 1
  Cfg().guideMode = "1"
  self:AdvancePastCompleted()
  self:NavigateToCurrent()
  self:RefreshUI()
  Print(string.format("Loaded |cff00ff00%s|r (%d steps). Guide Mode ON.", name, #self.steps))
  return true
end


function L:TryLoadNextGuide()
  local g = self.currentName and self.guides[self.currentName]
  if not g or not g.next then return false end
  local nextName = g.next
  -- exact or substring
  if self.guides[nextName] then
    return self:Load(nextName)
  end
  for k, _ in pairs(self.guides) do
    if string.find(string.lower(k), string.lower(nextName), 1, true) then
      return self:Load(k)
    end
  end
  Print("Next guide not found: " .. tostring(nextName))
  return false
end

function L:List()
  Print("Available guides:")
  local fac = PlayerFaction()
  for name, g in pairs(self.guides) do
    local mark = ""
    if g.faction and fac and g.faction ~= fac then
      mark = " |cff888888(" .. tostring(g.faction) .. " only)|r"
    end
    Print("  - " .. name .. mark)
  end
end

function L:SetMode(on)
  Cfg().guideMode = on and "1" or "0"
  if on and Cfg().guideName and Cfg().guideName ~= "" and not self.steps then
    self:Load(Cfg().guideName)
  end
  Print("Guide Mode " .. (on and "ON" or "OFF"))
  AutoQuestLearner_ForceArrowRefresh = true
  self:RefreshUI()
end

function L:IsModeOn()
  return Cfg().guideMode == "1"
end

-- ---------------------------------------------------------------------------
-- Arrow target from current step
-- ---------------------------------------------------------------------------
-- Returns loc table {x=, y=}, title, name, questID compatible with arrow cache
function L:GetArrowTarget()
  if not self:IsModeOn() then return nil end
  if not self.steps then
    if Cfg().guideName and Cfg().guideName ~= "" then
      self:Load(Cfg().guideName)
    else
      return nil
    end
  end
  self:AdvancePastCompleted()
  local step = self:GetCurrentStep()
  if not step then return nil end

  local title = step.label or "Guide step"
  local qid = step.qid

  if step.x and step.y then
    local loc = { x = step.x, y = step.y }
    return loc, title, step.zone or "Guide", qid, false, "guide"
  end

  -- No coords on step: try DB via existing FindClosest if available for this qid only
  if qid and type(FindClosestQuestDestination) == "function" then
    -- FindClosestQuestDestination is local in main file — not visible here.
    -- Leave name-only; main file can enrich.
  end

  -- Placeholder: pointless loc nil means main arrow keeps previous or searches
  return nil, title, "Guide (no coords)", qid, false, "guide"
end

-- Exposed for main arrow loop
function AutoQuestLearner_Leveling_GetArrowOverride()
  return L:GetArrowTarget()
end

function AutoQuestLearner_Leveling_IsActive()
  return L:IsModeOn() and L.steps ~= nil
end

-- ---------------------------------------------------------------------------
-- Quest Tracking UI (guide + log objectives)
-- ---------------------------------------------------------------------------
local function GetQuestLogObjectives(qid)
  if not qid or not GetNumQuestLogEntries then return nil, {} end
  local titleOut, objs = nil, {}
  for i = 1, GetNumQuestLogEntries() do
    local title, level, _, _, isHeader, _, isComplete, _, questID = GetQuestLogTitle(i)
    if not isHeader then
      local id = questID
      if id and tonumber(id) == tonumber(qid) then
        titleOut = title
        if SelectQuestLogEntry then SelectQuestLogEntry(i) end
        local n = GetNumQuestLeaderBoards and GetNumQuestLeaderBoards(i) or 0
        for o = 1, n do
          local text, objType, finished = GetQuestLogLeaderBoard(o, i)
          if text then
            table.insert(objs, { text = text, done = finished and true or false, type = objType })
          end
        end
        break
      end
    end
  end
  return titleOut, objs
end

function L:BuildTrackingText()
  local lines = {}
  local step, idx = self:GetCurrentStep()
  local total = self.steps and #self.steps or 0
  local mode = self:IsModeOn() and "|cff00ff00ON|r" or "|cffff6666OFF|r"
  local name = self.currentName or Cfg().guideName or "(no guide)"
  table.insert(lines, "|cffffcc00Guide:|r " .. tostring(name) .. "  | Mode " .. mode)
  if total > 0 then
    local pct = math.floor(((idx or 1) - 1) / math.max(total, 1) * 100)
    table.insert(lines, string.format("|cffffcc00Progress:|r step %d / %d  (%d%%)", idx or 0, total, pct))
  end
  table.insert(lines, " ")
  if step then
    local typeCol = {
      accept = "|cff00ff00Accept|r",
      turnin = "|cffffff00Turn-in|r",
      complete = "|cffff8800Complete|r",
      ["goto"] = "|cff88ccffGo to|r",
      note = "|cffaaaaaaNote|r",
    }
    table.insert(lines, (typeCol[step.type] or step.type) .. "  " .. (step.label or "?"))
    if step.qid then
      table.insert(lines, string.format("|cffaaaaaaQuest ID:|r %s", tostring(step.qid)))
    end
    if step.x and step.y then
      table.insert(lines, string.format("|cffaaaaaaCoords:|r %.1f, %.1f %s", step.x, step.y, step.zone or ""))
    end
    if step.qid then
      local qtitle, objs = GetQuestLogObjectives(step.qid)
      if qtitle then
        table.insert(lines, " ")
        table.insert(lines, "|cff00ff00In log:|r " .. qtitle)
        if #objs == 0 then
          table.insert(lines, "  |cffaaaaaa(no objectives listed)|r")
        else
          for _, o in ipairs(objs) do
            local mark = o.done and "|cff00ff00✓|r" or "|cffff0000•|r"
            table.insert(lines, "  " .. mark .. " " .. o.text)
          end
        end
      else
        table.insert(lines, "|cff888888(quest not in log yet)|r")
      end
    end
  else
    table.insert(lines, "No active step.")
    table.insert(lines, "|cffaaaaaa/aql guide list|r then |cffaaaaaa/aql guide load <name>|r")
  end
  -- Upcoming steps
  if self.steps and idx and idx < #self.steps then
    table.insert(lines, " ")
    table.insert(lines, "|cffffcc00Up next:|r")
    for j = idx + 1, math.min(idx + 3, #self.steps) do
      local s = self.steps[j]
      table.insert(lines, string.format("  %d. %s", j, s.label or "?"))
    end
  end
  return table.concat(lines, "\n")
end

function L:RefreshUI()
  if not self.ui then return end
  if self.ui.trackText then
    self.ui.trackText:SetText(self:BuildTrackingText())
  end
  if self.ui.title then
    local mode = self:IsModeOn() and "|cff00ff00ON|r" or "|cffff6666OFF|r"
    self.ui.title:SetText("|cff00ff00AQL Quest Tracker|r  " .. mode)
  end
  -- Progress bar
  if self.ui.bar and self.steps and #self.steps > 0 then
    local idx = self.index or 1
    local pct = (idx - 1) / #self.steps
    self.ui.bar:SetValue(pct * 100)
    if self.ui.barText then
      self.ui.barText:SetText(string.format("%d / %d", idx, #self.steps))
    end
  end
end

function L:ShowUI()
  if self.ui then
    self.ui:Show()
    self:RefreshUI()
    return
  end
  local f = CreateFrame("Frame", "AutoQuestLearnerLevelingUI", UIParent)
  f:SetWidth(360)
  f:SetHeight(300)
  f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 80)
  f:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
  })
  f:SetBackdropColor(0, 0, 0, 0.85)
  f:SetBackdropBorderColor(0.4, 0.8, 0.4, 1)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  f:SetClampedToScreen(true)
  table.insert(UISpecialFrames, "AutoQuestLearnerLevelingUI")

  f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.title:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -10)
  f.title:SetText("|cff00ff00AQL Quest Tracker|r")

  f.close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)

  -- Progress bar
  f.bar = CreateFrame("StatusBar", nil, f)
  f.bar:SetHeight(14)
  f.bar:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -32)
  f.bar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -32)
  f.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
  f.bar:SetStatusBarColor(0.2, 0.8, 0.3)
  f.bar:SetMinMaxValues(0, 100)
  f.bar:SetValue(0)
  local bg = f.bar:CreateTexture(nil, "BACKGROUND")
  bg:SetAllPoints()
  bg:SetTexture(0.1, 0.1, 0.1, 0.8)
  f.barText = f.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.barText:SetPoint("CENTER", f.bar, "CENTER")
  f.barText:SetText("0 / 0")

  f.scroll = CreateFrame("ScrollFrame", "AQLLevelingScroll", f)
  f.scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -52)
  f.scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -28, 58)

  f.content = CreateFrame("Frame", nil, f.scroll)
  f.content:SetWidth(320)
  f.content:SetHeight(400)
  f.scroll:SetScrollChild(f.content)

  f.trackText = f.content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.trackText:SetPoint("TOPLEFT", f.content, "TOPLEFT", 4, -4)
  f.trackText:SetWidth(310)
  f.trackText:SetJustifyH("LEFT")
  f.trackText:SetJustifyV("TOP")
  f.trackText:SetNonSpaceWrap(true)

  local function mkbtn(id, x, label, width, onclick)
    local b = CreateFrame("Button", id, f, "UIPanelButtonTemplate")
    b:SetWidth(width or 56)
    b:SetHeight(22)
    b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", x, 10)
    b:SetText(label)
    b:SetScript("OnClick", onclick)
    return b
  end
  mkbtn("AQLTrackPrev", 10, "Prev", 52, function() L:Prev() end)
  mkbtn("AQLTrackSkip", 66, "Skip", 52, function() L:Skip() end)
  mkbtn("AQLTrackNext", 122, "Next", 52, function() L:Next() end)
  mkbtn("AQLTrackMode", 178, "Mode", 52, function()
    L:SetMode(not L:IsModeOn())
  end)
  mkbtn("AQLTrackStart", 234, "Starter", 58, function()
    if AutoQuestLearner_Leveling_LoadStarter then AutoQuestLearner_Leveling_LoadStarter() end
  end)
  mkbtn("AQLTrackList", 296, "List", 48, function() L:List() end)
  -- Nav button sits above list if space tight — add second row
  local nav = CreateFrame("Button", "AQLTrackNav", f, "UIPanelButtonTemplate")
  nav:SetWidth(100)
  nav:SetHeight(20)
  nav:SetPoint("BOTTOM", f, "BOTTOM", 0, 34)
  nav:SetText("Point Arrow")
  nav:SetScript("OnClick", function() L:NavigateToCurrent() end)


  -- Live refresh while visible
  f:SetScript("OnUpdate", function(self, elapsed)
    self._t = (self._t or 0) + elapsed
    if self._t < 0.5 then return end
    self._t = 0
    if self:IsShown() then L:RefreshUI() end
  end)

  self.ui = f
  self:RefreshUI()
  f:Show()
end

-- ---------------------------------------------------------------------------
-- Events: auto-advance on quest log changes
-- ---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("QUEST_LOG_UPDATE")
ev:RegisterEvent("QUEST_COMPLETE")
ev:RegisterEvent("QUEST_FINISHED")
ev:SetScript("OnEvent", function(self, event)
  if event == "PLAYER_LOGIN" then
    local c = Cfg()
    if c.guideMode == "1" and c.guideName and c.guideName ~= "" then
      -- Guides register at load; delay slightly so all guide files are in
      self.elapsed = 0
      self:SetScript("OnUpdate", function(s, e)
        s.elapsed = (s.elapsed or 0) + e
        if s.elapsed < 1 then return end
        s:SetScript("OnUpdate", nil)
        if L.guides[c.guideName] then
          L.currentName = c.guideName
          L.steps = L.guides[c.guideName].steps
          L.index = tonumber(c.guideIndex) or 1
          L:AdvancePastCompleted()
          Print("Restored guide: " .. c.guideName)
        end
      end)
    end
    return
  end
  if L:IsModeOn() and L.steps then
    local before = L.index
    L:AdvancePastCompleted()
    if L.index ~= before then
      AutoQuestLearner_ForceArrowRefresh = true
      L:RefreshUI()
    end
  end
end)

-- ---------------------------------------------------------------------------
-- Slash helpers (wired from main /aql if present; also standalone)
-- ---------------------------------------------------------------------------
function AutoQuestLearner_Leveling_HandleCommand(msg)
  msg = msg or ""
  msg = strtrim and strtrim(msg) or msg
  local cmd, rest = msg:match("^(%S+)%s*(.*)$")
  cmd = cmd and string.lower(cmd) or ""
  rest = rest or ""

  if cmd == "mode" then
    local v = string.lower(rest)
    if v == "on" or v == "1" or v == "true" then L:SetMode(true)
    elseif v == "off" or v == "0" or v == "false" then L:SetMode(false)
    else Print("Usage: /aql guide mode on|off") end
  elseif cmd == "list" then
    L:List()
  elseif cmd == "load" then
    if rest == "" then Print("Usage: /aql guide load <name>") else L:Load(rest) end
  elseif cmd == "next" then
    L:Next()
  elseif cmd == "skip" then
    L:Skip()
  elseif cmd == "prev" then
    L:Prev()
  elseif cmd == "ui" or cmd == "show" then
    L:ShowUI()
  elseif cmd == "nextguide" or cmd == "chain" then
    self:TryLoadNextGuide()
  elseif cmd == "nav" or cmd == "waypoint" or cmd == "wp" then
    self:NavigateToCurrent()
    local step = self:GetCurrentStep()
    if step and step.x then
      Print(string.format("AQL arrow → %.1f, %.1f %s", step.x, step.y, step.zone or ""))
    else
      Print("No coordinates on current step.")
    end
  elseif cmd == "status" then
    Print(string.format("Mode=%s Guide=%s Step=%s/%s",
      tostring(L:IsModeOn()),
      tostring(L.currentName or Cfg().guideName),
      tostring(L.index),
      tostring(L.steps and #L.steps or 0)))
  else
    Print("Commands: mode on|off | list | load <name> | next | skip | prev | ui | nav | status")
  end
end

-- Auto-pick starter guide by faction (optional helper)
function AutoQuestLearner_Leveling_LoadStarter()
  local f = PlayerFaction()
  if f == "Horde" then
    return L:Load("1-12 Tirisfal Glades")
  elseif f == "Alliance" then
    return L:Load("1-12 Elwynn Forest")
  end
  Print("Unknown faction; use /aql guide list")
  return false
end
