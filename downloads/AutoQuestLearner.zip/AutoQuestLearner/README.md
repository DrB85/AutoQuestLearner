# AutoQuestLearner

A standalone quest-navigation addon for [Project Ascension](https://project-ascension.com/) (WotLK 3.3.5a client, custom classless system). No dependencies required — pfQuest and Questie-X are fully optional.

**Points you at your next quest giver, objective, or turn-in with a live arrow, learns locations automatically as you (and everyone else running it) play, and shares what it learns across your whole account and, optionally, your group.**

## What it does

At its core, this addon learns as you play. Quest giver locations, turn-in locations, and objective spawn points all get saved to a shared, account-wide database — so if the bundled data doesn't already know where something is, the addon fills that gap in, and it only gets more complete the more it's played through.

- **Smart navigation arrow** — points you at your next objective or turn-in, with the actual objective description shown underneath (not just "find X nearby")
- **Learns as you play** — quest givers, turn-ins, and objective spawns all get recorded automatically and refined toward the most recently confirmed position
- **Available quest suggestions** — the arrow can point you toward nearby quests you haven't picked up yet, filtered by level, faction, reputation, completion history, and known chain prerequisites
- **`/aql suggestzone`** — suggests which zone to level in next, following the same progression established Classic leveling guides use, race/faction-aware
- **Shared learning** — live sync with party/raid/guild, or `/aql export`/`/aql import` to trade your full learned history with anyone
- **In-game quest tracker**, map/minimap nodes, route planner, zone completion tracking, quest chain preview
- **Multi-language data** — quest/NPC/zone names available in German, French, Korean, Portuguese, Russian, Spanish, and Chinese, auto-matched to your client
- **Outline Spawn Areas** — optional shaded-area display for kill-objective hunting grounds instead of a dot cluster (gathering nodes always keep precise pins)
- Handles quest IDs Ascension has repurposed for different custom content, rather than just losing location data for them

Alliance and Horde are both fully supported.

## Installation

1. Download the latest release and extract it.
2. Copy the `AutoQuestLearner` folder into your WoW/Ascension `Interface\AddOns\` folder, so the final path looks like:
   ```
   ...\Interface\AddOns\AutoQuestLearner\AutoQuestLearner.toc
   ```
3. Fully restart the game client (not just `/reload`) the first time you install it.
4. Make sure the addon is enabled in your AddOns list.

## Getting started

Run `/aql guide` in-game for a full walkthrough of the arrow, map icons, and pinning a quest. `/aql status` (or just `/aql`) gives a quick command summary at any time; `/aql help all` lists every command, including advanced/diagnostic ones most people never need.

The most useful commands day-to-day:

| Command | What it does |
|---|---|
| `/aql config` | Opens the settings panel |
| `/aql learn [quest]` | Manually save your current spot as a location — the main way bad/missing data gets corrected |
| `/aql missing` | Report a quest giver that genuinely isn't where the arrow sent you |
| `/aql suggestzone` | Suggests where to level next |
| `/aql sync` | Check location-sharing status with your group |
| `/aql route` | Suggests an efficient order to tackle your active quests |

Full command reference is in the bundled `README.txt`, or the [project site](https://drb85.github.io/AutoQuestLearner/) (tiered by how often you'd actually need them).

## Contributing

Found a bad or missing location? `/aql learn` and `/aql missing` fix it permanently for everyone using the shared database — no need to file anything. For addon bugs or feature requests, open an issue here.

## Credits

Inspired by [pfQuest](https://github.com/shagu/pfQuest) (by shagu) and Questie-X (maintained by Xurkon, a fork of the original [Questie](https://github.com/Questie/Questie) project rebuilt for private servers). A number of quest NPC gaps are filled in from the original Questie project's contributors (Aero, Logon, Muehe, TheCrux/BreakBB, Drejjmit, Dyaxler, Cheeq, TechnoHunter, and others). Precise objective-area coordinates are supplemented with data from TourGuideVanilla (by cralor, credit to Tekkub for the original framework).

A lot of what powers this addon comes from projects that had gone quiet — community databases nobody had cross-checked in years, NPC data compiled by contributors long since moved on. The ongoing work here has been about maintaining those projects: validating old data against independent sources (including authentic client data pulled directly from a real 3.3.5a build), cross-checking creature spawn data against multiple independently-sourced databases, and fixing what had quietly drifted wrong — rather than just compiling from scratch.

Author: Ezinagro

## License

See `LICENSE` (or the license notes bundled with the addon) for terms.
