--[[
AutoQuestLearner v2.0
Enhanced standalone quest addon with auto-learning, quest tracker, map integration, and database.
Combines data from pfQuest and pfQuest-ascension with custom UI.

Features:
- Auto-learn quest locations from gossip, quest events, and proximity scans
- Quest tracker with objectives and progress tracking
- World map and minimap node display
- Quest database integration with pfQuest data (optional)
- Configuration panel for customization
- Standalone operation (no dependencies required)

Original Auto-Learning Features:
  QUEST_GREETING  - Learn from multi-quest greeting windows
  GOSSIP_SHOW     - Learn from gossip dialogs
  QUEST_DETAIL    - Learn from quest detail dialogs
  QUEST_PROGRESS  - Learn from quest progress dialogs
  QUEST_COMPLETE  - Learn from quest completion dialogs
  MERCHANT_SHOW   - Learn from vendor NPCs

New Features v2.0:
- Quest tracker with expandable objectives
- World map integration with quest nodes
- Minimap node display
- Database integration with pfQuest/pfQuest-ascension (optional)
- Configuration UI
- Enhanced slash commands
- Completely standalone (no external dependencies)

Slash commands:
  /aql         - show addon status and stats
  /aql scan    - force proximity scan now
  /aql gossip  - reprocess current gossip window
  /aql config  - open configuration panel
  /aql tracker - toggle quest tracker
]]

local addonName, ns = ...

-- Create global table for addon functions
AutoQuestLearner = AutoQuestLearner or CreateFrame("Frame")

------------------------------------------------------------
-- SavedVariables bootstrap
------------------------------------------------------------
local function EnsureDatabaseState()
    AutoQuestLearnerDB = AutoQuestLearnerDB or {}

    -- Quest/unit/object/item/zone data lives in AutoQuestLearnerData (a
    -- plain, non-SavedVariable global) — see AutoQuestLearner_Database.lua
    -- for why this must never be persisted to disk.
    AutoQuestLearnerData = AutoQuestLearnerData or {}
    AutoQuestLearnerData.quests = AutoQuestLearnerData.quests or {}
    AutoQuestLearnerData.quests["data"] = AutoQuestLearnerData.quests["data"] or {}
    AutoQuestLearnerData.quests["loc"] = AutoQuestLearnerData.quests["loc"] or {}
    AutoQuestLearnerData.units = AutoQuestLearnerData.units or {}
    AutoQuestLearnerData.units["data"] = AutoQuestLearnerData.units["data"] or {}
    AutoQuestLearnerData.objects = AutoQuestLearnerData.objects or {}
    AutoQuestLearnerData.objects["data"] = AutoQuestLearnerData.objects["data"] or {}
    AutoQuestLearnerData.items = AutoQuestLearnerData.items or {}
    AutoQuestLearnerData.items["data"] = AutoQuestLearnerData.items["data"] or {}
    AutoQuestLearnerData.zones = AutoQuestLearnerData.zones or {}
    AutoQuestLearnerData.zones["loc"] = AutoQuestLearnerData.zones["loc"] or {}

    -- Strip any leftover copy of the database from a previous version so
    -- it doesn't keep bloating the SavedVariables file.
    AutoQuestLearnerDB.quests = nil
    AutoQuestLearnerDB.units = nil
    AutoQuestLearnerDB.objects = nil
    AutoQuestLearnerDB.items = nil
    AutoQuestLearnerDB.zones = nil

    AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
    AutoQuestLearnerDB.history = AutoQuestLearnerDB.history or {}
    AutoQuestLearnerDB.colors = AutoQuestLearnerDB.colors or {}

    -- Same issue as above: the node style default was originally
    -- "Simple Markers" (single markers only, no dot clusters), and
    -- anyone who opened the config panel before this changed already
    -- has "simple" persisted regardless of the current default order.
    -- Force it to "spawn" (dot clusters) once, matching the
    -- consistently-requested preference.
    -- Force spawn-dot style once: one pin per unique spawn-table coord
    -- (avoids combined mode stacking badges + dots = overpopulation).
    if AutoQuestLearnerDB.config.nodeStyleForcedSpawn ~= "2" then
        AutoQuestLearnerDB.config.nodestyle = "spawn"
        AutoQuestLearnerDB.config.nodeStyleForcedSpawn = "2"
    end
end

EnsureDatabaseState()

AutoQuestLearnerDB.settings = AutoQuestLearnerDB.settings or {
    autoImportPfQuest = false, -- auto-trigger RexxarDB's pfQuest import on first login
    enableProximityScan = false, -- poll for nearby quest givers every few seconds
    proximityInterval = 15, -- seconds between proximity polls (cheap; not per-frame)
    gossipLearning = true, -- record locations from gossip / quest greeting windows
    eventLearning = true, -- record locations from quest detail / progress / complete events
}
AutoQuestLearnerDB.stats = AutoQuestLearnerDB.stats or {
    gossipLearned = 0,
    eventLearned = 0,
    proximityLearned = 0,
    lastImportCount = 0,
    lastImportTime = 0,
}

local function EnsureSettings()
    AutoQuestLearnerDB = AutoQuestLearnerDB or {}
    if not AutoQuestLearnerDB.settings then
        AutoQuestLearnerDB.settings = {
            autoImportPfQuest = false,
            enableProximityScan = true,
            proximityInterval = 10,
            gossipLearning = true,
            eventLearning = true,
        }
    end
    if not AutoQuestLearnerDB.stats then
        AutoQuestLearnerDB.stats = {
            gossipLearned = 0,
            eventLearned = 0,
            proximityLearned = 0,
            lastImportCount = 0,
            lastImportTime = 0,
        }
    end
    -- Initialize config table for new modules
    if not AutoQuestLearnerDB.config then
        AutoQuestLearnerDB.config = {
            showtracker = "1",
            trackeralpha = "0",
            trackerfontsize = "12",
            trackerexpand = "0",
            allquestgivers = "1",
            currentquestgivers = "1",
            showlowlevel = "0",
            showhighlevel = "0",
            minimapnodes = "1",
            focusmode = "1",
            syncParty = "1",
            syncGuild = "0",
            spawncolors = "0",
            worldmaptransp = "1.0",
            minimaptransp = "1.0",
            mouseover = "1",
            showtooltips = "1",
            trackerlevel = "1",
            questloglevel = "0",
            questlogbuttons = "1",
            worldmapmenu = "1",
            trackingmethod = 1,
        }
        print("|cff00ff00AutoQuestLearner:|r Thanks for installing! Type |cffffcc00/aql guide|r for a quick how-to-use guide, or |cffffcc00/aql config|r for settings.")

        -- Also pop the guide window itself open automatically, a few
        -- seconds after this first-ever install is detected (not
        -- instantly -- gives the player a moment to actually load into
        -- the world first, rather than a window appearing before
        -- they've even seen their character). Guarded since this file
        -- can technically run before AutoQuestLearner_Guide.lua has
        -- finished loading, however unlikely in practice.
        local welcomeTimer = CreateFrame("Frame")
        local welcomeElapsed = 0
        welcomeTimer:SetScript("OnUpdate", function(self, e)
            welcomeElapsed = welcomeElapsed + (e or 0)
            if welcomeElapsed < 3 then return end
            self:SetScript("OnUpdate", nil)
            if AutoQuestLearner_ShowGuide then
                AutoQuestLearner_ShowGuide()
            end
        end)
    end
    -- Forward-compat: fill in any new settings added after a user's existing DB
    local s = AutoQuestLearnerDB.settings
    s.autoImportPfQuest = (s.autoImportPfQuest == nil) and false or s.autoImportPfQuest
    s.enableProximityScan = (s.enableProximityScan == nil) and true or s.enableProximityScan
    s.proximityInterval = s.proximityInterval or 10
    s.gossipLearning = (s.gossipLearning == nil) and true or s.gossipLearning
    s.eventLearning = (s.eventLearning == nil) and true or s.eventLearning
end

------------------------------------------------------------
-- Standalone data storage system
------------------------------------------------------------
local function GetPlayerKey()
    return UnitName("player") .. "-" .. GetRealmName()
end

local function GetChar()
    local key = GetPlayerKey()
    AutoQuestLearnerDB.chars = AutoQuestLearnerDB.chars or {}
    AutoQuestLearnerDB.chars[key] = AutoQuestLearnerDB.chars[key] or {
        questLocations = {},
    }
    return AutoQuestLearnerDB.chars[key]
end

local function GetCurrentMap()
    -- IMPORTANT: AutoQuestLearnerMap.nodes are keyed by pfDB's own
    -- internal numeric zone-ID scheme (the same one coord[3] uses in
    -- units/objects coordinate data), which AutoQuestLearnerMap:GetMapID()
    -- resolves via a translation table -- NOT the numeric ID from
    -- GetCurrentMapAreaID() (Blizzard's own, unrelated AreaID scheme),
    -- and NOT the raw zone-name string either. Those are three
    -- different value spaces -- using the wrong one means nothing ever
    -- matches what UpdateNodes() / UpdateMinimap() look up, so nothing
    -- renders.
    --
    -- BUGFIX: GetCurrentMapContinent()/GetCurrentMapZone() report
    -- whatever zone the World Map UI is currently NAVIGATED TO, not
    -- necessarily the player's actual physical location -- if the map
    -- was ever manually browsed to a different zone (or simply left in
    -- that state), this kept returning the wrong zone for everything
    -- downstream, including the arrow and GetPlayerPos's coordinates.
    -- SetMapToCurrentZone() forces it back to reality, but only while
    -- the World Map is closed -- calling it while the map is open would
    -- yank it away from the player mid-browse, which is worse.
    if WorldMapFrame and not WorldMapFrame:IsVisible() then
        SetMapToCurrentZone()
    end

    if AutoQuestLearnerMap then
        return AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
    end
    return GetCurrentMapAreaID()
end
AutoQuestLearner_GetCurrentMap = GetCurrentMap

-- Cached separately from GetCurrentMap() itself: that function
-- deliberately does NOT force-sync to the player's real position while
-- the World Map is open (see its own comment above -- doing so would
-- yank the view away mid-browse). That's correct for its own use by
-- the arrow, but means it can't be used to answer "what zone is the
-- player ACTUALLY in" while the map is open and browsed elsewhere --
-- it would just report whatever's being browsed to. This cache updates
-- only when the map is closed (when GetCurrentMap() is safe to trust),
-- so it stays accurate regardless of what's currently being browsed.
AutoQuestLearner_LastKnownPlayerZone = nil
local playerZoneCacheFrame = CreateFrame("Frame")
playerZoneCacheFrame:RegisterEvent("ZONE_CHANGED")
playerZoneCacheFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
playerZoneCacheFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
playerZoneCacheFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
playerZoneCacheFrame:SetScript("OnEvent", function()
    if not WorldMapFrame or not WorldMapFrame:IsVisible() then
        AutoQuestLearner_LastKnownPlayerZone = GetCurrentMap()
    end
end)

local function GetPlayerPos()
    local x, y = GetPlayerMapPosition("player")
    if not x or (x == 0 and y == 0) then return nil end
    -- GetPlayerMapPosition returns 0-1 fractions; the rest of the addon
    -- (AddNode, pfDB coords, minimap/world map placement math) all use
    -- 0-100 percentages, so scale here once at the source.
    --
    -- Third return value: raw world Z height, from UnitPosition (added
    -- in the 3.1 API, available on this client -- NOT a percentage,
    -- an actual in-world height in yards). GetPlayerMapPosition's x/y
    -- alone can't tell two vertically-stacked locations apart (e.g. a
    -- cave with an upper and lower level, or a multi-story building) --
    -- confirmed real, this is exactly why the arrow's own "Coordinates
    -- can't tell floors apart" hint exists. Capturing height here too,
    -- wherever a location gets learned, is what makes it possible to
    -- actually tell the two floors apart afterward instead of just
    -- warning that they might be different. nil on any client where
    -- UnitPosition doesn't exist -- degrades gracefully, everything
    -- downstream already treats z as optional.
    local z = nil
    if UnitPosition then
        local ok, _, _, worldZ = pcall(UnitPosition, "player")
        if ok then z = worldZ end
    end
    return x * 100, y * 100, z
end

------------------------------------------------------------
-- AutoQuestLearner's own shared database
--
-- This is separate from GetChar()'s per-character questLocations
-- (which only tracks "have I already recorded this on THIS character",
-- for idempotency). AutoQuestLearnerDB.learned is account-wide and
-- shared across every character -- knowledge one character picks up
-- benefits all your alts immediately, and this is what actually gets
-- drawn as map/minimap nodes. Structure:
--   learned.quests[questID] = { title=, giver={x,y,mapID}, turnin={x,y,mapID} }
--   learned.objectives[questID][objIndex] = { text=, spawns={ {x,y,mapID}, ... } }
------------------------------------------------------------
-- Bump this whenever the shape or meaning of location data changes in
-- a way that makes previously-saved entries invalid or misleading.
-- The mapID field has gone through three different, mutually
-- incompatible formats over the course of development (Blizzard's raw
-- AreaID, then a zone-name string, now pfDB's own internal numeric
-- zone-ID scheme) -- rather than try to detect and salvage entries
-- from earlier formats, we just wipe and let it rebuild cleanly, since
-- none of those entries ever actually rendered correctly anyway.
local LEARNED_SCHEMA_VERSION = 4

local function GetLearnedDB()
    if AutoQuestLearnerDB.learnedSchemaVersion ~= LEARNED_SCHEMA_VERSION then
        AutoQuestLearnerDB.learned = { quests = {}, objectives = {} }
        if AutoQuestLearnerDB.chars then
            for _, char in pairs(AutoQuestLearnerDB.chars) do
                char.questLocations = {}
            end
        end
        AutoQuestLearnerDB.learnedSchemaVersion = LEARNED_SCHEMA_VERSION
    end

    AutoQuestLearnerDB.learned = AutoQuestLearnerDB.learned or {}
    AutoQuestLearnerDB.learned.quests = AutoQuestLearnerDB.learned.quests or {}
    AutoQuestLearnerDB.learned.objectives = AutoQuestLearnerDB.learned.objectives or {}
    return AutoQuestLearnerDB.learned
end

-- Shared by /aql learnedstats and the automatic PLAYER_LOGIN display
-- (see /aql learnedstatsauto to toggle the latter) -- direct, reusable
-- way to verify learned data is actually accumulating. Account-wide
-- (see GetLearnedDB/AutoQuestLearnerDB's SavedVariables declaration),
-- so this reflects everything learned by every character, not just
-- the one currently logged in.
local function PrintLearnedStats()
    local learned = GetLearnedDB()
    local questsWithGiver, questsWithTurnin = 0, 0
    for _, entry in pairs(learned.quests or {}) do
        if entry.giver then questsWithGiver = questsWithGiver + 1 end
        if entry.turnin then questsWithTurnin = questsWithTurnin + 1 end
    end
    local objectivesWithSpawns, totalSpawnPoints = 0, 0
    for _, objs in pairs(learned.objectives or {}) do
        for _, obj in pairs(objs) do
            local n = obj.spawns and table.getn(obj.spawns) or 0
            if n > 0 then
                objectivesWithSpawns = objectivesWithSpawns + 1
                totalSpawnPoints = totalSpawnPoints + n
            end
        end
    end
    print("|cff00ff00AutoQuestLearner:|r Learned data summary (account-wide, every character combined)")
    print("  Quest giver locations learned: " .. questsWithGiver)
    print("  Quest turn-in locations learned: " .. questsWithTurnin)
    print("  Objectives with at least one learned spawn point: " .. objectivesWithSpawns)
    print("  Total individual spawn points learned: " .. totalSpawnPoints)
    if questsWithGiver == 0 and questsWithTurnin == 0 and objectivesWithSpawns == 0 then
        print("  |cffff8800Nothing learned yet -- this would be 0 right after a fresh install, or if something's actually broken.|r")
    end
end

-- Returns a set of mapIDs (pfDB's numeric zone scheme, same as
-- GetCurrentMap()) that this quest is known to be associated with --
-- everywhere we've personally learned a giver/turn-in/objective
-- location for it, plus the bundled static giver/turn-in unit
-- coordinates when available. Returns nil if nothing is known at all
-- (deliberately distinct from an empty set) so callers can tell "we
-- have no idea" apart from "we checked, it's just not here" -- used by
-- the tracker's zone filter (AutoQuestLearnerDB.config.trackerzonefilter)
-- to decide whether to hide a quest that isn't for the player's
-- current zone, without hiding quests it simply has no data for.
-- True if this quest ID only exists because of an Ascension-specific
-- bundled source (data-ascension/data-questiex/etc.), not because it's
-- real vanilla/TBC content those sources happen to add supplementary
-- data to. Built once at database init by diffing quest IDs known
-- before vs. after the Ascension-specific merge -- see
-- InitializeDatabase in AutoQuestLearner_Database.lua.
function AutoQuestLearner_IsAscensionCustomQuest(questID)
    if not questID then return false end
    if AutoQuestLearnerAscensionOnlyQuestIDs then
        if AutoQuestLearnerAscensionOnlyQuestIDs[questID] then return true end
        if AutoQuestLearnerAscensionOnlyQuestIDs[tonumber(questID)] then return true end
        if AutoQuestLearnerAscensionOnlyQuestIDs[tostring(questID)] then return true end
    end
    return false
end

-- Tracker + arrow: never navigate/list Ascension-only / Path to Ascension quests
function AutoQuestLearner_ShouldIgnoreQuest(questID, questTitle)
    if questTitle and (
        string.find(questTitle, "^Path to Ascension")
        or string.find(questTitle, "^Path To Ascension")
    ) then
        return true
    end
    if questID and AutoQuestLearner_IsAscensionCustomQuest(questID) then
        return true
    end
    -- Ascension custom content uses very high numeric IDs (e.g. 1.6M+)
    local n = tonumber(questID)
    if n and n >= 100000 then
        return true
    end
    return false
end

function AutoQuestLearner_GetQuestZoneMapIDs(questID)
    if not questID then return nil end
    local zones = nil
    local function add(mapID)
        if not mapID then return end
        zones = zones or {}
        zones[mapID] = true
    end

    local learned = GetLearnedDB()
    local entry = learned.quests and learned.quests[questID]
    if entry then
        if entry.giver then add(entry.giver.mapID) end
        if entry.turnin then add(entry.turnin.mapID) end
    end
    local objs = learned.objectives and learned.objectives[questID]
    if objs then
        for _, obj in pairs(objs) do
            for _, spawn in pairs(obj.spawns or {}) do
                add(spawn.mapID)
            end
        end
    end

    local staticQuest = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"] and AutoQuestLearnerData.quests["data"][questID]
    if staticQuest then
        local function addUnitZones(idSet)
            if not idSet then return end
            for _, id in pairs(idSet) do
                local data = AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"] and AutoQuestLearnerData.units["data"][id]
                if data and data.coords then
                    for _, c in pairs(data.coords) do
                        add(c[3])
                    end
                end
            end
        end
        local function addObjectZones(idSet)
            if not idSet then return end
            for _, id in pairs(idSet) do
                local data = AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"] and AutoQuestLearnerData.objects["data"][id]
                if data and data.coords then
                    for _, c in pairs(data.coords) do
                        add(c[3])
                    end
                end
            end
        end
        if staticQuest["start"] then
            addUnitZones(staticQuest["start"]["U"])
            addObjectZones(staticQuest["start"]["O"])
        end
        if staticQuest["end"] then
            addUnitZones(staticQuest["end"]["U"])
            addObjectZones(staticQuest["end"]["O"])
        end
    end

    return zones
end

-- Scans every bundled quest for ones that are level-appropriate right
-- now, not already completed, not the wrong faction, and NOT in the
-- given zone -- tallying how many such quests each OTHER zone has.
-- Used to suggest where to go next once a zone looks finished, without
-- needing any curated "zone A leads to zone B" leveling-path data --
-- just counting real, level-matched, untouched quests this addon
-- already knows about, per zone. Returns an array of
-- { mapID, name, count }, sorted by count descending, capped to
-- topN entries.
function AutoQuestLearner_SuggestNextZones(excludeMapID, playerLevel, topN)
    if not AutoQuestLearnerData or not AutoQuestLearnerData.quests or not AutoQuestLearnerData.quests["data"] then
        return {}
    end
    topN = topN or 3
    -- A reasonably generous level band -- wide enough to catch a zone
    -- worth heading to next (not just quests exactly your level), not
    -- so wide it recommends something wildly out of range.
    local LEVEL_BAND_BELOW, LEVEL_BAND_ABOVE = 3, 6

    local playerFaction = UnitFactionGroup and UnitFactionGroup("player")
    local tally = {}

    for questID, questData in pairs(AutoQuestLearnerData.quests["data"]) do
        local questLoc = AutoQuestLearnerData.quests["loc"][questID]
        local minLevel = questData["min"]
        if questLoc and minLevel
            and minLevel >= (playerLevel - LEVEL_BAND_BELOW)
            and minLevel <= (playerLevel + LEVEL_BAND_ABOVE) then

            local raceField = AutoQuestLearner_GetEffectiveRaceField and AutoQuestLearner_GetEffectiveRaceField(questID, questData) or questData["race"]
            local wrongFaction = raceField and raceField ~= 0 and AutoQuestLearner_IsWrongFactionQuest
                and AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction)
            local isDone = AutoQuestLearner_IsQuestCompleted and AutoQuestLearner_IsQuestCompleted(questID, questLoc.T)

            if not wrongFaction and not isDone then
                local zones = AutoQuestLearner_GetQuestZoneMapIDs(questID)
                if zones then
                    -- Zone-based faction fallback: only relevant when
                    -- there was no explicit race field to check above
                    -- (see FACTION_EXCLUSIVE_ZONES near
                    -- AutoQuestLearner_IsWrongFactionQuest) -- a lot of
                    -- low-level starting-zone quests have no race field
                    -- at all despite their zone being 100%
                    -- faction-exclusive.
                    if (not raceField or raceField == 0) and AutoQuestLearner_IsWrongFactionQuest then
                        for mapID in pairs(zones) do
                            if AutoQuestLearner_IsWrongFactionQuest(nil, playerFaction, mapID) then
                                zones[mapID] = nil
                            end
                        end
                    end
                    for mapID in pairs(zones) do
                        if mapID ~= excludeMapID then
                            tally[mapID] = (tally[mapID] or 0) + 1
                        end
                    end
                end
            end
        end
    end

    local results = {}
    for mapID, count in pairs(tally) do
        local name = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"] and AutoQuestLearnerData.zones["loc"][mapID]
        if name then
            table.insert(results, { mapID = mapID, name = name, count = count })
        end
    end
    table.sort(results, function(a, b) return a.count > b.count end)

    local top = {}
    for i = 1, math.min(topN, table.getn(results)) do
        table.insert(top, results[i])
    end
    return top
end

-- Merges the bundled community-contributed seed dataset (see
-- bundled-db/ascension/community-seed.lua) into the player's own
-- learned data, so a fresh install has SOMETHING to build off of
-- instead of starting from nothing on a server this addon can't get
-- pre-made third-party coordinate data for any other way. Strictly
-- additive: never overwrites anything the player has already
-- personally learned, only fills in gaps -- same philosophy as
-- /aql import. Gated on a version number in the seed file itself, so
-- bumping that number in a future update re-runs this to pick up new
-- contributions without re-processing (or re-printing a message about)
-- data that was already merged in before.
local function MergeCommunitySeed()
    if not AutoQuestLearnerCommunitySeed then return end
    local seedVersion = AutoQuestLearnerCommunitySeed.version or 0
    if seedVersion <= 0 then return end
    if (AutoQuestLearnerDB.seedVersionApplied or 0) >= seedVersion then return end

    local learned = GetLearnedDB()
    learned.quests = learned.quests or {}
    learned.objectives = learned.objectives or {}
    local addedLocations, addedSpawns = 0, 0

    for questID, entry in pairs(AutoQuestLearnerCommunitySeed.quests or {}) do
        learned.quests[questID] = learned.quests[questID] or {}
        local mine = learned.quests[questID]
        if entry.giver and not mine.giver then
            mine.giver = entry.giver
            addedLocations = addedLocations + 1
        end
        if entry.turnin and not mine.turnin then
            mine.turnin = entry.turnin
            addedLocations = addedLocations + 1
        end
        if entry.title and not mine.title then
            mine.title = entry.title
        end
    end

    for questID, objectives in pairs(AutoQuestLearnerCommunitySeed.objectives or {}) do
        learned.objectives[questID] = learned.objectives[questID] or {}
        for objIndex, obj in pairs(objectives) do
            local mine = learned.objectives[questID][objIndex]
            if not mine then
                -- Deep copy so later edits to my own data can never
                -- accidentally mutate the shared seed table.
                local spawns = {}
                for _, s in pairs(obj.spawns or {}) do
                    table.insert(spawns, { x = s.x, y = s.y, mapID = s.mapID, z = s.z })
                end
                learned.objectives[questID][objIndex] = { text = obj.text, spawns = spawns }
                addedSpawns = addedSpawns + table.getn(spawns)
            else
                -- Already have some spawns for this objective -- add
                -- any seed spawns not already close to one I have,
                -- rather than skipping the whole objective.
                for _, s in pairs(obj.spawns or {}) do
                    local haveClose = false
                    for _, existing in pairs(mine.spawns) do
                        if existing.mapID == s.mapID then
                            local dx, dy = existing.x - s.x, existing.y - s.y
                            if (dx * dx + dy * dy) < 1 then
                                haveClose = true
                            end
                        end
                    end
                    if not haveClose and table.getn(mine.spawns) < 40 then
                        table.insert(mine.spawns, { x = s.x, y = s.y, mapID = s.mapID, z = s.z })
                        addedSpawns = addedSpawns + 1
                    end
                end
            end
        end
    end

    AutoQuestLearnerDB.seedVersionApplied = seedVersion
    if addedLocations > 0 or addedSpawns > 0 then
        print(string.format(
            "|cff00ff00AutoQuestLearner:|r Loaded community starter data (v%d): %d quest location(s) and %d spawn point(s) added to what you already know.",
            seedVersion, addedLocations, addedSpawns))
    end
end

-- questID resolution (see GetQuestIDs() in AutoQuestLearner_Database.lua)
-- prefers GetQuestLink()'s numeric ID, but falls back to the raw quest
-- title string when that's unavailable -- which can happen
-- inconsistently between characters, or even between polls in the same
-- session, since GetQuestLink can be timing-dependent right after a
-- quest updates. That means the SAME quest can end up learned under two
-- different keys: a numeric ID on one occasion, its title string on
-- another. Without this, data learned under one key form is completely
-- invisible to a lookup using the other -- observed as "this quest was
-- already learned on another character but the arrow still doesn't
-- know about it." These helpers check both forms.
local function GetLearnedQuestEntry(learned, questID, questTitle)
    local entry = learned.quests[questID]
    if entry then return entry end
    if questTitle and questTitle ~= questID then
        return learned.quests[questTitle]
    end
    return nil
end
-- Exposed globally so AutoQuestLearner_Database.lua's SearchQuestID
-- (a different file/chunk) can also look up learned locations, to keep
-- static map-node placement consistent with the arrow's priority fix
-- above (learned beats static, not "closer wins").
AutoQuestLearner_GetLearnedQuestEntry = GetLearnedQuestEntry

local function GetLearnedObjectives(learned, questID, questTitle)
    local objectives = learned.objectives[questID]
    if objectives then return objectives end
    if questTitle and questTitle ~= questID then
        return learned.objectives[questTitle]
    end
    return nil
end
-- Exposed globally for the same reason as AutoQuestLearner_GetLearnedQuestEntry
-- above -- SearchQuestID needs this to keep the objective map/minimap
-- clusters consistent with the arrow's learned-beats-static priority.
AutoQuestLearner_GetLearnedObjectives = GetLearnedObjectives

-- Static areatrigger coords for a quest (explore/stand-here objectives)
local function GetStaticAreatriggerCoords(questID)
    local sq = AutoQuestLearnerData and AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"]
        and AutoQuestLearnerData.quests["data"][questID]
    if not sq or not sq["obj"] or not sq["obj"]["A"] then return nil end
    local out = {}
    local at = AutoQuestLearnerData.areatrigger and AutoQuestLearnerData.areatrigger["data"]
    if not at then return nil end
    for _, triggerID in pairs(sq["obj"]["A"]) do
        local data = at[triggerID]
        if data and data.coords then
            for _, c in pairs(data.coords) do
                table.insert(out, { x = c[1], y = c[2], mapID = c[3], triggerID = triggerID })
            end
        end
    end
    if table.getn(out) == 0 then return nil end
    return out
end

local function IsNearAnyStaticAreatrigger(questID, x, y, mapID, maxDist)
    maxDist = maxDist or 8 -- map percent
    local coords = GetStaticAreatriggerCoords(questID)
    if not coords then return true end -- no static to compare; allow
    local maxSq = maxDist * maxDist
    for _, c in pairs(coords) do
        if c.mapID == mapID then
            local dx, dy = (c.x - x), (c.y - y)
            if (dx * dx + dy * dy) <= maxSq then return true end
        end
    end
    return false
end



-- Which "role" a learning source represents -- where you pick the
-- quest up ("giver") vs where you turn it in ("turnin").
local sourceRole = {
    gossip = "giver",
    ["gossip-turnin"] = "turnin",
    proximity = "giver",
    ["proximity-turnin"] = "turnin",
    detail = "giver",
    progress = "turnin",
    complete = "turnin",
}

-- Map Node Style — matches pfQuest modes (showspawn/showcluster):
--   "simple"   — cluster icons only (cluster_mob/item/misc)
--   "combined" — spawn dots + cluster icons (minimap: dots only)
--   "spawn"    — individual spawn dots only
local function GetNodeStyle()
    return AutoQuestLearnerDB.config.nodestyle or "combined"
end
local function ShouldShowSpawnDots()
    return GetNodeStyle() ~= "simple"
end
local function ShouldShowClusterIcons()
    return GetNodeStyle() ~= "spawn"
end
local function ShouldShowSingleMarkers()
    return true -- giver/turn-in icons always (pfQuest separates these)
end
local function ShouldShowClusters()
    return ShouldShowSpawnDots() or ShouldShowClusterIcons()
end

local function ResolveQuestTitle(questID)
    if AutoQuestLearnerData and AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"]
        and AutoQuestLearnerData.quests["loc"][questID] then
        return AutoQuestLearnerData.quests["loc"][questID].T
    end
    if AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID] then
        return AutoQuestLearner.questlog[questID].title
    end
    return nil
end

-- Picks pfQuest's own "complete" (bright "?", still working on it) vs
-- "complete_c" (ready to hand in) icon for a personally-learned turn-in
-- node, based on the quest's live status if it's currently in the log.
-- Same robust completion check used for the arrow and for the
-- bundled-database-driven nodes in AutoQuestLearner_Database.lua's
-- SearchQuestID -- doesn't trust Blizzard's isComplete flag alone,
-- since it can lag behind the leaderboard actually reporting done.
local function GetTurninNodeTexture(questID)
    local qlogid = AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID]
        and AutoQuestLearner.questlog[questID].qlogid
    local isComplete = false
    if qlogid then
        local _, _, _, _, _, complete = AutoQuestLearner_GetQuestLogTitle(qlogid)
        isComplete = complete and true or false
        if not isComplete then
            local numObjectives = GetNumQuestLeaderBoards(qlogid)
            if numObjectives and numObjectives > 0 then
                isComplete = true
                for i = 1, numObjectives do
                    local _, _, objDone = GetQuestLogLeaderBoard(i, qlogid)
                    if not objDone then
                        isComplete = false
                        break
                    end
                end
            end
        end
    end
    return isComplete
        and "Interface\\AddOns\\AutoQuestLearner\\img\\complete_c"
        or "Interface\\AddOns\\AutoQuestLearner\\img\\complete"
end

-- Draws a single learned pickup/turn-in location as a map/minimap node.
-- Shared by RecordLocation() (fresh learns) and the login replay of
-- previously-learned locations. Uses pfQuest's own icon set for each
-- role/state (available_c for the giver, complete/complete_c for the
-- turn-in) rather than a plain colored dot, matching how pfQuest itself
-- distinguishes these on the map.
local function DrawLearnedNode(questID, role, loc, title)
    if not AutoQuestLearnerMap or not loc or not loc.mapID then return end
    -- ALWAYS show personally-learned giver/turn-in (not gated by Map Node Style)

    local texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"
    local questTitle = title or ResolveQuestTitle(questID) or ("Quest " .. questID)
    local vertex = (role == "turnin") and { 0.3, 0.9, 1.0 } or { 1.0, 0.85, 0.2 }

    AutoQuestLearnerMap:AddNode({
        addon = "AUTOQUESTLEARNER",
        title = questTitle,
        zone = loc.mapID,
        x = loc.x,
        y = loc.y,
        spawn = questTitle .. " (" .. role .. ")",
        texture = texture,
        vertex = vertex,
        questid = questID,
        isLearned = true,
    })
end


-- Deterministic, well-spread color per quest ID, used to tint the plain
-- circular dot texture below. A naive `questID % N` clusters adjacent
-- quest IDs (which are extremely common to see together on the same
-- map, since they're often from the same zone/quest chain) into
-- near-identical hues; multiplying by 37 (coprime to 360) before taking
-- the modulus spreads consecutive IDs by a full 37-degree hue jump each
-- time instead, giving the map the same "different quest = different
-- color" readability pfQuest's own multicolor dot clouds have.
-- Same curated palette as AutoQuestLearner_Map.lua's str2rgb, kept as
-- a separate copy here to avoid cross-file load-order dependencies for
-- such a small constant. Deliberately identical values so a given
-- color reads the same whether it came from this function or that one.
local QUEST_COLOR_PALETTE = {
    { 0.64, 0.14, 0.14 }, -- dark red
    { 0.14, 0.51, 0.14 }, -- dark green
    { 0.20, 0.33, 0.64 }, -- dark blue
    { 0.48, 0.36, 0.01 }, -- dark gold
    { 0.64, 0.36, 0.08 }, -- dark orange
    { 0.01, 0.36, 0.36 }, -- dark teal
    { 0.58, 0.16, 0.38 }, -- dark pink
}

local function QuestColor(id)
    local numericID
    if type(id) == "number" then
        numericID = id
    elseif type(id) == "string" then
        -- Simple string hash for non-numeric IDs (e.g. an NPC name used
        -- as the target key) -- doesn't need to be cryptographically
        -- sound, just consistent for the same string every time.
        numericID = 0
        for i = 1, string.len(id) do
            numericID = (numericID * 31 + string.byte(id, i)) % 2147483647
        end
    else
        numericID = 0
    end
    local paletteSize = table.getn(QUEST_COLOR_PALETTE)
    local index = (numericID - math.floor(numericID / paletteSize) * paletteSize) + 1
    local c = QUEST_COLOR_PALETTE[index]
    return c[1], c[2], c[3]
end
AutoQuestLearner_IDColor = QuestColor

-- Draws a single learned objective spawn point (kill/collect/interact
-- target) as a cluster-style node, matching pfDB's obj.U/obj.O style
-- "cloud of dots" for a quest objective.
--
-- FEATURE (per user request): "gathering" objectives (herb/ore/etc.
-- nodes and other interactable world OBJECTS) should always keep the
-- dot-cluster look even when "Outline Spawn Areas" is on -- unlike
-- creature spawns, which wander/respawn at variable positions within
-- a general hunting ground, a gathering node is a FIXED point, so an
-- exact dot is genuinely more useful information than a boundary
-- shape, not less. `sourceType` ("unit"/"object") lets a caller that
-- already knows for certain which this is (the static bundled-DB path
-- below, which reads targetID straight out of the quest's own obj.U
-- vs obj.O lists) say so explicitly. Every other call site (mainly
-- the live/learned-from-play path, which doesn't track that
-- distinction directly) leaves it nil and gets a best-effort answer
-- derived from whether targetID is a known key in the bundled units
-- vs objects database -- not perfect, but right the large majority of
-- the time, since a learned point's targetID lives in the exact same
-- ID space either way.

-- pfQuest getcluster: pick the spawn with the most neighbors within ±5
-- map-% as the cluster badge center (not every point gets a sword/bag).
local _clusterCache = {}
local function GetClusterCenter(coords, cacheKey)
    if not coords then return nil end
    local n = 0
    for _ in pairs(coords) do n = n + 1 end
    if n == 0 then return nil end
    local key = tostring(cacheKey) .. ":" .. n
    if _clusterCache[key] then
        return _clusterCache[key][1], _clusterCache[key][2], _clusterCache[key][3]
    end
    local bestIdx, bestNeighbors = 1, -1
    for index, data in pairs(coords) do
        local x, y = data[1], data[2]
        if x and y then
            local xmin, xmax, ymin, ymax = x - 5, x + 5, y - 5, y + 5
            local neighbors = 0
            for _, compare in pairs(coords) do
                local cx, cy = compare[1], compare[2]
                if cx and cy and cx > xmin and cx < xmax and cy > ymin and cy < ymax then
                    neighbors = neighbors + 1
                end
            end
            if neighbors > bestNeighbors then
                bestNeighbors = neighbors
                bestIdx = index
            end
        end
    end
    local bx = coords[bestIdx][1] + 0.001
    local by = coords[bestIdx][2] + 0.001
    _clusterCache[key] = { bx, by, n }
    return bx, by, n
end

-- One pfQuest-style cluster badge (sword/bag/misc) at the dense center
-- of a spawn cloud for a single objective source on one map.
-- Sword (cluster_mob) = pure kill objectives ("X slain", "Kill Y").
-- Bag (cluster_item) = loot-from-kill / collect item objectives.
-- Explicit sourceType from the DB still wins when provided.
local function ResolveObjectiveSourceType(sourceType, targetID, objText)
    -- Caller may pass "loot" for item-collection objectives
    if sourceType == "loot" or sourceType == "item" then
        return "loot"
    end
    if sourceType == "object" then
        return "loot" -- bag for world-object / item-style objectives
    end
    if sourceType == "unit" then
        -- Unit spawn, but objective text may still be loot-from-kill
        if objText and type(objText) == "string" then
            local tl = string.lower(objText)
            local isKill = string.find(tl, "slain", 1, true) or string.find(tl, "slay", 1, true)
                or string.find(tl, "kill", 1, true) or string.find(tl, "defeat", 1, true)
                or string.find(tl, "destroy", 1, true)
            local isLoot = string.find(tl, "collect", 1, true) or string.find(tl, "loot", 1, true)
                or string.find(tl, "gather", 1, true) or string.find(tl, "obtain", 1, true)
                or string.find(tl, "retrieve", 1, true) or string.find(tl, "acquire", 1, true)
            if isLoot and not isKill then
                return "loot"
            end
            if isKill then
                return "unit"
            end
        end
        return "unit"
    end
    if objText and type(objText) == "string" then
        local tl = string.lower(objText)
        -- Pure kill wording → sword (check before loot, "slain" is definitive)
        if string.find(tl, "slain", 1, true) or string.find(tl, "slay", 1, true)
            or string.find(tl, "kill", 1, true) or string.find(tl, "defeat", 1, true)
            or string.find(tl, "destroy", 1, true) then
            return "unit"
        end
        -- Loot / collect from kills or objects → bag
        if string.find(tl, "collect", 1, true) or string.find(tl, "loot", 1, true)
            or string.find(tl, "gather", 1, true) or string.find(tl, "obtain", 1, true)
            or string.find(tl, "retrieve", 1, true) or string.find(tl, "acquire", 1, true)
            or string.find(tl, "fragment", 1, true) or string.find(tl, "sinew", 1, true)
            or string.find(tl, "hide", 1, true) or string.find(tl, "fang", 1, true)
            or string.find(tl, "claw", 1, true) or string.find(tl, "mineral", 1, true)
            or string.find(tl, "sample", 1, true) then
            return "loot"
        end
    end
    if targetID and AutoQuestLearnerData then
        if AutoQuestLearnerData.items and AutoQuestLearnerData.items["data"]
            and AutoQuestLearnerData.items["data"][targetID] then
            return "loot"
        end
        if AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"]
            and AutoQuestLearnerData.units["data"][targetID] then
            return "unit"
        end
        if AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"]
            and AutoQuestLearnerData.objects["data"][targetID] then
            return "loot"
        end
    end
    return "unit" -- default sword for unknown kill-style objectives
end

local function ObjectiveTextureFor(sourceType, targetID, objText)
    -- Always original hollow ring (never sword/bag)
    return "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"
end

function AutoQuestLearner_DrawClusterBadge(questID, questTitle, objText, targetID, sourceType, mapID, coordsList)
    if not AutoQuestLearnerMap or not mapID or not coordsList then return end
    local style = AutoQuestLearnerDB and AutoQuestLearnerDB.config and AutoQuestLearnerDB.config.nodestyle or "combined"
    -- Cluster center badges: simple + combined. Spawn-only mode skips badges.
    if style == "spawn" then return end
    if not (ShouldShowClusterIcons and ShouldShowClusterIcons()) then return end
    local n = 0
    for _ in pairs(coordsList) do n = n + 1 end
    if n < 1 then return end

    local cx, cy, priority = GetClusterCenter(coordsList, tostring(questID) .. ":" .. tostring(targetID or objText or "") .. ":" .. tostring(mapID))
    if not cx then return end

    local resolvedSourceType = ResolveObjectiveSourceType(sourceType, targetID, objText)
    -- Original circle style for cluster centers (not sword/bag)
    local texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"
    local cr, cg, cb = 0.9, 0.9, 0.2
    if QuestColor then cr, cg, cb = QuestColor(targetID or questID) end

    AutoQuestLearnerMap:AddNode({
        addon = "AUTOQUESTLEARNER",
        title = questTitle or ("Quest " .. questID),
        zone = mapID,
        x = cx,
        y = cy,
        spawn = objText or ("Quest " .. questID .. " objective"),
        texture = texture,
        vertex = { cr, cg, cb },
        questid = questID,
        isObjective = true,
        cluster = true,
        priority = math.min(priority or n, 10),
        objectiveSourceType = resolvedSourceType,
        highlightKey = tostring(targetID or questID),
    })
end

local function DrawObjectiveNode(questID, spawn, questTitle, objText, targetID, sourceType)
    if not AutoQuestLearnerMap or not spawn or not spawn.mapID then return end

    -- "Spawn Clusters" style (matching pfQuest's "Spawn Points" mode)
    -- plots every known spawn as its own dot, building up a visible
    -- cloud over time. The alternative "single marker" style shows
    -- just one representative icon per objective instead, for a less
    -- cluttered map.
    --
    -- IMPORTANT: uses img\node (a plain flat-gray circular blip built
    -- for vertex-color tinting), NOT img\cluster_mob/cluster_misc --
    -- those two are detailed baked-in icon shapes (a sword and a sack,
    -- respectively), not circles, and don't respond to color tinting
    -- the way a "multicolor dot cloud" needs. Using them here is why
    -- objective clusters were rendering as tiny swords instead of the
    -- colored circles pfQuest itself shows.
    --
    -- Colored by targetID (the specific NPC/object/item-source) when
    -- known, rather than by questID -- a quest with multiple distinct
    -- objectives (e.g. "collect 4 different items from 4 different
    -- creatures") would otherwise show every single one of those
    -- creatures' spawn points in one indistinguishable color, making it
    -- impossible to tell which dots belong to which target. Falls back
    -- to questID when no specific target is known (personally-learned
    -- objectives don't capture which exact NPC was killed, only where).
    -- Learned objective points always show; static dots respect Map Node Style
    local isLearnedSpawn = spawn and spawn.isLearned
    if not isLearnedSpawn and not (ShouldShowSpawnDots and ShouldShowSpawnDots()) then return end

    -- Learned pins always draw. Only skip exact duplicates (same cell as
    -- an existing learned pin) — never hide learned because static DB
    -- has a nearby point (that made "saved clusters never show").
    if isLearnedSpawn and AutoQuestLearnerMap and AutoQuestLearnerMap.nodes and spawn.mapID then
        local addonNodes = AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"]
        local zoneData = addonNodes and (addonNodes[spawn.mapID] or addonNodes[tonumber(spawn.mapID)] or addonNodes[tostring(spawn.mapID)])
        if zoneData then
            local sx, sy = tonumber(spawn.x), tonumber(spawn.y)
            if sx and sy then
                local cell = string.format("%.1f|%.1f", sx, sy)
                local node = zoneData[cell]
                if node then
                    for _, entry in pairs(node) do
                        if entry and entry.isLearned then
                            local qok = (entry.questid == questID)
                                or (tonumber(entry.questid) == tonumber(questID))
                            if qok then return end
                        end
                    end
                end
            end
        end
    end

    local resolvedSourceType = ResolveObjectiveSourceType(sourceType, targetID, objText)
    local texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"

    -- Per kill-group color: NPC id when known, else stable hash of the
    -- objective label (so Shaman / Warlock / Mauler never share one color).
    local colorKey = targetID
    if not colorKey and objText and objText ~= "" then
        local label = string.match(objText, "^(.-)%s*:?%s*%d") or objText
        colorKey = "obj:" .. string.lower(label)
    end
    colorKey = colorKey or questID
    local cr, cg, cb
    if AutoQuestLearner_IDColor then
        cr, cg, cb = AutoQuestLearner_IDColor(colorKey)
    elseif QuestColor then
        cr, cg, cb = QuestColor(colorKey)
    else
        cr, cg, cb = 0.4, 0.85, 0.35
    end
    -- Learned pins get a slight brightness bump so they stay visible
    -- on top of static dots of the same color group.
    if isLearnedSpawn then
        cr = math.min(1, cr + 0.12)
        cg = math.min(1, cg + 0.12)
        cb = math.min(1, cb + 0.08)
    end

    -- Unique title per objective group so AddNode does not overwrite
    -- Shaman with Warlock at the same coord key.
    -- Prefer creature/object name over item name so "Metallic Fragments"
    -- pins merge into the Frayfeather / Forest Walker kill clusters.
    local spawnLabel = objText or ("Quest " .. questID .. " objective")
    if targetID then
        local uname = AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(targetID)
        local oname = (not uname) and AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(targetID)
        if uname and uname ~= "" then
            spawnLabel = uname
        elseif oname and oname ~= "" then
            spawnLabel = oname
        end
    end
    local shortLabel = string.match(spawnLabel, "^(.-)%s*:?%s*%d") or spawnLabel
    local nodeTitle = (questTitle or ("Quest " .. questID)) .. " · " .. shortLabel

    AutoQuestLearnerMap:AddNode({
        addon = "AUTOQUESTLEARNER",
        title = nodeTitle,
        zone = spawn.mapID,
        x = spawn.x,
        y = spawn.y,
        spawn = spawnLabel,
        texture = texture,
        vertex = { cr, cg, cb },
        questid = questID,
        isObjective = true,
        isLearned = isLearnedSpawn and true or nil,
        cluster = false,
        objectiveSourceType = resolvedSourceType,
        highlightKey = tostring(colorKey),
    })
end

-- Draws every known STATIC spawn point for a quest's kill/interact
-- objectives immediately, using the bundled units/objects coordinate
-- databases -- not the player's own play history. This is what actually
-- reproduces pfQuest's familiar "cloud of dots" the moment a quest is
-- picked up: previously, AutoQuestLearner could only ever plot spawn
-- points the player had personally already seen (via
-- AutoQuestLearner_RecordObjectiveProgress), which meant every quest
-- started with an empty map and only slowly built up a handful of dots
-- over many play sessions, never approaching pfQuest's immediate,
-- comprehensive cluster. staticQuest["obj"]["U"]/["O"] tells us which
-- NPC/object IDs satisfy the objective; cross-referencing those against
-- the bundled units/objects "data" tables (which independently already
-- carry full multi-spawn coordinate lists per NPC/object, per the
-- MergeSpawnEntry union logic above) gives the same full picture pfQuest
-- itself uses. Objective type "I" (item-collection, e.g. "Collect 8
-- Witchwing Talons") is resolved via the bundled items+refloot
-- databases (AutoQuestLearner_ResolveItemSources) to whichever NPCs/
-- objects actually drop it. "A" (areatrigger) is still not drawn: no
-- areatrigger coordinate table is bundled at all, so guessing would be
-- worse than showing nothing.
local staticObjectiveDrawn = {}
function AutoQuestLearner_ClearStaticObjectiveDrawn()
    for k in pairs(staticObjectiveDrawn) do
        staticObjectiveDrawn[k] = nil
    end
end

-- Normalizes a title for repurposed-quest-ID comparison (see
-- questIDIsRepurposed below and in FindClosestQuestDestination) --
-- shared here since both the map's static-cluster drawing and the
-- arrow's own candidate selection need to detect the same thing:
-- Ascension reusing a real vanilla quest ID for unrelated custom
-- content, identified by the live in-game title not matching what
-- this addon's bundled data calls that same numeric ID.
local function normalizeTitle(s)
    if not s then return nil end
    s = string.lower(s)
    s = string.gsub(s, "[^%a%d]", "")
    return s
end

local function DrawStaticObjectiveClusters(questID, questTitle)
    if staticObjectiveDrawn[questID] then return end
    if not ShouldShowClusters() then return end
    if not AutoQuestLearnerData or not AutoQuestLearnerData.quests then return end

    local staticQuest = AutoQuestLearnerData.quests["data"] and AutoQuestLearnerData.quests["data"][questID]
    if not staticQuest or not staticQuest["obj"] then return end

    -- BUGFIX: confirmed real -- this map-drawing function had no
    -- repurposed-quest-ID protection at all, unlike the arrow's own
    -- candidate selection (see questIDIsRepurposed there). Without
    -- this, a quest whose ID Ascension reused for unrelated content
    -- (confirmed via quest 246, "Serena's Head" here vs bundled
    -- "Assessing the Threat", a completely different Redridge
    -- Mountains quest) would have this function silently draw clusters
    -- for the WRONG creatures/objects on the map -- the vanilla
    -- quest's targets, not Ascension's actual ones -- even though the
    -- arrow was already correctly refusing to use that same wrong
    -- data. Uses the same manually-verified override table as the
    -- arrow when one exists for this specific ID, rather than losing
    -- all objective clusters outright.
    local liveTitle = AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID] and AutoQuestLearner.questlog[questID].title
    local bundledLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
    local bundledTitle = bundledLoc and bundledLoc.T
    if normalizeTitle(liveTitle) and normalizeTitle(bundledTitle) and normalizeTitle(liveTitle) ~= normalizeTitle(bundledTitle) then
        local override = AutoQuestLearnerRepurposedQuestOverrides and AutoQuestLearnerRepurposedQuestOverrides[questID]
        if override then
            staticQuest = { ["obj"] = override }
        else
            staticObjectiveDrawn[questID] = true
            return
        end
    end

    -- BUGFIX: confirmed real -- the arrow's own target selection
    -- already stops considering static "obj" candidates once we've
    -- personally learned a real one for this quest (see the matching
    -- comment in FindClosestQuestDestination), but this MAP-drawing
    -- function never got the same treatment -- it drew every bundled
    -- static coordinate unconditionally, regardless of whether the
    -- player had already killed/looted the real thing and recorded
    -- its actual location. Result: a correct, personally-verified
    -- cluster could sit right next to a wrong bundled one on the map,
    -- since nothing ever suppressed the wrong one once better data
    -- existed. Same coarse "whole quest, not per-sub-objective" grain
    -- as the arrow's version, for the same reason: the bundled data
    -- has no link from a specific NPC/item source to which leaderboard
    -- line it belongs to, so finer-grained suppression isn't reliably
    -- possible.
    -- If we already have personally learned spawns for this quest, still
    -- draw static spawn-table points — but DrawObjectiveNode skips any
    -- learned point that sits on top of a static one (see dedupe there).

    questTitle = questTitle or ResolveQuestTitle(questID) or ("Quest " .. questID)
    staticObjectiveDrawn[questID] = true

    -- Skip any sub-objective that's already individually done, by name
    -- -- same reasoning and same heuristic as FindClosestQuestDestination's
    -- equivalent filter: the bundled data has no direct link from a
    -- specific NPC/object/item-source to which leaderboard line it
    -- belongs to, so this cross-references by matching names against
    -- the live leaderboard's already-done entries.
    local doneObjectiveTexts = {}
    local qlogid = AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID] and AutoQuestLearner.questlog[questID].qlogid
    if qlogid then
        local numObjectives = GetNumQuestLeaderBoards(qlogid)
        if numObjectives and numObjectives > 0 then
            for oi = 1, numObjectives do
                local otext, _, odone = GetQuestLogLeaderBoard(oi, qlogid)
                if odone and otext then
                    local label = string.match(otext, "^(.-)%s*:?%s*%d") or otext
                    table.insert(doneObjectiveTexts, string.lower(label))
                end
            end
        end
    end
    -- Strict match only: shared words like "Gordunni" must not mark
    -- Shaman done when only Mauler is finished.
    local function isAlreadyDone(name)
        if not name or table.getn(doneObjectiveTexts) == 0 then return false end
        local nameLower = string.lower(name)
        nameLower = string.gsub(nameLower, "%s+slain$", "")
        nameLower = string.gsub(nameLower, "%s+killed$", "")
        for _, doneText in pairs(doneObjectiveTexts) do
            local d = string.gsub(doneText, "%s+slain$", "")
            d = string.gsub(d, "%s+killed$", "")
            if d == nameLower or string.find(d, nameLower, 1, true) == 1
                or string.find(nameLower, d, 1, true) == 1 then
                -- Require the longer string to still contain a distinctive
                -- token (last word) so "Gordunni" alone never matches all.
                local last = string.match(nameLower, "(%S+)$") or nameLower
                if string.len(last) >= 4 and string.find(d, last, 1, true) then
                    return true
                end
            end
        end
        return false
    end

    local MAX_NODES_PER_TYPE = 120

    local function isSourceHidden(sourceID)
        local hk = AutoQuestLearnerDB.hiddenStaticSources
        if not hk or not sourceID then return false end
        return hk[tostring(questID) .. ":" .. tostring(sourceID)] and true or false
    end

    local drawnNpcIDs = {}
    local function drawUnit(npcID, label)
        if not npcID or drawnNpcIDs[npcID] or isSourceHidden(npcID) then return end
        drawnNpcIDs[npcID] = true
        local unitData = AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"]
            and AutoQuestLearnerData.units["data"][npcID]
        label = label or (AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(npcID))
            or (questTitle .. " objective")
        if unitData and unitData.coords and not isAlreadyDone(label) then
            local count = 0
            for _, c in pairs(unitData.coords) do
                if count >= MAX_NODES_PER_TYPE then break end
                DrawObjectiveNode(questID, { x = c[1], y = c[2], mapID = c[3] }, questTitle, label, npcID, "unit")
                count = count + 1
            end
        end
    end

    for _, npcID in pairs(staticQuest["obj"]["U"] or {}) do
        drawUnit(npcID)
    end

    -- Also map incomplete leaderboard names → unit IDs so multi-kill
    -- quests (Ogres of Feralas: Shaman/Warlock/Mauler) still get a
    -- spawn cloud when the quest obj table only lists one NPC type.
    local qlogid2 = AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID]
        and AutoQuestLearner.questlog[questID].qlogid
    if qlogid2 and AutoQuestLearnerDatabase and AutoQuestLearnerDatabase.GetIDByName then
        local n = GetNumQuestLeaderBoards(qlogid2)
        if n and n > 0 then
            for oi = 1, n do
                local otext, _, odone = GetQuestLogLeaderBoard(oi, qlogid2)
                if not odone and otext then
                    local label = string.match(otext, "^(.-)%s*:?%s*%d") or otext
                    label = string.gsub(label, "%s+[Ss]lain%s*$", "")
                    local ids = AutoQuestLearnerDatabase:GetIDByName(label, "units")
                        or AutoQuestLearnerDatabase:GetIDByName(label, "unit")
                    if type(ids) == "table" then
                        for _, id in pairs(ids) do drawUnit(id, label) end
                    elseif ids then
                        drawUnit(ids, label)
                    end
                end
            end
        end
    end

    for _, objID in pairs(staticQuest["obj"]["O"] or {}) do
        if not isSourceHidden(objID) then
            local objData = AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"]
                and AutoQuestLearnerData.objects["data"][objID]
            local label = (AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(objID))
                or (questTitle .. " objective")
            if objData and objData.coords and not isAlreadyDone(label) then
                local count = 0
                for _, c in pairs(objData.coords) do
                    if count >= MAX_NODES_PER_TYPE then break end
                    DrawObjectiveNode(questID, { x = c[1], y = c[2], mapID = c[3] }, questTitle, label, objID, "object")
                    count = count + 1
                end
            end
        end
    end

    if staticQuest["obj"]["I"] and AutoQuestLearner_ResolveItemSources then
        -- Loot-from-kill: show the CREATURE/OBJECT spawn clusters that
        -- drop the item — not a separate rainbow of pins per item name.
        -- Multiple incomplete items that share the same drop mob (e.g.
        -- Metallic Fragments + Resilient Sinew both from Frayfeather)
        -- draw that mob's table ONCE with one color (targetID = unit id).
        local MAX_NODES_PER_SOURCE = 25
        local MAX_TOTAL_ITEM_NODES = 100
        local uniqueSources = {} -- key "U:id" / "O:id" → { type, id }
        local order = {}

        for _, itemID in pairs(staticQuest["obj"]["I"]) do
            local itemName = AutoQuestLearner_GetItemName and AutoQuestLearner_GetItemName(itemID)
            if not isAlreadyDone(itemName) then
                local sources = AutoQuestLearner_ResolveItemSources(itemID)
                for _, src in pairs(sources or {}) do
                    if src and src.id and not isSourceHidden(src.id) then
                        local key = tostring(src.type or "U") .. ":" .. tostring(src.id)
                        if not uniqueSources[key] then
                            uniqueSources[key] = { type = src.type or "U", id = src.id }
                            table.insert(order, key)
                        end
                    end
                end
            end
        end

        local totalDrawn = 0
        for _, key in ipairs(order) do
            if totalDrawn >= MAX_TOTAL_ITEM_NODES then break end
            local src = uniqueSources[key]
            local data = (src.type == "U")
                and AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"] and AutoQuestLearnerData.units["data"][src.id]
                or AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"] and AutoQuestLearnerData.objects["data"][src.id]
            if data and data.coords then
                local label = (src.type == "U" and AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(src.id))
                    or (src.type == "O" and AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(src.id))
                if not label or label == "" then
                    label = (src.type == "O" and ("object:" .. tostring(src.id))) or ("unit:" .. tostring(src.id))
                end
                local stype = (src.type == "O") and "object" or "unit"
                local count = 0
                for _, c in pairs(data.coords) do
                    if count >= MAX_NODES_PER_SOURCE or totalDrawn >= MAX_TOTAL_ITEM_NODES then break end
                    DrawObjectiveNode(questID, { x = c[1], y = c[2], mapID = c[3] }, questTitle, label, src.id, stype)
                    count = count + 1
                    totalDrawn = totalDrawn + 1
                end
            end
        end
    end

    -- Areatrigger objectives ("Find X nearby" -- e.g. discover a cave
    -- entrance or search a radius, rather than kill/loot/collect
    -- anything specific).
    if staticQuest["obj"]["A"] then
        for _, triggerID in pairs(staticQuest["obj"]["A"]) do
            local data = AutoQuestLearnerData.areatrigger and AutoQuestLearnerData.areatrigger["data"]
                and AutoQuestLearnerData.areatrigger["data"][triggerID]
            if data and data.coords and not isAlreadyDone("search area") then
                local count = 0
                for _, c in pairs(data.coords) do
                    if count >= MAX_NODES_PER_TYPE then break end
                    DrawObjectiveNode(questID, { x = c[1], y = c[2], mapID = c[3] }, questTitle,
                        questTitle .. " objective (search area)", triggerID, "unit")
                    count = count + 1
                end
            end
        end
    end
end

-- Handles the case DrawStaticObjectiveClusters' own learned-data check
-- (above) can't: static clusters that were ALREADY drawn on an earlier
-- call, before any learned data existed for this quest yet. That
-- check only prevents drawing wrong static nodes in the FUTURE -- it
-- does nothing to remove ones already sitting on the map from before
-- the player killed/looted the real thing. Confirmed real: without
-- this, a personally-verified correct cluster could appear right next
-- to an already-drawn wrong bundled one, neither ever going away.
-- Wipes every objective node for the quest (both the wrong static ones
-- and, unavoidably, the just-recorded learned one too, since
-- DeleteObjectiveNodes can't distinguish origin) then immediately
-- redraws every currently-known learned spawn for this quest fresh --
-- net effect is the static clusters vanish and only the correct,
-- personally-learned ones remain.
--
-- BUGFIX: only called once there are several (3+) independently-
-- verified points, not on the very first one -- confirmed real that
-- triggering this on a single kill wiped an entire legitimate,
-- mostly-correct bundled cluster down to just the one dot you
-- happened to be standing on, losing every other real spawn point in
-- the process. That's a regression for common creatures with large,
-- largely-accurate clusters, even if it was the right call for
-- genuinely wrong static data -- the fix is patience, not never doing
-- it at all.
local function PurgeStaticObjectiveClustersIfSuperseded(questID, questTitle, zoneID)
    if not staticObjectiveDrawn[questID] then return end
    if not AutoQuestLearnerMap or not AutoQuestLearnerMap.DeleteObjectiveNodes then return end

    AutoQuestLearnerMap:DeleteObjectiveNodes("AUTOQUESTLEARNER", questID, questTitle, zoneID)

    local learned = GetLearnedDB()
    local objectives = learned.objectives and learned.objectives[questID]
    if not objectives then return end
    local useClusters = ShouldShowClusters()
    for _, obj in pairs(objectives) do
        if useClusters then
            for _, spawn in pairs(obj.spawns or {}) do
                if not AutoQuestLearner_ShouldSkipLearnedItemPin(questID, obj.text, spawn.targetID) then
                    DrawObjectiveNode(questID, spawn, questTitle, obj.text, spawn.targetID)
                end
            end
        elseif obj.spawns and obj.spawns[1] then
            local sp = obj.spawns[1]
            if not AutoQuestLearner_ShouldSkipLearnedItemPin(questID, obj.text, sp.targetID) then
                DrawObjectiveNode(questID, sp, questTitle, obj.text, sp.targetID)
            end
        end
    end
end

-- Global wrapper so AutoQuestLearner_Quest.lua (a separate file) can
-- trigger this when it detects a quest newly added to the log.
function AutoQuestLearner_DrawStaticObjectiveClusters(questID, questTitle)
    DrawStaticObjectiveClusters(questID, questTitle)
end
-- Idempotent per-character AND per-role: skips only if this character
-- has already recorded a location for this SPECIFIC role (giver vs.
-- turnin) of this questID, so re-visiting the same NPC doesn't spam
-- duplicate work -- but the underlying shared entry benefits every
-- character regardless of who wrote it.
--
-- BUGFIX: this used to gate on char.questLocations[questID] alone (a
-- single flat entry per quest, not per role). Since the giver location
-- is almost always learned first (you accept the quest before you can
-- ever turn it in), that single entry got permanently claimed by
-- role="giver" the moment the quest was accepted -- which silently
-- blocked the turn-in location from EVER being recorded afterward for
-- that quest, on that character, forever (this is saved data, so it
-- didn't even clear on relog). For any quest whose turn-in location
-- isn't in the bundled static database, this meant
-- FindClosestQuestDestination()/the arrow never got a turn-in
-- candidate at all -- reproducing exactly the "arrow points back at
-- the quest giver" symptom. Keying per-role fixes this: giver and
-- turnin are now independent slots, both learnable.
--
-- BUGFIX (per user report, confirmed real): the "already known, skip"
-- decision above ONLY checked char.questLocations -- THIS character's
-- own personal record of having recorded it -- never the shared,
-- account-wide learned table itself. The arrow/map were always
-- correctly reading the shared table (GetLearnedDB() /
-- GetLearnedQuestEntry(), used everywhere navigation actually happens),
-- so nothing was ever silently lost between characters -- but this gate
-- meant EVERY brand-new character re-triggered a full "Learned location
-- for 'X'!" announcement and a redundant rewrite the first time they
-- personally encountered each NPC, even for locations the account had
-- already known for months. That's what made it look like nothing was
-- shared at all. Gate on the account-wide entry instead: if it's
-- already known to the account, silently refresh the shared position
-- (spawn points can drift -- same "refresh toward most recent
-- confirmed" behavior this addon has always had) and stamp this
-- character's own per-character bookkeeping (used for personal
-- stats/import-detection elsewhere), but skip the announcement and the
-- party/guild broadcast -- nothing NEW was actually discovered.
-- Returns true only when this was genuinely new information to the
-- ACCOUNT (not just to this character). `force` (used only by the
-- explicit "/aql learn" manual command) bypasses both gates entirely --
-- appropriate there because a human deliberately standing at a spot and
-- typing a command is a much stronger signal than the passive
-- gossip/event/proximity auto-learners.
local function RecordLocation(questID, questTitle, label, source, force)
    if not questID or questID == 0 then return false end

    -- Resilient first-learn: gossip/detail/progress/complete must have a
    -- real NPC targeted (those frames set target). Prevents locking a
    -- random street corner when an event fires without a proper target.
    -- Force (/aql learn) and proximity scans are exempt — proximity has
    -- its own unit-scan pipeline and does not rely on the target unit.
    if not force and source ~= "proximity" and source ~= "proximity-turnin" then
        if not UnitExists("target") or UnitIsPlayer("target") then
            return false
        end
        if CheckInteractDistance and not CheckInteractDistance("target", 4) then
            return false
        end
    end

    -- Always snap the world map to the player's real zone before reading
    -- coordinates. If the map was left open on another continent/zone,
    -- GetPlayerMapPosition + GetCurrentMap() can report the WRONG mapID
    -- and/or (0,0) -- which is a common reason forced learns "don't stick"
    -- (they saved under the wrong zone, so the arrow never sees them).
    if SetMapToCurrentZone then
        pcall(SetMapToCurrentZone)
    end

    local x, y, z = GetPlayerPos()
    if not x then
        -- Retry once after forcing the map (some clients need a frame).
        if SetMapToCurrentZone then pcall(SetMapToCurrentZone) end
        x, y, z = GetPlayerPos()
    end
    if not x then return false end
    local mapID = GetCurrentMap()
    if not mapID then return false end

    local role = sourceRole[source] or "giver"

    local char = GetChar()
    char.questLocations[questID] = char.questLocations[questID] or {}

    local learned = GetLearnedDB()
    learned.quests[questID] = learned.quests[questID] or {}

    local existing = learned.quests[questID][role]
    local alreadyKnownAccountWide = existing ~= nil

    -- PERMANENT once learned (account-wide SavedVariables):
    -- First successful learn for a role (giver / turnin) is kept forever
    -- on EVERY character. Passive gossip / event / proximity on any alt
    -- must NOT move it. The ONLY overwrite path is explicit force
    -- (/aql learn …, force=true).
    if alreadyKnownAccountWide and not force then
        local npcNameKeep = UnitExists("target") and not UnitIsPlayer("target") and UnitName("target") or nil
        if npcNameKeep and existing and not existing.name then
            existing.name = npcNameKeep
        end
        if existing then
            existing.locked = true -- migrate older unlocked entries to sticky
        end
        learned.quests[questID].title = questTitle or learned.quests[questID].title
        char.questLocations[questID][role] = char.questLocations[questID][role] or {
            x = existing.x, y = existing.y, mapID = existing.mapID, source = source, role = role, z = existing.z,
            label = label or (questTitle or ("Quest " .. questID)) .. " (" .. source .. ")",
            locked = true,
        }
        DrawLearnedNode(questID, role, existing, learned.quests[questID].title)
        return false
    end

    -- Every call site here fires while a quest-related NPC frame is
    -- open (gossip, quest detail/progress/complete), which reliably
    -- sets that NPC as your target on this client -- so grab its name
    -- while we have the chance. Without this, a learned (as opposed to
    -- static-database) location had no name attached at all, so the
    -- arrow fell back to a generic "Ready to turn in here." instead of
    -- naming the NPC the way it does for static candidates.
    local npcName = UnitExists("target") and not UnitIsPlayer("target") and UnitName("target") or nil
    -- First learn OR forced overwrite: always lock so future passive
    -- learns (any character) leave coordinates alone.
    local loc = {
        x = x, y = y, mapID = mapID, name = npcName, z = z,
        locked = true,
        learnedAt = time and time() or nil,
        forced = force and true or nil,
    }

    -- Force path OR first-time learn: write and lock permanently.
    learned.quests[questID][role] = loc
    -- IMPORTANT: store the bare quest title here, NOT the decorated
    -- label (which has a "(source)" suffix baked in for the print
    -- confirmation message). Storing the decorated version meant every
    -- future place that displays this quest's title would append yet
    -- another suffix on top of an already-suffixed string, stacking up
    -- over time (e.g. "Blueleaf Tubers (turn-in) (quest area)").
    learned.quests[questID].title = questTitle or learned.quests[questID].title

    char.questLocations[questID][role] = {
        x = x, y = y, mapID = mapID, source = source, role = role, z = z,
        label = label or (questTitle or ("Quest " .. questID)) .. " (" .. source .. ")",
        locked = true,
    }

    -- This is the step that was missing entirely before: without this,
    -- everything the addon learned was saved to disk but never actually
    -- drawn as a node anywhere.
    DrawLearnedNode(questID, role, loc, learned.quests[questID].title)

    if AutoQuestLearner_BroadcastLearnedLocation then
        AutoQuestLearner_BroadcastLearnedLocation(questID, role, x, y, mapID)
    end

    -- Force an immediate arrow recompute on the next OnUpdate (avoids
    -- calling the local UpdateArrowFrame from here -- it's defined later
    -- in this file and is not an upvalue of RecordLocation).
    if force then
        AutoQuestLearner_ForceArrowRefresh = true
    end

    return true
end

------------------------------------------------------------
-- Live sync with other players running this addon
--
-- Whenever RecordLocation() above genuinely learns something NEW
-- (never on a redundant re-learn of something already known -- that
-- distinction only became reliable once RecordLocation actually
-- returned true/false correctly), broadcast it to whichever channels
-- are enabled. Other players running this addon receive it and merge
-- it into their own database, using the exact same "never overwrite
-- something already confirmed" rule that protects learned data
-- everywhere else in this addon -- a synced location can only ever
-- fill a gap, never silently replace something you already have.
--
-- SECURITY: incoming messages are parsed with plain string matching
-- only (tonumber/string.match) -- never loadstring, RunScript, or any
-- other form of executing received text as code. A malicious or
-- corrupted message can at worst be silently rejected as malformed;
-- it can never run arbitrary code on the receiving client.
------------------------------------------------------------
local SYNC_PREFIX = "AQLSync1"
local syncRegistered = false
local function EnsureSyncRegistered()
    if syncRegistered then return end
    if RegisterAddonMessagePrefix then
        RegisterAddonMessagePrefix(SYNC_PREFIX)
    end
    syncRegistered = true
end

-- Simple per-session throttle: don't re-broadcast the exact same
-- questID+role more than once every few seconds, in case something
-- calls RecordLocation repeatedly in a short window (shouldn't happen
-- given the "already known" guard, but cheap insurance against
-- flooding the channel).
local lastBroadcast = {}
function AutoQuestLearner_BroadcastLearnedLocation(questID, role, x, y, mapID)
    if not C_ChatInfo and not SendAddonMessage then return end
    if not questID or not role or not x or not y or not mapID then return end
    if type(questID) ~= "number" then return end -- see the matching guard/comment in AutoQuestLearner_ExportLearnedLocations -- quest identifiers can be strings (title fallback) in this codebase, confirmed via a live error report
    if type(mapID) ~= "number" then return end -- same reasoning for mapID -- can be a "C-1Z0" style fallback string, confirmed via a second live error report

    local syncParty = AutoQuestLearnerDB.config.syncParty == "1"
    local syncGuild = AutoQuestLearnerDB.config.syncGuild == "1"
    if not syncParty and not syncGuild then return end

    local key = questID .. ":" .. role
    local now = GetTime()
    if lastBroadcast[key] and lastBroadcast[key] > now - 5 then return end
    lastBroadcast[key] = now

    EnsureSyncRegistered()

    local message = string.format("L:%d:%s:%.1f:%.1f:%d", questID, role, x, y, mapID)
    local sendFunc = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage

    if syncParty and (GetNumPartyMembers() > 0 or GetNumRaidMembers() > 0) then
        sendFunc(SYNC_PREFIX, message, IsInRaid and IsInRaid() and "RAID" or "PARTY")
    end
    if syncGuild and IsInGuild and IsInGuild() then
        sendFunc(SYNC_PREFIX, message, "GUILD")
    end
end

-- Objective (kill/collect) spawn counterpart to
-- AutoQuestLearner_BroadcastLearnedLocation, above. Confirmed real gap:
-- giver/turn-in locations were shared live with party/guild the moment
-- they were learned, but a freshly-learned KILL SPAWN -- arguably the
-- more common and more valuable thing to learn while actually grouped
-- up and grinding together -- never was, and was also invisible to
-- /aql export entirely. targetID (the specific NPC this spawn is
-- attributable to, when known -- see RecordObjectiveProgress) is sent
-- as 0 rather than omitted when unknown, since the message format is
-- fixed-field and needs a value in that slot either way; 0 is never a
-- real creature/object ID so it's an unambiguous "none" marker on
-- the receiving end.
local lastObjBroadcast = {}
function AutoQuestLearner_BroadcastLearnedObjective(questID, objIndex, x, y, mapID, targetID, text)
    if not C_ChatInfo and not SendAddonMessage then return end
    if not questID or not objIndex or not x or not y or not mapID then return end
    if type(questID) ~= "number" then return end
    if type(mapID) ~= "number" then return end

    local syncParty = AutoQuestLearnerDB.config.syncParty == "1"
    local syncGuild = AutoQuestLearnerDB.config.syncGuild == "1"
    if not syncParty and not syncGuild then return end

    -- Throttled per (quest, objIndex) rather than per exact point --
    -- deliberately coarser than the giver/turn-in throttle, since a
    -- single objective can rack up many distinct spawn points in quick
    -- succession while actively grinding, and there's no need for each
    -- one to reset a shared cooldown.
    local key = questID .. ":" .. objIndex
    local now = GetTime()
    if lastObjBroadcast[key] and lastObjBroadcast[key] > now - 2 then return end
    lastObjBroadcast[key] = now

    EnsureSyncRegistered()

    -- Semicolon separates entries in both the live message batching
    -- (not used here, one spawn per message) and the export format
    -- (see AutoQuestLearner_ExportLearnedLocations) -- strip any
    -- stray one from the text field so it can never be misread as an
    -- entry boundary in either context.
    local safeText = string.gsub(text or "", ";", ",")
    local message = string.format("O:%d:%d:%.1f:%.1f:%d:%d:%s", questID, objIndex, x, y, mapID, targetID or 0, safeText)
    local sendFunc = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage

    if syncParty and (GetNumPartyMembers() > 0 or GetNumRaidMembers() > 0) then
        sendFunc(SYNC_PREFIX, message, IsInRaid and IsInRaid() and "RAID" or "PARTY")
    end
    if syncGuild and IsInGuild and IsInGuild() then
        sendFunc(SYNC_PREFIX, message, "GUILD")
    end
end

local syncStats = { received = 0, applied = 0 }
local function HandleIncomingSyncLocation(message, sender)
    local msgType, questID, role, x, y, mapID = string.match(
        message, "^(%a):(%-?%d+):(%a+):(%-?%d+%.?%d*):(%-?%d+%.?%d*):(%-?%d+)$")

    if msgType ~= "L" then return false end -- not this type, let the caller try another

    questID = tonumber(questID)
    x = tonumber(x)
    y = tonumber(y)
    mapID = tonumber(mapID)
    if not questID or not x or not y or not mapID then return true end
    if role ~= "giver" and role ~= "turnin" then return true end

    syncStats.received = syncStats.received + 1

    -- Reuses RecordLocation's own logic path (via the learned-DB and
    -- questLocations structures directly) rather than duplicating it --
    -- but does its OWN "already known" check first, since this data
    -- didn't come from actually being at the location ourselves.
    local char = GetChar()
    char.questLocations[questID] = char.questLocations[questID] or {}
    if char.questLocations[questID][role] then
        return true -- already have this one, synced data never overwrites
    end

    local questLoc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
    local questTitle = questLoc and questLoc.T

    local loc = { x = x, y = y, mapID = mapID, name = nil }
    local learned = GetLearnedDB()
    learned.quests[questID] = learned.quests[questID] or {}
    if not learned.quests[questID][role] then
        learned.quests[questID][role] = loc
        learned.quests[questID].title = questTitle or learned.quests[questID].title

        char.questLocations[questID][role] = {
            x = x, y = y, mapID = mapID, source = "sync", role = role,
            label = (questTitle or ("Quest " .. questID)) .. " (synced from " .. tostring(sender) .. ")",
        }

        DrawLearnedNode(questID, role, loc, learned.quests[questID].title)
        syncStats.applied = syncStats.applied + 1
    end
    return true
end

-- Objective-spawn counterpart to HandleIncomingSyncLocation, above.
-- Same "never overwrite, only fill gaps" and same ~1% proximity dedup
-- RecordObjectiveProgress itself uses, so a synced point that's
-- basically the same spot as one already known (either personally
-- learned or from an earlier sync/import) doesn't create a near-
-- duplicate.
local function HandleIncomingSyncObjective(message, sender)
    local msgType, questID, objIndex, x, y, mapID, targetID, text = string.match(
        message, "^(%a):(%-?%d+):(%d+):(%-?%d+%.?%d*):(%-?%d+%.?%d*):(%-?%d+):(%-?%d+):(.*)$")

    if msgType ~= "O" then return false end

    questID = tonumber(questID)
    objIndex = tonumber(objIndex)
    x = tonumber(x)
    y = tonumber(y)
    mapID = tonumber(mapID)
    targetID = tonumber(targetID)
    if targetID == 0 then targetID = nil end
    if not questID or not objIndex or not x or not y or not mapID then return true end

    syncStats.received = syncStats.received + 1

    local learned = GetLearnedDB()
    learned.objectives[questID] = learned.objectives[questID] or {}
    local obj = learned.objectives[questID][objIndex]
    if not obj then
        obj = { text = (text ~= "" and text or nil), spawns = {} }
        learned.objectives[questID][objIndex] = obj
    end
    obj.text = obj.text or (text ~= "" and text or nil)

    for _, spawn in pairs(obj.spawns) do
        if spawn.mapID == mapID then
            local dx, dy = spawn.x - x, spawn.y - y
            if (dx * dx + dy * dy) < 1 then
                return true -- already have a point right here
            end
        end
    end

    if table.getn(obj.spawns) >= 40 then return true end

    local spawn = { x = x, y = y, mapID = mapID, targetID = targetID }
    table.insert(obj.spawns, spawn)
    syncStats.applied = syncStats.applied + 1

    local useClusters = ShouldShowClusters and ShouldShowClusters()
    if useClusters or table.getn(obj.spawns) == 1 then
        local questTitle = ResolveQuestTitle and ResolveQuestTitle(questID) or obj.text
        DrawObjectiveNode(questID, spawn, questTitle, obj.text, targetID)
    end
    return true
end

local syncFrame = CreateFrame("Frame")
syncFrame:RegisterEvent("CHAT_MSG_ADDON")
syncFrame:SetScript("OnEvent", function(self, event, prefix, message, channel, sender)
    if prefix ~= SYNC_PREFIX then return end
    local ok, err = pcall(function()
        if HandleIncomingSyncLocation(message, sender) then return end
        HandleIncomingSyncObjective(message, sender)
    end)
    if not ok then
        AutoQuestLearner:Debug("Sync parse error: " .. tostring(err))
    end
end)

------------------------------------------------------------
-- Export / Import
--
-- Live sync (above) only ever shares things learned WHILE grouped, at
-- that exact moment -- nothing learned before grouping up, or while
-- ungrouped entirely, ever gets exchanged that way. This is the
-- deliberate complement: a one-time, on-demand dump of your ENTIRE
-- learned-locations history into a plain text string, which someone
-- else can paste into their own import box (via Discord or however
-- else) regardless of whether you were ever grouped, or even online
-- at the same time at all.
--
-- SECURITY: same rule as live sync -- imported text is parsed with
-- plain string matching only, never loadstring/RunScript/executed as
-- code. A malformed or tampered string can only ever be silently
-- rejected, never run anything.
------------------------------------------------------------
function AutoQuestLearner_ExportLearnedLocations()
    local learned = GetLearnedDB()
    local parts = {}
    for questID, entry in pairs(learned.quests or {}) do
        -- learned.quests can be keyed by either the numeric quest ID or
        -- (as a fallback, when the numeric ID couldn't be resolved) the
        -- quest title as a plain string -- confirmed real via a live
        -- error report ("Emergency Measures" breaking %d formatting).
        -- String-keyed entries are just an alias for the same
        -- underlying data as their numeric-keyed counterpart, not
        -- separate information, so only the numeric ones are exported
        -- -- also matches what the import format expects.
        if type(questID) == "number" then
            for _, role in ipairs({ "giver", "turnin" }) do
                local loc = entry[role]
                -- Also guard mapID being a string -- confirmed real via
                -- a second live error report ("C-1Z0"). That's the
                -- fallback zone-ID format AutoQuestLearnerMap:GetMapID
                -- uses when the bundled database has no direct
                -- translation for a given continent/zone pair (see its
                -- own comment on that) -- not a portable, universal
                -- zone identifier worth sharing with another player,
                -- so these are skipped the same way string-keyed quest
                -- IDs are above.
                if loc and loc.x and loc.y and type(loc.mapID) == "number" then
                    table.insert(parts, string.format("Q:%d:%s:%.1f:%.1f:%d", questID, role, loc.x, loc.y, loc.mapID))
                end
            end
        end
    end

    -- BUGFIX: confirmed real -- objective (kill/collect) spawn points
    -- were entirely absent from export, even though that's most of
    -- what actually gets learned during normal play. Same numeric-ID-
    -- only and numeric-mapID-only guards as the quest loop above, for
    -- the same reasons.
    for questID, objectives in pairs(learned.objectives or {}) do
        if type(questID) == "number" then
            for objIndex, obj in pairs(objectives) do
                if type(objIndex) == "number" then
                    for _, spawn in pairs(obj.spawns or {}) do
                        if spawn.x and spawn.y and type(spawn.mapID) == "number" then
                            local safeText = string.gsub(obj.text or "", ";", ",")
                            table.insert(parts, string.format("O:%d:%d:%.1f:%.1f:%d:%d:%s",
                                questID, objIndex, spawn.x, spawn.y, spawn.mapID, spawn.targetID or 0, safeText))
                        end
                    end
                end
            end
        end
    end

    return "AQL2:" .. table.concat(parts, ";")
end

-- Returns applied, total, error-or-nil
function AutoQuestLearner_ImportLearnedLocations(importString)
    if not importString or importString == "" then return 0, 0, "empty string" end

    -- AQL2 (current): tagged entries, "Q:..." (giver/turn-in) or
    -- "O:..." (objective spawn) mixed together.
    -- AQL1 (legacy): untagged, quest giver/turn-in entries only --
    -- still accepted so an export string someone saved before this
    -- update still works, just without objective data (which it never
    -- had to begin with).
    local body = string.match(importString, "^AQL2:(.*)$")
    local legacy = false
    if not body then
        body = string.match(importString, "^AQL1:(.*)$")
        legacy = true
    end
    if not body then return 0, 0, "doesn't look like an AutoQuestLearner export string" end

    local applied, total = 0, 0
    for entry in string.gmatch(body, "[^;]+") do
        local kind, rest
        if legacy then
            kind, rest = "Q", entry
        else
            kind, rest = string.match(entry, "^(%a):(.*)$")
        end

        if kind == "Q" and rest then
            local questID, role, x, y, mapID = string.match(
                rest, "^(%-?%d+):(%a+):(%-?%d+%.?%d*):(%-?%d+%.?%d*):(%-?%d+)$")
            if questID then
                questID = tonumber(questID)
                x = tonumber(x)
                y = tonumber(y)
                mapID = tonumber(mapID)
                if questID and x and y and mapID and (role == "giver" or role == "turnin") then
                    total = total + 1
                    local char = GetChar()
                    char.questLocations[questID] = char.questLocations[questID] or {}
                    if not char.questLocations[questID][role] then
                        local questLoc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
                        local questTitle = questLoc and questLoc.T
                        local loc = { x = x, y = y, mapID = mapID, name = nil }
                        local learned = GetLearnedDB()
                        learned.quests[questID] = learned.quests[questID] or {}
                        if not learned.quests[questID][role] then
                            learned.quests[questID][role] = loc
                            learned.quests[questID].title = questTitle or learned.quests[questID].title
                            char.questLocations[questID][role] = {
                                x = x, y = y, mapID = mapID, source = "import", role = role,
                                label = (questTitle or ("Quest " .. questID)) .. " (imported)",
                            }
                            DrawLearnedNode(questID, role, loc, learned.quests[questID].title)
                            applied = applied + 1
                        end
                    end
                end
            end
        elseif kind == "O" and rest then
            local questID, objIndex, x, y, mapID, targetID, text = string.match(
                rest, "^(%-?%d+):(%d+):(%-?%d+%.?%d*):(%-?%d+%.?%d*):(%-?%d+):(%-?%d+):(.*)$")
            if questID then
                questID = tonumber(questID)
                objIndex = tonumber(objIndex)
                x = tonumber(x)
                y = tonumber(y)
                mapID = tonumber(mapID)
                targetID = tonumber(targetID)
                if targetID == 0 then targetID = nil end
                if questID and objIndex and x and y and mapID then
                    total = total + 1
                    local learned = GetLearnedDB()
                    learned.objectives[questID] = learned.objectives[questID] or {}
                    local obj = learned.objectives[questID][objIndex]
                    if not obj then
                        obj = { text = (text ~= "" and text or nil), spawns = {} }
                        learned.objectives[questID][objIndex] = obj
                    end
                    obj.text = obj.text or (text ~= "" and text or nil)

                    local dupe = false
                    for _, spawn in pairs(obj.spawns) do
                        if spawn.mapID == mapID then
                            local dx, dy = spawn.x - x, spawn.y - y
                            if (dx * dx + dy * dy) < 1 then
                                dupe = true
                                break
                            end
                        end
                    end

                    if not dupe and table.getn(obj.spawns) < 40 then
                        local spawn = { x = x, y = y, mapID = mapID, targetID = targetID }
                        table.insert(obj.spawns, spawn)
                        applied = applied + 1

                        local useClusters = ShouldShowClusters and ShouldShowClusters()
                        if useClusters or table.getn(obj.spawns) == 1 then
                            local questTitle = ResolveQuestTitle and ResolveQuestTitle(questID) or obj.text
                            DrawObjectiveNode(questID, spawn, questTitle, obj.text, targetID)
                        end
                    end
                end
            end
        end
    end
    return applied, total
end

StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"] = {
  text = "|cff00ff00AutoQuestLearner|r Export -- copy this and share it (Ctrl+C)",
  button1 = "Close",
  hasEditBox = 1,
  hasWideEditBox = 1,
  timeout = 0,
  exclusive = 1,
  whileDead = 1,
  hideOnEscape = 1,
  OnShow = function()
    local editBox = _G[this:GetName().."WideEditBox"]
    editBox:SetText(StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"].data)
    editBox:HighlightText()
  end,
  OnHide = function()
    _G[this:GetName().."WideEditBox"]:SetText("")
  end,
  EditBoxOnEnterPressed = function()
    this:GetParent():Hide()
  end,
  EditBoxOnEscapePressed = function()
    this:GetParent():Hide()
  end,
  EditBoxOnTextChanged = function()
    this:SetText(StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"].data)
    this:HighlightText()
  end,
}

StaticPopupDialogs["AUTOQUESTLEARNER_IMPORTPASTE"] = {
  text = "|cff00ff00AutoQuestLearner|r Import -- paste an export string, then click Import",
  button1 = "Import",
  button2 = "Cancel",
  hasEditBox = 1,
  hasWideEditBox = 1,
  timeout = 0,
  exclusive = 1,
  whileDead = 1,
  hideOnEscape = 1,
  OnShow = function()
    local editBox = _G[this:GetName().."WideEditBox"]
    editBox:SetText("")
    editBox:SetFocus()
  end,
  OnHide = function()
    _G[this:GetName().."WideEditBox"]:SetText("")
  end,
  OnAccept = function()
    local editBox = _G[this:GetParent():GetName().."WideEditBox"]
    local text = editBox and editBox:GetText()
    local applied, total, errText = AutoQuestLearner_ImportLearnedLocations(text)
    if errText then
        print("|cffff0000AutoQuestLearner:|r Import failed -- " .. errText)
    else
        print(string.format("|cff00ff00AutoQuestLearner:|r Import complete -- %d new location(s) added (%d were already known and skipped).",
            applied, total - applied))
    end
  end,
  EditBoxOnEnterPressed = function()
    StaticPopupDialogs["AUTOQUESTLEARNER_IMPORTPASTE"].OnAccept()
    this:GetParent():Hide()
  end,
  EditBoxOnEscapePressed = function()
    this:GetParent():Hide()
  end,
}


------------------------------------------------------------
-- NPC sighting learning
--
-- Everything above only learns a location during an actual quest
-- interaction moment (accept/turn-in/gossip/progress). That's the
-- overwhelming majority of what's learnable at all -- WoW's client API
-- doesn't expose other units' positions, so there's no way to know
-- "where is NPC X" except by being at their exact position ourselves,
-- which only reliably happens during those specific interactions.
--
-- This extends that same idea to one more real, achievable moment:
-- simply TARGETING an NPC we already know (from bundled data) is a
-- giver or turn-in for some quest, whether or not you're actively
-- working that specific quest right now. Reuses RecordLocation()
-- itself, which already refuses to overwrite anything already known
-- -- so this only ever fills gaps, never risks corrupting confirmed
-- data.
------------------------------------------------------------
local npcToQuestRoles = nil -- lazily built: [npcID] = { {questID, source}, ... }
local function BuildNPCToQuestIndex()
    npcToQuestRoles = {}
    if not AutoQuestLearnerData.quests or not AutoQuestLearnerData.quests["data"] then return end
    for questID, questData in pairs(AutoQuestLearnerData.quests["data"]) do
        if questData["start"] and questData["start"]["U"] then
            for _, npcID in pairs(questData["start"]["U"]) do
                npcToQuestRoles[npcID] = npcToQuestRoles[npcID] or {}
                table.insert(npcToQuestRoles[npcID], { questID, "gossip" }) -- gossip -> "giver" role
            end
        end
        if questData["end"] and questData["end"]["U"] then
            for _, npcID in pairs(questData["end"]["U"]) do
                npcToQuestRoles[npcID] = npcToQuestRoles[npcID] or {}
                table.insert(npcToQuestRoles[npcID], { questID, "complete" }) -- complete -> "turnin" role
            end
        end
    end
end

local lastSightingGUID = nil
function AutoQuestLearner_RecordNPCSighting()
    if not UnitExists("target") or UnitIsPlayer("target") then return end
    local guid = UnitGUID("target")
    if not guid or guid == lastSightingGUID then return end -- same target as last check, nothing new to learn
    lastSightingGUID = guid

    -- WotLK 3.3.5 GUID format (NOT retail's modern dash-delimited
    -- format): a hex string like "0xF530004D2B008852" where the NPC
    -- entry ID is the 7th-10th hex digit. Verified against a real
    -- worked example from source before use, not assumed.
    local npcID = tonumber(string.sub(guid, 9, 12), 16)
    if not npcID then return end

    if not npcToQuestRoles then BuildNPCToQuestIndex() end
    local roles = npcToQuestRoles[npcID]
    if not roles then return end

    local npcName = UnitName("target")

    -- BUGFIX (confirmed real, traced from actual corrupted SavedVariables
    -- data): this used to fire the moment ANY known-npcID was targeted,
    -- with zero verification that the creature actually standing there
    -- is still the same one the BUNDLED VANILLA data assumed lives at
    -- that npcID. npcToQuestRoles is built entirely from static bundled
    -- data (BuildNPCToQuestIndex above) -- if Ascension has repurposed
    -- that specific NPC template ID for different content (same
    -- category of repurposing this addon already handles for quest
    -- IDs, just on the NPC-ID side instead), this would silently record
    -- the WRONG position for a quest the player may have never even
    -- seen, into the SHARED account-wide database every other player
    -- reads from. Verified this is a real, live problem: cross-checked
    -- a real player's learned data against Ascension's own live quest
    -- database and found confirmed cases of exactly this signature --
    -- a quest's bundled giver correctly matching Ascension's live data,
    -- while the player's own learned entry for that same quest showed a
    -- completely unrelated NPC, in a completely different zone.
    --
    -- Fix: verify the ACTUALLY-targeted NPC's live name against the
    -- bundled database's own expected name for this npcID before
    -- trusting the reverse index at all. A mismatch means the static
    -- mapping can't be trusted for this specific npcID on this server,
    -- so skip recording entirely rather than risk writing corrupted
    -- data other players will then be sent to.
    local expectedName = AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(npcID)
    if expectedName and npcName and string.lower(expectedName) ~= string.lower(npcName) then
        return
    end

    for _, entry in ipairs(roles) do
        local questID, source = entry[1], entry[2]
        local questLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
        local questTitle = questLoc and questLoc.T
        RecordLocation(questID, questTitle,
            (questTitle or ("Quest " .. questID)) .. " (sighting)", source)
    end
end

local sightingErrorShown = false
local sightingFrame = CreateFrame("Frame")
sightingFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
sightingFrame:SetScript("OnEvent", function()
    local ok, err = pcall(AutoQuestLearner_RecordNPCSighting)
    if not ok and not sightingErrorShown then
        sightingErrorShown = true
        print("|cffff0000AutoQuestLearner:|r NPC sighting error: " .. tostring(err))
    end
end)

------------------------------------------------------------
-- Objective (kill/collect/interact) spawn-point learning
--
-- Called from AutoQuestLearner_Quest.lua whenever a tracked quest's
-- objective progress is observed to increase. Records the player's
-- current position as a known spawn point for that objective, deduping
-- against nearby already-known points so repeated kills of the same
-- mob don't spam the map with near-identical dots, and capping the
-- total per objective to keep the cluster readable.
------------------------------------------------------------
-- Written by the kill-tracking listener further down (declared here,
-- ahead of RecordObjectiveProgress below, purely because Lua locals
-- have to exist before any code that reads them -- the listener itself
-- lives later in the file since it also needs GetPlayerPos/GetCurrentMap
-- already defined). Lets a freshly-learned spawn point record WHICH
-- specific NPC actually caused the progress, the same identity kill-
-- tracking (HideNearestNode) needs to later recognize "this exact dot"
-- again. Without this, only bundled-database objective nodes could
-- ever be individually hidden on kill -- personally-learned ones had
-- no NPC identity attached at all, just a location.
local lastKillNPCID, lastKillTime = nil, nil
-- Also referenced by the kill-tracking listener further down, to force
-- the arrow to recompute on its next frame right after a kill instead
-- of waiting out the rest of its normal 0.5s throttle window (see
-- destinationSearchFrame's OnUpdate, much later in this file, which is
-- what actually reads this).
local arrowSearchElapsed = 0
-- No per-mob respawn timer data is available from any bundled source
-- on this server, so this is a generic trash-mob estimate, not a
-- guarantee -- see the kill-tracking listener further down for the
-- full explanation.
local DEFAULT_KILL_HIDE_SECONDS = 300


-- Remove learned objective pins that conflict with static areatriggers
function AutoQuestLearner_ScrubBadAreatriggerLearned()
    local learned = GetLearnedDB and GetLearnedDB() or (AutoQuestLearnerDB and AutoQuestLearnerDB.learned)
    if not learned or not learned.objectives then return 0 end
    local removed = 0
    for questID, objectives in pairs(learned.objectives) do
        local staticA = GetStaticAreatriggerCoords(questID)
        if staticA then
            for objIndex, obj in pairs(objectives) do
                if obj.spawns then
                    local kept = {}
                    for _, spawn in pairs(obj.spawns) do
                        if IsNearAnyStaticAreatrigger(questID, spawn.x, spawn.y, spawn.mapID, 10) then
                            table.insert(kept, spawn)
                        else
                            removed = removed + 1
                        end
                    end
                    obj.spawns = kept
                end
            end
        end
    end
    return removed
end

function AutoQuestLearner_RecordObjectiveProgress(questID, objIndex, objText)
    if not questID or not objIndex then return end
    local x, y, z = GetPlayerPos()
    if not x then return end
    local mapID = GetCurrentMap()

    -- Explore/areatrigger only: if this quest has static areatriggers AND
    -- no unit/object kill objectives, require standing near a real trigger.
    -- Never block normal kill/loot learning (that hid Gordunni etc.).
    do
        local sq = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"]
            and AutoQuestLearnerData.quests["data"][questID]
        local hasA = sq and sq["obj"] and sq["obj"]["A"] and next(sq["obj"]["A"])
        local hasKill = sq and sq["obj"] and (
            (sq["obj"]["U"] and next(sq["obj"]["U"]))
            or (sq["obj"]["O"] and next(sq["obj"]["O"]))
            or (sq["obj"]["I"] and next(sq["obj"]["I"]))
        )
        if hasA and not hasKill then
            if not IsNearAnyStaticAreatrigger(questID, x, y, mapID, 10) then
                return
            end
        end
    end

    local learned = GetLearnedDB()
    learned.objectives[questID] = learned.objectives[questID] or {}
    local obj = learned.objectives[questID][objIndex]
    if not obj then
        obj = { text = objText, spawns = {} }
        learned.objectives[questID][objIndex] = obj
    end
    obj.text = objText or obj.text

    -- Only save a TRULY new location. NPC pathing/wander near an
    -- existing cluster (static DB or already-learned) does NOT count.
    -- ~2% of zone (dx^2+dy^2 < 4) covers typical patrol without merging
    -- separate camps. Static pfDB clusters are never overwritten —
    -- learned points are additive and stay visible through kill/loot.
    local NEAR_SQ = 4 -- map-percent distance^2 (~2% of zone)

    local function isNearXY(sx, sy, sz)
        local dx, dy = sx - x, sy - y
        if (dx * dx + dy * dy) >= NEAR_SQ then return false end
        if z and sz and math.abs(sz - z) >= 10 then return false end
        return true
    end

    -- 1) Already-learned points for this objective
    for _, spawn in pairs(obj.spawns) do
        if spawn.mapID == mapID and isNearXY(spawn.x, spawn.y, spawn.z) then
            return -- patrol sample of a known learned pin, not a new spot
        end
    end

    -- 2) Optional: skip learning when already standing on a static spawn
    -- (saves duplicate rows). Does NOT prevent drawing learned pins.
    local staticQuest = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"]
        and AutoQuestLearnerData.quests["data"][questID]
    if staticQuest and staticQuest["obj"] and AutoQuestLearnerDB.config.learnNearStatic == "0" then
        local function nearStaticCoords(idSet, dataTable)
            if not idSet or not dataTable then return false end
            for _, id in pairs(idSet) do
                local data = dataTable[id]
                if data and data.coords then
                    for _, c in pairs(data.coords) do
                        if c[3] == mapID and isNearXY(c[1], c[2], nil) then
                            return true
                        end
                    end
                end
            end
            return false
        end
        local units = AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"]
        local objects = AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"]
        if nearStaticCoords(staticQuest["obj"]["U"], units)
            or nearStaticCoords(staticQuest["obj"]["O"], objects) then
            return -- standing in an existing DB cluster; keep DB dots, no new learn
        end
        -- Item objectives: resolve drop sources, same proximity rule
        if staticQuest["obj"]["I"] and AutoQuestLearner_ResolveItemSources then
            for _, itemID in pairs(staticQuest["obj"]["I"]) do
                local sources = AutoQuestLearner_ResolveItemSources(itemID)
                for _, src in pairs(sources or {}) do
                    local data = (src.type == "O") and objects and objects[src.id]
                        or (units and units[src.id])
                    if data and data.coords then
                        for _, c in pairs(data.coords) do
                            if c[3] == mapID and isNearXY(c[1], c[2], nil) then
                                return
                            end
                        end
                    end
                end
            end
        end
    end

    if table.getn(obj.spawns) >= 40 then return end

    -- If a kill was credited within the last few seconds, it's very
    -- likely what caused this exact progress tick (either the kill
    -- itself counted, or that NPC dropped the item needed) -- tag the
    -- spawn with that NPC's ID so it gets the same per-target identity
    -- a bundled-database node would have (proper color grouping, and
    -- kill-tracking can recognize and hide this specific dot later).
    -- A short window keeps this from misattributing to a stale,
    -- unrelated kill from a while ago.
    local recentKillNPCID = nil
    if lastKillNPCID and lastKillTime and (GetTime() - lastKillTime) <= 5 then
        recentKillNPCID = lastKillNPCID
    end

    local spawn = {
        x = x, y = y, mapID = mapID, z = z,
        targetID = recentKillNPCID,
        isLearned = true,
    }
    table.insert(obj.spawns, spawn)

    -- BUGFIX: confirmed real -- this function has always run
    -- automatically (no dependency on pinning or /aql learn at all),
    -- but never once confirmed it in chat, unlike /aql learn's own
    -- "Saved your current position..." message. Silent success looks
    -- identical to silent failure, so there was no way to tell this
    -- was ever actually working -- naturally leading to assuming
    -- manual learning was required every time. Only fires for a
    -- genuinely NEW point (the dedup check above already returns
    -- early for ones we already knew), so this won't spam chat on
    -- repeat kills at the same spot. Toggleable via /aql learnnotify
    -- in case it turns out to be too chatty once it's actually visible
    -- -- defaults on so this update actually surfaces the fix.
    if AutoQuestLearnerDB.config.learnNotify ~= "0" then
        print(string.format("|cff888888AutoQuestLearner:|r Learned a new spawn point for \"%s\" (%s).",
            obj.text or "this objective", ResolveQuestTitle(questID) or ("Quest " .. questID)))
    end

    -- BUGFIX: confirmed real -- purging (and replacing) static clusters
    -- the INSTANT a single point gets learned was too aggressive. For
    -- a common creature with a legitimately large, mostly-correct
    -- bundled cluster, that meant killing just ONE of them wiped the
    -- entire cluster down to the single dot you happened to be
    -- standing on, losing every other real spawn point you hadn't
    -- personally found yet -- a real regression, not an improvement.
    -- Now only replaces static data once there's enough accumulated,
    -- independently-verified evidence to actually trust the learned
    -- cluster over the bundled one, rather than acting on the very
    -- first single observation.
    local learnedName = obj.text and (string.match(obj.text, "^(.-)%s*:?%s*%d") or obj.text)
                        -- BUGFIX: confirmed real -- the fallback above
                        -- (matching no progress-count pattern, so using
                        -- the raw text as-is) is only valid when that
                        -- raw text already IS a short creature/item
                        -- name. For non-counted objectives (explore/
                        -- travel-style, e.g. "Explore the waters of the
                        -- Forgotten Pools") there's no count to strip in
                        -- the first place, so the ENTIRE sentence was
                        -- being used as if it were an NPC name -- shows
                        -- up as a garbled "Find <the whole objective
                        -- description> nearby." on the arrow. A real
                        -- creature/item name is never a full sentence;
                        -- word count is a cheap, reliable way to tell.
                        if learnedName and select(2, string.gsub(learnedName, "%S+", "")) > 5 then
                            learnedName = nil
                        end
    -- NEVER purge the full static spawn cloud when a new point is learned.
    -- That deleted every cluster for the quest and only re-drew the few
    -- personally-learned dots — looked like "all clusters disappeared"
    -- the moment progress ticked. Learned pins are additive on top of
    -- static data; wrong static sources are filtered at resolve time
    -- (ResolveItemSources), not by wiping the map here.

    if AutoQuestLearner_BroadcastLearnedObjective then
        AutoQuestLearner_BroadcastLearnedObjective(questID, objIndex, x, y, mapID, recentKillNPCID, obj.text)
    end

    -- In simple (non-cluster) mode, only the first known spawn point
    -- actually needs to be drawn -- additional ones are still recorded
    -- (useful if you switch back to cluster mode later) but skipped
    -- here to avoid stacking multiple single-markers on top of each
    -- other.
    local useClusters = ShouldShowClusters()
    if useClusters or table.getn(obj.spawns) == 1 then
        DrawObjectiveNode(questID, spawn, ResolveQuestTitle(questID), obj.text, recentKillNPCID)

        -- Hide STATIC cluster dots for the mob you just killed (respawn
        -- timer). Do NOT hide the newly learned pin itself -- that used
        -- to wipe the only minimap marker for this objective for
        -- minutes, looking like "learned clusters never show".
        -- Optional: hide the static DB twin of a just-killed NPC.
        -- Default OFF — pins staying visible is less confusing than
        -- minimap dots vanishing on every kill/loot.
        if recentKillNPCID and AutoQuestLearnerMap and AutoQuestLearnerMap.HideNearestNode
            and AutoQuestLearnerDB.config.hideKilledNodes == "1" then
            AutoQuestLearnerMap:HideNearestNode(mapID, x, y, tostring(recentKillNPCID), DEFAULT_KILL_HIDE_SECONDS)
            -- Soft retarget soon; do not force a full FindClosest+map rebuild
            -- this frame (that hitch is the kill/loot freeze).
            arrowSearchElapsed = math.max(arrowSearchElapsed or 0, 1.2)
        end
        -- Cheap: mark minimap dirty. Full UpdateNodes is deferred/throttled
        -- elsewhere — never run both map rebuilds on the loot frame.
        if AutoQuestLearnerMap then
            -- Cheap: dirty minimap only. Full UpdateNodes on loot/kill causes hitch.
            AutoQuestLearnerMap._mmForceRebuild = true
            AutoQuestLearnerMap.stationaryTick = 0
            AutoQuestLearnerMap.xPlayer = nil
            AutoQuestLearner._learnedSyncBypass = GetTime()
        end
    end
end

------------------------------------------------------------
-- Manual objective-location save.
--
-- AutoQuestLearner_RecordObjectiveProgress() (above) is normally
-- triggered automatically by AutoQuestLearner_Quest.lua watching for
-- the leaderboard count to increase between polls. That covers the
-- vast majority of cases, but isn't foolproof -- e.g. a kill that
-- grants credit for multiple objectives at once, an objective whose
-- text format doesn't match the "n/n" pattern cleanly, or just bad
-- timing against the poll. This gives a manual fallback: stand where
-- you want the location remembered and run it, no dependency on the
-- automatic delta-detection having caught anything.
--
-- Deliberately scoped to ONE specific quest per call (never "save my
-- current spot for everything in my log at once") -- with several
-- quests tracked simultaneously, blindly recording all of them at
-- wherever you happen to be standing would attribute a location to
-- quests you have nothing to do with right now, which is worse than
-- not recording anything.
------------------------------------------------------------
function AutoQuestLearner_ManualLearnObjective(filterText)
    if not AutoQuestLearner.questlog then
        print("|cff00ff00AutoQuestLearner:|r Quest log not loaded yet.")
        return
    end

    -- Optional role prefix: /aql learn giver [name], /aql learn turnin [name]
    -- Forces a LOCKED giver/turn-in coord that passive learning cannot overwrite.
    local forcedRole = nil
    if filterText and filterText ~= "" then
        local roleWord, rest = string.match(filterText, "^(%S+)%s*(.*)$")
        if roleWord then
            local rw = string.lower(roleWord)
            if rw == "giver" or rw == "start" or rw == "pickup" then
                forcedRole = "giver"
                filterText = rest
            elseif rw == "turnin" or rw == "turn-in" or rw == "end" or rw == "complete" then
                forcedRole = "turnin"
                filterText = rest
            end
        end
    end

    local targetQuestID, targetTitle

    if filterText and filterText ~= "" then
        local lowered = filterText:lower()
        local matches = {}
        for qid, entry in pairs(AutoQuestLearner.questlog) do
            if entry.title and string.find(entry.title:lower(), lowered, 1, true) then
                table.insert(matches, qid)
            end
        end
        if table.getn(matches) == 0 then
            print("|cff00ff00AutoQuestLearner:|r No quest in your log matches \"" .. filterText .. "\".")
            return
        elseif table.getn(matches) > 1 then
            print("|cff00ff00AutoQuestLearner:|r Multiple quests match \"" .. filterText .. "\" -- be more specific:")
            for _, qid in pairs(matches) do
                print("  - " .. AutoQuestLearner.questlog[qid].title)
            end
            return
        end
        targetQuestID = matches[1]
    elseif AutoQuestLearner.pinnedQuestID and AutoQuestLearner.questlog[AutoQuestLearner.pinnedQuestID] then
        targetQuestID = AutoQuestLearner.pinnedQuestID
    else
        -- No quest specified and none pinned -- fall back to "exactly
        -- one quest is currently being watched/tracked" as a
        -- reasonable guess, but refuse to guess among several.
        local watchedIDs = {}
        for qid, entry in pairs(AutoQuestLearner.questlog) do
            if entry.state and string.find(entry.state, "^track") then
                table.insert(watchedIDs, qid)
            end
        end
        if table.getn(watchedIDs) == 1 then
            targetQuestID = watchedIDs[1]
        else
            print("|cff00ff00AutoQuestLearner:|r Not sure which quest you mean.")
            print("  Either pin one first (Alt+Right-Click it in the tracker) and run |cffffcc00/aql learn|r again,")
            print("  or specify it directly: |cffffcc00/aql learn <part of quest name>|r")
            print("  To lock an NPC spot: |cffffcc00/aql learn turnin|r or |cffffcc00/aql learn giver|r (stand on the NPC).")
            return
        end
    end

    targetTitle = AutoQuestLearner.questlog[targetQuestID].title
    local qlogid = AutoQuestLearner.questlog[targetQuestID].qlogid
    if not qlogid then
        print("|cff00ff00AutoQuestLearner:|r Couldn't find \"" .. tostring(targetTitle) .. "\" in the live quest log right now.")
        return
    end

    local objectives = GetNumQuestLeaderBoards(qlogid)

    -- Check completion the same robust way used everywhere else in this
    -- addon (Blizzard's own isComplete flag alone isn't reliable on
    -- this client -- see the notes elsewhere on this). If the quest is
    -- complete, standing here and running this command means "this is
    -- where I turn it in" -- record a TURN-IN location (the same data
    -- slot the arrow's turn-in logic actually reads from), not an
    -- objective location, which would silently go to the wrong place
    -- and never actually fix the arrow for this quest.
    local _, _, _, _, _, isComplete = AutoQuestLearner_GetQuestLogTitle(qlogid)
    if not isComplete and objectives and objectives > 0 then
        isComplete = true
        for i = 1, objectives do
            local _, _, objDone = GetQuestLogLeaderBoard(i, qlogid)
            if not objDone then
                isComplete = false
                break
            end
        end
    end

    -- Explicit role: always force-lock giver or turn-in at current feet.
    if forcedRole == "giver" then
        local ok = RecordLocation(targetQuestID, targetTitle, targetTitle .. " (manual giver)", "detail", true)
        local entry = GetLearnedQuestEntry(GetLearnedDB(), targetQuestID, targetTitle)
        local loc = entry and entry.giver
        if loc then
            print(string.format(
                "|cff00ff00AutoQuestLearner:|r |cffffcc00LOCKED|r giver for \"%s\" at %.1f, %.1f (map %s). Passive learning will not move this.",
                targetTitle, loc.x or 0, loc.y or 0, tostring(loc.mapID)))
        elseif not ok then
            print("|cff00ff00AutoQuestLearner:|r Could not read your position -- open the map once, stand still, try again.")
        end
        return
    end
    if forcedRole == "turnin" or isComplete then
        local ok = RecordLocation(targetQuestID, targetTitle, targetTitle .. " (manual turn-in)", "complete", true)
        local entry = GetLearnedQuestEntry(GetLearnedDB(), targetQuestID, targetTitle)
        local loc = entry and entry.turnin
        if loc then
            print(string.format(
                "|cff00ff00AutoQuestLearner:|r |cffffcc00LOCKED|r turn-in for \"%s\" at %.1f, %.1f (map %s). Passive learning will not move this.",
                targetTitle, loc.x or 0, loc.y or 0, tostring(loc.mapID)))
        elseif not ok then
            print("|cff00ff00AutoQuestLearner:|r Could not read your position -- open the map once, stand still, try again.")
        end
        return
    end

    if not objectives or objectives == 0 then
        -- No objectives and not complete: treat as giver/pickup lock.
        local ok = RecordLocation(targetQuestID, targetTitle, targetTitle .. " (manual giver)", "detail", true)
        local entry = GetLearnedQuestEntry(GetLearnedDB(), targetQuestID, targetTitle)
        local loc = entry and entry.giver
        if loc then
            print(string.format(
                "|cff00ff00AutoQuestLearner:|r |cffffcc00LOCKED|r giver for \"%s\" at %.1f, %.1f (map %s).",
                targetTitle, loc.x or 0, loc.y or 0, tostring(loc.mapID)))
        elseif not ok then
            print("|cff00ff00AutoQuestLearner:|r \"" .. targetTitle .. "\" has no trackable objectives -- stand on the NPC and use |cffffcc00/aql learn giver|r or |cffffcc00/aql learn turnin|r.")
        end
        return
    end

    local saved = 0
    for i = 1, objectives do
        local text = GetQuestLogLeaderBoard(i, qlogid)
        if text then
            local objLabel = string.match(text, "^(.-)%s*:?%s*%d") or text
            AutoQuestLearner_RecordObjectiveProgress(targetQuestID, i, objLabel)
            saved = saved + 1
        end
    end

    print(string.format("|cff00ff00AutoQuestLearner:|r Saved your current position for %d objective(s) of \"%s\".", saved, targetTitle))
    print("  Tip: to lock the |cffffcc00quest giver|r or |cffffcc00turn-in NPC|r forever, stand on them and type:")
    print("  |cffffcc00/aql learn giver|r  or  |cffffcc00/aql learn turnin|r")
end

-- Checks whether ANY location data (learned or static) is known for a
-- quest, in any zone -- not just the current one. Used to give honest
-- feedback when pinning a quest that has nothing to show yet, rather
-- than silently making the arrow disappear with no explanation.
function AutoQuestLearner_HasAnyKnownLocation(questID, questTitle)
    if not questID then return false end

    local learned = GetLearnedDB()
    local questEntry = GetLearnedQuestEntry(learned, questID, questTitle)
    if questEntry and (questEntry.giver or questEntry.turnin) then return true end
    local objectives = GetLearnedObjectives(learned, questID, questTitle)
    if objectives and next(objectives) then return true end

    local staticQuest = AutoQuestLearnerData.quests["data"][questID]
    if staticQuest and (staticQuest["end"] or staticQuest["obj"] or staticQuest["start"]) then
        return true
    end

    return false
end



------------------------------------------------------------
-- Available quest giver cache (for the arrow)
--
-- "Display Available Quest Givers" (allquestgivers config) already
-- draws map/minimap pins for nearby NPCs offering quests you haven't
-- picked up yet, via AutoQuestLearnerDatabase:SearchQuests(). That's
-- purely a map-drawing pass though -- the arrow never considered these
-- as a destination, only quests already in your log. This mirrors the
-- same filtering (faction, level range, completion history) to build a
-- small per-zone candidate list the arrow can read cheaply, refreshed
-- on the same ~3s cadence as the map scan rather than rescanning the
-- whole quest database on every 0.5s arrow update.
------------------------------------------------------------
------------------------------------------------------------
-- Authoritative quest completion check
--
-- AutoQuestLearnerDB.history only knows about quests turned in SINCE
-- this addon was tracking them -- a quest completed earlier (before
-- installing/updating the addon, or in a much older playthrough) would
-- have no record there at all, making it look "available" forever even
-- though it's genuinely done. IsQuestFlaggedCompleted (the modern,
-- reliable way to ask this) doesn't exist on this client generation --
-- it wasn't added until Mists of Pandaria, years after 3.3.5. The real
-- period-correct answer is QueryQuestsCompleted() + the
-- QUEST_QUERY_COMPLETE event + GetQuestsCompleted(): this asks the
-- SERVER for your actual, complete completion history (every quest
-- you've ever turned in on this character, regardless of when or
-- whether this addon existed yet), which is what several real WotLK
-- addons solving this exact "have I already done this" problem
-- (e.g. Quest Completist, EveryQuest) rely on.
------------------------------------------------------------
local serverCompletedQuests = {}
if QueryQuestsCompleted and GetQuestsCompleted then
    local questQueryFrame = CreateFrame("Frame")
    questQueryFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    questQueryFrame:RegisterEvent("QUEST_QUERY_COMPLETE")
    questQueryFrame:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_ENTERING_WORLD" then
            QueryQuestsCompleted()
        elseif event == "QUEST_QUERY_COMPLETE" then
            GetQuestsCompleted(serverCompletedQuests)
            -- BUGFIX: this reply arrives ASYNCHRONOUSLY, some time
            -- after PLAYER_ENTERING_WORLD -- if availableGiverCache
            -- (see below) had already been built even a moment
            -- earlier, every prerequisite check that depends on
            -- serverCompletedQuests ran against an EMPTY table and
            -- got it wrong. Nothing previously re-ran that cache once
            -- this real completion history actually landed, so a
            -- quest gated behind an already-finished prerequisite
            -- (e.g. "Feathers for Grazle" needing "Timbermaw Ally")
            -- could stay incorrectly marked available for the rest of
            -- the session, since none of the cache's other refresh
            -- triggers (level up, zoning, skill change) have anything
            -- to do with quest completion. Force one now that the
            -- data this check actually depends on is finally correct.
            if AutoQuestLearner then
                AutoQuestLearner.updateQuestGivers = true
            end
        end
    end)
end

-- questTitle is optional (falls back to AutoQuestLearnerDB.history's
-- title-keyed alias, same reasoning as everywhere else in this addon:
-- completion can get recorded under whichever key form GetQuestIDs()
-- resolved to at turn-in time).
local function AutoQuestLearner_IsQuestCompleted(questID, questTitle)
    -- Repeatable/daily quests can be done over and over -- "completed
    -- before" doesn't mean "unavailable now" the way it does for a
    -- normal quest. Once we've personally seen a quest flagged daily
    -- in the log (see UpdateQuestlog in AutoQuestLearner_Quest.lua),
    -- permanently treat it as never "completed" for availability
    -- purposes -- we have no reliable way to know whether today's
    -- reset has happened, so the honest answer is "don't claim to
    -- know," not "assume it's still done."
    if AutoQuestLearnerDB.repeatable then
        if questID and AutoQuestLearnerDB.repeatable[questID] then return false end
        if questTitle and AutoQuestLearnerDB.repeatable[questTitle] then return false end
    end
    -- Same idea, but from bundled data (CodexLite/pfQuest's exflag
    -- field, bit 1 = repeatable) instead of waiting to personally see
    -- it in the log first -- covers repeatable quests upfront, before
    -- you've ever encountered them.
    if questID and AutoQuestLearnerQuestExFlags and AutoQuestLearnerQuestExFlags[questID]
        and bit.band(AutoQuestLearnerQuestExFlags[questID], 1) ~= 0 then
        return false
    end
    if questID and serverCompletedQuests[questID] then return true end
    if AutoQuestLearnerDB.history then
        if questID and AutoQuestLearnerDB.history[questID] then return true end
        if questTitle and AutoQuestLearnerDB.history[questTitle] then return true end
    end
    return false
end
_G.AutoQuestLearner_IsQuestCompleted = AutoQuestLearner_IsQuestCompleted

local availableGiverCache = {}
-- Tracks how far along each destination zone's checkpoint chain the
-- player has advanced (keyed by destination mapID, since two different
-- quests pointing at the same real-world zone should share progress
-- along the same physical path). Forward-only/self-correcting, same
-- reasoning as the objective-spawn priority system above -- never
-- regresses if you backtrack, matching how the rest of this addon
-- treats "have I been here" state.
local travelRouteProgress = {}
-- This bundled database (converted from real game data) carries roughly
-- 200 internal/development-only quest entries that were never meant to
-- be seen by players -- deprecated duplicates, cut content, or
-- placeholder flags, each marked with a recognizable title prefix
-- (confirmed by direct count against the bundled data: ~80 "OLD ",
-- ~115 "BETA ", plus a handful of "UNUSED"/"FLAG "/"[Not Used]").
-- Without filtering these out, a stale duplicate like "OLD Conquering
-- Arathi Basin" could get suggested as a real, obtainable quest.
-- Reverse lookup built from AutoQuestLearnerQuestChain's forward links
-- (this quest -> the one that follows it) -- for checking the OTHER
-- direction: does THIS quest require a prerequisite, and if so, is it
-- done? Built once, lazily, since the bundled chain data doesn't
-- change mid-session. Covers only the ~1436 chain links this addon's
-- bundled data actually knows about (a subset, not every real
-- prerequisite in the game) -- this can only correctly HIDE a quest we
-- know is gated, never incorrectly hide one we don't have data for, so
-- it's a strict improvement with no downside, just not total coverage.
local questChainPrereq = nil
-- BUGFIX: the old check compared questData["race"] against a small
-- fixed list of known "whole faction" bitmask values (77/1101 = every
-- Alliance race combined, 178/690 = every Horde race combined). That
-- only caught quests restricted to an ENTIRE faction's race set -- a
-- quest restricted to a single race or a subset (e.g. Draenei-only,
-- Night Elf-only) uses a completely different number that matches
-- none of those four, so it silently passed through unfiltered. The
-- correct check is a real bitwise test: does the quest's race
-- restriction share ANY bit with the player's own faction's full race
-- set? If not, every race that could take this quest is on the other
-- faction, regardless of which specific one(s).
local ALLIANCE_RACES = 1101 -- Human|Dwarf|NightElf|Gnome|Draenei
local HORDE_RACES = 690     -- Orc|Undead|Tauren|Troll|BloodElf

-- BUGFIX: confirmed real via direct data inspection -- a large share
-- of low-level starting-zone quests have NO race field at all in the
-- bundled data (e.g. most Teldrassil 1-5 quests: race=nil), even
-- though the zone itself is 100% faction-exclusive. IsWrongFactionQuest
-- correctly returns "not wrong" when there's no race field to check --
-- it was never broken, it just had nothing to work with for these.
-- This table is the fallback signal for exactly that gap: known
-- faction-exclusive starting zones, used ONLY when raceField is
-- missing (an explicit race tag on the quest always takes priority).
-- mapIDs verified directly against this addon's own bundled zone-name
-- data, not guessed.
local FACTION_EXCLUSIVE_ZONES = {
    [141] = "Alliance",  -- Teldrassil
    [1] = "Alliance",    -- Dun Morogh
    [12] = "Alliance",   -- Elwynn Forest
    [3524] = "Alliance", -- Azuremyst Isle
    [14] = "Horde",      -- Durotar
    [215] = "Horde",     -- Mulgore
    [85] = "Horde",      -- Tirisfal Glades
    [3430] = "Horde",    -- Eversong Woods
}

-- FEATURE (per user request): canonical zone-by-level progression,
-- sourced from Wowhead's Classic WoW Alliance/Horde leveling guides
-- (wowhead.com/classic/guide/alliance-leveling-classic-wow and the
-- horde equivalent, both updated 2024/11/19). Covers vanilla content
-- only (levels 1-60) -- deliberately NOT extended into TBC/Outland
-- zones, so anything level 61+ falls through to the count-based
-- fallback below.
--
-- Each entry: { mapID, minLvl, maxLvl, faction, race, tier }
--   faction: nil = contested/shared, otherwise "Alliance"/"Horde"
--   race: only set for 1-10 starting zones -- the englishRace string
--     (from UnitRace) this zone is the actual starting zone for.
--     Left nil for every other zone, since race stops mattering once
--     you leave your starting zone.
--   tier: 1 = the guide's primary recommendation for that level/race/
--     faction, 2 = a solid secondary alternative also called out by
--     the guide.
-- mapIDs cross-checked against this addon's own FACTION_EXCLUSIVE_ZONES
-- table above and its bundled zone-name data, not guessed.
local CANONICAL_LEVELING_ZONES = {
    -- Levels 1-10 (starting zones, one tier-1 per race)
    { 1, 1, 10, "Alliance", "Dwarf", 1 },      -- Dun Morogh
    { 1, 1, 10, "Alliance", "Gnome", 1 },      -- Dun Morogh
    { 12, 1, 10, "Alliance", "Human", 1 },     -- Elwynn Forest
    { 141, 1, 10, "Alliance", "NightElf", 1 }, -- Teldrassil
    { 3524, 1, 10, "Alliance", "Draenei", 1 }, -- Azuremyst Isle
    { 14, 1, 10, "Horde", "Orc", 1 },          -- Durotar
    { 14, 1, 10, "Horde", "Troll", 1 },        -- Durotar
    { 215, 1, 10, "Horde", "Tauren", 1 },      -- Mulgore
    { 85, 1, 10, "Horde", "Scourge", 1 },      -- Tirisfal Glades (Undead)
    { 3430, 1, 10, "Horde", "BloodElf", 1 },   -- Eversong Woods

    -- Levels 10-20
    { 40, 10, 20, "Alliance", nil, 1 },  -- Westfall
    { 38, 10, 20, "Alliance", nil, 1 },  -- Loch Modan
    { 148, 10, 20, "Alliance", nil, 1 }, -- Darkshore
    { 17, 10, 20, "Horde", nil, 1 },     -- The Barrens
    { 130, 10, 20, "Horde", nil, 2 },    -- Silverpine Forest
    { 3525, 10, 20, "Alliance", nil, 2 },-- Bloodmyst Isle
    { 3433, 10, 20, "Horde", nil, 2 },   -- Ghostlands
    { 44, 15, 25, nil, nil, 2 },         -- Redridge Mountains

    -- Levels 20-30
    { 17, 20, 33, "Horde", nil, 1 },   -- The Barrens (still optimal for Horde)
    { 406, 15, 25, nil, nil, 1 },      -- Stonetalon Mountains
    { 331, 19, 30, nil, nil, 1 },      -- Ashenvale
    { 267, 20, 30, nil, nil, 2 },      -- Hillsbrad Foothills
    { 11, 20, 30, "Alliance", nil, 2 },-- Wetlands
    { 10, 20, 30, "Alliance", nil, 2 },-- Duskwood

    -- Levels 30-40
    { 33, 30, 45, nil, nil, 1 },  -- Stranglethorn Vale
    { 400, 25, 35, nil, nil, 2 }, -- Thousand Needles
    { 405, 30, 40, nil, nil, 2 }, -- Desolace
    { 45, 30, 40, nil, nil, 2 },  -- Arathi Highlands

    -- Levels 35-45
    { 15, 35, 45, nil, nil, 2 }, -- Dustwallow Marsh
    { 3, 35, 45, nil, nil, 2 },  -- Badlands
    { 8, 35, 45, "Horde", nil, 2 }, -- Swamp of Sorrows

    -- Levels 40-50
    { 357, 40, 50, nil, nil, 1 }, -- Feralas
    { 440, 40, 50, nil, nil, 2 }, -- Tanaris
    { 47, 40, 50, nil, nil, 2 },  -- The Hinterlands
    { 51, 43, 50, nil, nil, 2 },  -- Searing Gorge

    -- Levels 47-55
    { 490, 48, 55, nil, nil, 1 }, -- Un'Goro Crater
    { 4, 47, 55, nil, nil, 2 },   -- Blasted Lands
    { 361, 48, 55, nil, nil, 2 }, -- Felwood
    { 16, 48, 55, nil, nil, 2 },  -- Azshara

    -- Levels 50-60
    { 28, 50, 60, nil, nil, 1 },  -- Western Plaguelands
    { 46, 50, 59, nil, nil, 2 },  -- Burning Steppes
    { 139, 55, 60, nil, nil, 1 }, -- Eastern Plaguelands
    { 618, 55, 60, nil, nil, 1 }, -- Winterspring
    { 1377, 55, 60, nil, nil, 2 },-- Silithus
}

local function AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction, giverZoneID)
    if not raceField or raceField == 0 then
        if giverZoneID and FACTION_EXCLUSIVE_ZONES[giverZoneID] and playerFaction then
            return FACTION_EXCLUSIVE_ZONES[giverZoneID] ~= playerFaction
        end
        return false
    end
    local factionMask
    if playerFaction == "Alliance" then
        factionMask = ALLIANCE_RACES
    elseif playerFaction == "Horde" then
        factionMask = HORDE_RACES
    else
        return false
    end
    if bit and bit.band then
        return bit.band(raceField, factionMask) == 0
    end
    -- Fallback if the bit library isn't available on this client: at
    -- least catch the whole-faction case, same as before.
    return raceField == (playerFaction == "Alliance" and HORDE_RACES or ALLIANCE_RACES)
        or raceField == (playerFaction == "Alliance" and 178 or 77)
end
_G.AutoQuestLearner_IsWrongFactionQuest = AutoQuestLearner_IsWrongFactionQuest

local function GetQuestPrerequisites(questID)
    -- Prefer the real, bundled prerequisite data -- found this session:
    -- 2,415 quests have this field, including entries with MULTIPLE
    -- prerequisites (101 of them) that the old single-value chain
    -- table couldn't represent at all. Confirmed against two quests
    -- already manually researched and verified this session (Marg
    -- Speaks -> prereq 1240, Sigil of Thoradin -> prereq 640) -- both
    -- matched exactly. Falls back to the manually-researched
    -- questchain.lua entries (built up one real, verified quest at a
    -- time earlier this session) for anything the bundled data doesn't
    -- have.
    local questData = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"] and AutoQuestLearnerData.quests["data"][questID]
    if questData and questData["pre"] and table.getn(questData["pre"]) > 0 then
        return questData["pre"]
    end

    if not questChainPrereq then
        questChainPrereq = {}
        if AutoQuestLearnerQuestChain then
            for fromID, toID in pairs(AutoQuestLearnerQuestChain) do
                questChainPrereq[toID] = fromID
            end
        end
    end
    local fallback = questChainPrereq[questID]
    if fallback then
        return { fallback }
    end
    return nil
end
_G.AutoQuestLearner_GetQuestPrerequisites = GetQuestPrerequisites

-- BUGFIX: real bundled data can leave a quest's own "race" field
-- untagged even when the quest is clearly faction-restricted -- e.g.
-- "Hints of a New Plague?" (quest 657, Alliance-only) has race=nil,
-- while the FIRST quest in that same chain (659) correctly has
-- race=77. The bitwise check (AutoQuestLearner_IsWrongFactionQuest)
-- can only act on data that exists; it has nothing to check when the
-- field itself is missing. Since a quest chain essentially never
-- switches faction partway through, walking to the nearest tagged
-- chain relative (prerequisite first, then follow-up) recovers the
-- real restriction for untagged mid-chain quests generally, instead of
-- needing each one patched individually as it's noticed. Capped at 10
-- steps each direction as a safety net against any cyclical data.
local function AutoQuestLearner_GetEffectiveRaceField(questID, questData)
    if questData and questData["race"] and questData["race"] ~= 0 then
        return questData["race"]
    end
    if not questID or not AutoQuestLearnerData.quests or not AutoQuestLearnerData.quests["data"] then
        return questData and questData["race"]
    end

    local seen = {}
    local queue = { questID }
    local visited = 0
    while table.getn(queue) > 0 and visited < 30 do
        local id = table.remove(queue, 1)
        local prereqs = GetQuestPrerequisites(id)
        if prereqs then
            for _, prereq in ipairs(prereqs) do
                if not seen[prereq] then
                    seen[prereq] = true
                    visited = visited + 1
                    local prereqData = AutoQuestLearnerData.quests["data"][prereq]
                    if prereqData and prereqData["race"] and prereqData["race"] ~= 0 then
                        return prereqData["race"]
                    end
                    table.insert(queue, prereq)
                end
            end
        end
    end

    seen = {}
    id = questID
    for _ = 1, 10 do
        local nextID = AutoQuestLearnerQuestChain and AutoQuestLearnerQuestChain[id]
        if not nextID or seen[nextID] then break end
        seen[nextID] = true
        local nextData = AutoQuestLearnerData.quests["data"][nextID]
        if nextData and nextData["race"] and nextData["race"] ~= 0 then
            return nextData["race"]
        end
        id = nextID
    end

    return questData and questData["race"]
end
_G.AutoQuestLearner_GetEffectiveRaceField = AutoQuestLearner_GetEffectiveRaceField

-- Lazily-built reverse lookup: is a given string a known ITEM name?
-- Built once on first use (not scanned every 0.5s tick) since the
-- bundled item database doesn't change mid-session. Used to tell a
-- learned objective's name apart from a real creature/object name --
-- e.g. a single-required-item objective's leaderboard text is often
-- JUST the item's name ("Gnoll Paw", no visible count), which isn't
-- something a /targetexact macro can target, and shouldn't be allowed
-- to block the static resolution's real creature names either.
local knownItemNames = nil
-- Skill-line IDs the bundled quest data's "skill" field uses to mark
-- profession-gated quests -- cross-verified against multiple
-- independent sources (WoWWiki's GetProfessionInfo page, a detailed
-- sequential skill-ID list distinguishing it from the unrelated
-- Retribution talent tree at 184, and Wowhead's own skill=165 page
-- confirming Leatherworking specifically, the profession that
-- surfaced this whole gap in the first place). WotLK-era professions
-- only; Archaeology (added later, in Cataclysm) is irrelevant here.
local SKILL_LINE_NAMES = {
    [164] = "Blacksmithing",
    [165] = "Leatherworking",
    [171] = "Alchemy",
    [182] = "Herbalism",
    [185] = "Cooking",
    [186] = "Mining",
    [197] = "Tailoring",
    [202] = "Engineering",
    [129] = "First Aid",
    [333] = "Enchanting",
    [356] = "Fishing",
    [393] = "Skinning",
    [755] = "Jewelcrafting",
    [773] = "Inscription",
}

-- Cached per-session (professions don't change mid-session outside of
-- deliberately unlearning one, which is rare enough not to poll for)
-- since GetProfessions()/GetProfessionInfo() calls add up if run on
-- every single quest in the database.
local playerSkillNames = nil
local function AutoQuestLearner_HasRequiredSkill(skillLineID, questID)
    if not skillLineID then return true end
    local requiredName = SKILL_LINE_NAMES[skillLineID]
    if not requiredName then return true end -- unknown skill ID, don't block on something we can't verify

    if not playerSkillNames then
        playerSkillNames = {}
        if GetProfessions then
            local profs = { GetProfessions() }
            for _, index in ipairs(profs) do
                if index and GetProfessionInfo then
                    local name = GetProfessionInfo(index)
                    if name then playerSkillNames[name] = true end
                end
            end
        end
    end
    if not (playerSkillNames[requiredName] == true) then return false end

    -- Rank/level threshold, when we have it (CodexLite's skill={id,
    -- rank} field, e.g. "needs Leatherworking at rank 225+", not just
    -- "has Leatherworking at all"). Pattern (iterate GetNumSkillLines
    -- via GetSkillLineInfo to find the matching rank) adapted from
    -- pfQuest's own proven GetPlayerSkill function.
    local rankReq = questID and AutoQuestLearnerQuestSkillRank and AutoQuestLearnerQuestSkillRank[questID]
    if rankReq and rankReq[1] == skillLineID and rankReq[2] and GetNumSkillLines and GetSkillLineInfo then
        local requiredRank = rankReq[2]
        local numSkills = GetNumSkillLines()
        for i = 1, numSkills do
            local skillName, _, _, skillRank = GetSkillLineInfo(i)
            if skillName == requiredName then
                return (skillRank or 0) >= requiredRank
            end
        end
        return false -- profession confirmed present above, but rank lookup failed -- be conservative
    end

    return true
end
_G.AutoQuestLearner_HasRequiredSkill = AutoQuestLearner_HasRequiredSkill

-- DISABLED: Ascension runs ~21 custom classes instead of vanilla/WotLK's
-- standard 9 -- confirmed by the person running this addon. UnitClass
-- ("player") on this server returns class tokens this standard
-- bitmask table (sourced from CodexLite/pfQuest, built for the
-- standard class roster) has no way to recognize, meaning this check
-- has likely never correctly filtered a class-restricted quest for
-- ANYONE on this server -- it was silently failing open every time
-- (by design, as a safety fallback for "can't verify"), not just for
-- unusual cases. Confirmed live: a Druid-only quest (Torwa Pathfinder,
-- quest 9063) was suggested to a non-Druid player. Without Ascension's
-- own custom class bitmask system, there's no reliable way to make
-- this check work correctly here, so it's disabled rather than left
-- silently non-functional.
local function AutoQuestLearner_HasRequiredClass(classBitmask)
    return true
end
_G.AutoQuestLearner_HasRequiredClass = AutoQuestLearner_HasRequiredClass

--[[ Kept for reference in case a future build ever has Ascension's own
class mapping to work with:

-- Class bitmask: 1=Warrior, 2=Paladin, 4=Hunter, 8=Rogue, 16=Priest,
-- 32=Death Knight, 64=Shaman, 128=Mage, 256=Warlock, 1024=Druid --
-- verified against real values in the extracted CodexLite data before
-- trusting this mapping (see codexlite-quest-flags.lua).
local CLASS_TOKEN_BITS = {
    WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16,
    DEATHKNIGHT = 32, SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024,
}
local playerClassBit = nil
local function AutoQuestLearner_HasRequiredClass_STANDARD(classBitmask)
    if not classBitmask or classBitmask == 0 then return true end
    if not playerClassBit then
        local _, classToken = UnitClass("player")
        playerClassBit = classToken and CLASS_TOKEN_BITS[classToken] or 0
    end
    if playerClassBit == 0 then return true end -- unrecognized class token, don't block on something we can't verify
    return bit.band(classBitmask, playerClassBit) ~= 0
end
--]]

-- Not cached (unlike class/skill above) -- reputation genuinely
-- changes while playing, and the lookup itself is cheap (iterating a
-- few dozen faction pane rows), so there's no real cost to just
-- checking fresh every time.
local REP_NO_LIMIT_SENTINEL = 4294967295
local function AutoQuestLearner_HasRequiredReputation(repData)
    if not repData then return true end
    local factionID, minRep, maxRep = repData[1], repData[2], repData[3]
    local factionName = AutoQuestLearnerFactionIDNames and AutoQuestLearnerFactionIDNames[factionID]
    if not factionName then return true end -- unknown faction ID, don't block on something we can't verify

    local numFactions = GetNumFactions()
    for i = 1, numFactions do
        local name, _, _, _, _, barValue = GetFactionInfo(i)
        if name == factionName then
            if minRep and minRep > -REP_NO_LIMIT_SENTINEL and barValue < minRep then return false end
            if maxRep and maxRep < REP_NO_LIMIT_SENTINEL and barValue > maxRep then return false end
            return true
        end
    end
    -- Faction not found in the player's reputation pane at all -- this
    -- can genuinely mean "not yet encountered", which for a MINIMUM
    -- requirement means it's definitely not met (an unencountered
    -- faction starts at 0, same as freshly-neutral). Only treat this
    -- as "can't verify, don't block" when there's no minimum to fail.
    if minRep and minRep > -REP_NO_LIMIT_SENTINEL then return false end
    return true
end
_G.AutoQuestLearner_HasRequiredReputation = AutoQuestLearner_HasRequiredReputation

-- True when the client calendar reports at least one HOLIDAY event
-- for today. Used only as a soft gate for exflag "needs event" quests;
-- private servers without a working calendar still stay hidden unless
-- showSeasonalQuests is turned on. Throttled to once per minute.
local seasonalEventCache, seasonalEventCacheAt = nil, 0
-- Title keywords for holiday content missing a solid exflag in the DB.
local SEASONAL_TITLE_PATTERNS = {
    "children's week", "children's week", "orphan",
    "brewfest", "midsummer", "fire festival", "flame warden", "flame keeper",
    "hallow's end", "hallows end", "wickerman", "headless horseman",
    "winter veil", "greatfather winter", "smokywood", "metzen",
    "love is in the air", "noblegarden", "pilgrim's bount", "harvest festival",
    "day of the dead", "lunar festival", "elder ", "coin of ancestry",
    "darkmoon",
}
function AutoQuestLearner_IsSeasonalQuestTitle(title)
    if not title or title == "" then return false end
    local lower = string.lower(title)
    for _, pat in ipairs(SEASONAL_TITLE_PATTERNS) do
        if string.find(lower, pat, 1, true) then return true end
    end
    return false
end
_G.AutoQuestLearner_IsSeasonalQuestTitle = AutoQuestLearner_IsSeasonalQuestTitle

function AutoQuestLearner_IsSeasonalEventActive()
    local now = GetTime and GetTime() or 0
    if seasonalEventCache ~= nil and (now - seasonalEventCacheAt) < 60 then
        return seasonalEventCache
    end
    seasonalEventCacheAt = now
    seasonalEventCache = false
    if type(CalendarGetDate) == "function" and type(CalendarGetNumDayEvents) == "function"
        and type(CalendarGetDayEvent) == "function" then
        local ok, weekday, month, day, year = pcall(CalendarGetDate)
        if ok and month and day then
            local ok2, n = pcall(CalendarGetNumDayEvents, month, day)
            n = (ok2 and n) or 0
            for i = 1, n do
                local ok3, title, hour, minute, calendarType = pcall(CalendarGetDayEvent, month, day, i)
                if ok3 and calendarType == "HOLIDAY" then
                    seasonalEventCache = true
                    break
                end
            end
        end
    end
    return seasonalEventCache
end
_G.AutoQuestLearner_IsSeasonalEventActive = AutoQuestLearner_IsSeasonalEventActive

-- Unified quest-gating check, combining everything that can make a
-- quest not actually available yet even though it looks like it
-- should be:
--   1. AND-prerequisites (existing "pre" field / questchain.lua
--      fallback) -- ALL listed prerequisites must be complete.
--   2. OR-prerequisite groups (CodexLite's preGroup) -- ANY ONE of
--      the listed alternatives being complete is enough. Different
--      from #1, which requires ALL of them.
--   3. Parent-active requirement (CodexLite's parent) -- available
--      only while a specific OTHER quest is currently active in the
--      log, not necessarily complete.
--   4. Mutual exclusion (CodexLite's excl) -- if any other quest in
--      the same exclusive group is already complete or currently
--      active, taking this one isn't actually possible.
-- Returns true if the quest is NOT blocked by any of these (i.e. safe
-- to suggest as available), false if blocked by at least one.
local function AutoQuestLearner_MeetsQuestGating(questID)
    -- Ground truth beats bundled data: if we've actually stood at this
    -- quest's giver, had its gossip window open, and the game itself
    -- didn't offer it -- despite our data saying every requirement we
    -- know about was met -- that means this server has some extra,
    -- undocumented requirement we have no way to check directly. Take
    -- the hint and stop suggesting it, rather than trusting our own
    -- (evidently incomplete) data over what actually happened in game.
    -- See the negative-learning cross-check in LearnFromGossip().
    if AutoQuestLearnerDB.knownUnavailable and AutoQuestLearnerDB.knownUnavailable[questID] then
        return false
    end

    -- Manual, account-wide snooze (/aql sleep). Deliberately checked
    -- here alongside knownUnavailable so it applies everywhere that
    -- function is already used to decide "should this show as
    -- available" -- and since AutoQuestLearnerDB is account-wide
    -- SavedVariables (not per-character), this naturally covers every
    -- alt on the account too, not just whichever character set it.
    if AutoQuestLearnerDB.snoozed and AutoQuestLearnerDB.snoozed[questID] then
        return false
    end

    -- Seasonal / holiday / event quests (CodexLite exflag bit 2 = needs
    -- event). Without an active world event these givers are not in the
    -- world, but the static DB still lists them — so they showed as
    -- available year-round. Hide unless the user forces them on, or a
    -- calendar HOLIDAY is detected for today.
    if AutoQuestLearnerDB.config.showSeasonalQuests ~= "1"
        and not AutoQuestLearner_IsSeasonalEventActive() then
        local needsEvent = questID and AutoQuestLearnerQuestExFlags
            and AutoQuestLearnerQuestExFlags[questID]
            and bit.band(AutoQuestLearnerQuestExFlags[questID], 2) ~= 0
        if needsEvent then
            return false
        end
        local qloc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"]
            and AutoQuestLearnerData.quests["loc"][questID]
        if qloc and qloc.T and AutoQuestLearner_IsSeasonalQuestTitle
            and AutoQuestLearner_IsSeasonalQuestTitle(qloc.T) then
            return false
        end
    end

    local prereqIDs = GetQuestPrerequisites(questID)
    if prereqIDs then
        for _, prereqID in ipairs(prereqIDs) do
            local prereqLoc = AutoQuestLearnerData.quests["loc"][prereqID]
            if not AutoQuestLearner_IsQuestCompleted(prereqID, prereqLoc and prereqLoc.T) then
                return false
            end
        end
    end

    local preGroup = AutoQuestLearnerQuestPreGroup and AutoQuestLearnerQuestPreGroup[questID]
    if preGroup then
        local anyComplete = false
        for _, altID in ipairs(preGroup) do
            local altLoc = AutoQuestLearnerData.quests["loc"][altID]
            if AutoQuestLearner_IsQuestCompleted(altID, altLoc and altLoc.T) then
                anyComplete = true
                break
            end
        end
        if not anyComplete then return false end
    end

    local parentID = AutoQuestLearnerQuestParent and AutoQuestLearnerQuestParent[questID]
    if parentID and not (AutoQuestLearner.questlog and AutoQuestLearner.questlog[parentID]) then
        return false
    end

    local exclGroup = AutoQuestLearnerQuestExcl and AutoQuestLearnerQuestExcl[questID]
    if exclGroup then
        for _, otherID in ipairs(exclGroup) do
            if otherID ~= questID then
                local otherLoc = AutoQuestLearnerData.quests["loc"][otherID]
                if AutoQuestLearner_IsQuestCompleted(otherID, otherLoc and otherLoc.T)
                    or (AutoQuestLearner.questlog and AutoQuestLearner.questlog[otherID]) then
                    return false
                end
            end
        end
    end

    return true
end
_G.AutoQuestLearner_MeetsQuestGating = AutoQuestLearner_MeetsQuestGating

local skillCacheInvalidateFrame = CreateFrame("Frame")
skillCacheInvalidateFrame:RegisterEvent("SKILL_LINES_CHANGED")
skillCacheInvalidateFrame:SetScript("OnEvent", function()
    playerSkillNames = nil
end)

local function AutoQuestLearner_IsKnownItemName(name)
    if not name then return false end
    if not knownItemNames then
        knownItemNames = {}
        if AutoQuestLearnerData.items and AutoQuestLearnerData.items["loc"] then
            for _, v in pairs(AutoQuestLearnerData.items["loc"]) do
                local itemName = type(v) == "string" and v or (type(v) == "table" and v["T"])
                if itemName then
                    knownItemNames[itemName] = true
                end
            end
        end
    end
    return knownItemNames[name] == true
end

local function AutoQuestLearner_IsDeprecatedQuestTitle(title)
    if not title then return false end
    if string.find(title, "^OLD ") then return true end
    if string.find(title, "^BETA ") then return true end
    if string.find(title, "^UNUSED") then return true end
    if string.find(title, "^FLAG ") then return true end
    if string.find(title, "%[Not Used%]") then return true end
    return false
end
_G.AutoQuestLearner_IsDeprecatedQuestTitle = AutoQuestLearner_IsDeprecatedQuestTitle

local availableGiverCacheMapID = nil
local availableGiverCacheBuiltAt = 0

local function RefreshAvailableGiverCache(force)
    if AutoQuestLearnerDB.config.allquestgivers ~= "1" then
        availableGiverCache = {}
        availableGiverCacheMapID = nil
        return
    end
    local mapID = GetCurrentMap()
    if not mapID then return end

    -- Skip rebuild if we already have a fresh list for this exact zone
    -- (unless force). Stale same-zone lists still refresh every 15s so
    -- completed/seasonal/level gates catch up without waiting for a zone.
    local now = GetTime and GetTime() or 0
    if not force and availableGiverCacheMapID == mapID and next(availableGiverCache)
        and (now - availableGiverCacheBuiltAt) < 15 then
        return
    end

    local playerLevel = UnitLevel("player")
    local playerFaction = UnitFactionGroup and UnitFactionGroup("player")

    local list = {}
    for questID, questData in pairs(AutoQuestLearnerData.quests["data"]) do
        local questLoc = AutoQuestLearnerData.quests["loc"][questID]
        if questLoc then
            local shouldSkip = AutoQuestLearner_IsDeprecatedQuestTitle(questLoc.T)
            local raceField = AutoQuestLearner_GetEffectiveRaceField(questID, questData)
            if not shouldSkip and AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction) then
                shouldSkip = true
            end
            -- Profession-gated quests (recipe/pattern teaching quests
            -- especially) shouldn't be suggested to a player who
            -- doesn't even have the required profession -- confirmed
            -- real with "Wild Leather Armor" (skill=165/Leatherworking
            -- in the bundled data), which was showing as available
            -- with no NPC "!" actually present.
            if not shouldSkip and not AutoQuestLearner_HasRequiredSkill(questData["skill"], questID) then
                shouldSkip = true
            end
            -- "Use item on object" quests (start object and end object
            -- are the same one, with an item objective requirement --
            -- e.g. The Super Egg-O-Matic, needing a Hippogryph Egg
            -- already in hand just to interact with it at all)
            -- shouldn't be suggested as available if you don't
            -- actually have the required item -- confirmed real, and a
            -- genuine recognizable pattern (64 quests bundled match
            -- this shape), not a one-off special case.
            if not shouldSkip and questData["start"] and questData["start"]["O"] and questData["end"] and questData["end"]["O"]
                and questData["start"]["O"][1] == questData["end"]["O"][1]
                and questData["obj"] and questData["obj"]["I"] and questData["obj"]["I"][1] then
                local requiredItemID = questData["obj"]["I"][1]
                if GetItemCount and GetItemCount(requiredItemID) == 0 then
                    shouldSkip = true
                end
            end
            -- Ascension-custom quests aren't suggested for pickup at
            -- all by default -- this server's own content frequently
            -- has undocumented requirements (reputation gates, hidden
            -- prerequisites, etc. -- confirmed real multiple times this
            -- session, e.g. the Grazle/Timbermaw case) that no bundled
            -- source captures, making "available" unreliable to claim
            -- confidently for this content specifically. Toggle with
            -- /aql trackascension.
            if not shouldSkip and AutoQuestLearnerDB.config.trackAscensionQuests ~= "1"
                and AutoQuestLearner_IsAscensionCustomQuest and AutoQuestLearner_IsAscensionCustomQuest(questID) then
                shouldSkip = true
            end
            -- Class-restricted quests aren't suggested for pickup at
            -- all by default, even for a matching class -- these often
            -- carry extra requirements (class trial completion,
            -- specific talent/level milestones) this addon's generic
            -- gating can't reliably verify, so the safer default is
            -- not to claim confidently that one is actually available
            -- right now. Toggle with /aql trackclassquests.
            if not shouldSkip and AutoQuestLearnerDB.config.trackClassQuests ~= "1"
                and AutoQuestLearnerClassRestrictions and AutoQuestLearnerClassRestrictions[questID] then
                shouldSkip = true
            end
            -- Reputation-gated quests shouldn't be suggested if the
            -- player doesn't meet the requirement (data from
            -- CodexLite/pfQuest, see bundled-db/codexlite-reputation.lua).
            if not shouldSkip and AutoQuestLearnerQuestReputation and AutoQuestLearnerQuestReputation[questID]
                and not AutoQuestLearner_HasRequiredReputation(AutoQuestLearnerQuestReputation[questID]) then
                shouldSkip = true
            end

            -- PvP-flag-gated quests (learned from the game's own "must
            -- be PvP flagged" error, see the CHAT_MSG_SYSTEM handler
            -- for pvpRequired elsewhere in this file) shouldn't be
            -- suggested for pickup on a non-PvP-by-default server
            -- either -- this existed for navigating to an already-
            -- accepted quest's objective, but was never checked here
            -- at the pickup-suggestion stage at all.
            if not shouldSkip and AutoQuestLearnerDB.pvpRequired and AutoQuestLearnerDB.pvpRequired[questID]
                and not (UnitIsPVP and UnitIsPVP("player")) then
                shouldSkip = true
            end

            local minLevel = questData["min"] or 0
            local questLevel = questData["lvl"] or minLevel
            if not shouldSkip and minLevel > playerLevel then
                shouldSkip = true
            end
            if not shouldSkip and AutoQuestLearnerDB.config.showhighlevel == "0" and questLevel > playerLevel + 3 then
                shouldSkip = true
            end
            if not shouldSkip and AutoQuestLearnerDB.config.showlowlevel == "0" and questLevel < playerLevel - 5 then
                shouldSkip = true
            end
            if not shouldSkip and AutoQuestLearner_IsQuestCompleted(questID, questLoc.T) then
                shouldSkip = true
            end
            -- Skip quests we know are gated behind an incomplete
            -- prerequisite, an unsatisfied OR-group, a required parent
            -- quest not currently active, or a completed/active
            -- mutually-exclusive alternative -- the NPC would actually
            -- offer a different (or no) quest in any of these cases,
            -- so surfacing this one as "available" would be
            -- misleading. See AutoQuestLearner_MeetsQuestGating's own
            -- comment for the full breakdown of what it checks.
            if not shouldSkip and not AutoQuestLearner_MeetsQuestGating(questID) then
                shouldSkip = true
            end
            -- Unlike the map-node pass, always skip quests already in
            -- your log here regardless of the "Display Current Quest
            -- Givers" setting -- those are already fully handled (with
            -- learned-location priority, objective tracking, etc.) by
            -- the main candidate loop above; an "available" duplicate
            -- would just be redundant.
            if not shouldSkip and AutoQuestLearner.questlog and
                (AutoQuestLearner.questlog[questID] or (questLoc.T and AutoQuestLearner.questlog[questLoc.T])) then
                shouldSkip = true
            end

            if not shouldSkip and questData["start"] then
                local function addCandidates(idSet, dataTable, nameResolver)
                    if not idSet then return end
                    for _, id in pairs(idSet) do
                        local entryData = dataTable[id]
                        if entryData and entryData["coords"] then
                            local resolvedName = (nameResolver and nameResolver(id)) or entryData["name"]
                            for _, coord in pairs(entryData["coords"]) do
                                if coord[3] == mapID then
                                    table.insert(list, {
                                        x = coord[1], y = coord[2], mapID = mapID,
                                        title = (questLoc.T or ("Quest " .. questID)) .. " (available)",
                                        name = resolvedName,
                                        questid = questID,
                                    })
                                end
                            end
                        end
                    end
                end
                addCandidates(questData["start"]["U"], AutoQuestLearnerData.units["data"], AutoQuestLearner_GetUnitName)
                addCandidates(questData["start"]["O"], AutoQuestLearnerData.objects["data"], AutoQuestLearner_GetObjectName)
            end
        end
    end
    availableGiverCache = list
    availableGiverCacheMapID = mapID
    availableGiverCacheBuiltAt = GetTime and GetTime() or 0
end
AutoQuestLearner_RefreshAvailableGiverCache = RefreshAvailableGiverCache


-- This continuously picks the CLOSEST known destination among:
-- pickup/turn-in locations for quests currently in your log, and
-- objective spawn points for their incomplete objectives -- driving
-- the navigation arrow, automatically switching to the next-closest
-- thing as you move, complete objectives, or turn quests in.
--
-- Limited to your current zone -- distance can't be meaningfully
-- compared across zones (see crossZoneMapID below for how a
-- different-zone candidate is still surfaced, just not competed on
-- distance).
------------------------------------------------------------
local function FindClosestQuestDestination(questFilter)
    local px, py = GetPlayerPos()
    if not px then return nil end
    local currentZone = GetCurrentMap()
    if not currentZone or not AutoQuestLearner.questlog then return nil end

    -- A pinned quest that's no longer in your log (turned in,
    -- abandoned, etc.) can't be un-pinned via Alt+Right-Click anymore,
    -- since it's no longer in the tracker to click -- auto-release it
    -- instead of leaving the arrow permanently stuck on nothing.
    if AutoQuestLearner.pinnedQuestID and not AutoQuestLearner.questlog[AutoQuestLearner.pinnedQuestID] then
        print("|cff00ff00AutoQuestLearner:|r Pinned quest is no longer active -- auto-unpinned, arrow back to auto-select.")
        AutoQuestLearner.pinnedQuestID = nil
    end

    local learned = GetLearnedDB()
    local bestLoc, bestDist, bestTitle, bestName, bestQuestID = nil, nil, nil, nil, nil
    -- Tracks the best candidate found in a DIFFERENT zone than the
    -- player's current one, for when nothing is known in-zone at all.
    -- Previously these were silently discarded entirely (consider()
    -- just returned early) -- so a quest whose only known location was,
    -- say, Ashenvale, while standing in Stonetalon Mountains, showed
    -- "no location known" even though the addon actually knew exactly
    -- where to go, just not in the zone currently open. Distance can't
    -- be meaningfully compared across zones, so this just keeps
    -- whichever cross-zone candidate is found first rather than trying
    -- to rank them.
    local crossZoneMapID, crossZoneTitle, crossZoneName = nil, nil, nil
    -- Set at the top of each outer per-quest loop iteration below; consider()
    -- reads this implicitly so every existing call site (there are many)
    -- doesn't need to be touched to also pass a questID through.
    local currentConsiderQuestID = nil

    local bestFallbackLoc, bestFallbackDist, bestFallbackTitle, bestFallbackName, bestFallbackSource, bestFallbackQuestID = nil, nil, nil, nil, nil, nil
    local bestSource = nil

    -- sourceTag (optional 5th arg): "locked" | "learned" | "static" | "route" | "available" | "guess"
    local function consider(loc, title, name, isFallback, sourceTag)
        if not loc then return end
        -- Skip static sources the player explicitly hid (Shift-click on a cluster)
        if sourceTag == "static" and currentConsiderQuestID and loc._sourceKey then
            local hk = AutoQuestLearnerDB.hiddenStaticSources
            if hk and hk[tostring(currentConsiderQuestID) .. ":" .. tostring(loc._sourceKey)] then
                return
            end
        end
        -- Number vs string map IDs (17 vs "17") used to fail equality and
        -- dump every Barrens turn-in into the cross-zone bucket — so the
        -- arrow fell through to a bogus in-zone "available" like Jin'Zil.
        local locZone, curZone = loc.mapID, currentZone
        local sameZone = (locZone == curZone)
            or (tonumber(locZone) and tonumber(curZone) and tonumber(locZone) == tonumber(curZone))
            or (tostring(locZone) == tostring(curZone))
        if not sameZone then
            if not isFallback and not crossZoneMapID then
                crossZoneMapID = loc.mapID
                crossZoneTitle = title
                crossZoneName = name
            end
            return
        end
        local dx, dy = loc.x - px, loc.y - py
        local dist = dx * dx + dy * dy
        if isFallback then
            if not bestFallbackDist or dist < bestFallbackDist then
                bestFallbackDist = dist
                bestFallbackLoc = loc
                bestFallbackTitle = title
                bestFallbackName = name
                bestFallbackSource = sourceTag or "guess"
                bestFallbackQuestID = currentConsiderQuestID
            end
            return
        end
        if not bestDist or dist < bestDist then
            bestDist = dist
            bestLoc = loc
            bestTitle = title
            bestName = name
            bestQuestID = currentConsiderQuestID
            bestSource = sourceTag or "static"
        end
    end

    -- Considers every known spawn coordinate for a set of NPC/object IDs
    -- from the static bundled database (pfQuest + Questie-X), the same
    -- data SearchQuestID() draws from for map nodes. This is what makes
    -- the arrow useful immediately, not just after something has
    -- been personally observed -- the learned database above still
    -- takes priority via distance (closer wins), so anything you've
    -- actually found in-game naturally corrects a bad static guess.
    -- Cap static coord scans hard: large multi-spawn tables were the main
    -- hitch when retargeting the arrow after kills (FPS dips + memory spikes).
    local MAX_COORDS_PER_SOURCE = 12
    local function considerStatic(idSet, idType, title, isFallback)
        if not idSet then return end
        for _, id in pairs(idSet) do
            local hideKey = currentConsiderQuestID and (tostring(currentConsiderQuestID) .. ":" .. tostring(id))
            if hideKey and AutoQuestLearnerDB.hiddenStaticSources and AutoQuestLearnerDB.hiddenStaticSources[hideKey] then
                -- Player hid this NPC/object source for this quest
            else
            local data = idType == "U" and AutoQuestLearnerData.units["data"][id]
                or idType == "O" and AutoQuestLearnerData.objects["data"][id]
            local name = idType == "U" and AutoQuestLearner_GetUnitName(id)
                or idType == "O" and AutoQuestLearner_GetObjectName(id)
            if data and data["coords"] then
                local checked = 0
                for _, coord in pairs(data["coords"]) do
                    if coord[3] then
                        consider({ x = coord[1], y = coord[2], mapID = coord[3], _sourceKey = id }, title, name, isFallback, "static")
                        checked = checked + 1
                        if checked >= MAX_COORDS_PER_SOURCE then break end
                    end
                end
            end
            end
        end
    end

    -- Old learned turn-in entries (recorded before RecordLocation()
    -- started capturing the target's name) have coordinates but no
    -- name. The *name* can still safely come from the static database
    -- even when its *coordinates* can't be trusted -- who the NPC is
    -- doesn't change just because Ascension placed them somewhere
    -- different, only where they are does.
    local function StaticTurninName(staticQuest)
        if not staticQuest or not staticQuest["end"] then return nil end
        local endU = staticQuest["end"]["U"]
        if endU then
            for _, id in pairs(endU) do
                local nm = AutoQuestLearner_GetUnitName(id)
                if nm then return nm end
            end
        end
        local endO = staticQuest["end"]["O"]
        if endO then
            for _, id in pairs(endO) do
                local nm = AutoQuestLearner_GetObjectName(id)
                if nm then return nm end
            end
        end
        return nil
    end

    local questsToCheck = AutoQuestLearner.questlog
    if questFilter then
        -- Route planner: restrict to exactly one quest for this call,
        -- reusing all the same location-resolution logic below rather
        -- than a separate, duplicated implementation.
        questsToCheck = {}
        if AutoQuestLearner.questlog[questFilter] then
            questsToCheck[questFilter] = AutoQuestLearner.questlog[questFilter]
        end
    elseif AutoQuestLearner.pinnedQuestID then
        -- A quest is pinned -- only ever consider that one, ignoring
        -- everything else, until it's unpinned (Alt+Right-Click it
        -- again in the tracker).
        questsToCheck = {}
        if AutoQuestLearner.questlog[AutoQuestLearner.pinnedQuestID] then
            questsToCheck[AutoQuestLearner.pinnedQuestID] = AutoQuestLearner.questlog[AutoQuestLearner.pinnedQuestID]
        end
    end

    for questID, logData in pairs(questsToCheck) do
        currentConsiderQuestID = questID
        local questTitle = logData.title or ("Quest " .. tostring(questID))
        local questEntry = GetLearnedQuestEntry(learned, questID, questTitle)
        questTitle = (questEntry and questEntry.title) or questTitle

        -- BUGFIX: confirmed real -- Ascension (like any heavily custom
        -- server) sometimes reuses a real vanilla quest ID for its own,
        -- completely unrelated custom content. Every piece of bundled
        -- STATIC data for that ID (creature/object sources, item
        -- sources, third-party leveling-guide coordinates) is data for
        -- the VANILLA quest that number originally meant, not whatever
        -- Ascension actually put there -- so all of it is not just
        -- imprecise but flatly wrong when this happens, and can easily
        -- look "stuck near town" if the vanilla quest's real location
        -- happens to be nearby (it has nothing to do with the real
        -- objective, it's simply a coincidence of where THAT quest was).
        -- Comparing the live in-game title against our bundled title
        -- for the same numeric ID catches this directly -- a
        -- numeric ID can be trusted to mean the same quest across
        -- sources, but ONLY if the title agrees too.
        local questIDIsRepurposed = false
        local numericID = tonumber(questID)
        if numericID then
            local bundledLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][numericID]
            local bundledTitle = bundledLoc and bundledLoc.T
            local liveNorm, bundledNorm = normalizeTitle(logData.title), normalizeTitle(bundledTitle)
            if liveNorm and bundledNorm and liveNorm ~= bundledNorm then
                questIDIsRepurposed = true
            end
        end

        -- "Path to Ascension" quests are Ascension's own built-in
        -- tutorial/leveling guide, completed through a special client
        -- UI panel (open it, click through objectives, "Start Quest"
        -- buttons, etc.) -- not a real quest giver/turn-in NPC anywhere
        -- in the world. Any location data we might have "learned" or
        -- matched for one of these is either wrong or irrelevant, so
        -- skip them entirely rather than send the arrow somewhere
        -- meaningless.
        -- Path to Ascension only (log quests you accepted still get the arrow)
        if questTitle and string.find(questTitle, "^Path to Ascension") then
            -- skip tutorial panel quests
        elseif AutoQuestLearnerDB.pvpRequired and AutoQuestLearnerDB.pvpRequired[questID]
            and AutoQuestLearner.pinnedQuestID ~= questID
            and not (UnitIsPVP and UnitIsPVP("player")) then
            -- Confirmed real -- learned from the game's own "must be
            -- PvP flagged" error (see the CHAT_MSG_SYSTEM handler
            -- above). This is a non-PvP-by-default server, so don't
            -- keep sending the arrow to an objective that will just
            -- refuse to work until the player deliberately opts into
            -- PvP -- unless they explicitly pinned this exact quest
            -- themselves, in which case that's a deliberate choice to
            -- respect, not override.
            -- skip
        elseif AutoQuestLearnerDB.repRequired and AutoQuestLearnerDB.repRequired[questID]
            and AutoQuestLearner.pinnedQuestID ~= questID then
            -- Same idea, for reputation gates instead of PvP flagging
            -- (see the repGateMessageFrame CHAT_MSG_SYSTEM handler).
            -- No auto-recheck here -- reputation only changes by
            -- actually playing, not a quick toggle, so this stays
            -- suppressed until manually cleared once the player knows
            -- they've earned enough standing. Pin overrides, same as
            -- the PvP case.
            -- skip
        else

        local qlogid = logData.qlogid
        local staticQuest = AutoQuestLearnerData.quests["data"][questID]
        if questIDIsRepurposed then
            -- Every field on staticQuest (obj U/O/I sources, end U/O,
            -- etc.) describes the VANILLA quest this ID used to mean,
            -- not Ascension's actual quest using the same number --
            -- nil it out here rather than gating each individual
            -- consumer separately below.
            --
            -- Exception: if this specific ID has a manually-verified
            -- override (see repurposed-quest-overrides.lua), use that
            -- instead of losing all objective data outright -- confirmed
            -- real need via quest 246 ("Serena's Head" on Ascension):
            -- the correct target (creature 3452, Serena Bloodfeather)
            -- has genuinely correct bundled coordinate data sitting in
            -- the database, but nothing connected the quest to it once
            -- the wrong (Redridge) vanilla objective data was
            -- suppressed -- the arrow fell back to a "quest area" guess
            -- near the turn-in NPC instead of the real spawn, despite
            -- the real spawn's location being fully known all along.
            local override = AutoQuestLearnerRepurposedQuestOverrides and AutoQuestLearnerRepurposedQuestOverrides[questID]
            if override then
                staticQuest = { ["obj"] = override }
            else
                staticQuest = nil
            end
        end

        -- Once a quest is in your log, its pickup ("giver") location is
        -- no longer relevant to route toward -- only ever consider the
        -- turn-in location or remaining incomplete objectives.
        local _, _, _, header, _, questComplete = qlogid and AutoQuestLearner_GetQuestLogTitle(qlogid)

        -- Note: deliberately NOT also checking
        -- GetNumQuestLeaderBoards(qlogid) == 0 here. On this client,
        -- that can return 0 for a quest whose objective/leaderboard
        -- detail simply hasn't been loaded yet (it's often only
        -- populated once you've actually selected/viewed that quest in
        -- your log), not just for quests that genuinely have zero
        -- objectives -- which caused real, uncompleted quests to be
        -- misreported as ready to turn in.
        --
        -- BUGFIX: Blizzard's own isComplete flag (questComplete above)
        -- is NOT reliable enough on its own -- observed in practice on
        -- this client (Ascension): a quest with two kill objectives
        -- both individually confirmed done (leaderboard reads 1/1 and
        -- 1/1, tracker shows 100%) still had isComplete come back
        -- false, leaving the arrow stuck pointing at "objective nearby"
        -- forever instead of switching to the turn-in. Cross-check with
        -- the leaderboard as a second, independent signal: if it has at
        -- least one objective AND every single one of them reports
        -- done, treat the quest as complete regardless of what
        -- isComplete says. This is a much stronger positive signal than
        -- the "0 objectives" false-positive case above (which required
        -- guarding against an EMPTY leaderboard, not a fully-done one),
        -- so it doesn't reopen that old bug.
        if not questComplete and qlogid then
            local numObjectives = GetNumQuestLeaderBoards(qlogid)
            if numObjectives and numObjectives > 0 then
                local allDone = true
                for i = 1, numObjectives do
                    local _, _, objDone = GetQuestLogLeaderBoard(i, qlogid)
                    if not objDone then
                        allDone = false
                        break
                    end
                end
                if allDone then
                    questComplete = true
                end
            end
        end

        if questComplete then
            -- Every objective is done (or there were none to begin
            -- with) -- all that's left is turning it in.
            --
            -- BUGFIX: a personally-confirmed ("learned") turn-in
            -- location now WINS OUTRIGHT over the static/RXP database,
            -- instead of both being fed into consider() and letting
            -- raw distance decide. Ascension is a private server with
            -- its own custom NPC placements -- the bundled static data
            -- (converted from vanilla/WotLK sources) is frequently
            -- just wrong here, sometimes by a whole building or more.
            -- "Closer wins" meant that if the (wrong) static coordinate
            -- happened to be nearer than the real, learned one given
            -- your approach direction, the arrow/map pin would
            -- keep sending you to the wrong spot even AFTER you'd
            -- personally stood at the correct one and it got recorded
            -- -- exactly backwards from what "learning" a location
            -- should do.
            local hasLearnedTurnin = questEntry and questEntry.turnin and questEntry.turnin.mapID
            if hasLearnedTurnin then
                local turninName = questEntry.turnin.name or StaticTurninName(staticQuest)
                local src = questEntry.turnin.locked and "locked" or "learned"
                consider(questEntry.turnin, questTitle .. " (turn-in)", turninName, false, src)
            else
                if staticQuest and staticQuest["end"] then
                    considerStatic(staticQuest["end"]["U"], "U", questTitle .. " (turn-in)")
                    considerStatic(staticQuest["end"]["O"], "O", questTitle .. " (turn-in)")
                end
                -- Precise turn-in coordinates from RXPGuides (see
                -- bundled-db/rxp-coords.lua), cross-validated against
                -- this addon's own data before being bundled -- still
                -- just static/bundled data, so it only applies when we
                -- have no personally-learned location of our own yet.
                -- Same repurposed-ID protection as the tourguide
                -- fallback above -- see questIDIsRepurposed. Marked as
                -- an actual fallback (see consider()'s isFallback
                -- param) rather than an equal competitor, matching the
                -- same fix just applied to the tourguide case -- a
                -- real static turn-in location from considerStatic
                -- just above should always win over this if one exists.
                local numericQuestID2 = tonumber(questID)
                if not questIDIsRepurposed and numericQuestID2 and AutoQuestLearnerRXPTurnin and AutoQuestLearnerRXPTurnin[numericQuestID2] then
                    local rxp = AutoQuestLearnerRXPTurnin[numericQuestID2]
                    consider({ x = rxp[1], y = rxp[2], mapID = rxp[3] }, questTitle .. " (turn-in)", nil, true)
                end
            end
        else
            -- Objective candidates (real, known locations) always take
            -- priority over the giver/turn-in fallback below -- even if
            -- the fallback happens to be closer to the player right now
            -- (e.g. you're still standing near the quest giver). Without
            -- this, the "closest wins" logic in consider() would let the
            -- fallback win purely on proximity, so the arrow pointed
            -- back at the giver until you'd already walked most of the
            -- way to the real objective -- defeating the point of
            -- knowing the objective location at all. objectiveCandidateCount
            -- tracks whether we found ANY real objective candidate in
            -- this zone; the fallback only runs if that's zero.
            local objectiveCandidateCount = 0
            local hasLearnedObjective = false

            local objectives = GetLearnedObjectives(learned, questID, questTitle)
            if objectives and qlogid then
                for objIndex, obj in pairs(objectives) do
                    local _, _, objDone = GetQuestLogLeaderBoard(tonumber(objIndex), qlogid)
                    if not objDone then
                        -- Learned objectives don't carry a specific NPC ID
                        -- (RecordObjectiveProgress only ever captured
                        -- position + the leaderboard text, not what was
                        -- actually killed there) -- the leaderboard text
                        -- itself is usually already NPC-name-shaped
                        -- ("Bandit slain: 0/5"), so strip the counter and
                        -- use that as the best available name.
                        --
                        -- BUGFIX: some objectives (item-collection ones
                        -- especially, e.g. a single required item like
                        -- "Gnoll Paw") show NO count suffix at all in
                        -- their leaderboard text -- no digit anywhere for
                        -- the pattern above to anchor on, so it silently
                        -- produced nil. That name=nil then fed into the
                        -- learned-beats-static priority system, which
                        -- suppresses static objective data (the real
                        -- creature name, e.g. "Riverpaw Bandit") once ANY
                        -- learned entry exists for the quest -- so this
                        -- one broken name was blocking a perfectly good
                        -- one instead of just being a cosmetic miss.
                        -- Falling back to the raw text itself when the
                        -- pattern doesn't match ensures this is never nil.
                        local learnedName = obj.text and (string.match(obj.text, "^(.-)%s*:?%s*%d") or obj.text)
                        -- BUGFIX: confirmed real -- the fallback above
                        -- (matching no progress-count pattern, so using
                        -- the raw text as-is) is only valid when that
                        -- raw text already IS a short creature/item
                        -- name. For non-counted objectives (explore/
                        -- travel-style, e.g. "Explore the waters of the
                        -- Forgotten Pools") there's no count to strip in
                        -- the first place, so the ENTIRE sentence was
                        -- being used as if it were an NPC name -- shows
                        -- up as a garbled "Find <the whole objective
                        -- description> nearby." on the arrow. A real
                        -- creature/item name is never a full sentence;
                        -- word count is a cheap, reliable way to tell.
                        if learnedName and select(2, string.gsub(learnedName, "%S+", "")) > 5 then
                            learnedName = nil
                        end

                        -- BUGFIX: this client reports DIFFERENT "current
                        -- zone" mapIDs for the same physical spot
                        -- depending on exactly where you're standing --
                        -- e.g. Durotar (14) broadly vs. the named
                        -- "Valley of Trials" sub-area (363) within it.
                        -- consider() requires an exact mapID match, so a
                        -- learned spawn recorded under one of those IDs
                        -- was invisible while standing somewhere that
                        -- currently reads as a different (but related)
                        -- one -- even though it's the same real place.
                        -- If the CURRENT zone itself is already one of
                        -- the mapIDs this exact objective has spawns
                        -- under, treat every mapID in that same set as
                        -- interchangeable for this objective specifically
                        -- -- the addon having recorded them together
                        -- under one objective IS the proof they're the
                        -- same place, which is more reliable evidence
                        -- than a single zone-ID reading.
                        local zoneFamily = nil
                        for _, spawn in pairs(obj.spawns or {}) do
                            if spawn.mapID == currentZone then
                                zoneFamily = true
                                break
                            end
                        end

                        -- Only a learned name that's actually a
                        -- creature/object (not an item) should be
                        -- allowed to suppress static resolution -- an
                        -- item-only name like "Gnoll Paw" isn't
                        -- targetable anyway, so blocking the static
                        -- data's real creature names (e.g. "Riverpaw
                        -- Bandit") over it would trade a good result
                        -- for a useless one. The learned spawn's
                        -- LOCATION is still used as a candidate either
                        -- way -- this only affects whether it gates out
                        -- static candidates too.
                        local learnedNameIsCreature = learnedName and not AutoQuestLearner_IsKnownItemName(learnedName)

                        for _, spawn in pairs(obj.spawns or {}) do
                            -- BUGFIX: confirmed real -- kill-tracking
                            -- (HideNearestNode) only ever updated what
                            -- the MAP drew; this candidate-gathering
                            -- loop reads the same raw spawn data
                            -- directly and had no idea a point was just
                            -- killed, so the arrow could keep pointing
                            -- at a cleared spot indefinitely even
                            -- though its dot had correctly vanished
                            -- from the map. Skip it here the same way.
                            local isHidden = spawn.targetID and AutoQuestLearnerMap and AutoQuestLearnerMap.IsHidden
                                and AutoQuestLearnerMap:IsHidden(spawn.mapID, spawn.x, spawn.y, tostring(spawn.targetID))
                            if not isHidden then
                            -- Drop learned points that contradict known areatrigger coords
                            if not IsNearAnyStaticAreatrigger(questID, spawn.x, spawn.y, spawn.mapID, 10) then
                                -- skip bad learned explore pin
                            else
                            if learnedNameIsCreature then
                                hasLearnedObjective = true
                            end
                            if spawn.mapID == currentZone then
                                objectiveCandidateCount = objectiveCandidateCount + 1
                                consider(spawn, (obj.text or questTitle) .. " (objective)", learnedName, false, "learned")
                            elseif zoneFamily then
                                objectiveCandidateCount = objectiveCandidateCount + 1
                                consider({ x = spawn.x, y = spawn.y, mapID = currentZone },
                                    (obj.text or questTitle) .. " (objective)", learnedName, false, "learned")
                            else
                                consider(spawn, (obj.text or questTitle) .. " (objective)", learnedName, false, "learned")
                            end
                            end
                            end
                        end
                    end
                end
            end
            -- Precise "stand here" coordinates for zone-wide "kill/
            -- interact somewhere in this area" objectives, from a
            -- community leveling guide (see bundled-db/tourguide-
            -- coords.lua) -- exactly the class of quest our own NPC/
            -- object-ID-based data is least precise for, since there's
            -- no single spawn point to anchor to.
            --
            -- BUGFIX: confirmed real -- this was being added
            -- unconditionally, competing purely on raw distance against
            -- real static spawn data even when that data exists and is
            -- rich (e.g. a real 25-47 point NPC spawn cluster). This
            -- fallback's own header comment says it exists specifically
            -- for objectives with NO single spawn point to anchor to --
            -- when real spawn data already covers the objective, a
            -- single guide-author's waypoint has no business
            -- outcompeting it just by chance proximity. Gated the same
            -- way the (quest area) turn-in-proxy fallback below already
            -- correctly is: only when zero real candidates exist yet.
            --
            -- Also skip entirely if this quest ID has been repurposed
            -- (see questIDIsRepurposed above) -- that coordinate would
            -- be for whatever vanilla quest this ID actually was.
            if objectiveCandidateCount == 0 and not questIDIsRepurposed and numericID and AutoQuestLearnerTourGuideCoords and AutoQuestLearnerTourGuideCoords[numericID] then
                local tg = AutoQuestLearnerTourGuideCoords[numericID]
                consider({ x = tg[1], y = tg[2], mapID = tg[3] }, questTitle .. " (objective)", nil, true)
            end

            if staticQuest and staticQuest["obj"] and not hasLearnedObjective then
                -- BUGFIX: previously this static objective data was
                -- always considered alongside any learned objective
                -- location, and consider()'s "closest wins" logic
                -- decided between them by raw distance -- the same bug
                -- already fixed above for giver/turn-in locations, just
                -- not yet applied here. On Ascension, where the bundled
                -- static coordinates (converted from vanilla/WotLK
                -- sources) frequently don't match where the mob/object
                -- actually spawns, that meant a wrong static cluster
                -- could keep outcompeting a correctly learned one
                -- depending on which was nearer at any given moment.
                -- Now: once we've personally recorded ANY real
                -- objective location for this quest, the static "obj"
                -- pool is skipped entirely rather than left to compete.
                --
                -- The bundled "obj" data is a flat pool of every
                -- NPC/object/areatrigger ID relevant to the quest as a
                -- whole -- it doesn't record which specific leaderboard
                -- line each one belongs to. Without this, a quest with
                -- one sub-objective finished (e.g. "Razormane Geomancer
                -- slain: 8/8") and another still in progress ("Kreenig
                -- Snarlsnout's Tusk: 0/1") would keep offering the
                -- FINISHED one as a candidate right alongside the
                -- unfinished one -- and since you're often already
                -- standing at/near the finished one when it completes,
                -- it would keep winning "closest" and the arrow would
                -- never advance to what's actually still needed. Build
                -- the set of already-done leaderboard texts once here,
                -- then skip any static candidate whose resolved name
                -- matches one (same substring heuristic used for map
                -- node culling, for consistency between the two).
                local doneObjectiveTexts = {}
                if qlogid then
                    local numObjectives = GetNumQuestLeaderBoards(qlogid)
                    if numObjectives and numObjectives > 0 then
                        for oi = 1, numObjectives do
                            local otext, _, odone = GetQuestLogLeaderBoard(oi, qlogid)
                            if odone and otext then
                                local label = string.match(otext, "^(.-)%s*:?%s*%d") or otext
                                table.insert(doneObjectiveTexts, string.lower(label))
                            end
                        end
                    end
                end

                local function isAlreadyDone(name)
                    if not name or table.getn(doneObjectiveTexts) == 0 then return false end
                    local nameLower = string.lower(name)
                    for _, doneText in pairs(doneObjectiveTexts) do
                        if string.find(doneText, nameLower, 1, true) or string.find(nameLower, doneText, 1, true) then
                            return true
                        end
                    end
                    return false
                end

                local function considerStaticCounting(idSet, idType, title)
                    if not idSet then return end
                    for _, id in pairs(idSet) do
                        local data = idType == "U" and AutoQuestLearnerData.units["data"][id]
                            or idType == "O" and AutoQuestLearnerData.objects["data"][id]
                            or idType == "A" and AutoQuestLearnerData.areatrigger["data"][id]
                        local name = idType == "U" and AutoQuestLearner_GetUnitName(id)
                            or idType == "O" and AutoQuestLearner_GetObjectName(id)
                            or idType == "A" and "the search area"
                        if data and data["coords"] and not isAlreadyDone(name) then
                            local checked = 0
                            for _, coord in pairs(data["coords"]) do
                                if coord[3] then
                                    -- Same kill-tracking awareness as the
                                    -- learned-spawn path above.
                                    local isHidden = AutoQuestLearnerMap and AutoQuestLearnerMap.IsHidden
                                        and AutoQuestLearnerMap:IsHidden(coord[3], coord[1], coord[2], tostring(id))
                                    if not isHidden then
                                        if coord[3] == currentZone then
                                            objectiveCandidateCount = objectiveCandidateCount + 1
                                        end
                                        consider({ x = coord[1], y = coord[2], mapID = coord[3] }, title, name)
                                        checked = checked + 1
                                        if checked >= MAX_COORDS_PER_SOURCE then break end
                                    end
                                end
                            end
                        end
                    end
                end
                considerStaticCounting(staticQuest["obj"]["U"], "U", questTitle .. " (objective)")
                considerStaticCounting(staticQuest["obj"]["O"], "O", questTitle .. " (objective)")
                considerStaticCounting(staticQuest["obj"]["A"], "A", questTitle .. " (objective)")

                -- Item-collection objectives ("Collect 8 Witchwing
                -- Talons"): the quest itself has no NPC/object ID
                -- attached, only an item requirement, so it has to be
                -- resolved through the item's drop sources first. Uses
                -- the exact same resolution AutoQuestLearner_Database.lua's
                -- SearchQuestID uses for map nodes -- without this, the
                -- arrow and the map nodes could disagree with each
                -- other (nodes showing a cluster while the arrow still
                -- says "no location known").
                -- PERFFIX (confirmed real via /aql perfdebug: average
                -- cost climbed back up to ~5.5ms/call after being fixed
                -- to ~0.4-3ms, reported alongside a returning stutter
                -- while killing mobs with 1-3 quests tracked): unlike
                -- considerStatic/considerStaticCounting above (which
                -- cap coordinates PER SOURCE at MAX_COORDS_PER_SOURCE),
                -- nothing capped the NUMBER of sources an item-collection
                -- objective could pull in. AutoQuestLearner_ResolveItemSources
                -- returns every known drop source for an item completely
                -- uncapped -- and common junk-drop items have a LOT of
                -- them: item 117 (Linen Cloth) alone has 100+ NPC
                -- sources in the bundled database. A quest needing a
                -- common item like that meant this loop could call
                -- considerStaticCounting 100+ times, each itself
                -- scanning up to 30 coordinates -- thousands of
                -- distance checks for one single objective, on top of
                -- everything else this function already does. Capping
                -- the number of sources checked (not just coords per
                -- source) closes the same class of "uncapped iteration
                -- over the now much larger bundled database" issue the
                -- original MAX_COORDS_PER_SOURCE fix addressed, just in
                -- a spot that fix didn't reach.
                local MAX_ITEM_SOURCES = 15
                if staticQuest["obj"]["I"] and AutoQuestLearner_ResolveItemSources then
                    for _, itemID in pairs(staticQuest["obj"]["I"]) do
                        local itemName = AutoQuestLearner_GetItemName and AutoQuestLearner_GetItemName(itemID)
                        if not isAlreadyDone(itemName) then
                            local sources = AutoQuestLearner_ResolveItemSources(itemID)
                            local sourcesChecked = 0
                            for _, src in pairs(sources) do
                                considerStaticCounting({ src.id }, src.type, questTitle .. " (objective)")
                                sourcesChecked = sourcesChecked + 1
                                if sourcesChecked >= MAX_ITEM_SOURCES then break end
                            end
                        end
                    end
                end
            end

            -- Fallback: our bundled data usually only has start/end
            -- linkage, not objective-specific kill-target NPCs (that
            -- field was skipped during conversion due to schema
            -- uncertainty -- see bundled-db conversion notes). Without
            -- this fallback, an incomplete quest with no objective data
            -- would never get a candidate at all, even though we
            -- perfectly well know where to turn it in eventually.
            -- IMPORTANT: labeled as "(quest area)", NOT "(turn-in)" --
            -- this is the turn-in NPC's location being used as a rough
            -- proxy for "where this quest happens", not a claim that
            -- the quest is actually ready to hand in. Only used when we
            -- have zero real objective candidates (see above).
            if objectiveCandidateCount == 0 then
                -- Same learned-beats-static priority as the completed-quest
                -- branch above, applied to this rougher "quest area" guess too.
                if questEntry and questEntry.turnin and questEntry.turnin.mapID then
                    local turninName = questEntry.turnin.name or StaticTurninName(staticQuest)
                    consider(questEntry.turnin, questTitle .. " (quest area)", turninName, true)
                else
                    if staticQuest and staticQuest["end"] then
                        considerStatic(staticQuest["end"]["U"], "U", questTitle .. " (quest area)", true)
                        considerStatic(staticQuest["end"]["O"], "O", questTitle .. " (quest area)", true)
                    end
                end
            end
        end
        end
    end

    -- Available (not-yet-picked-up) quest givers -- only in auto-select
    -- mode, since pinning a specific quest means "only care about this
    -- one", not "also suggest new quests to grab along the way".
    --
    -- BUGFIX: this only checked pinnedQuestID, not questFilter (the
    -- route planner's per-quest scoping) -- meaning every single call
    -- from AutoQuestLearner_PlanRoute() for a SPECIFIC quest still let
    -- an unrelated available quest win the "closest" comparison if it
    -- happened to be nearer, silently returning the wrong quest's
    -- location. Confirmed real: "Tooga's Quest (available)" showed up
    -- as the route stop for 16 different, unrelated quests in a row,
    -- since it kept winning over whichever quest was actually being
    -- asked about.
    if not AutoQuestLearner.pinnedQuestID and not questFilter then
        -- Available (!) pickups in THIS zone only.
        --
        -- RULE (player request): never pull the arrow to a new pickup
        -- (especially one that would send you toward another zone) while
        -- you still have log work in the current zone — turn-ins and
        -- incomplete objectives always win. Available ! is only:
        --   • suggested when almost no in-zone log work remains, OR
        --   • allowed if you are standing right on the ! (≤2.5 map %)
        -- Zone-change / out-of-zone guidance stays on the cross-zone path
        -- below, which only runs when bestLoc is nil (nothing left here).
        if AutoQuestLearnerDB.config.allquestgivers == "1"
            and AutoQuestLearner_RefreshAvailableGiverCache then
            AutoQuestLearner_RefreshAvailableGiverCache(false)
        end

        -- HARD RULE: while ANY quest is still in the log, do not let
        -- available (!) pickups steal the arrow. Only exception: you are
        -- standing on the giver (≤2.5 map %). This stops "Jin'Zil available"
        -- mid-Barrens when turn-ins are still outstanding.
        local logCount = 0
        if AutoQuestLearner.questlog then
            for _ in pairs(AutoQuestLearner.questlog) do
                logCount = logCount + 1
            end
        end
        local logHasWork = logCount > 0
        local priorityRange = 2.5
        local maxRange
        if logHasWork then
            maxRange = priorityRange
        elseif bestDist then
            maxRange = tonumber(AutoQuestLearnerDB.config.availableQuestRadiusWhileActive) or 20
        else
            maxRange = tonumber(AutoQuestLearnerDB.config.availableQuestRadius) or 30
        end
        local maxRangeSq = maxRange * maxRange

        local nearCand, nearDistSq = nil, nil
        for _, cand in pairs(availableGiverCache) do
            local same = (cand.mapID == currentZone)
                or (tonumber(cand.mapID) and tonumber(currentZone) and tonumber(cand.mapID) == tonumber(currentZone))
                or (tostring(cand.mapID) == tostring(currentZone))
            if same and px and py and cand.x and cand.y then
                local dx, dy = cand.x - px, cand.y - py
                local distSq = dx * dx + dy * dy
                if distSq <= maxRangeSq and (not nearDistSq or distSq < nearDistSq) then
                    nearDistSq = distSq
                    nearCand = cand
                end
            end
        end

        if nearCand and nearDistSq then
            -- Never override an existing log target with available
            if not bestLoc and not bestFallbackLoc then
                currentConsiderQuestID = nearCand.questid
                bestDist = nearDistSq
                bestLoc = nearCand
                bestTitle = nearCand.title
                bestName = nearCand.name
                bestQuestID = nearCand.questid
                bestSource = "available"
            end
        end
    end

    -- If the quest's real destination is in a different zone, but this
    -- travel route has a verified CHECKPOINT CHAIN (waypoints, ordered)
    -- instead of just a single point, walk it self-correctingly: once
    -- within a checkpoint's own arrival radius, advance to the next one
    -- in the chain -- same self-correction pattern already used for
    -- learned objectives earlier in this file, just applied to a
    -- pre-authored route instead of personally-recorded spawns. This is
    -- what lets the route follow an actual road around a mountain
    -- instead of a single straight line through it, once a chain with
    -- real intermediate points exists for a given zone.
    if not bestLoc and crossZoneMapID and AutoQuestLearnerTravelRoutes then
        local route = AutoQuestLearnerTravelRoutes[crossZoneMapID]
        local chain = route and route.waypoints
        if chain and table.getn(chain) > 0 then
            local progressKey = tostring(crossZoneMapID)
            local startIndex = travelRouteProgress[progressKey] or 1
            for i = startIndex, table.getn(chain) do
                local cp = chain[i]
                if cp.mapID == currentZone then
                    bestLoc = { x = cp.x, y = cp.y, mapID = cp.mapID }
                    bestTitle = (crossZoneTitle or "") .. " (travel route)"
                    bestName = cp.label
                    if px and py then
                        local d = math.sqrt((cp.x - px) ^ 2 + (cp.y - py) ^ 2)
                        if d <= (cp.radius or 2.5) then
                            travelRouteProgress[progressKey] = i + 1
                        end
                    end
                    break
                end
            end
        end
    end

    -- PRIORITY FIX: in-zone work always beats "go to another zone".
    -- Promote soft in-zone fallbacks before any cross-zone "Not in this zone"
    -- message so the arrow keeps pointing at local work while you still have it.
    if not bestLoc and bestFallbackLoc then
        bestLoc, bestTitle, bestName = bestFallbackLoc, bestFallbackTitle, bestFallbackName
        bestQuestID = bestFallbackQuestID
        bestSource = bestFallbackSource or "guess"
    end

    -- Final safety: never leave the arrow on an "(available)" target while
    -- the quest log still has entries (turn-ins / objectives). Forces the
    -- next-best log destination or cross-zone turn-in message instead.
    if bestTitle and string.find(bestTitle, "%(available%)") and AutoQuestLearner.questlog then
        local hasLog = false
        for _ in pairs(AutoQuestLearner.questlog) do hasLog = true; break end
        if hasLog then
            bestLoc, bestDist, bestTitle, bestName, bestQuestID, bestSource = nil, nil, nil, nil, nil, nil
            if bestFallbackLoc then
                bestLoc, bestTitle, bestName = bestFallbackLoc, bestFallbackTitle, bestFallbackName
                bestQuestID = bestFallbackQuestID
                bestSource = bestFallbackSource or "guess"
            end
        end
    end

    -- Extra safety: if ANY active log quest has a map pin / learned point in
    -- the current zone, never mute the ? for an out-of-zone tracker entry.
    -- (FindClosest can miss some static links; map nodes are authoritative.)
    if not bestLoc and currentZone and AutoQuestLearnerMap and AutoQuestLearnerMap.nodes then
        local hasInZoneWork = false
        for _, data in pairs(AutoQuestLearnerMap.nodes) do
            local zoneData = data and (data[currentZone] or data[tonumber(currentZone)] or data[tostring(currentZone)])
            if zoneData then
                for _, node in pairs(zoneData) do
                    for title, entry in pairs(node) do
                        local qid = entry and entry.questid
                        if qid and AutoQuestLearner.questlog and AutoQuestLearner.questlog[qid] then
                            hasInZoneWork = true
                            break
                        end
                        if qid and AutoQuestLearner.questlog and AutoQuestLearner.questlog[tonumber(qid)] then
                            hasInZoneWork = true
                            break
                        end
                    end
                    if hasInZoneWork then break end
                end
            end
            if hasInZoneWork then break end
        end
        if hasInZoneWork then
            crossZoneMapID = nil
        end
    end

    local crossZoneInfo = nil
    -- Only show cross-zone guidance when there is truly nothing to do here
    -- and the player has not pinned an out-of-zone quest deliberately.
    if not bestLoc and crossZoneMapID then
        if AutoQuestLearner.pinnedQuestID then
            local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
                and AutoQuestLearnerData.zones["loc"][crossZoneMapID]
            crossZoneInfo = { mapID = crossZoneMapID, title = crossZoneTitle, name = crossZoneName, zoneName = zoneName }
        else
            -- Unpinned: still allow cross-zone text only if no in-zone target
            local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
                and AutoQuestLearnerData.zones["loc"][crossZoneMapID]
            crossZoneInfo = { mapID = crossZoneMapID, title = crossZoneTitle, name = crossZoneName, zoneName = zoneName }
        end
    end

    if bestLoc and AutoQuestLearner.pinnedQuestID and bestQuestID == AutoQuestLearner.pinnedQuestID then
        bestSource = "pinned"
    end

    return bestLoc, bestTitle, bestName, bestQuestID, crossZoneInfo, bestSource
end

-- Route planner ("least backtracking" quest order suggestion).
--
-- Gathers every active quest's known destination in the player's
-- CURRENT zone only (cross-zone entries are skipped -- a "least
-- backtracking" route only makes sense within one local area), reusing
-- FindClosestQuestDestination per-quest via the questFilter parameter
-- above so this can never resolve a location differently than the
-- arrow itself would for the same quest.
--
-- Ordering uses a greedy nearest-neighbor heuristic: starting from the
-- player's position, repeatedly pick whichever remaining stop is
-- closest to wherever the route currently ends, and add it next. This
-- is NOT guaranteed to be the mathematically optimal route (that's the
-- traveling salesman problem, expensive to solve exactly as stop count
-- grows) -- but nearest-neighbor is a standard, well-understood
-- heuristic that's fast, simple enough to get right without live
-- testing, and produces a genuinely reasonable route in practice at
-- the scale this ever needs to handle (a player's active quest count,
-- typically well under 20).
-- Looks up a quest's turn-in NPC location in the CURRENT zone,
-- regardless of whether the quest is actually complete yet -- unlike
-- FindClosestQuestDestination above, which only reports the turn-in
-- once a quest is done (correct for the arrow, since you can't turn in
-- an incomplete quest yet). The route planner needs this to see BOTH a
-- quest's objective AND its eventual turn-in point as two separate
-- stops, so the routing can actually discover "do these three nearby
-- objectives, then loop back for turn-ins" instead of only ever seeing
-- one location per quest and bouncing back and forth.
local function GetQuestTurnInLocation(questID)
    local currentZone = GetCurrentMap()
    if not currentZone or not AutoQuestLearner.questlog then return nil end
    local logData = AutoQuestLearner.questlog[questID]
    if not logData then return nil end
    local questTitle = logData.title or ("Quest " .. tostring(questID))
    if AutoQuestLearner_ShouldIgnoreQuest and AutoQuestLearner_ShouldIgnoreQuest(questID, questTitle) then return nil end

    local learned = GetLearnedDB()
    local questEntry = GetLearnedQuestEntry(learned, questID, questTitle)
    local staticQuest = AutoQuestLearnerData.quests["data"][questID]

    if questEntry and questEntry.turnin and questEntry.turnin.mapID == currentZone then
        return { x = questEntry.turnin.x, y = questEntry.turnin.y }, (questEntry.title or questTitle)
    end
    if staticQuest and staticQuest["end"] then
        for _, idSet in pairs({ { staticQuest["end"]["U"], "U" }, { staticQuest["end"]["O"], "O" } }) do
            local ids, idType = idSet[1], idSet[2]
            if ids then
                for _, id in pairs(ids) do
                    local data = idType == "U" and AutoQuestLearnerData.units["data"][id]
                        or idType == "O" and AutoQuestLearnerData.objects["data"][id]
                    if data and data["coords"] then
                        for _, coord in pairs(data["coords"]) do
                            if coord[3] == currentZone then
                                return { x = coord[1], y = coord[2] }, questTitle
                            end
                        end
                    end
                end
            end
        end
    end
    return nil
end

function AutoQuestLearner_PlanRoute()
    local px, py = GetPlayerPos()
    if not px then return nil end
    if not AutoQuestLearner.questlog then return nil end

    local stops = {}
    for questID, logData in pairs(AutoQuestLearner.questlog) do
        local loc, title, name = FindClosestQuestDestination(questID)
        if loc then
            table.insert(stops, { x = loc.x, y = loc.y, title = title, name = name, questID = questID })
            -- If this stop was the objective (not already a turn-in),
            -- the quest isn't complete yet -- also add its eventual
            -- turn-in point as a SEPARATE stop, if known. This is what
            -- lets the route actually cluster nearby objectives before
            -- looping back for turn-ins, instead of only ever seeing
            -- one location per quest and bouncing between them one at
            -- a time.
            if title and not string.find(title, "%(turn%-in%)") then
                local turnLoc, turnTitle = GetQuestTurnInLocation(questID)
                if turnLoc and (turnLoc.x ~= loc.x or turnLoc.y ~= loc.y) then
                    table.insert(stops, { x = turnLoc.x, y = turnLoc.y, title = (turnTitle or logData.title) .. " (turn-in)", name = nil, questID = questID })
                end
            end
        end
    end

    if table.getn(stops) == 0 then
        return {}
    end

    -- Geographic clustering: group stops by physical proximity to each
    -- other first, then order within each cluster (objectives before
    -- that cluster's turn-ins), then visit clusters nearest-first. Pure
    -- nearest-neighbor across all stops (the previous approach) could
    -- still hop between different areas of the map mid-cluster if a
    -- single point happened to be marginally closer -- this instead
    -- commits to finishing one whole area before moving to the next,
    -- which is what was actually asked for: group quests by which side
    -- of the map their turn-in NPCs are on, finish that whole area
    -- before heading to a different one.
    --
    -- CLUSTER_THRESHOLD is a judgment call, not a precisely derived
    -- value -- same 0-100 zone-percentage coordinate space used
    -- throughout this addon (see the route command's own distance
    -- output). Tuned to catch "same general area of a zone" without
    -- being so wide it merges genuinely separate areas together.
    local CLUSTER_THRESHOLD = 15
    local CLUSTER_THRESHOLD_SQ = CLUSTER_THRESHOLD * CLUSTER_THRESHOLD

    local function distSq(a, b)
        local dx, dy = a.x - b.x, a.y - b.y
        return dx * dx + dy * dy
    end

    local function nearestIndex(fromX, fromY, list)
        local bestIdx, bestDist = nil, nil
        for idx, stop in pairs(list) do
            local dx, dy = stop.x - fromX, stop.y - fromY
            local dist = dx * dx + dy * dy
            if not bestDist or dist < bestDist then
                bestDist, bestIdx = dist, idx
            end
        end
        return bestIdx, bestDist
    end

    local function removeAt(list, idx)
        local newList = {}
        for i, v in pairs(list) do
            if i ~= idx then table.insert(newList, v) end
        end
        return newList
    end

    local route = {}
    local curX, curY = px, py
    local unassigned = stops

    while table.getn(unassigned) > 0 do
        -- Seed the next cluster with whichever remaining stop is
        -- closest to wherever the route currently ends -- this is what
        -- makes clusters themselves get visited nearest-first.
        local seedIdx = nearestIndex(curX, curY, unassigned)
        local cluster = { unassigned[seedIdx] }
        unassigned = removeAt(unassigned, seedIdx)

        -- Expand the cluster: pull in any remaining stop that's within
        -- the threshold of the SEED specifically, repeating until
        -- nothing more qualifies.
        --
        -- BUGFIX: confirmed real -- this previously checked distance to
        -- ANY existing cluster member, not just the seed, which let
        -- clusters chain-grow unbounded: stop A within threshold of B,
        -- B within threshold of C, C within threshold of D -- all four
        -- would merge into one cluster even though A and D could be far
        -- apart, well past any reasonable "same area" definition. That
        -- sprawling cluster then got visited in nearest-neighbor order,
        -- which zigzags back and forth across the whole span instead of
        -- forming a sensible line -- looks like a broken, nonsensical
        -- path crossing terrain it shouldn't need to. Anchoring to the
        -- seed bounds every cluster to roughly 2x CLUSTER_THRESHOLD in
        -- diameter, no matter how many stops chain together.
        local seed = cluster[1]
        local grew = true
        while grew do
            grew = false
            local stillUnassigned = {}
            for _, stop in pairs(unassigned) do
                if distSq(stop, seed) <= CLUSTER_THRESHOLD_SQ then
                    table.insert(cluster, stop)
                    grew = true
                else
                    table.insert(stillUnassigned, stop)
                end
            end
            unassigned = stillUnassigned
        end

        -- Within this cluster: objectives first, then turn-ins for
        -- this same cluster -- both nearest-neighbor ordered from
        -- wherever the route currently is.
        local objectives, turnins = {}, {}
        for _, stop in pairs(cluster) do
            if stop.title and string.find(stop.title, "%(turn%-in%)") then
                -- Chain-aware: a turn-in that's known to unlock a
                -- specific follow-up quest gets tagged here, so it can
                -- be prioritized ahead of turn-ins with no known
                -- follow-up -- visiting it earlier in the cluster means
                -- more chance to actually pick up and start that next
                -- quest while still in the area, rather than it being
                -- the last thing done before moving on. Only covers
                -- quests this addon's bundled chain data actually has
                -- (a subset, not every real chain) -- a stop with no
                -- known follow-up just falls back to pure nearest-
                -- neighbor ordering within its own group, same as
                -- before.
                if stop.questID and AutoQuestLearnerQuestChain then
                    local nextQuestID = AutoQuestLearnerQuestChain[stop.questID]
                    if nextQuestID then
                        local nextLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][nextQuestID]
                        stop.chainNext = nextLoc and nextLoc.T or true
                    end
                end
                table.insert(turnins, stop)
            else
                table.insert(objectives, stop)
            end
        end

        for _, group in pairs({ objectives, turnins }) do
            -- Chain-continuing stops go first within this group (still
            -- nearest-neighbor ordered among themselves), everything
            -- else follows (also nearest-neighbor ordered among
            -- themselves) -- a priority tier, not a full re-sort, so
            -- geographic sanity within each tier is preserved.
            local priority, rest = {}, {}
            for _, stop in pairs(group) do
                if stop.chainNext then
                    table.insert(priority, stop)
                else
                    table.insert(rest, stop)
                end
            end
            for _, remaining in pairs({ priority, rest }) do
                while table.getn(remaining) > 0 do
                    local idx = nearestIndex(curX, curY, remaining)
                    local chosen = remaining[idx]
                    chosen.distFromPrev = math.sqrt((chosen.x - curX) ^ 2 + (chosen.y - curY) ^ 2)
                    table.insert(route, chosen)
                    curX, curY = chosen.x, chosen.y
                    remaining = removeAt(remaining, idx)
                end
            end
        end
    end

    return route
end


------------------------------------------------------------
-- Native navigation arrow
--
-- This is AutoQuestLearner's own in-world directional arrow, requiring
-- neither pfQuest nor TomTom. The rotation math is adapted directly
-- from pfQuest's route.lua (itself adapted from TomTomVanilla, per its
-- own comment) -- this exact formula is intricate and precision-
-- sensitive (it mixes radians and a degree-scale value by design, in a
-- way that's only internally consistent as a whole pipeline), so it's
-- reproduced verbatim rather than re-derived, using our own bundled
-- arrow.tga (confirmed byte-identical to pfQuest's own copy, so the
-- same texture-atlas coordinate math applies correctly).
--
-- pfQuest's own "Distance" readout is not real yards either -- it's
-- the same 0-100 percentage-space Euclidean distance used here, just
-- without a unit suffix to avoid implying a precision it doesn't have.
------------------------------------------------------------
-- math.mod does not exist on this client -- matches pfQuest's own
-- modulo() helper exactly.
local function mod(val, by)
    return val - math.floor(val / by) * by
end

AutoQuestLearner.arrow = CreateFrame("Frame", "AutoQuestLearnerArrow", UIParent)
AutoQuestLearner.arrow:SetFrameStrata("HIGH")
AutoQuestLearner.arrow:SetPoint("CENTER", 0, -100)
AutoQuestLearner.arrow:SetWidth(48)
AutoQuestLearner.arrow:SetHeight(36)
AutoQuestLearner.arrow:SetClampedToScreen(true)
AutoQuestLearner.arrow:SetMovable(true)
AutoQuestLearner.arrow:EnableMouse(true)
AutoQuestLearner.arrow:RegisterForDrag("LeftButton")
AutoQuestLearner.arrow:SetScript("OnDragStart", function()
    if IsShiftKeyDown() then
        this:StartMoving()
    end
end)
AutoQuestLearner.arrow:SetScript("OnDragStop", function()
    this:StopMovingOrSizing()
end)
AutoQuestLearner.arrow:SetAlpha(0)

AutoQuestLearner.arrow.model = AutoQuestLearner.arrow:CreateTexture("AutoQuestLearnerArrowModel", "MEDIUM")
AutoQuestLearner.arrow.model:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\arrow")
AutoQuestLearner.arrow.model:SetTexCoord(0, 0, 0.109375, 0.08203125)
AutoQuestLearner.arrow.model:SetAllPoints()
AutoQuestLearner.arrow.model:SetVertexColor(0, 1, 0)

-- Quest-marker icon (the "?" mark), matching pfQuest's layout of a
-- small icon sitting just under the arrow model itself.
AutoQuestLearner.arrow.icon = AutoQuestLearner.arrow:CreateTexture("AutoQuestLearnerArrowIcon", "OVERLAY")
AutoQuestLearner.arrow.icon:SetWidth(20)
AutoQuestLearner.arrow.icon:SetHeight(20)
AutoQuestLearner.arrow.icon:SetPoint("BOTTOM", AutoQuestLearner.arrow.model, "BOTTOM", 0, -2)

AutoQuestLearner.arrow.title = AutoQuestLearner.arrow:CreateFontString("AutoQuestLearnerArrowText", "HIGH", "GameFontNormal")
AutoQuestLearner.arrow.title:SetPoint("TOP", AutoQuestLearner.arrow.model, "BOTTOM", 0, -10)
AutoQuestLearner.arrow.title:SetTextColor(1, .8, 0)
AutoQuestLearner.arrow.title:SetJustifyH("CENTER")

AutoQuestLearner.arrow.description = AutoQuestLearner.arrow:CreateFontString("AutoQuestLearnerArrowDescription", "HIGH", "GameFontHighlightSmall")
AutoQuestLearner.arrow.description:SetPoint("TOP", AutoQuestLearner.arrow.title, "BOTTOM", 0, -2)
AutoQuestLearner.arrow.description:SetTextColor(1, 1, 1)
AutoQuestLearner.arrow.description:SetJustifyH("CENTER")
AutoQuestLearner.arrow.description:SetWidth(220)

AutoQuestLearner.arrow.distance = AutoQuestLearner.arrow:CreateFontString("AutoQuestLearnerArrowDistance", "HIGH", "GameFontHighlightSmall")
AutoQuestLearner.arrow.distance:SetPoint("TOP", AutoQuestLearner.arrow.description, "BOTTOM", 0, -2)
AutoQuestLearner.arrow.distance:SetTextColor(.7, .7, .7)
AutoQuestLearner.arrow.distance:SetJustifyH("CENTER")

local arrowInvalidSince = nil
local arrowLastTitle = nil
local standingOnItTargetKey = nil
local standingOnItSince = nil

-- Given a questID and a target pin, finds which learned objective
-- (objIndex) that pin's coordinates belong to, if any -- so a floor
-- hint can be applied to every OTHER known spawn point recorded for
-- that same objective, not just the one exact pin the player happened
-- to be standing on. Confirmed real need: a single objective's kill
-- target can easily have several recorded spawns clustered together
-- underground (a cave full of the same mob), each a slightly different
-- x/y -- while a DIFFERENT objective on the same quest could be an
-- entirely separate cluster on the main floor. Grouping by objIndex
-- (rather than by quest, or by raw proximity) is what keeps those two
-- independent instead of over-applying one hint to both.
local function FindObjIndexForLoc(questID, loc)
    if not questID or not loc then return nil end
    local learned = GetLearnedDB()
    local objectives = learned.objectives and learned.objectives[questID]
    if not objectives then return nil end
    for objIndex, obj in pairs(objectives) do
        for _, spawn in pairs(obj.spawns or {}) do
            if spawn.mapID == loc.mapID then
                local dx, dy = spawn.x - loc.x, spawn.y - loc.y
                if (dx * dx + dy * dy) < 1 then -- intentionally tighter than the ~2% spawn-dedup tolerance -- this is matching an exact known point, not deduping a new recording
                    return objIndex
                end
            end
        end
    end
    return nil
end

local arrowCachedLoc, arrowCachedTitle, arrowCachedName, arrowCachedQuestID, arrowCachedCrossZone, arrowCachedSource = nil, nil, nil, nil, nil, nil
AutoQuestLearner_GetTrackedQuestID = function() return arrowCachedQuestID end

-- This runs independently of whether the arrow itself is shown, so the
-- route line (which reuses this same cache) keeps working even if only
-- the arrow specifically gets disabled.
------------------------------------------------------------
-- Self-calibrating minimap zone dimensions
--
-- Some starting-zone sub-areas (Shadowglen, Coldridge Valley, Camp
-- Narache, Red Cloud Mesa, Deathknell, Valley of Trials) are treated
-- as their own separately-zoomable maps on this client -- a real
-- Ascension-specific client customization (verified: standard WotLK
-- 3.3.5 never had this; it was added to the base game much later, in
-- patch 5.0.4). Because of that, no external community database
-- (pfQuest, Astrolabe, Cartographer, Gatherer, etc.) has ever needed
-- this exact dimension, since it doesn't exist anywhere outside
-- Ascension's own client files -- confirmed via direct research before
-- building this. Rather than use the much larger PARENT zone's
-- dimension as a stand-in (which was producing minimap dots that
-- drifted further wrong the more you moved, since the scale itself was
-- wrong), this measures the real value directly from actual play,
-- matching the same "learn from personal observation" approach the
-- rest of this addon already uses everywhere else.
--
-- How it works: GetUnitSpeed("player") gives real movement speed in
-- yards/second -- a genuine Blizzard API value, not an estimate. By
-- comparing how far you actually moved (speed * time) against how much
-- your percent-position changed over that same short window, one axis
-- at a time (only counting samples where movement was clearly mostly
-- horizontal or mostly vertical, to avoid diagonal-movement math
-- getting the two axes tangled), it collects real samples over time as
-- you naturally walk around, and once there's enough of them, saves a
-- permanent, real value -- not a synthetic estimate.
------------------------------------------------------------
local STARTING_ZONE_TARGETS = {
    [188] = true, -- Shadowglen
    [132] = true, -- Coldridge Valley
    [221] = true, -- Camp Narache
    [220] = true, -- Red Cloud Mesa
    [154] = true, -- Deathknell
    [363] = true, -- Valley of Trials
}
local MIN_CALIBRATION_SAMPLES = 15
-- Sanity-check phase for zones NOT already known-bad: a much smaller
-- sample count just to compare against the static value and decide
-- whether full calibration is actually warranted, rather than
-- re-measuring every zone in full "just in case".
local SANITY_CHECK_SAMPLES = 5
-- How far the sanity-check estimate has to diverge from the static
-- value before treating it as a real problem worth fully calibrating,
-- rather than ordinary measurement noise from a short sample.
local DISCREPANCY_RATIO = 1.5

local calibSamples = {} -- [rawZoneID] = { widths = {}, heights = {} }
local calibLastX, calibLastY, calibLastTime, calibLastZone = nil, nil, nil, nil

local function Median(list)
    if not list or table.getn(list) == 0 then return nil end
    local sorted = {}
    for i, v in ipairs(list) do sorted[i] = v end
    table.sort(sorted)
    local n = table.getn(sorted)
    local mid = math.ceil(n / 2)
    return sorted[mid]
end

function AutoQuestLearner_UpdateMinimapCalibration()
    if not AutoQuestLearnerMap or not GetUnitSpeed then return end
    AutoQuestLearnerDB.calibratedMinimap = AutoQuestLearnerDB.calibratedMinimap or {}
    -- Zones that passed the sanity check (observed scale roughly
    -- matches static data) -- skipped on future visits so this doesn't
    -- re-sample every single zone every session forever.
    AutoQuestLearnerDB.calibrationVerified = AutoQuestLearnerDB.calibrationVerified or {}
    -- Zones NOT in the known-bad starting-zone list, but where the
    -- sanity check found a real discrepancy and promoted it to full
    -- calibration -- generalizes the whole system beyond the 6 zones
    -- we already knew about, catching problems we don't yet know
    -- exist instead of only fixing known ones.
    AutoQuestLearnerDB.autoDetectedBadZones = AutoQuestLearnerDB.autoDetectedBadZones or {}

    local rawZone = AutoQuestLearnerMap:GetMapID(nil, nil, true)
    if AutoQuestLearnerDB.calibratedMinimap[rawZone] or AutoQuestLearnerDB.calibrationVerified[rawZone] then
        -- Fully calibrated already, or already sanity-checked as fine
        -- -- reset tracking state so a stale reading doesn't leak into
        -- a later zone's samples.
        calibLastX, calibLastY, calibLastTime, calibLastZone = nil, nil, nil, nil
        return
    end

    local isTargetZone = STARTING_ZONE_TARGETS[rawZone] or AutoQuestLearnerDB.autoDetectedBadZones[rawZone]
    local targetSampleCount = isTargetZone and MIN_CALIBRATION_SAMPLES or SANITY_CHECK_SAMPLES

    local x, y = GetPlayerMapPosition("player")
    if not x or (x == 0 and y == 0) then return end
    x, y = x * 100, y * 100
    local now = GetTime()

    if calibLastZone == rawZone and calibLastX and calibLastTime then
        local dt = now - calibLastTime
        local speed = GetUnitSpeed("player")
        -- Guard against noise: too short an interval is imprecise,
        -- too long risks non-straight-line movement (turning corners)
        -- corrupting the sample, and zero speed means not moving at
        -- all (nothing to measure).
        if speed and speed > 0 and dt >= 0.3 and dt <= 2.0 then
            local dx = x - calibLastX
            local dy = y - calibLastY
            local totalYards = speed * dt
            local absDx, absDy = math.abs(dx), math.abs(dy)

            calibSamples[rawZone] = calibSamples[rawZone] or { widths = {}, heights = {} }
            local s = calibSamples[rawZone]

            -- Only use samples that are clearly mostly-horizontal or
            -- mostly-vertical -- a diagonal movement can't cleanly
            -- isolate which axis it's telling you about.
            if absDx > 0.1 and absDx > 3 * absDy then
                table.insert(s.widths, totalYards * 100 / absDx)
            elseif absDy > 0.1 and absDy > 3 * absDx then
                table.insert(s.heights, totalYards * 100 / absDy)
            end

            if table.getn(s.widths) >= targetSampleCount and table.getn(s.heights) >= targetSampleCount then
                local width = Median(s.widths)
                local height = Median(s.heights)

                if isTargetZone then
                    -- Already know (or already found) this zone needs
                    -- fixing -- finish calibrating outright.
                    AutoQuestLearnerDB.calibratedMinimap[rawZone] = { width, height }
                    calibSamples[rawZone] = nil
                    local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"] and AutoQuestLearnerData.zones["loc"][rawZone]
                    print(string.format("|cff00ff00AutoQuestLearner:|r Finished calibrating minimap scale for %s (%.0f x %.0f yards) -- minimap positioning should now be accurate here.",
                        tostring(zoneName or rawZone), width, height))
                else
                    -- Sanity-check phase: compare the quick estimate
                    -- against the static bundled dimension.
                    local staticDim = AutoQuestLearnerDB.minimap and AutoQuestLearnerDB.minimap[rawZone]
                    local staticWidth = staticDim and staticDim[1]
                    local staticHeight = staticDim and staticDim[2]
                    local needsFullCalibration = false

                    if not staticWidth or not staticHeight or staticWidth == 0 or staticHeight == 0 then
                        needsFullCalibration = true -- no static data at all -- worth getting a real value
                    else
                        local widthRatio = width / staticWidth
                        local heightRatio = height / staticHeight
                        if widthRatio > DISCREPANCY_RATIO or widthRatio < 1 / DISCREPANCY_RATIO
                            or heightRatio > DISCREPANCY_RATIO or heightRatio < 1 / DISCREPANCY_RATIO then
                            needsFullCalibration = true
                        end
                    end

                    if needsFullCalibration then
                        AutoQuestLearnerDB.autoDetectedBadZones[rawZone] = true
                        local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"] and AutoQuestLearnerData.zones["loc"][rawZone]
                        print(string.format("|cff00ff00AutoQuestLearner:|r Detected a possibly-wrong minimap scale in %s -- measuring the real value now (keep playing normally).",
                            tostring(zoneName or rawZone)))
                        -- Deliberately don't clear samples or return
                        -- here -- this zone now needs the full 15-per-
                        -- axis threshold, not just the 5-sample sanity
                        -- check, so it keeps accumulating from here.
                    else
                        AutoQuestLearnerDB.calibrationVerified[rawZone] = true
                        calibSamples[rawZone] = nil
                    end
                end
            end
        end
    end

    calibLastX, calibLastY, calibLastTime, calibLastZone = x, y, now, rawZone
end

local calibrationFrame = CreateFrame("Frame")
local calibrationElapsed = 0
local calibrationErrorShown = false
calibrationFrame:SetScript("OnUpdate", function(self, elapsed)
    calibrationElapsed = calibrationElapsed + (elapsed or 0)
    if calibrationElapsed < 1.5 then return end
    calibrationElapsed = 0
    local ok, err = pcall(AutoQuestLearner_UpdateMinimapCalibration)
    if not ok and not calibrationErrorShown then
        calibrationErrorShown = true
        print("|cffff0000AutoQuestLearner:|r Minimap calibration error: " .. tostring(err))
    end
end)


local destinationSearchErrorShown = false
-- Was 0.5s → 0.85s → 1.35s. 2.0s further cuts hitching when the arrow
-- retargets the next spawn cluster after kills (FindClosest is expensive).
-- FindClosestQuestDestination is heavy (full log + static tables).
local ARROW_DEST_INTERVAL = 3.0
local destinationSearchFrame = CreateFrame("Frame")
destinationSearchFrame:SetScript("OnUpdate", function(self, elapsed)
    arrowSearchElapsed = arrowSearchElapsed + (elapsed or 0)
    -- Force-learn: pick up new locked coord on the next interval tick.
    if AutoQuestLearner_ForceArrowRefresh then
        AutoQuestLearner_ForceArrowRefresh = nil
        arrowSearchElapsed = ARROW_DEST_INTERVAL
    end
    if arrowSearchElapsed < ARROW_DEST_INTERVAL then return end
    arrowSearchElapsed = 0

    if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then return end

    -- Skip expensive search when standing still and already have a target
    local px, py = GetPlayerMapPosition("player")
    if px and arrowCachedLoc and not AutoQuestLearner_ForceArrowRefresh then
        if AutoQuestLearner._arrowLastPX and math.abs(px - AutoQuestLearner._arrowLastPX) < 0.0015
            and math.abs(py - (AutoQuestLearner._arrowLastPY or 0)) < 0.0015 then
            return
        end
    end
    AutoQuestLearner._arrowLastPX, AutoQuestLearner._arrowLastPY = px, py

    local perfStart
    if AutoQuestLearner_PerfDebug and AutoQuestLearner_PerfDebug.active then
        local ok2, t = pcall(debugprofilestop)
        if ok2 then perfStart = t end
    end
    local ok, a, b, c, d, e, f = pcall(FindClosestQuestDestination)
    if perfStart then
        local elapsed = debugprofilestop() - perfStart
        AutoQuestLearner_PerfDebug.totals["FindClosestQuestDestination"] = (AutoQuestLearner_PerfDebug.totals["FindClosestQuestDestination"] or 0) + elapsed
        AutoQuestLearner_PerfDebug.calls["FindClosestQuestDestination"] = (AutoQuestLearner_PerfDebug.calls["FindClosestQuestDestination"] or 0) + 1
    end
    if ok then
        local questChanged = (d ~= arrowCachedQuestID)
        arrowCachedLoc, arrowCachedTitle, arrowCachedName, arrowCachedQuestID, arrowCachedCrossZone, arrowCachedSource = a, b, c, d, e, f
        -- Arrow switched quest: only dirty the minimap this frame.
        -- Full UpdateNodes is 1s-throttled; running it sync here caused
        -- the "screen freezes when arrow changes target" hitch.
        if questChanged and AutoQuestLearnerMap then
            AutoQuestLearnerMap._mmForceRebuild = true
            if AutoQuestLearnerMap.UpdateNodes then
                AutoQuestLearnerMap:UpdateNodes() -- coalesced, not sync-heavy
            end
        end
    elseif not destinationSearchErrorShown then
        destinationSearchErrorShown = true
        print("|cffff0000AutoQuestLearner:|r Navigation arrow error (this is what's breaking it): " .. tostring(a))
    end
end)

-- BUGFIX: confirmed real -- "Scouring the Desert" (Deliver Silithyst)
-- sent the arrow to a PvE-flagged player's Silithyst node, which
-- flatly refuses to be collected without being PvP flagged, on a
-- server where PvP flagging is opt-in. No bundled database tracks
-- this (it's not a quest prerequisite in the normal sense -- it's an
-- interaction-time restriction on the gathering node/object itself),
-- so the game's own error message when it happens is the only signal
-- available. arrowCachedQuestID (declared above) is whichever quest
-- the arrow was pointed at right when this fired -- reliable here
-- since the message only appears from actually trying to interact
-- with what the arrow just sent the player to.
local pvpFlagMessageFrame = CreateFrame("Frame")
pvpFlagMessageFrame:RegisterEvent("CHAT_MSG_SYSTEM")
pvpFlagMessageFrame:SetScript("OnEvent", function(self, event, msg)
    if not msg or not string.find(string.lower(msg), "must be pvp flagged") then return end
    local questID = arrowCachedQuestID
    if not questID then return end
    AutoQuestLearnerDB.pvpRequired = AutoQuestLearnerDB.pvpRequired or {}
    if not AutoQuestLearnerDB.pvpRequired[questID] then
        AutoQuestLearnerDB.pvpRequired[questID] = true
        print("|cffff8800AutoQuestLearner:|r Noted -- this objective needs you to be PvP flagged to actually collect/interact with it. Won't send the arrow there again unless you already are flagged.")
    end
end)

-- Reputation-gate self-learning -- same underlying problem and same
-- fix as the PvP-flag detection above: no bundled database (including
-- the server's own quest DB, confirmed earlier with "Feathers for
-- Grazle") tracks reputation requirements at all, so the game's own
-- error message when an interaction gets refused for insufficient
-- reputation is the only signal available. Broader pattern match than
-- the PvP case (that one matches a single known exact phrase) since
-- reputation-gate wording varies more across different content --
-- matches on "reputation" appearing alongside a negation/requirement
-- word, which real unrelated system messages are very unlikely to
-- combine incidentally.
--
-- Deliberately does NOT auto-expire the way PvP flagging can (that's
-- an instant toggle; reputation only changes by actually playing) --
-- suppressed until manually cleared via /aql repRequired clear, once
-- the player knows they've since earned enough standing.
local repGateMessageFrame = CreateFrame("Frame")
repGateMessageFrame:RegisterEvent("CHAT_MSG_SYSTEM")
repGateMessageFrame:SetScript("OnEvent", function(self, event, msg)
    if not msg then return end
    local lower = string.lower(msg)
    if not string.find(lower, "reputation") then return end
    if not (string.find(lower, "not") or string.find(lower, "need") or string.find(lower, "must") or string.find(lower, "require")) then return end

    local questID = arrowCachedQuestID
    if not questID then return end
    AutoQuestLearnerDB.repRequired = AutoQuestLearnerDB.repRequired or {}
    if not AutoQuestLearnerDB.repRequired[questID] then
        AutoQuestLearnerDB.repRequired[questID] = true
        print("|cffff8800AutoQuestLearner:|r Noted -- this objective needs more reputation than you currently have. Won't send the arrow there again until you run /aql repRequired clear " .. questID .. " (once you've earned enough standing).")
    end
end)

-- Live "just killed it" tracking: when a kill is credited to the
-- player/party, and the dead unit's NPC ID matches a currently-known
-- objective spawn cluster (the same highlightKey already used for
-- coloring), hide the ONE closest matching point on the map/minimap
-- for a while, rather than leaving a static cluster that doesn't
-- reflect what's actually alive right now. DEFAULT_KILL_HIDE_SECONDS
-- (declared earlier, alongside lastKillNPCID/lastKillTime) is a
-- generic trash-mob estimate, not a guarantee -- no per-mob respawn
-- timer data is available from any bundled source on this server, so
-- it'll reappear on this timer regardless of the mob's real respawn,
-- which for most common trash is in the right neighborhood but won't
-- be exact for everything.

local killTrackFrame = CreateFrame("Frame")
killTrackFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
killTrackFrame:SetScript("OnEvent", function(self, event, ...)
    -- BUGFIX: confirmed real via /aql killdebug -- fixed-position
    -- argument destructuring (timestamp, subevent, hideCaster,
    -- sourceGUID, sourceName, sourceFlags, destGUID, destName,
    -- destFlags) put a plain unit NAME ("Mo'grosh Brute", even the
    -- player's own name "Redirage") where a GUID was expected, meaning
    -- this server's combat log argument order doesn't line up with
    -- the standard WotLK layout that assumed. Rather than guess at
    -- the right fixed position, scan every argument for anything
    -- GUID-shaped (WoW GUIDs are always "0x" + hex digits) -- immune
    -- to whatever the real positional layout turns out to be. A death
    -- event has exactly two GUIDs in it (source, dest); the dest one
    -- (the unit that died) is what we want.
    local subevent = select(2, ...)
    if subevent ~= "PARTY_KILL" and subevent ~= "UNIT_DIED" then return end

    -- Cheap GUID scan without allocating a table every death
    local n = select("#", ...)
    local destGUID, firstGUID = nil, nil
    for i = 1, n do
        local v = select(i, ...)
        if type(v) == "string" and string.find(v, "^0x%x+$") then
            if not firstGUID then
                firstGUID = v
            else
                destGUID = v
                break
            end
        end
    end
    destGUID = destGUID or firstGUID

    if not destGUID then
        if AutoQuestLearner_KillDebug then
            local dump = {}
            for i = 1, n do table.insert(dump, tostring(select(i, ...))) end
            print("|cffff8800AutoQuestLearner:|r [kill debug] " .. subevent .. " fired but no GUID-shaped argument found. Raw args: " .. table.concat(dump, " | "))
        end
        return
    end

    local npcID = tonumber(string.sub(destGUID, 9, 12), 16)
    if not npcID then
        if AutoQuestLearner_KillDebug then
            print("|cffff8800AutoQuestLearner:|r [kill debug] " .. subevent .. " fired but couldn't parse an NPC ID from destGUID: " .. tostring(destGUID))
        end
        return
    end

    if AutoQuestLearner_KillDebug then
        print(string.format("|cff00ff00AutoQuestLearner:|r [kill debug] %s: killed NPC #%d (destGUID=%s)",
            subevent, npcID, destGUID))
    end

    -- Recorded regardless of whether HideNearestNode finds a match
    -- below -- RecordObjectiveProgress (earlier in this file) reads
    -- this to tag newly-learned spawns with the NPC that likely caused
    -- them, which is useful even the very first time a given mob is
    -- ever seen (before any node exists to hide).
    lastKillNPCID = npcID
    lastKillTime = GetTime()

    if not AutoQuestLearnerMap or not AutoQuestLearnerMap.HideNearestNode then return end
    local x, y = GetPlayerPos()
    if not x then return end
    local mapID = GetCurrentMap()

    if AutoQuestLearnerDB.config.hideKilledNodes == "1" then
        AutoQuestLearnerMap:HideNearestNode(mapID, x, y, tostring(npcID), DEFAULT_KILL_HIDE_SECONDS)
    end

    -- Force the arrow to recompute soon, but not every frame — full
    -- FindClosest after every kill was a major FPS hitch source.
    arrowSearchElapsed = 1.5
end)

-- Checks for a known flight connection between two zones, using the
-- bundled InFlight route graph and the (deliberately partial) flight
-- point -> zone mapping. Only covers the ~18 flight points that could
-- be safely cross-referenced -- see bundled-db/flightzones.lua's own
-- notes for why the rest were excluded rather than guessed at. Returns
-- nil whenever it can't find a *verified* connection, rather than a
-- best-effort guess.
local function FindFlightSuggestion(fromZoneID, toZoneID)
    if not AutoQuestLearnerFlightZones or not AutoQuestLearnerFlightGraph then return nil end
    if not fromZoneID or not toZoneID then return nil end
    local faction = UnitFactionGroup and UnitFactionGroup("player")
    if not faction then return nil end

    local fromPoints, toPoints = {}, {}
    for name, zid in pairs(AutoQuestLearnerFlightZones) do
        if zid == fromZoneID then table.insert(fromPoints, name) end
        if zid == toZoneID then table.insert(toPoints, name) end
    end
    if table.getn(fromPoints) == 0 or table.getn(toPoints) == 0 then return nil end

    local bestOrigin, bestDest, bestTime = nil, nil, nil
    for _, origin in pairs(fromPoints) do
        local edges = AutoQuestLearnerFlightGraph[faction .. "|" .. origin]
        if edges then
            for _, dest in pairs(toPoints) do
                local flightTime = edges[dest]
                if flightTime and (not bestTime or flightTime < bestTime) then
                    bestTime = flightTime
                    bestOrigin = origin
                    bestDest = dest
                end
            end
        end
    end
    return bestOrigin, bestDest
end

local function UpdateArrowFrame()
    if AutoQuestLearnerDB.config.navArrow == "0" then
        AutoQuestLearner.arrow:SetAlpha(0)
        return
    end

    if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then
        -- Nothing this addon suggests is actionable while dead/a
        -- ghost -- the arrow would otherwise just keep pointing at
        -- whatever quest objective was active before dying, which is
        -- both useless and actively confusing at exactly the moment
        -- the player is disoriented and needs clear guidance back to
        -- their corpse instead. WoW's own built-in corpse-recovery UI
        -- already handles that guidance, so this doesn't try to
        -- duplicate it -- just steps out of the way until the player
        -- is alive again, which happens automatically since this
        -- function re-runs every frame regardless.
        arrowInvalidSince = nil
        AutoQuestLearner.arrow:SetAlpha(1)
        if AutoQuestLearner.arrow.model then
            AutoQuestLearner.arrow.model:Hide()
        end
        local displayKey = "dead-or-ghost"
        if displayKey ~= arrowLastTitle then
            arrowLastTitle = displayKey
            AutoQuestLearner.arrow.title:SetText("|cff888888Find your corpse first|r")
        end
        return
    end

    local loc, title, npcName, questID, crossZone, arrowSource = arrowCachedLoc, arrowCachedTitle, arrowCachedName, arrowCachedQuestID, arrowCachedCrossZone, arrowCachedSource
    local function SourceTag()
        local s = arrowSource or "static"
        if s == "pinned" then return " |cff00ccff[Pinned]|r" end
        if s == "locked" then return " |cff00ff00[Locked learn]|r" end
        if s == "learned" then return " |cff88ff88[Learned]|r" end
        if s == "static" then return " |cffaaaaaa[Static DB]|r" end
        if s == "route" then return " |cff88ccff[Travel route]|r" end
        if s == "available" then return " |cffffff00[Available]|r" end
        if s == "guess" then return " |cffffaa00[Guess]|r" end
        return " |cff888888[" .. tostring(s) .. "]|r"
    end

    if not loc then
        if crossZone then
            -- Nothing known in this zone, but something IS known in a
            -- different one -- show that instead of a flat "no location
            -- known". Can't compute a meaningful rotation across zones
            -- (there's no shared coordinate space), so the directional
            -- arrow graphic itself is hidden while the text panel stays
            -- up with the actual useful information: which zone to go
            -- to. This is what tells you "the quest isn't here, it's in
            -- Ashenvale" instead of silently going blank.
            arrowInvalidSince = nil
            AutoQuestLearner.arrow:SetAlpha(1)
            if AutoQuestLearner.arrow.model then
                AutoQuestLearner.arrow.model:Hide()
            end
            local zoneName = crossZone.zoneName or "another zone"
            local displayKey = "crosszone|" .. tostring(crossZone.mapID) .. "|" .. tostring(crossZone.title) .. "|" .. tostring(questID)
            if displayKey ~= arrowLastTitle then
                arrowLastTitle = displayKey
                local prefix = AutoQuestLearner.pinnedQuestID and "|cff00ccff[Pinned]|r " or ""
                local idSuffix = tonumber(questID) and (" |cff888888<" .. questID .. ">|r") or ""
                AutoQuestLearner.arrow.title:SetText(prefix .. (crossZone.title or "") .. idSuffix)
                AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
                AutoQuestLearner.arrow.icon:SetVertexColor(.6, .8, 1)

                local flightFrom, flightTo = FindFlightSuggestion(currentZone, crossZone.mapID)
                local travelRoute = AutoQuestLearnerTravelRoutes and AutoQuestLearnerTravelRoutes[crossZone.mapID]
                local travelDirections = travelRoute and travelRoute.text
                local locationPhrase = crossZone.name and (crossZone.name .. " is in " .. zoneName)
                    or ("known to be in " .. zoneName)
                if flightFrom and flightTo then
                    AutoQuestLearner.arrow.description:SetText(
                        "Not in this zone -- " .. locationPhrase ..
                        ". Take the flight from " .. flightFrom .. " to " .. flightTo .. ".")
                elseif travelDirections then
                    AutoQuestLearner.arrow.description:SetText(
                        "Not in this zone -- " .. locationPhrase .. ". " .. travelDirections)
                else
                    AutoQuestLearner.arrow.description:SetText(
                        "Not in this zone -- " .. locationPhrase .. ". Fly or travel there.")
                end
                AutoQuestLearner.arrow.distance:SetText("")
            end
            return
        end

        if AutoQuestLearner.arrow.model then
            AutoQuestLearner.arrow.model:Show()
        end

        -- FEATURE (per user request): if this is one of the quests
        -- known to reference an NPC/object with zero coordinate data
        -- anywhere in this addon (see
        -- bundled-db/ascension/known-coordinate-gaps.lua's own comment
        -- for why that list deliberately isn't populated with a
        -- guessed location), say so plainly instead of just silently
        -- fading the arrow away with no explanation. Finding it in
        -- game still teaches RecordLocation()/
        -- AutoQuestLearner_RecordObjectiveProgress() its real,
        -- confirmed Ascension position automatically, same as
        -- anything else this addon learns -- this message doesn't
        -- change that process, it only adds awareness while the gap
        -- still exists, so it's clear WHY nothing is showing instead
        -- of it looking like the addon is just broken.
        local numericQuestID = tonumber(questID)
        if numericQuestID and AutoQuestLearnerKnownGaps and AutoQuestLearnerKnownGaps.questIDs[numericQuestID] then
            arrowInvalidSince = nil
            AutoQuestLearner.arrow:SetAlpha(1)
            if AutoQuestLearner.arrow.model then
                AutoQuestLearner.arrow.model:Hide()
            end
            local displayKey = "knowngap|" .. tostring(questID)
            if displayKey ~= arrowLastTitle then
                arrowLastTitle = displayKey
                local prefix = AutoQuestLearner.pinnedQuestID and "|cff00ccff[Pinned]|r " or ""
                local idSuffix = " |cff888888<" .. questID .. ">|r"
                AutoQuestLearner.arrow.title:SetText(prefix .. (title or "") .. idSuffix)
                AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
                AutoQuestLearner.arrow.icon:SetVertexColor(1, .82, 0)
                AutoQuestLearner.arrow.description:SetText(
                    "Location not in our database yet -- you may be one of the first to find this on Ascension. " ..
                    "Finding it will automatically teach the addon (and every other player) where it is.")
                AutoQuestLearner.arrow.distance:SetText("")
            end
            return
        end

        if arrowInvalidSince and arrowInvalidSince < GetTime() then
            AutoQuestLearner.arrow:SetAlpha(0)
        elseif not arrowInvalidSince then
            arrowInvalidSince = GetTime() + 1
        end
        return
    end
    arrowInvalidSince = nil
    if AutoQuestLearner.arrow.model then
        AutoQuestLearner.arrow.model:Show()
    end
    AutoQuestLearner.arrow:SetAlpha(1)

    local xplayer, yplayer = GetPlayerMapPosition("player")
    if not xplayer or (xplayer == 0 and yplayer == 0) then
        AutoQuestLearner.arrow:SetAlpha(0)
        return
    end
    local zplayer = nil
    if UnitPosition then
        local ok, _, _, worldZ = pcall(UnitPosition, "player")
        if ok then zplayer = worldZ end
    end

    -- Rotation math verbatim from pfQuest's route.lua (itself adapted
    -- from TomTomVanilla). xDelta gets a 1.5x multiplier to correct for
    -- the world map's aspect ratio; the mixed radian/degree-scale
    -- handling below is intentional and self-consistent as a whole,
    -- even though individual steps look mismatched in isolation.
    -- RESTORED from known-good build (user confirmed: does not spin).
    -- Do not "simplify" this — pure-radian rewrites caused continuous
    -- 360 spins on Ascension 3.3.5a.
    local xDelta = (loc.x - xplayer * 100) * 1.5
    local yDelta = (loc.y - yplayer * 100)
    local dir = atan2(xDelta, -(yDelta))
    dir = dir > 0 and (math.pi * 2) - dir or -dir
    if dir < 0 then dir = dir + 360 end
    local angle = math.rad(dir)

    local player = GetPlayerFacing() or 0
    angle = angle - player

    local cell = mod(floor(angle / (math.pi * 2) * 108 + 0.5), 108)
    local column = mod(cell, 9)
    local row = floor(cell / 9)
    local xstart = (column * 56) / 512
    local ystart = (row * 42) / 512
    local xend = ((column + 1) * 56) / 512
    local yend = ((row + 1) * 42) / 512

    AutoQuestLearner.arrow.model:SetTexCoord(xstart, xend, ystart, yend)

    local distance = floor(math.sqrt((loc.x - xplayer * 100) ^ 2 + (loc.y - yplayer * 100) ^ 2) * 10) / 10
    local standingOnIt = distance < 0.3

    -- This client's position API is 2D-only by default
    -- (GetPlayerMapPosition gives X/Y as a percent of the zone, no
    -- altitude), which is why a quest giver on the 2nd floor of a
    -- building sits at essentially the SAME coordinate as an NPC
    -- directly below on the ground floor with no way to tell them
    -- apart. UnitPosition would normally give real height too, but
    -- confirmed via /aql arrow: this server doesn't expose it at all
    -- (likely stripped server-side as an anti-cheat measure), so that
    -- avenue is a dead end here specifically -- the code below stays
    -- in place and would activate automatically if that ever changes,
    -- but for now falls straight through to two things that DON'T
    -- need height data:
    --   1. A manual hint (/aql floor up|down), recorded once by the
    --      player after actually finding the real NPC -- self-sourced
    --      ground truth beats a guess, and this doesn't fade the way
    --      memory does.
    --   2. If a spot keeps triggering "stood here too long" across
    --      multiple separate visits without ever getting a manual
    --      hint, that repetition IS itself a meaningful signal (a
    --      one-off could be lag or a NPC that walked off; a recurring
    --      pattern at the same coordinate means something's actually
    --      ambiguous there) -- nudge toward setting one instead of
    --      silently repeating the same unhelpful guess forever.
    if standingOnIt then
        local targetKey = tostring(loc.x) .. "," .. tostring(loc.y) .. "," .. tostring(loc.mapID)
        if standingOnItTargetKey ~= targetKey then
            standingOnItTargetKey = targetKey
            standingOnItSince = GetTime()
        end
    else
        standingOnItTargetKey = nil
        standingOnItSince = nil
    end
    local standingTooLong = standingOnIt and standingOnItSince and (GetTime() - standingOnItSince) > 8
    local currentTargetKey = standingOnIt and (tostring(loc.x) .. "," .. tostring(loc.y) .. "," .. tostring(loc.mapID)) or nil
    local currentObjIndex = standingOnIt and questID and FindObjIndexForLoc(questID, loc) or nil
    local currentGroupKey = currentObjIndex and (tostring(questID) .. ":" .. tostring(currentObjIndex)) or nil
    AutoQuestLearner.currentFloorHintKey = currentTargetKey -- consumed by /aql floor
    AutoQuestLearner.currentFloorHintGroupKey = currentGroupKey
    AutoQuestLearner.currentFloorHintQuestID = standingOnIt and questID or nil
    AutoQuestLearner.currentFloorHintObjIndex = currentObjIndex

    local heightDiff = (zplayer and loc.z) and (loc.z - zplayer) or nil
    -- ~10 yards is comfortably more than normal ground unevenness/hills
    -- would produce but well under a typical floor-to-floor gap in a
    -- building or multi-level cave.
    local floorMismatch = heightDiff and math.abs(heightDiff) > 10
    -- Group-scoped hint (covers this whole objective's spawn cluster)
    -- takes priority over a single-point one, since it's the more
    -- deliberately-set, broader signal -- falls back to the exact-point
    -- hint for giver/turnin pins and static-only targets that don't
    -- belong to any learned objective cluster.
    local manualHint = (currentGroupKey and AutoQuestLearnerDB.floorHintGroups and AutoQuestLearnerDB.floorHintGroups[currentGroupKey])
        or (currentTargetKey and AutoQuestLearnerDB.floorHints and AutoQuestLearnerDB.floorHints[currentTargetKey])

    local floorHint = ""
    if floorMismatch then
        floorHint = string.format(
            " |cffff8800(Different floor -- go %s, ~%d yards)|r",
            heightDiff > 0 and "up" or "down", math.abs(heightDiff))
    elseif manualHint then
        floorHint = string.format(" |cffff8800(Different floor -- try going %s, per your own earlier note)|r", manualHint)
    elseif standingTooLong then
        floorHint = " |cffff8800(Not seeing them? Coordinates can't tell floors apart -- check upstairs/downstairs, or /aql floor up|down once found.)|r"
    end

    local displayKey = tostring(title) .. "|" .. tostring(npcName) .. "|" .. tostring(AutoQuestLearner.pinnedQuestID) .. "|" .. tostring(standingOnIt) .. "|" .. tostring(floorHint) .. "|" .. tostring(questID)
    if displayKey ~= arrowLastTitle then
        arrowLastTitle = displayKey
        local prefix = AutoQuestLearner.pinnedQuestID and "|cff00ccff[Pinned]|r " or ""
        local idSuffix = tonumber(questID) and (" |cff888888<" .. questID .. ">|r") or ""
        AutoQuestLearner.arrow.title:SetText(prefix .. (title or "") .. idSuffix)

        -- Icon + description, inferred from the role suffix already
        -- baked into the title text ("(turn-in)", "(quest area)",
        -- "objective"). Matches pfQuest's layout: a quest-marker icon
        -- with a short instructional line underneath the title. Names
        -- the specific NPC/object when known (npcName), rather than
        -- just a generic instructional phrase.
        if title and string.find(title, "%(travel route%)") then
            AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
            AutoQuestLearner.arrow.icon:SetVertexColor(.6, .8, 1)
            AutoQuestLearner.arrow.description:SetText(
                (npcName or "Head this way to reach the next zone") .. ".")
        elseif title and string.find(title, "%(available%)") then
            AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\AvailableQuestIcon")
            AutoQuestLearner.arrow.icon:SetVertexColor(1, 1, 1)
            local baseText = npcName and ("Speak to " .. npcName .. " to accept this quest.") or "Quest available here."
            AutoQuestLearner.arrow.description:SetText(baseText .. floorHint)
        elseif title and string.find(title, "%(turn%-in%)") then
            AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
            AutoQuestLearner.arrow.icon:SetVertexColor(1, 1, .3)
            local baseText = npcName and ("Turn in to " .. npcName .. ".") or "Ready to turn in here."

            -- Quest chain preview: if this quest is known to lead
            -- directly into another one, name it -- so turning in
            -- doesn't come as a surprise follow-up, and it's easier to
            -- notice if the next quest didn't auto-offer for some
            -- reason. Only covers quests this addon's bundled data
            -- actually has chain data for (a subset, not every chain
            -- that exists) -- silently says nothing extra rather than
            -- guessing when it doesn't know.
            local nextText = ""
            if questID and AutoQuestLearnerQuestChain then
                local nextQuestID = AutoQuestLearnerQuestChain[questID]
                if nextQuestID then
                    local nextLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][nextQuestID]
                    local nextTitle = nextLoc and nextLoc.T
                    if nextTitle then
                        nextText = " |cff00ccffNext:|r " .. nextTitle
                    end
                end
            end

            AutoQuestLearner.arrow.description:SetText(baseText .. nextText .. SourceTag() .. floorHint)
        elseif title and string.find(title, "%(objective%)") then
            AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
            AutoQuestLearner.arrow.icon:SetVertexColor(.7, .7, .7)
            local objText = npcName and ("Find " .. npcName .. " nearby.") or "Complete this objective nearby."
            objText = objText .. SourceTag()

            -- Full bundled objective text, when we have it -- a bare
            -- target name doesn't explain unusual objectives (e.g. a
            -- boss that must be summoned first, an item that must be
            -- used on something, an NPC that needs a specific approach)
            -- the way the actual quest-log instruction does. Strips the
            -- "$B$B" paragraph-break markers used in the raw source
            -- text and caps length so one unusually long quest
            -- description can't take over the whole arrow tooltip.
            local fullObjText = nil
            if questID then
                local questLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
                local rawObj = questLoc and questLoc.O
                if rawObj and rawObj ~= "" then
                    fullObjText = string.gsub(rawObj, "%$[bB]%$?[bB]?", " ")
                    fullObjText = string.gsub(fullObjText, "%s+", " ")
                    fullObjText = string.gsub(fullObjText, "^%s*(.-)%s*$", "%1")
                    if string.len(fullObjText) > 200 then
                        fullObjText = string.sub(fullObjText, 1, 197) .. "..."
                    end
                end
            end

            if fullObjText then
                AutoQuestLearner.arrow.description:SetText(objText .. floorHint .. "\n|cffaaaaaa" .. fullObjText .. "|r")
            else
                AutoQuestLearner.arrow.description:SetText(objText .. floorHint)
            end
        else
            AutoQuestLearner.arrow.icon:SetTexture("Interface\\GossipFrame\\ActiveQuestIcon")
            AutoQuestLearner.arrow.icon:SetVertexColor(.7, .7, .7)
            -- If this fallback candidate is right where the player is
            -- already standing, it's not really pointing anywhere new
            -- -- it means no separate objective location is known yet
            -- (no bundled data, nothing personally observed). Say so
            -- plainly instead of implying there's a fresh destination.
            if standingOnIt then
                AutoQuestLearner.arrow.description:SetText(
                    "No separate objective location known yet.")
            elseif npcName then
                AutoQuestLearner.arrow.description:SetText(
                    "Quest area (near " .. npcName .. ") -- not yet complete.")
            else
                AutoQuestLearner.arrow.description:SetText("Quest area -- not yet complete.")
            end
        end
    end

    AutoQuestLearner.arrow.distance:SetText("Distance: " .. string.format("%.1f", distance))
end

local arrowUpdateErrorShown = false
-- ~20 fps is enough for smooth arrow rotation; full 60fps was pure CPU waste.
local ARROW_DRAW_INTERVAL = 0.05
local arrowDrawElapsed = 0
AutoQuestLearner.arrow:SetScript("OnUpdate", function(self, elapsed)
    arrowDrawElapsed = arrowDrawElapsed + (elapsed or 0)
    if arrowDrawElapsed < ARROW_DRAW_INTERVAL then return end
    arrowDrawElapsed = 0
    local ok, err = pcall(UpdateArrowFrame)
    if not ok and not arrowUpdateErrorShown then
        arrowUpdateErrorShown = true
        print("|cffff0000AutoQuestLearner:|r Navigation arrow error (this is what's breaking it): " .. tostring(err))
    end
end)

------------------------------------------------------------
-- Route line (dotted path)
--
-- Draws a trail of small dots from the player to the current arrow
-- target, matching pfQuest's route.tga dotted-path feature, on both
-- the minimap and the world map (when open). The minimap math reuses
-- the exact same zoom/calibration approach already proven in
-- AutoQuestLearnerMap:UpdateMinimap() (Minimap:GetViewRadius(), the
-- bundled minimap_sizes calibration table); the world map math is
-- pfQuest's own (simpler, since the world map doesn't zoom/pan the
-- same way).
------------------------------------------------------------
local routeDotsMinimap = {}
local routeDotsWorldmap = {}

local function ClearRouteDots(dots)
    for _, tex in pairs(dots) do
        tex.enable = false
        tex:Hide()
    end
end

local function DrawRouteLine(dots, parent, x, y, nx, ny, isMinimap, xDraw, yDraw, xPlayerPix, yPlayerPix, startOffset)
    local dx, dy = x - nx, y - ny
    local totalDots
    if isMinimap then
        -- Minimap coordinate scaling isn't uniformly square, so the
        -- 1.5x factor on the X component compensates for that when
        -- deciding dot density/spacing -- matches the original
        -- pfQuest-derived calibration, left as-is.
        totalDots = ceil(math.sqrt(dx * 1.5 * dx * 1.5 + dy * dy))
    else
        -- BUGFIX: confirmed real -- the world map's actual on-screen
        -- aspect ratio is already handled separately below (drawX/drawY
        -- scale by WorldMapButton's real width/height when POSITIONING
        -- each dot), so reusing the minimap's 1.5x heuristic here
        -- double-applies an aspect correction meant for an entirely
        -- different coordinate system -- producing systematically wrong
        -- dot spacing/count for any route segment with meaningful
        -- horizontal distance, which is most of them. Use the map's own
        -- real pixel-space distance instead, so density stays even and
        -- consistent regardless of a segment's direction.
        local pixelDX = dx / 100 * WorldMapButton:GetWidth()
        local pixelDY = dy / 100 * WorldMapButton:GetHeight()
        totalDots = ceil(math.sqrt(pixelDX * pixelDX + pixelDY * pixelDY) / 12)
    end
    if totalDots < 2 then return startOffset or 0 end

    local shown = startOffset or 0
    for i = (isMinimap and 1 or 2), totalDots - (isMinimap and 1 or 2) do
        local xpos = nx + dx / totalDots * i
        local ypos = ny + dy / totalDots * i
        local display = true
        local drawX, drawY

        if isMinimap then
            drawX = (xpos - xPlayerPix) * xDraw
            drawY = -(ypos - yPlayerPix) * yDraw
            local dist = math.sqrt(drawX * drawX + drawY * drawY)
            display = (dist + 1 < Minimap:GetWidth() / 2)
        else
            drawX = xpos / 100 * WorldMapButton:GetWidth()
            drawY = ypos / 100 * WorldMapButton:GetHeight()
        end

        if display then
            shown = shown + 1
            local tex = dots[shown]
            if not tex then
                tex = parent:CreateTexture(nil, "OVERLAY")
                tex:SetWidth(isMinimap and 4 or 5)
                tex:SetHeight(isMinimap and 4 or 5)
                tex:SetTexture("Interface\\AddOns\\AutoQuestLearner\\img\\route")
                tex:SetVertexColor(1.0, 0.82, 0.25, 0.95)
                dots[shown] = tex
            end
            tex:ClearAllPoints()
            if isMinimap then
                tex:SetPoint("CENTER", parent, "CENTER", drawX, drawY)
            else
                tex:SetPoint("CENTER", parent, "TOPLEFT", drawX, -drawY)
            end
            tex:Show()
            tex.enable = true
        end
    end

    return shown
end

local function HideRouteDotsFrom(dots, fromIndex)
    for i = fromIndex + 1, table.getn(dots) do
        if dots[i] then
            dots[i]:Hide()
            dots[i].enable = false
        end
    end
end

local routeFrame = CreateFrame("Frame")
routeFrame.tick = 0
routeFrame.planTick = 0
routeFrame.cachedPlan = nil
routeFrame:SetScript("OnUpdate", function(self, elapsed)
    if AutoQuestLearnerDB.config.navArrow == "0" or AutoQuestLearnerDB.config.routeLine == "0" then
        ClearRouteDots(routeDotsMinimap)
        ClearRouteDots(routeDotsWorldmap)
        return
    end

    routeFrame.tick = routeFrame.tick + (elapsed or 0)
    if routeFrame.tick < 0.2 then return end
    routeFrame.tick = 0

    local xplayer, yplayer = GetPlayerMapPosition("player")
    if not xplayer or (xplayer == 0 and yplayer == 0) then
        ClearRouteDots(routeDotsMinimap)
        ClearRouteDots(routeDotsWorldmap)
        return
    end
    xplayer, yplayer = xplayer * 100, yplayer * 100

    -- Minimap route line: single segment to the arrow's current
    -- target. A full multi-stop route wouldn't fit in the minimap's
    -- limited view radius anyway, so this stays as-is.
    local loc = arrowCachedLoc
    if loc and AutoQuestLearnerMap and AutoQuestLearnerMap.GetMinimapSizes then
        local mapID = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap()) or AutoQuestLearnerMap:GetMapID()
        local calib = AutoQuestLearnerMap:GetMinimapSizes()[mapID]
        if calib and calib[1] and calib[2] then
            local mapZoom = 200
            if Minimap.GetViewRadius then
              local ok, r = pcall(function() return Minimap:GetViewRadius() end)
              if ok and r and r > 10 then mapZoom = r * 2 end
            end
            local xScale = mapZoom / calib[1]
            local yScale = mapZoom / calib[2]
            local xDraw = Minimap:GetWidth() / xScale / 100
            local yDraw = Minimap:GetHeight() / yScale / 100
            local used = DrawRouteLine(routeDotsMinimap, Minimap, loc.x, loc.y, xplayer, yplayer, true, xDraw, yDraw, xplayer, yplayer, 0)
            HideRouteDotsFrom(routeDotsMinimap, used)
        else
            ClearRouteDots(routeDotsMinimap)
        end
    else
        ClearRouteDots(routeDotsMinimap)
    end

    -- World map: ONE clean line from player to the arrow's current
    -- target only. Drawing PlanRoute's full multi-stop chain produced
    -- long diagonal "triangles" across the zone that looked messy and
    -- ignored terrain. Full ordered route remains available via /aql route.
    if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapButton then
        local loc = arrowCachedLoc
        -- Fallback: refresh target if cache is empty but arrow is enabled
        if (not loc or not loc.x) and AutoQuestLearner_FindClosestQuestDestination then
            local a = AutoQuestLearner_FindClosestQuestDestination()
            if a and a.x and a.y then loc = a end
        end
        if loc and loc.x and loc.y then
            local tx, ty = tonumber(loc.x), tonumber(loc.y)
            -- Accept 0-1 fraction coords if something stored them that way
            if tx and tx > 0 and tx <= 1 and ty and ty > 0 and ty <= 1 then
                tx, ty = tx * 100, ty * 100
            end
            if tx and ty then
                local used = DrawRouteLine(routeDotsWorldmap, WorldMapButton,
                    tx, ty, xplayer, yplayer, false, nil, nil, nil, nil, 0)
                HideRouteDotsFrom(routeDotsWorldmap, used)
            else
                ClearRouteDots(routeDotsWorldmap)
            end
        else
            ClearRouteDots(routeDotsWorldmap)
        end
    else
        ClearRouteDots(routeDotsWorldmap)
        routeFrame.cachedPlan = nil
    end
end)

------------------------------------------------------------
-- Proactive "you're about done here" zone nudge
--
-- The zone completion tracker (/aql zone) already shows this, but only
-- if you think to check it. This surfaces the same information
-- proactively, once, the moment it crosses a threshold worth noticing
-- -- no curated "zone A leads to zone B" leveling-path data needed,
-- just AutoQuestLearner_SuggestNextZones (above) counting real,
-- level-matched, untouched quests this addon already knows about in
-- OTHER zones.
------------------------------------------------------------
local zoneNudgeFrame = CreateFrame("Frame")
zoneNudgeFrame.elapsed = 0
zoneNudgeFrame.notifiedZones = {}
zoneNudgeFrame:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + (elapsed or 0)
    if self.elapsed < 30 then return end
    self.elapsed = 0

    if not (AutoQuestLearner.db and AutoQuestLearner.db.GetZoneCompletion) then return end
    if AutoQuestLearnerDB.config.zoneNudge == "0" then return end
    local total, done, _, mapID = AutoQuestLearner.db:GetZoneCompletion()
    if not mapID or total < 5 then return end -- too few known quests here to mean anything
    if self.notifiedZones[mapID] then return end

    local pct = done / total
    if pct < 0.85 then return end

    self.notifiedZones[mapID] = true

    local zoneName = (AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
        and AutoQuestLearnerData.zones["loc"][mapID]) or "this zone"
    local playerLevel = UnitLevel and UnitLevel("player")
    if not playerLevel then return end

    local nextZones = AutoQuestLearner_SuggestNextZones(mapID, playerLevel, 3)

    print(string.format("|cff00ff00AutoQuestLearner:|r %d%% of known quests done in %s -- might be a good time to think about moving on.",
        math.floor(pct * 100), zoneName))
    if table.getn(nextZones) > 0 then
        local parts = {}
        for _, z in ipairs(nextZones) do
            table.insert(parts, string.format("%s (%d)", z.name, z.count))
        end
        print("  |cff888888Zones with more level-appropriate quests still available: " .. table.concat(parts, ", ") .. "|r")
    end
end)
-- (see AutoQuestLearnerDatabase:GetQuestIDs for the same technique).
-- Falls back to matching against the local pfQuest database by title
-- when the quest isn't in the log yet.
------------------------------------------------------------
local function ResolveQuestID(questTitle)
    if not questTitle or questTitle == "" then return nil end

    if GetQuestLink then
        for qlogid = 1, GetNumQuestLogEntries() do
            local title, _, _, header = AutoQuestLearner_GetQuestLogTitle(qlogid)
            if title == questTitle and not header then
                local link = GetQuestLink(qlogid)
                if link then
                    local _, _, id = strfind(link, "|c.*|Hquest:([%d]+):([%-]?[%d]+)|h%[(.*)%]|h|r")
                    if id then return tonumber(id) end
                end
                break
            end
        end
    end

    if AutoQuestLearner.db and AutoQuestLearner.db.GetIDByName then
        local ids = AutoQuestLearner.db:GetIDByName(questTitle, "quests")
        -- BUGFIX (confirmed real: 841 titles in the bundled database are
        -- shared by 2+ different quest IDs, worst case "Candy Bucket"
        -- shared by 80 different quests across every capital city).
        -- This used to just take ids[1], the first match, with no
        -- disambiguation -- meaning a title collision could silently
        -- attribute a location to a completely unrelated quest,
        -- depending on Lua's undefined pairs() iteration order. Only
        -- trust this when the title is genuinely unambiguous (exactly
        -- one candidate); otherwise fall through to the title-string
        -- fallback below, same as the "couldn't resolve at all" case.
        if ids and table.getn(ids) == 1 then return ids[1] end
    end

    -- No numeric ID resolvable -- this happens for gossip-window
    -- "available" quests you haven't accepted yet (not in your quest
    -- log, so GetQuestLink() can't help) when there's also no pfQuest
    -- database to match the title against. Rather than lose the
    -- learning opportunity entirely, fall back to using the title
    -- itself as the key -- the same pattern already used elsewhere
    -- (e.g. AutoQuestLearnerDatabase:GetQuestIDs) when no numeric ID
    -- is available. If you later accept the quest, event-based
    -- learning will resolve and store it under the real numeric ID.
    return questTitle
end

------------------------------------------------------------
-- Gossip / quest greeting learning
--
-- When a quest NPC opens its multi-quest greeting or gossip window, the
-- WoW client populates data about every quest that NPC offers / tracks.
-- This is a goldmine for learning -- you talk to one NPC and you can
-- record positions for 5-10 quests at once, even if you never accept
-- any of them.
--
-- IMPORTANT: this client does NOT have the modern indexed
-- GetGossipAvailableQuestInfo(i) / GetGossipActiveQuestInfo(i)
-- functions -- those are retail-only additions that don't exist here at
-- all. The only functions available on this client are the flat,
-- no-index forms: GetGossipAvailableQuests() / GetGossipActiveQuests(),
-- which return every quest's fields concatenated into ONE long list in
-- a single call. Worse, this client's era predates the "questID" field
-- being added to these functions entirely (that only happened in a much
-- later retail patch), so there is no numeric ID available from gossip
-- at all -- only titles. We resolve each title to a real ID via
-- ResolveQuestID() (which falls back to a title match against the
-- local pfQuest database).
--
-- Rather than hardcode how many fields belong to each quest (which has
-- changed across patches and may differ further on this custom server),
-- we compute it dynamically: total values returned, divided by the
-- quest count from GetNumGossipAvailableQuests()/GetNumGossipActiveQuests().
-- The title is always the first field in each quest's group either way.
------------------------------------------------------------
local function LearnFromGossip()
    if not AutoQuestLearnerDB.settings.gossipLearning then return end
    local char = GetChar()
    local learned = 0
    local actualAvailableTitles = {}

    -- Available quests (the ones this NPC can give you).
    local numAvailable = GetNumGossipAvailableQuests and GetNumGossipAvailableQuests() or 0
    if numAvailable and numAvailable > 0 then
        local values = { GetGossipAvailableQuests() }
        local stride = math.floor(table.getn(values) / numAvailable)
        if stride >= 1 then
            for i = 1, numAvailable do
                local title = values[(i - 1) * stride + 1]
                if title and title ~= "" then
                    actualAvailableTitles[title] = true
                    local questID = ResolveQuestID(title)
                    -- Note: no outer "already known" pre-check here --
                    -- RecordLocation() itself gates per-role now, which
                    -- is the fix for the turn-in-never-learned bug. An
                    -- outer check keyed only on questID would silently
                    -- reintroduce that same bug.
                    if questID then
                        if RecordLocation(questID, title,
                            string.format("%s (gossip)", title), "gossip") then
                            learned = learned + 1
                        end
                    end
                end
            end
        end
    end

    -- BUGFIX: negative learning. Confirmed real -- a quest ("Feathers
    -- for Grazle", 8466) passed every gating check this addon knows
    -- about (its one documented prerequisite was genuinely complete,
    -- server-confirmed) and was suggested as available, but the NPC's
    -- actual gossip window offered no such quest -- meaning Ascension
    -- has some extra requirement here that isn't in any database this
    -- addon (or even Ascension's own quest DB site) has. Since we now
    -- KNOW this NPC's real gossip contents, cross-check every quest we
    -- believed this NPC gives (from the bundled start/U data) against
    -- what's actually here. A believed-available giver quest that's
    -- silently absent gets flagged so we stop recommending it, instead
    -- of insisting forever on data reality just disproved.
    local guid = UnitGUID and UnitGUID("target")
    local npcID = guid and tonumber(string.sub(guid, 9, 12), 16)
    if npcID then
        if not npcToQuestRoles then BuildNPCToQuestIndex() end
        local roles = npcToQuestRoles[npcID]
        if roles then
            for _, entry in ipairs(roles) do
                local believedQuestID, source = entry[1], entry[2]
                if source == "gossip" then
                    local believedLoc = AutoQuestLearnerData.quests["loc"][believedQuestID]
                    local believedTitle = believedLoc and believedLoc.T
                    local currentlyBelievedAvailable = believedTitle
                        and not (AutoQuestLearner.questlog and AutoQuestLearner.questlog[believedQuestID])
                        and not AutoQuestLearner_IsQuestCompleted(believedQuestID, believedTitle)
                        and AutoQuestLearner_MeetsQuestGating(believedQuestID)
                    if currentlyBelievedAvailable and not actualAvailableTitles[believedTitle] then
                        AutoQuestLearnerDB.knownUnavailable = AutoQuestLearnerDB.knownUnavailable or {}
                        if not AutoQuestLearnerDB.knownUnavailable[believedQuestID] then
                            AutoQuestLearnerDB.knownUnavailable[believedQuestID] = true
                            print(string.format(
                                "|cffff8800AutoQuestLearner:|r %s didn't actually offer \"%s\" even though our data said it should -- this server must have an extra requirement we don't know about. No longer suggesting it.",
                                UnitName("target") or "This NPC", believedTitle))
                            AutoQuestLearner.updateQuestGivers = true
                        end
                    end
                end
            end
        end
    end

    -- Active quests (the ones this NPC is tracking for you -- turn-in
    -- candidates).
    local numActive = GetNumGossipActiveQuests and GetNumGossipActiveQuests() or 0
    if numActive and numActive > 0 then
        local values = { GetGossipActiveQuests() }
        local stride = math.floor(table.getn(values) / numActive)
        if stride >= 1 then
            for i = 1, numActive do
                local title = values[(i - 1) * stride + 1]
                if title and title ~= "" then
                    local questID = ResolveQuestID(title)
                    if questID then
                        if RecordLocation(questID, title,
                            string.format("%s (turn-in)", title), "gossip-turnin") then
                            learned = learned + 1
                        end
                    end
                end
            end
        end
    end

    if learned > 0 then
        AutoQuestLearnerDB.stats.gossipLearned =
            (AutoQuestLearnerDB.stats.gossipLearned or 0) + learned
        print(string.format(
            "|cff00ff00AutoQuestLearner:|r Learned %d quest location%s from gossip window.",
            learned, learned == 1 and "" or "s"))
    end
end

------------------------------------------------------------
-- Quest detail / progress / complete learning
--
-- Fires when the client is ABOUT to show a specific quest's detail
-- dialog, the progress dialog, or the turn-in dialog. In all three
-- cases, we know the player is standing next to the relevant NPC.
--
-- Note: this client has NEITHER the modern per-context functions
-- (GetAvailableQuestID() / GetActiveQuestID() / GetQuestIDToComplete())
-- NOR the older unified GetQuestID() — all of them are nil globals
-- here. GetTitleText() does work though, and gives us the title of
-- whatever quest frame is currently open.
--
-- For QUEST_PROGRESS / QUEST_COMPLETE the quest is already in the
-- player's quest log, so we can resolve its real ID for free by
-- finding the matching quest log entry and pulling the ID out of
-- GetQuestLink()'s hyperlink text — no database required. This is the
-- exact technique pfQuest itself uses (see pfDatabase:GetQuestIDs).
-- For QUEST_DETAIL the quest isn't in the log yet, so that trick isn't
-- available; we fall back to matching the title against our local
-- pfQuest database, and simply skip if that database isn't loaded.
------------------------------------------------------------
local function LearnFromQuestEvent(source)
    if not AutoQuestLearnerDB.settings.eventLearning then return end
    if type(GetTitleText) ~= "function" then return end

    local questTitle = GetTitleText()
    if not questTitle or questTitle == "" then return end

    local questID = ResolveQuestID(questTitle)
    if not questID then return end

    -- No outer "already known" pre-check here -- RecordLocation() gates
    -- per-role now (giver vs. turnin independently). This function is
    -- the main path for QUEST_DETAIL (accept, role=giver) AND
    -- QUEST_PROGRESS/QUEST_COMPLETE (turn-in, role=turnin), so an outer
    -- check keyed only on questID would block the turn-in dialog from
    -- ever recording its location once the accept dialog already had --
    -- which was the actual bug behind the arrow pointing at the quest
    -- giver instead of the turn-in/objective.
    local label = questTitle .. " (" .. source .. ")"
    if RecordLocation(questID, questTitle, label, source) then
        AutoQuestLearnerDB.stats.eventLearned =
            (AutoQuestLearnerDB.stats.eventLearned or 0) + 1
        print(string.format(
            "|cff00ff00AutoQuestLearner:|r Learned location for '%s' (quest %s) from %s.",
            questTitle, tostring(questID), source))
    end
end

------------------------------------------------------------
-- Proximity scan
--
-- Even without an open gossip window, any NPC the player is standing
-- near that has a quest relationship to the player is a learning
-- opportunity. This iterates the local unit list (everything within
-- nameplate range, which is generous on this client), and for any
-- quest-related entry, records a position snapshot under the right
-- quest IDs.
--
-- The big question: how do you tell from a nameplate alone whether
-- an NPC is a quest giver? The 3.3.5 client has IsActiveQuestTrivial
-- / IsActiveQuestTrivial and a few Gossip-related APIs that require
-- the unit to be the player's target. So this scan is target-only:
-- it checks the current target, not every nearby nameplate. Cheap
-- (one API call per scan) and avoids the "scan the whole world"
-- cost of iterating every nameplate in range.
--
-- The target check is intentionally narrow: if the target has
-- any active or available quest for us, record under that quest ID.
-- Most of the time the target is empty, so the scan is a no-op.
------------------------------------------------------------
local function ProximityScan()
    if not AutoQuestLearnerDB.settings.enableProximityScan then return end

    -- Guard: nothing to do if the player has no target
    if not UnitExists("target") then return end
    if not UnitCanCooperate("player", "target") then
        -- Enemy / hostile — quest NPCs are friendly, so skip
        return
    end
    if UnitIsDead("target") or UnitIsDeadOrGhost("player") then return end

    local learned = 0

    -- Available quests (this NPC has for the player). This client's
    -- actual signature (added 3.3.3) is 5 values -- isTrivial, frequency,
    -- isRepeatable, isLegendary, questID -- with no title and no extra
    -- "isDaily" field. (A previous version of this code inserted an
    -- extra field before questID, which pushed the real questID into a
    -- 6th return value that doesn't exist on this client, so it was
    -- always nil.)
    for i = 1, GetNumAvailableQuests() do
        local isTrivial, frequency, isRepeatable, isLegendary,
            questID = GetAvailableQuestInfo(i)
        if questID and questID > 0 then
            do
                -- No API on this client resolves a title from a numeric
                -- quest ID directly, so we just use a generic label here.
                local title = "Quest " .. questID
                if RecordLocation(questID, title, title .. " (proximity)", "proximity") then
                    learned = learned + 1
                end
            end
        end
    end

    -- Active quests (this NPC is tracking for the player — turn-in).
    -- GetActiveQuestInfo() is not a real function on this client (or
    -- any client version, as far as can be determined) -- the correct
    -- older-style functions are GetActiveTitle(index)/GetActiveLevel(index),
    -- and neither returns a quest ID at all, so we resolve it by title
    -- via ResolveQuestID() the same way gossip learning does.
    for i = 1, GetNumActiveQuests() do
        local questName = GetActiveTitle(i)
        if questName and questName ~= "" then
            local questID = ResolveQuestID(questName)
            if questID then
                if RecordLocation(questID, questName, questName .. " (turn-in proximity)", "proximity-turnin") then
                    learned = learned + 1
                end
            end
        end
    end

    if learned > 0 then
        AutoQuestLearnerDB.stats.proximityLearned =
            (AutoQuestLearnerDB.stats.proximityLearned or 0) + learned
    end
end

------------------------------------------------------------
-- pfQuest data import (optional)
------------------------------------------------------------
local function MaybeAutoImportPfQuest()
    if not AutoQuestLearnerDB.settings.autoImportPfQuest then return end
    local char = GetChar()
    local existingCount = 0
    for _ in pairs(char.questLocations) do existingCount = existingCount + 1 end
    if existingCount > 0 then return end -- already learned something; don't import

    -- If pfQuest is available, we could import data from it
    -- This is now optional since we work standalone
    if pfDB and AutoQuestLearner.db then
        print("|cff00ff00AutoQuestLearner:|r pfQuest detected. Database integration available.")
    end
end

------------------------------------------------------------
-- Diagnostics
------------------------------------------------------------
local function PrintDebug()
    print("|cff00ff00AutoQuestLearner Diagnostics|r")

    print("  pfDB global present: " .. tostring(pfDB ~= nil))

    local dbQuestCount = 0
    if AutoQuestLearnerData and AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"] then
        for _ in pairs(AutoQuestLearnerData.quests["data"]) do dbQuestCount = dbQuestCount + 1 end
    end
    print("  AutoQuestLearnerData.quests.data entries: " .. dbQuestCount)

    local qlogCacheCount = 0
    if AutoQuestLearner.questlog then
        for _ in pairs(AutoQuestLearner.questlog) do qlogCacheCount = qlogCacheCount + 1 end
    end
    print("  AutoQuestLearner.questlog (internal cache) entries: " .. qlogCacheCount)

    local _, numQuests = GetNumQuestLogEntries()
    print("  Real quest log entries (GetNumQuestLogEntries): " .. tostring(numQuests))

    print("  this.lock active (still in startup delay): " ..
        tostring(AutoQuestLearner.lock and AutoQuestLearner.lock > GetTime()))

    local trackerButtonCount = 0
    local trackerVisibleCount = 0
    if AutoQuestLearnerTracker and AutoQuestLearnerTracker.buttons then
        for _, button in pairs(AutoQuestLearnerTracker.buttons) do
            trackerButtonCount = trackerButtonCount + 1
            if not button.empty then trackerVisibleCount = trackerVisibleCount + 1 end
        end
    end
    print("  Tracker buttons created: " .. trackerButtonCount ..
        " (non-empty: " .. trackerVisibleCount .. ")")

    print("  Tracker frame shown: " ..
        tostring(AutoQuestLearnerTracker and AutoQuestLearnerTracker:IsShown()))
    print("  Tracker mode: " .. tostring(AutoQuestLearnerTracker and AutoQuestLearnerTracker.mode))

    print("  AutoQuestLearnerMap loaded: " .. tostring(AutoQuestLearnerMap ~= nil))

    -- How much data actually exists to plot as nodes, vs. whether it's
    -- being rendered. This distinguishes "nothing learned/known yet"
    -- from "data exists but isn't showing up".
    local learnedQuestCount, learnedGiverCount, learnedTurninCount = 0, 0, 0
    if AutoQuestLearnerDB.learned and AutoQuestLearnerDB.learned.quests then
        for _, entry in pairs(AutoQuestLearnerDB.learned.quests) do
            learnedQuestCount = learnedQuestCount + 1
            if entry.giver then learnedGiverCount = learnedGiverCount + 1 end
            if entry.turnin then learnedTurninCount = learnedTurninCount + 1 end
        end
    end
    print("  Learned quests (shared DB): " .. learnedQuestCount ..
        " (giver locations: " .. learnedGiverCount ..
        ", turn-in locations: " .. learnedTurninCount .. ")")

    local learnedObjectiveSpawns = 0
    if AutoQuestLearnerDB.learned and AutoQuestLearnerDB.learned.objectives then
        for _, objectives in pairs(AutoQuestLearnerDB.learned.objectives) do
            for _, obj in pairs(objectives) do
                learnedObjectiveSpawns = learnedObjectiveSpawns + table.getn(obj.spawns or {})
            end
        end
    end
    print("  Learned objective spawn points (shared DB): " .. learnedObjectiveSpawns)

    local totalNodes, currentZoneNodes = 0, 0

    -- Detailed step-by-step trace of GetMapID(), since by its own logic
    -- it should never be able to return nil (it always falls back to a
    -- "C<cid>Z<mid>" string as a last resort) -- if it does return nil
    -- in practice, this pinpoints exactly which step produced it.
    local rawCid = GetCurrentMapContinent()
    local rawMid = GetCurrentMapZone()
    print("  Raw GetCurrentMapContinent(): " .. tostring(rawCid))
    print("  Raw GetCurrentMapZone(): " .. tostring(rawMid))
    if AutoQuestLearnerMap then
        local zoneList = { GetMapZones(rawCid) }
        print("  GetMapZones(continent) entry count: " .. table.getn(zoneList))
        print("  Zone name at that index: " .. tostring(zoneList[rawMid]))
    end

    local currentZone = AutoQuestLearnerMap and
        AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
    local currentZoneNoArgs = AutoQuestLearnerMap and AutoQuestLearnerMap:GetMapID()
    print("  GetMapID(explicit args): " .. tostring(currentZone))
    print("  GetMapID(no args, internal defaults): " .. tostring(currentZoneNoArgs))

    if AutoQuestLearnerMap and AutoQuestLearnerMap.nodes then
        for addon, byMap in pairs(AutoQuestLearnerMap.nodes) do
            for mapKey, byCoord in pairs(byMap) do
                for _, byTitle in pairs(byCoord) do
                    for _ in pairs(byTitle) do
                        totalNodes = totalNodes + 1
                        if mapKey == currentZone then
                            currentZoneNodes = currentZoneNodes + 1
                        end
                    end
                end
            end
        end
    end
    print("  Total plotted nodes (all zones): " .. totalNodes)
    print("  Current zone: " .. tostring(currentZone) ..
        " (nodes here: " .. currentZoneNodes .. ")")

    -- List first few real quest log titles for cross-reference
    print("  First quest log entries seen:")
    local shown = 0
    for qlogid=1,40 do
        local title, level, tag, header = AutoQuestLearner_GetQuestLogTitle(qlogid)
        if title and not header then
            print("    [" .. qlogid .. "] " .. title)
            shown = shown + 1
            if shown >= 5 then break end
        end
    end
    if shown == 0 then
        print("    (none found — your quest log appears empty)")
    end
end

------------------------------------------------------------
-- Status print
------------------------------------------------------------
local function PrintStatus()
    EnsureSettings()
    local char = GetChar()
    local count = 0
    for _ in pairs(char.questLocations) do count = count + 1 end
    local stats = AutoQuestLearnerDB.stats or {}

    local learnedQuestCount, learnedObjCount = 0, 0
    if AutoQuestLearnerDB.learned then
        if AutoQuestLearnerDB.learned.quests then
            for _ in pairs(AutoQuestLearnerDB.learned.quests) do learnedQuestCount = learnedQuestCount + 1 end
        end
        if AutoQuestLearnerDB.learned.objectives then
            for _, objectives in pairs(AutoQuestLearnerDB.learned.objectives) do
                for _, obj in pairs(objectives) do
                    learnedObjCount = learnedObjCount + table.getn(obj.spawns or {})
                end
            end
        end
    end

    print("|cff00ff00AutoQuestLearner v2.0|r")
    print("  Quest locations for this character: " .. count)
    print("  Learned via gossip:    " .. (stats.gossipLearned or 0))
    print("  Learned via events:    " .. (stats.eventLearned or 0))
    print("  Learned via proximity: " .. (stats.proximityLearned or 0))
    print("  Shared database: " .. learnedQuestCount .. " quests, " ..
        learnedObjCount .. " objective spawn points learned")
    print("  pfQuest data loaded:   " ..
        (pfDB ~= nil and "|cff00ff00yes|r (bonus data available)" or
        "|cffffcc00no|r (fully optional -- own learning system still works)"))
    print("  Proximity scan:        " ..
        (AutoQuestLearnerDB.settings.enableProximityScan and
            "|cff00ff00on|r (" .. (AutoQuestLearnerDB.settings.proximityInterval or 10) .. "s)" or "|cffff0000off|r"))
    print("  Quest Tracker:         " ..
        (AutoQuestLearnerDB.config.showtracker == "1" and "|cff00ff00enabled|r" or "|cffff0000disabled|r"))
    print("  Map Nodes:             " ..
        (AutoQuestLearnerDB.config.minimapnodes == "1" and "|cff00ff00enabled|r" or "|cffff0000disabled|r"))
    print("  Database Loaded:       " ..
        ((AutoQuestLearnerData and AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"]
            and next(AutoQuestLearnerData.quests["loc"]) ~= nil)
            and "|cff00ff00yes|r" or "|cffff0000no|r"))
    print("")
    print("  Commands (the essentials -- /aql help all for the full list):")
    print("  /aql guide   - open the in-game how-to-use guide")
    print("  /aql config  - open configuration panel")
    print("  /aql learn [quest name] - manually save your current spot as an objective location")
    print("  /aql mismatch - list live vs bundled quest title mismatches + hidden sources")
    print("  /aql unhide  - restore Shift-click-hidden static spawn sources")
    print("  /aql missing - report that a quest giver the arrow says is here genuinely isn't -- stops suggesting it at this spot")
    print("  /aql sleep [questID] - stop an available (not-yet-picked-up) quest from being suggested, on any character, until woken back up")
    print("  /aql wake [questID|all] - undo a sleep -- with no args, wakes whatever the arrow's currently pointing at")
    print("  /aql sync - check location-sharing status with party/raid/guild")
    print("  /aql export - get a copyable text string of everything you've learned, to share")
    print("  /aql import - paste someone else's export string to add their learned locations to yours")
    print("  /aql route   - suggest an order to tackle your active quests in this zone (least backtracking)")
    print("  /aql zone    - show known-quest completion progress for this zone")
    print("  /aql suggestzone - suggest which zone(s) to level in next, based on your current level and known quest coverage")
    print("  /aql chain [quest name] - show the known follow-up quest, if any")
    print("  /aql tracker - toggle quest tracker")
    print("  /aql unpin - clear a pinned quest (arrow back to auto-select)")
    print("  Alt+Right-Click a tracked quest - pin/unpin the arrow to that quest")
end

local function PrintAllCommands()
    print("|cff00ff00AutoQuestLearner:|r Full command list")
    print("  /aql guide   - open the in-game how-to-use guide")
    print("  /aql config  - open configuration panel")
    print("  /aql learn [quest name] - manually save your current spot as an objective location")
    print("  /aql missing - report that a quest giver the arrow says is here genuinely isn't -- stops suggesting it at this spot")
    print("  /aql sleep [questID] - stop an available (not-yet-picked-up) quest from being suggested, on any character, until woken back up")
    print("  /aql wake [questID|all] - undo a sleep -- with no args, wakes whatever the arrow's currently pointing at")
    print("  /aql sync - check location-sharing status with party/raid/guild")
    print("  /aql export - get a copyable text string of everything you've learned, to share")
    print("  /aql import - paste someone else's export string to add their learned locations to yours")
    print("  /aql route   - suggest an order to tackle your active quests in this zone (least backtracking)")
    print("  /aql zone    - show known-quest completion progress for this zone")
    print("  /aql suggestzone - suggest which zone(s) to level in next, based on your current level and known quest coverage")
    print("  /aql chain [quest name] - show the known follow-up quest, if any")
    print("  /aql tracker - toggle quest tracker")
    print("  /aql unpin - clear a pinned quest (arrow back to auto-select)")
    print("  --- everything else ---")
    print("  /aql scan    - force proximity scan now")
    print("  /aql proximity - toggle automatic proximity-based learning on/off")
    print("  /aql learnnotify - toggle the chat confirmation when automatic kill/loot learning records a new spawn point")
    print("  /aql db      - detailed breakdown of the shared learned database")
    print("  /aql resync  - force-reload all learned locations & refresh map nodes")
    print("  /aql focus   - toggle showing only what the arrow is currently tracking")
    print("  /aql gossip  - reprocess current gossip window")
    print("  /aql flickerdebug - diagnose tracker flickering (5s recording)")
    print("  /aql usage  - open live panel of ALL addons memory (CPU if available)")
    print("  /aql perf    - check this addons own memory/CPU footprint")
    print("  /aql perfdebug - real timing measurements for likely-expensive functions (10s)")
    print("  /aql blizztracker - toggle Blizzard's default tracker")
    print("  /aql arrow - diagnose why the navigation arrow isn't showing")
    print("  /aql questitems - diagnose why quest item buttons aren't showing")
    print("  /aql calibrate [reset] - check/reset minimap scale calibration for starting zones")
    print("  /aql learnedstats - show how much has actually been learned so far (account-wide, all characters combined)")
    print("  /aql learnedstatsauto - toggle showing that same summary automatically every login/reload (on by default)")
    print("  /aql opendb [questID] - open the Ascension Database page for the selected (or given) quest")
    print("  /aql why [questID] - explain exactly why a quest is/isn't showing as available")
    print("  /aql unavailable [clear|clear questID] - list quests flagged as never actually offered despite passing our checks, or clear that flag")
    print("  /aql floor up|down|clear - while standing on an unresolved pin, teach the arrow which way the real NPC actually is (applies to that whole objective's spawn cluster when it's an objective, not just the one pin)")
    print("  /aql pvprequired [clear|clear questID] - list quests flagged as needing PvP flag to interact with, or clear that flag")
    print("  /aql reprequired [clear|clear questID] - list quests flagged as needing more reputation, or clear that flag once you've earned enough standing")
    print("  /aql killdebug - toggle chat output for every kill's parsed NPC ID and whether a matching map node was found")
    print("  /aql backfillids - re-run the one-time NPC-identity backfill on existing learned spawns (normally runs once automatically on login)")
    print("  /aql respawntimers [clear] - list (or clear) learned per-NPC respawn intervals, used instead of the default 5-minute guess once observed")
    print("  /aql zonefilter - toggle showing only current-zone quests in the tracker (pinned quests and unknown-location quests always show)")
    print("  /aql zonenudge - toggle the one-time-per-zone nudge suggesting where to go next once a zone's known quests are mostly done")
    print("  /aql announceparty - toggle announcing quest accept/complete/abandon in party chat (off by default)")
    print("  /aql announcepartyprogress - toggle announcing kill/loot progress (e.g. \"4/8\") in party chat (off by default, separate from the above)")
    print("  /aql questitemtooltip - toggle showing quest progress on item tooltips (on by default)")
    print("  /aql lock - toggle locking the tracker's position/size so it can't be accidentally dragged or resized (off by default)")
    print("  /aql debuglog - toggle internal diagnostic logging to chat (off by default; for troubleshooting)")
    print("  /aql clusterdebug - toggle a visual debug overlay on the world map for cluster merging (for troubleshooting)")
    print("  /aql availrange [number] - view or set how far the arrow will look for an available quest to auto-suggest (default 20, smaller = only very nearby ones)")
    print("  /aql availrangeactive [number] - same, but specifically while you already have a real active-quest objective to head toward (default 5, tighter than the above -- an available pickup only competes if genuinely close by)")
    print("  /aql trackascension - toggle whether Ascension-custom quests get suggested for pickup at all (off by default -- their requirements are often undocumented)")
    print("  /aql trackclassquests - toggle whether class-restricted quests get suggested for pickup at all (off by default, even for a matching class)")
    print("  /aql map     - update map nodes")
    print("  /aql debug   - print diagnostic info")
end

------------------------------------------------------------
-- Replace Blizzard's default quest tracker
--
-- Blizzard's built-in objective tracker on this client generation is
-- the WatchFrame (introduced in patch 3.3.0, replacing the older
-- vanilla/TBC QuestWatchFrame). It auto-shows itself again on various
-- events (accepting a quest, zoning, combat ending), so a one-time
-- Hide() isn't enough -- we hook its own Show() to keep it collapsed
-- for as long as the option is enabled, and restore normal behavior
-- immediately if the option gets turned back off.
------------------------------------------------------------
local watchFrameHooked = false

function AutoQuestLearner_UpdateBlizzardTrackerVisibility()
    if not WatchFrame then return end

    if AutoQuestLearnerDB.config.hideblizzardtracker == "0" then
        WatchFrame:Show()
        return
    end

    WatchFrame:Hide()

    if not watchFrameHooked then
        watchFrameHooked = true
        WatchFrame:HookScript("OnShow", function(self)
            if AutoQuestLearnerDB.config.hideblizzardtracker ~= "0" then
                self:Hide()
            end
        end)
    end
end

-- One-time cleanup: the auto-targeting macro feature (AQLTalk/AQLKill)
-- was removed from the addon -- delete any macros it already created
-- so they aren't left behind as orphaned, no-longer-updating clutter.
local macroCleanupFrame = CreateFrame("Frame")
macroCleanupFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
macroCleanupFrame:SetScript("OnEvent", function(self)
    if InCombatLockdown and InCombatLockdown() then return end -- DeleteMacro only works out of combat
    if not DeleteMacro or not GetMacroIndexByName then return end
    for _, name in ipairs({ "AQLTalk", "AQLKill" }) do
        if GetMacroIndexByName(name) ~= 0 then
            DeleteMacro(name)
        end
    end
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")
end)

local watchFrameEventFrame = CreateFrame("Frame")
watchFrameEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
watchFrameEventFrame:SetScript("OnEvent", AutoQuestLearner_UpdateBlizzardTrackerVisibility)

------------------------------------------------------------
-- Quest item panel ("use this on the objective")
--
-- Stock WotLK 3.3.5 has this feature built into Blizzard's own
-- WatchFrame (WatchFrameItemN buttons), and Ascension's client still
-- computes the same underlying WatchFrame/WATCHFRAME_QUESTLINES data
-- in the background (confirmed: GetQuestLogSpecialItemInfo returns
-- real data, and WatchFrame's own top-level position tracks the
-- visible tracker correctly). But individual line positions inside it
-- proved unreliable to anchor to directly on this client -- three
-- different anchoring strategies (direct anchor, protected-frame-safe
-- absolute offset, continuous polling) all landed in the same wrong
-- spot, which points to the per-line layout data itself being stale
-- or not cascading the way a normal WoW frame hierarchy would.
--
-- Rather than keep fighting that, this is a small standalone panel:
-- not anchored into the mystery tracker at all, so it can't inherit
-- whatever's unreliable about it. Each row is labeled with the quest
-- name directly, so which icon belongs to which quest is never
-- ambiguous even without being physically next to that quest's line.
-- Shift-drag to move it anywhere; position is remembered.
------------------------------------------------------------
AutoQuestLearnerDB.config.questitempanelpos = AutoQuestLearnerDB.config.questitempanelpos or nil

local questItemPanel = CreateFrame("Frame", "AutoQuestLearnerQuestItemPanel", UIParent)
questItemPanel:SetWidth(200)
questItemPanel:SetHeight(20)
questItemPanel:SetMovable(true)
questItemPanel:EnableMouse(true)
questItemPanel:RegisterForDrag("LeftButton")
questItemPanel:SetScript("OnDragStart", function(self)
    if IsShiftKeyDown() then self:StartMoving() end
end)
questItemPanel:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, _, x, y = self:GetPoint()
    AutoQuestLearnerDB.config.questitempanelpos = { point, x, y }
end)

if AutoQuestLearnerDB.config.questitempanelpos then
    local point, x, y = unpack(AutoQuestLearnerDB.config.questitempanelpos)
    questItemPanel:SetPoint(point, UIParent, point, x, y)
else
    questItemPanel:SetPoint("TOPRIGHT", WatchFrame or UIParent, "TOPLEFT", -10, -4)
end

local bg = questItemPanel:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints()
bg:SetTexture(0, 0, 0, 0.35)

local questItemRows = {}

local function GetOrCreateQuestItemRow(i)
    if questItemRows[i] then return questItemRows[i] end
    local row = CreateFrame("Button", "AutoQuestLearnerQuestItemRow" .. i, questItemPanel, "SecureActionButtonTemplate")
    row:SetWidth(196)
    row:SetHeight(20)
    row:SetPoint("TOP", questItemPanel, "TOP", 0, -(i - 1) * 22 - 2)
    row:RegisterForClicks("AnyUp", "AnyDown")

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetWidth(18)
    row.icon:SetHeight(18)
    row.icon:SetPoint("LEFT", 2, 0)
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local border = row:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetPoint("CENTER", row.icon, "CENTER", 0, 0)
    border:SetWidth(18)
    border:SetHeight(18)

    row.label = row:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
    row.label:SetJustifyH("LEFT")
    row.label:SetWidth(170)

    row:SetScript("OnEnter", function(self)
        if not self.questIndex then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetQuestLogSpecialItem(self.questIndex)
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Rows cover almost the entire panel, so the panel's own
    -- OnDragStart never fires -- the mouse event is consumed by
    -- whichever row is under the cursor first. Same fix already used
    -- by AutoQuestLearnerTracker's own buttons: put the shift+drag
    -- handling on each row instead of the parent.
    row:SetScript("OnMouseDown", function(self)
        if IsShiftKeyDown() then
            questItemPanel:StartMoving()
        end
    end)
    row:SetScript("OnMouseUp", function(self)
        questItemPanel:StopMovingOrSizing()
        local point, _, _, x, y = questItemPanel:GetPoint()
        AutoQuestLearnerDB.config.questitempanelpos = { point, x, y }
    end)

    questItemRows[i] = row
    return row
end

local function AutoQuestLearner_UpdateQuestItemButtons_Impl()
    if AutoQuestLearnerDB.config.questitembuttons == "0" then
        questItemPanel:Hide()
        return
    end
    if not GetNumQuestWatches or not GetQuestIndexForWatch or not GetQuestLogSpecialItemInfo then return end
    if InCombatLockdown and InCombatLockdown() then return end -- secure attributes can't change in combat

    local shown = 0
    local numWatches = GetNumQuestWatches()
    for i = 1, numWatches do
        local questIndex = GetQuestIndexForWatch(i)
        if questIndex then
            local link, item, charges = GetQuestLogSpecialItemInfo(questIndex)
            if item then
                shown = shown + 1
                local title = GetQuestLogTitle(questIndex) or "?"
                local row = GetOrCreateQuestItemRow(shown)
                row.icon:SetTexture(item)
                row.label:SetText(title)
                row.questIndex = questIndex
                row:SetAttribute("type", "item")
                row:SetAttribute("item", link)
                row:Show()
            end
        end
    end

    for i = shown + 1, table.getn(questItemRows) do
        questItemRows[i]:Hide()
    end

    if shown > 0 then
        questItemPanel:SetHeight(shown * 22 + 4)
        questItemPanel:Show()
    else
        questItemPanel:Hide()
    end
end

local questItemButtonsLastError = nil
function AutoQuestLearner_UpdateQuestItemButtons()
    local ok, err = pcall(AutoQuestLearner_UpdateQuestItemButtons_Impl)
    if not ok then
        questItemButtonsLastError = err
    else
        questItemButtonsLastError = nil
    end
end

local questItemEventFrame = CreateFrame("Frame")
questItemEventFrame:RegisterEvent("QUEST_LOG_UPDATE")
questItemEventFrame:RegisterEvent("QUEST_WATCH_UPDATE")
questItemEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
questItemEventFrame:SetScript("OnEvent", AutoQuestLearner_UpdateQuestItemButtons)

------------------------------------------------------------
-- Replay previously-learned locations on login
--
-- RecordLocation() / AutoQuestLearner_RecordObjectiveProgress() draw a
-- node immediately when something is freshly learned, but that only
-- covers the current session. Everything learned in past sessions
-- lives in the shared AutoQuestLearnerDB.learned database and needs to
-- be redrawn each time the addon loads. GetLearnedDB() already wipes
-- stale entries from earlier, incompatible mapID formats via schema
-- versioning, so anything here is safe to draw directly.
------------------------------------------------------------
-- Ensure learned objective spawns for mapID exist in Map.nodes so the
-- minimap can draw them (arrow already reads SavedVariables directly).
local _learnedSyncStamp = {}

-- True when this learned objective text is an item-collect line whose
-- drop creatures are already plotted from static DB (skip item-name pins).
function AutoQuestLearner_ShouldSkipLearnedItemPin(questID, objText, targetID)
    if targetID then return false end
    if not objText or not AutoQuestLearner_ResolveItemSources then return false end
    local sq = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"]
        and AutoQuestLearnerData.quests["data"][questID]
    if not sq or not sq["obj"] or not sq["obj"]["I"] then return false end
    local short = string.match(objText, "^(.-)%s*:?%s*%d") or objText
    short = string.lower(short or "")
    for _, itemID in pairs(sq["obj"]["I"]) do
        local iname = AutoQuestLearner_GetItemName and AutoQuestLearner_GetItemName(itemID)
        if iname and string.find(short, string.lower(iname), 1, true) then
            local sources = AutoQuestLearner_ResolveItemSources(itemID)
            if sources and next(sources) then return true end
        end
    end
    return false
end

function AutoQuestLearner_SyncLearnedObjectivesForMap(mapID)
    if not mapID or not AutoQuestLearnerMap then return end
    local now = GetTime()
    local key = tostring(mapID)
    -- Fresh learn sets _learnedSyncBypass so this runs immediately
    local bypass = AutoQuestLearner._learnedSyncBypass
    if bypass and (now - bypass) < 2.0 then
        AutoQuestLearner._learnedSyncBypass = nil
        _learnedSyncStamp[key] = nil
    end
    if _learnedSyncStamp[key] and (now - _learnedSyncStamp[key]) < 5.0 then
        return
    end
    _learnedSyncStamp[key] = now

    local learned = GetLearnedDB and GetLearnedDB()
    if not learned or not learned.objectives then return end

    -- Focus mode: only sync the arrow-tracked quest (avoids scanning all learned)
    local focusOnly = (not AutoQuestLearnerDB.config) or AutoQuestLearnerDB.config.focusmode ~= "0"
    local focusQ = AutoQuestLearner_GetTrackedQuestID and AutoQuestLearner_GetTrackedQuestID()
    local mapNum = tonumber(mapID)
    local groups = {}
    local drawn = 0
    local MAX_DRAW = 80

    local function processQuest(questID, objectives)
        if drawn >= MAX_DRAW then return end
        local questTitle = ResolveQuestTitle and ResolveQuestTitle(questID) or nil
        for objIndex, obj in pairs(objectives) do
            if drawn >= MAX_DRAW then return end
            for _, spawn in pairs(obj.spawns or {}) do
                if drawn >= MAX_DRAW then return end
                if spawn and spawn.mapID and (
                    spawn.mapID == mapID or spawn.mapID == mapNum
                    or tostring(spawn.mapID) == tostring(mapID)
                ) then
                    if ShouldShowSpawnDots and ShouldShowSpawnDots() then
                        if not AutoQuestLearner_ShouldSkipLearnedItemPin(questID, obj.text, spawn.targetID) then
                            spawn.isLearned = true
                            DrawObjectiveNode(questID, spawn, questTitle, obj.text, spawn.targetID)
                            drawn = drawn + 1
                        end
                    end
                    local gkey = tostring(questID) .. ":" .. tostring(objIndex) .. ":" .. tostring(spawn.targetID or "x")
                    groups[gkey] = groups[gkey] or {
                        questID = questID, questTitle = questTitle, text = obj.text,
                        targetID = spawn.targetID, coords = {},
                    }
                    table.insert(groups[gkey].coords, { spawn.x, spawn.y })
                end
            end
        end
    end

    if focusOnly and focusQ and learned.objectives[focusQ] then
        processQuest(focusQ, learned.objectives[focusQ])
    elseif focusOnly and focusQ then
        local n = tonumber(focusQ)
        if n and learned.objectives[n] then
            processQuest(n, learned.objectives[n])
        else
            for questID, objectives in pairs(learned.objectives) do
                if tostring(questID) == tostring(focusQ) then
                    processQuest(questID, objectives)
                    break
                end
            end
        end
    else
        for questID, objectives in pairs(learned.objectives) do
            processQuest(questID, objectives)
            if drawn >= MAX_DRAW then break end
        end
    end

    if ShouldShowClusterIcons and ShouldShowClusterIcons() then
        for _, g in pairs(groups) do
            AutoQuestLearner_DrawClusterBadge(g.questID, g.questTitle, g.text, g.targetID, nil, mapID, g.coords)
        end
    end
end

function AutoQuestLearner_ReplayLearnedLocations(filterQuestID, opts)
    -- opts = { skipStatic = true, force = true }
    -- filterQuestID: only re-apply that quest's learned pins (cheap path after SearchQuestID)
    opts = opts or {}
    local now = GetTime and GetTime() or 0
    if not filterQuestID and not opts.force then
        if AutoQuestLearner._lastFullReplay and (now - AutoQuestLearner._lastFullReplay) < 2.0 then
            return
        end
        AutoQuestLearner._lastFullReplay = now
    end
    local learned = GetLearnedDB()
    if not learned then return end

    local function matchesFilter(qid)
        if not filterQuestID then return true end
        return qid == filterQuestID or tostring(qid) == tostring(filterQuestID)
    end

    for questID, questEntry in pairs(learned.quests or {}) do
        if matchesFilter(questID) and questEntry then
            for _, role in ipairs({ "giver", "turnin" }) do
                local loc = questEntry[role]
                if loc then
                    DrawLearnedNode(questID, role, loc, questEntry.title)
                end
            end
        end
    end

    -- Static clusters: only on full replay (login/zone). SearchQuestID already draws static.
    if AutoQuestLearner.questlog and not opts.skipStatic then
        for questID, logData in pairs(AutoQuestLearner.questlog) do
            if matchesFilter(questID) then
                local skipDraw = false
                if logData.qlogid then
                    local _, _, _, _, _, isComplete = AutoQuestLearner_GetQuestLogTitle(logData.qlogid)
                    if not isComplete then
                        local numObjectives = GetNumQuestLeaderBoards(logData.qlogid)
                        if numObjectives and numObjectives > 0 then
                            isComplete = true
                            for oi = 1, numObjectives do
                                local _, _, objDone = GetQuestLogLeaderBoard(oi, logData.qlogid)
                                if not objDone then
                                    isComplete = false
                                    break
                                end
                            end
                        end
                    end
                    skipDraw = isComplete and true or false
                end
                if not skipDraw then
                    local ok, err = pcall(DrawStaticObjectiveClusters, questID, logData.title)
                    if not ok and AutoQuestLearner.Debug then
                        AutoQuestLearner:Debug("DrawStaticObjectiveClusters (replay) error: " .. tostring(err))
                    end
                end
            end
        end
    end

    local groups = {}
    for questID, objectives in pairs(learned.objectives or {}) do
        if matchesFilter(questID) then
            local questTitle = ResolveQuestTitle(questID)
            for objIndex, obj in pairs(objectives) do
                for _, spawn in pairs(obj.spawns or {}) do
                    if ShouldShowSpawnDots and ShouldShowSpawnDots() then
                        -- Skip learned item-name pins when static DB already
                        -- plots the drop creatures (avoids "Metallic Fragments"
                        -- as its own cluster beside Frayfeather spawns).
                        if not AutoQuestLearner_ShouldSkipLearnedItemPin(questID, obj.text, spawn.targetID) then
                            spawn.isLearned = true
                            DrawObjectiveNode(questID, spawn, questTitle, obj.text, spawn.targetID, spawn.sourceType)
                        end
                    end
                    if spawn and spawn.mapID then
                        local gkey = tostring(questID) .. ":" .. tostring(objIndex) .. ":" .. tostring(spawn.mapID) .. ":" .. tostring(spawn.targetID or "x")
                        groups[gkey] = groups[gkey] or {
                            questID = questID, questTitle = questTitle, text = obj.text,
                            targetID = spawn.targetID, mapID = spawn.mapID, coords = {},
                        }
                        table.insert(groups[gkey].coords, { spawn.x, spawn.y })
                    end
                end
            end
        end
    end
    if ShouldShowClusterIcons and ShouldShowClusterIcons() then
        for _, g in pairs(groups) do
            AutoQuestLearner_DrawClusterBadge(g.questID, g.questTitle, g.text, g.targetID, nil, g.mapID, g.coords)
        end
    end
end


-- BUGFIX: confirmed real -- kill-tracking (HideNearestNode) matches by
-- targetID, but every spawn learned BEFORE that field existed (which
-- is the vast majority of anyone's existing data, including the whole
-- community seed dataset) has none, so its highlightKey falls back to
-- just the quest ID -- never matching a killed NPC's ID string, so
-- nothing ever gets hidden for pre-existing data no matter how many
-- times its NPC gets killed.
--
-- Can't know for certain which NPC an old multi-source objective's
-- spawns came from (that's the same fundamental gap as the floor-
-- height data -- info that was never captured can't be recovered).
-- But when the bundled database says a quest's kill/interact objective
-- has exactly ONE possible source NPC, there's no ambiguity at all --
-- every spawn recorded for it must be that NPC. This backfills exactly
-- that unambiguous case, one time, and leaves genuinely-ambiguous
-- multi-source objectives alone rather than guessing.
local function BackfillObjectiveTargetIDs(forcePrint)
    if AutoQuestLearnerDB.targetIDBackfillDone and not forcePrint then return 0 end
    local learned = GetLearnedDB()
    local filled = 0

    for questID, objs in pairs(learned.objectives or {}) do
        local staticQuest = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"] and AutoQuestLearnerData.quests["data"][questID]
        local singleID = nil
        if staticQuest and staticQuest["obj"] then
            local candidates = {}
            if staticQuest["obj"]["U"] then
                for _, id in pairs(staticQuest["obj"]["U"]) do table.insert(candidates, id) end
            end
            if staticQuest["obj"]["O"] then
                for _, id in pairs(staticQuest["obj"]["O"]) do table.insert(candidates, id) end
            end
            if table.getn(candidates) == 1 then
                singleID = candidates[1]
            end
        end
        if singleID then
            for objIndex, obj in pairs(objs) do
                for _, spawn in pairs(obj.spawns or {}) do
                    if not spawn.targetID then
                        spawn.targetID = singleID
                        filled = filled + 1
                    end
                end
            end
        end
    end

    AutoQuestLearnerDB.targetIDBackfillDone = true
    if filled > 0 then
        print("|cff00ff00AutoQuestLearner:|r One-time update: tagged NPC identity onto " .. filled ..
            " previously-learned spawn point(s) where the source was unambiguous. These can now be individually hidden when killed, same as newly-learned ones.")
        local ok, err = pcall(AutoQuestLearner_ReplayLearnedLocations)
        if not ok and AutoQuestLearner.Debug then
            AutoQuestLearner:Debug("ReplayLearnedLocations (post-backfill) error: " .. tostring(err))
        end
    elseif forcePrint then
        print("|cff00ff00AutoQuestLearner:|r Nothing to backfill -- every learned spawn either already has NPC identity, or belongs to a multi-source objective that can't be disambiguated.")
    end
    return filled
end

local replayFrame = CreateFrame("Frame")
replayFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
-- ZONE_CHANGED_NEW_AREA covers moving between zones on foot/mount/
-- flight path within the same continent -- a case that does NOT
-- reliably fire PLAYER_ENTERING_WORLD (that one's really only
-- guaranteed on login, /reload, and continent-crossing loading
-- screens). Without this, a fresh zone's learned locations could
-- fail to appear until the next full reload. AddNode()'s own
-- dedup cache (keyed by addon/map/coords/title/etc.) makes calling
-- ReplayLearnedLocations() again here cheap -- it's a no-op for
-- anything already drawn.
replayFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
replayFrame:SetScript("OnEvent", function()
    if event == "ZONE_CHANGED_NEW_AREA" then
        -- BUGFIX: confirmed real -- this used to be gated behind
        -- AutoQuestLearnerDB.localized, a flag that was read here (and
        -- in a debug print) but never actually SET anywhere in the
        -- codebase, meaning it was always nil/false and this branch
        -- never ran. Learned locations for any zone other than the one
        -- you happened to be standing in at login/reload would never
        -- get their clusters drawn at all, exactly the case this
        -- handler exists to cover per the comment below.
        if AutoQuestLearner_ScrubBadAreatriggerLearned then
            local n = AutoQuestLearner_ScrubBadAreatriggerLearned()
            if n and n > 0 then
                DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00AutoQuestLearner:|r Removed " .. n .. " bad explore/areatrigger learned pin(s).")
            end
        end
        AutoQuestLearner_ReplayLearnedLocations(nil, { force = true })
        return
    end

    -- Small delay so AutoQuestLearnerData (pfQuest DB copy, used for
    -- resolving quest titles) has finished initializing first.
    local elapsedTotal = 0
    replayFrame:SetScript("OnUpdate", function(self, elapsed)
        elapsedTotal = elapsedTotal + elapsed
        if elapsedTotal >= 2 then
            self:SetScript("OnUpdate", nil)
            AutoQuestLearner_ReplayLearnedLocations(nil, { force = true })
        end
    end)
end)

------------------------------------------------------------
-- Slash command (single /aql command)
------------------------------------------------------------
SLASH_AUTOQUESTLEARNER1 = "/aql"
-- BUGFIX: confirmed real -- /aql sleep read arrowCachedQuestID, which
-- is only refreshed every 0.5s by destinationSearchFrame. When two
-- "(available)" quest givers stand close together (e.g. two Deviate-
-- themed NPCs a few yards apart in the Barrens), the "closest" one can
-- flip between refresh ticks -- so what the player was actually
-- LOOKING AT on screen ("Deviate Eradication") and what the command
-- silently grabbed a moment later ("Deviate Hides", a completely
-- different quest) could disagree. Reading the arrow's title
-- FontString directly instead of the cache guarantees whatever gets
-- slept is exactly whatever's visibly on screen at the moment the
-- command runs, no race possible.
local function GetDisplayedAvailableQuestID()
    if not AutoQuestLearner.arrow or not AutoQuestLearner.arrow.title then return nil, nil end
    local text = AutoQuestLearner.arrow.title:GetText()
    if not text then return nil, nil end
    text = string.gsub(text, "^|cff%x%x%x%x%x%x%[Pinned%]|r%s*", "")
    -- Prefer the inline <questID> now shown right on the arrow itself
    -- (see the title-suffix change in UpdateArrowFrame) -- reads the
    -- ID directly rather than reverse-looking-up a title, which is
    -- both more direct and immune to two different quests happening to
    -- share the exact same title text.
    local idFromSuffix = tonumber(string.match(text, "|cff%x%x%x%x%x%x<(%d+)>|r%s*$"))
    local title = string.match(text, "^(.-)%s*%(available%)")
    if idFromSuffix then
        return idFromSuffix, title
    end
    if not title then return nil, nil end
    for id, loc in pairs(AutoQuestLearnerData.quests["loc"] or {}) do
        if loc.T == title then
            return id, title
        end
    end
    return nil, title
end

SlashCmdList["AUTOQUESTLEARNER"] = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    
    -- Default: open config panel if no argument
    if msg == "" then
        if AutoQuestLearnerConfig then
            AutoQuestLearnerConfig:Show()
        else
            print("|cff00ff00AutoQuestLearner:|r Configuration module not loaded.")
            PrintStatus()
        end
        return
    end
    
    if msg == "status" or msg == "help" then
        PrintStatus()
        return
    end

    if msg == "mem" or msg == "memory" then
        -- Runtime footprint report (nodes + caches + pin pools)
        local function countKeys(t)
            if not t then return 0 end
            local n = 0
            for _ in pairs(t) do n = n + 1 end
            return n
        end
        local nodeZones, nodeCoords = 0, 0
        if AutoQuestLearnerMap and AutoQuestLearnerMap.nodes then
            for _, maps in pairs(AutoQuestLearnerMap.nodes) do
                if type(maps) == "table" then
                    for _, zone in pairs(maps) do
                        nodeZones = nodeZones + 1
                        if type(zone) == "table" then
                            for _ in pairs(zone) do nodeCoords = nodeCoords + 1 end
                        end
                    end
                end
            end
        end
        local pins = AutoQuestLearnerMap and AutoQuestLearnerMap.pins and table.getn(AutoQuestLearnerMap.pins) or 0
        local mpins = AutoQuestLearnerMap and AutoQuestLearnerMap.mpins and table.getn(AutoQuestLearnerMap.mpins) or 0
        local tips = AutoQuestLearnerMap and countKeys(AutoQuestLearnerMap.tooltips) or 0
        local memKB = (collectgarbage and collectgarbage("count")) or 0
        print("|cff00ff00AQL mem:|r Lua ~" .. string.format("%.1f", memKB / 1024) .. " MB (addon+all)")
        print("  map zones cached: " .. nodeZones .. "  coord buckets: " .. nodeCoords)
        print("  world pins pooled: " .. pins .. "  minimap pins pooled: " .. mpins)
        print("  tooltip cache keys: " .. tips)
        print("  Tip: /reload after long sessions; zone change prunes old zone nodes.")
        if AutoQuestLearnerMap and AutoQuestLearnerMap.PruneInactiveZoneNodes then
            local keep = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap())
                or (AutoQuestLearnerMap.GetMapID and AutoQuestLearnerMap:GetMapID())
            AutoQuestLearnerMap:PruneInactiveZoneNodes(keep)
            print("  Pruned inactive zone nodes now.")
        end
        return
    end

    if msg == "help all" or msg == "helpall" then
        PrintAllCommands()
        return
    end
    
    if string.find(msg, "^learn") then
        local filterText = string.match(msg, "^learn%s+(.*)$")
        AutoQuestLearner_ManualLearnObjective(filterText)
        return
    end

    if msg == "db" then
        -- Direct proof that the shared, account-wide learned database
        -- is actually accumulating data (not just "trust me") -- these
        -- numbers should only ever grow as you play, on ANY character,
        -- and never reset between sessions (aside from the one-time
        -- schema-version wipe noted below, which only fires on an
        -- addon update that changes the data format).
        local learned = GetLearnedDB()
        local giverCount, turninCount, bothCount = 0, 0, 0
        for _, entry in pairs(learned.quests) do
            local hasGiver, hasTurnin = entry.giver and true or false, entry.turnin and true or false
            if hasGiver then giverCount = giverCount + 1 end
            if hasTurnin then turninCount = turninCount + 1 end
            if hasGiver and hasTurnin then bothCount = bothCount + 1 end
        end
        local objQuestCount, spawnPointCount = 0, 0
        for _, objectives in pairs(learned.objectives) do
            objQuestCount = objQuestCount + 1
            for _, obj in pairs(objectives) do
                spawnPointCount = spawnPointCount + table.getn(obj.spawns or {})
            end
        end
        print("|cff00ff00AutoQuestLearner:|r Shared learned database (account-wide, SavedVariables: AutoQuestLearnerDB.learned, schema v" .. LEARNED_SCHEMA_VERSION .. "):")
        print(string.format("  Quests with a learned giver location: %d", giverCount))
        print(string.format("  Quests with a learned turn-in location: %d", turninCount))
        print(string.format("  Quests with BOTH learned: %d", bothCount))
        print(string.format("  Quests with at least one learned objective spawn: %d (%d total spawn points recorded)", objQuestCount, spawnPointCount))
        print("  This is shared across every character on this account -- log into an alt and run this again to confirm the same numbers show up (or higher, if that alt has learned more).")
    elseif msg == "scan" then
        ProximityScan()
        print("|cff00ff00AutoQuestLearner:|r Proximity scan complete.")
    elseif msg == "resync" then
        -- Manual safety net: force-redraw every learned quest location
        -- from the shared account-wide database, then refresh the
        -- currently visible map/minimap nodes. Normally this happens
        -- automatically on login/reload and on zone changes -- this is
        -- here for the rare case something didn't catch (e.g. right
        -- after installing this update, or if a node got stuck).
        --
        -- Also resets and re-runs the objective-node cleanup tracking:
        -- a quest whose cluster failed to clear (e.g. from a bug that's
        -- since been fixed) would have its "already tried" flag stuck
        -- true for the rest of the session, silently preventing even a
        -- corrected cleanup from running again until a full /reload.
        -- This clears that memory and immediately re-checks every
        -- quest currently in the log.
        AutoQuestLearner.objectiveNodesCulled = {}
        AutoQuestLearner.objCulled = {}
        AutoQuestLearner_ReplayLearnedLocations()
        if AutoQuestLearner.UpdateQuestlog then
            AutoQuestLearner:UpdateQuestlog()
        end
        if AutoQuestLearnerMap then
            AutoQuestLearnerMap:UpdateNodes()
        end
        print("|cff00ff00AutoQuestLearner:|r Resynced all learned quest locations and re-checked completed quests for stuck objective clusters.")
    elseif msg == "unhide" then
        local n = 0
        if AutoQuestLearnerDB.hiddenStaticSources then
            for _ in pairs(AutoQuestLearnerDB.hiddenStaticSources) do n = n + 1 end
            AutoQuestLearnerDB.hiddenStaticSources = {}
        end
        print("|cff00ff00AutoQuestLearner:|r Cleared " .. n .. " hidden static source(s). Re-open quest log or /reload to redraw clusters.")
        if AutoQuestLearnerMap and AutoQuestLearnerMap.UpdateNodes then
            AutoQuestLearnerMap:UpdateNodes()
        end
    elseif msg == "mismatch" then
        print("|cff00ff00AutoQuestLearner:|r Quest title mismatches (live log vs bundled DB):")
        local found = 0
        if AutoQuestLearner.questlog then
            for questID, data in pairs(AutoQuestLearner.questlog) do
                local live = data.title
                local bundled = AutoQuestLearnerData and AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"]
                    and AutoQuestLearnerData.quests["loc"][questID]
                local bundledTitle = bundled and (type(bundled) == "table" and bundled.T or bundled)
                if live and bundledTitle and string.lower(live) ~= string.lower(bundledTitle) then
                    found = found + 1
                    print(string.format("  |cffffcc00%d|r  live: %s  |  bundled: %s", tonumber(questID) or 0, live, bundledTitle))
                end
            end
        end
        if found == 0 then
            print("  (none in current log)")
        else
            print("  " .. found .. " mismatch(es). Check db.ascension.gg / db.exil.es for Ascension truth.")
        end
        local hid = 0
        if AutoQuestLearnerDB.hiddenStaticSources then
            for k in pairs(AutoQuestLearnerDB.hiddenStaticSources) do
                hid = hid + 1
                print("  hidden source: " .. tostring(k))
            end
        end
        if hid > 0 then
            print("  " .. hid .. " hidden static source key(s). /aql unhide to clear.")
        end
    elseif msg == "focus" then
        -- Toggles focus mode: only show map/minimap nodes for whatever
        -- quest the arrow is currently tracking, hiding everything
        -- else. Switches automatically as the arrow's target changes.
        local newVal = (AutoQuestLearnerDB.config.focusmode == "1") and "0" or "1"
        AutoQuestLearnerDB.config.focusmode = newVal
        if AutoQuestLearnerMap then
            AutoQuestLearnerMap:UpdateNodes()
        end
        print("|cff00ff00AutoQuestLearner:|r Focus mode " .. (newVal == "1" and "ON -- only showing what the arrow is tracking." or "OFF -- showing all known nodes again."))
    elseif msg == "gossip" then
        LearnFromGossip()
    elseif msg == "proximity" then
        EnsureSettings()
        AutoQuestLearnerDB.settings.enableProximityScan =
            not AutoQuestLearnerDB.settings.enableProximityScan
        print("|cff00ff00AutoQuestLearner:|r Proximity scan " ..
            (AutoQuestLearnerDB.settings.enableProximityScan and "enabled" or "disabled") .. ".")
    elseif msg == "learnnotify" then
        AutoQuestLearnerDB.config.learnNotify = (AutoQuestLearnerDB.config.learnNotify == "0") and "1" or "0"
        print("|cff00ff00AutoQuestLearner:|r Automatic learn notifications " ..
            (AutoQuestLearnerDB.config.learnNotify == "0" and "disabled" or "enabled") .. ".")
    elseif msg == "config" then
        if AutoQuestLearner_OpenConfig then
            AutoQuestLearner_OpenConfig()
        elseif AutoQuestLearnerConfig then
            AutoQuestLearnerConfig:Show()
        else
            print("|cff00ff00AutoQuestLearner:|r Configuration module not loaded.")
        end
    elseif msg == "minimap" then
        if AutoQuestLearner_ToggleMinimapButton then
            AutoQuestLearner_ToggleMinimapButton()
        else
            print("|cff00ff00AutoQuestLearner:|r Minimap button module not loaded.")
        end
    elseif msg == "guide" then
        if AutoQuestLearner_ShowGuide then
            AutoQuestLearner_ShowGuide()
        else
            print("|cff00ff00AutoQuestLearner:|r Guide module not loaded.")
        end
    elseif msg == "backfillids" then
        BackfillObjectiveTargetIDs(true)
    elseif msg == "respawntimers" or string.match(msg, "^respawntimers%s") then
        local arg = string.match(msg, "^respawntimers%s+(.*)$")
        if arg == "clear" then
            local count = 0
            if AutoQuestLearnerDB.respawnTimers then
                for _ in pairs(AutoQuestLearnerDB.respawnTimers) do count = count + 1 end
            end
            AutoQuestLearnerDB.respawnTimers = {}
            print("|cff00ff00AutoQuestLearner:|r Cleared " .. count .. " learned respawn timer(s). Kill-tracking falls back to the default 5-minute guess until new observations come in.")
        else
            local any = false
            print("|cff00ff00AutoQuestLearner:|r Learned respawn timers (from repeated observation, most accurate first):")
            local rows = {}
            if AutoQuestLearnerDB.respawnTimers then
                for npcID, rt in pairs(AutoQuestLearnerDB.respawnTimers) do
                    table.insert(rows, { id = npcID, avg = rt.avg, samples = rt.samples })
                end
            end
            table.sort(rows, function(a, b) return a.samples > b.samples end)
            for _, row in ipairs(rows) do
                any = true
                local name = AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(row.id)
                print(string.format("  [%d] %s -- %.0fs avg (%d sample%s)",
                    row.id, name or "unknown NPC", row.avg, row.samples, row.samples == 1 and "" or "s"))
            end
            if not any then
                print("  (none yet -- these build up as the same spawn point gets killed, goes hidden, and gets killed again)")
            end
            print("  Usage: /aql respawntimers clear")
        end
    elseif msg == "killdebug" then
        AutoQuestLearner_KillDebug = not AutoQuestLearner_KillDebug
        print("|cff00ff00AutoQuestLearner:|r Kill-tracking debug " .. (AutoQuestLearner_KillDebug and "ON" or "OFF") ..
            (AutoQuestLearner_KillDebug and " -- every kill will print what NPC ID it parsed and whether a matching map node was found/hidden." or ""))
    elseif msg == "flickerdebug" then
        if not AutoQuestLearner_FlickerDebug then
            print("|cff00ff00AutoQuestLearner:|r Tracker module not loaded.")
        elseif AutoQuestLearner_FlickerDebug.active then
            print("|cff00ff00AutoQuestLearner:|r Already running -- wait for the current window to finish.")
        else
            AutoQuestLearner_FlickerDebug.counts = {}
            AutoQuestLearner_FlickerDebug.active = true
            print("|cff00ff00AutoQuestLearner:|r Recording for 5 seconds -- hold your mouse still over a quest with visible objectives now.")
            local dbgFrame = CreateFrame("Frame")
            local dbgElapsed = 0
            dbgFrame:SetScript("OnUpdate", function(self, e)
                dbgElapsed = dbgElapsed + (e or 0)
                if dbgElapsed < 5 then return end
                self:SetScript("OnUpdate", nil)
                AutoQuestLearner_FlickerDebug.active = false
                local counts = AutoQuestLearner_FlickerDebug.counts
                local names = {}
                for k in pairs(counts) do table.insert(names, k) end
                table.sort(names)
                print("|cff00ff00AutoQuestLearner:|r Results (5 second window):")
                if table.getn(names) == 0 then
                    print("  Nothing fired at all -- if the flicker happened during this window, it isn't coming from any of the tracked functions.")
                else
                    for _, name in pairs(names) do
                        print(string.format("  %s: %d", name, counts[name]))
                    end
                end
            end)
        end
    elseif msg == "usage" or msg == "mem" or msg == "memory" or msg == "addons" then
        if AutoQuestLearner.Usage and AutoQuestLearner.Usage.Toggle then
            AutoQuestLearner.Usage:Toggle()
            AutoQuestLearner.Usage:PrintChatSummary(12)
        else
            -- Minimal fallback if Usage.lua failed to load
            if UpdateAddOnMemoryUsage then pcall(UpdateAddOnMemoryUsage) end
            local luaKB = 0
            if collectgarbage then
                local ok, n = pcall(collectgarbage, "count")
                if ok and type(n) == "number" then luaKB = n end
            elseif gcinfo then
                local ok, n = pcall(gcinfo)
                if ok and type(n) == "number" then luaKB = n end
            end
            print("|cff00ff00AutoQuestLearner|r Usage UI missing. Lua UI memory total: " ..
                string.format("%.2f MB", luaKB / 1024))
            print("  Ensure AutoQuestLearner_Usage.lua is in the addon folder.")
        end
    elseif msg == "perf" then
        local memKB = GetAddOnMemoryUsage and GetAddOnMemoryUsage("AutoQuestLearner")
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        memKB = GetAddOnMemoryUsage and GetAddOnMemoryUsage("AutoQuestLearner")

        print("|cff00ff00AutoQuestLearner:|r Performance snapshot:")
        if memKB then
            print(string.format("  Memory in use: %.1f MB", memKB / 1024))
        else
            print("  Memory in use: unavailable on this client.")
        end

        -- NOTE: this deliberately does NOT suggest enabling
        -- scriptProfile for CPU timing -- confirmed to crash this
        -- specific client. Memory usage above is always safely
        -- available with no setup; for CPU/FPS impact specifically,
        -- the reliable method on this client is a direct A/B test:
        -- disable the addon (ESC -> AddOns, uncheck it, /reload),
        -- compare FPS for a few minutes, then re-enable and /reload
        -- again. No crash risk, no special console commands needed.
        print("  For FPS impact specifically: disable this addon (ESC menu -> AddOns, uncheck, /reload), compare your FPS for a few minutes, then re-enable and /reload again. (Not suggesting scriptProfile CPU tracking here -- confirmed to crash on this client.)")
        print("  Tip: |cffffcc00/aql usage|r opens a live panel of ALL addons' memory (and CPU if scriptProfile is already on).")
    elseif msg == "chain" or string.find(msg, "^chain ") then
        local filterText = string.find(msg, "^chain ") and string.sub(msg, 7) or ""
        if not AutoQuestLearner.questlog then
            print("|cff00ff00AutoQuestLearner:|r Quest log not loaded yet.")
        elseif not AutoQuestLearnerQuestChain then
            print("|cff00ff00AutoQuestLearner:|r Quest chain data not loaded.")
        else
            local targetQuestID, targetTitle

            if filterText and filterText ~= "" then
                local lowered = filterText:lower()
                local matches = {}
                for qid, entry in pairs(AutoQuestLearner.questlog) do
                    if entry.title and string.find(entry.title:lower(), lowered, 1, true) then
                        table.insert(matches, qid)
                    end
                end
                if table.getn(matches) == 0 then
                    print("|cff00ff00AutoQuestLearner:|r No quest in your log matches \"" .. filterText .. "\".")
                    targetQuestID = nil
                elseif table.getn(matches) > 1 then
                    print("|cff00ff00AutoQuestLearner:|r Multiple quests match \"" .. filterText .. "\" -- be more specific:")
                    for _, qid in pairs(matches) do
                        print("  - " .. AutoQuestLearner.questlog[qid].title)
                    end
                    targetQuestID = nil
                else
                    targetQuestID = matches[1]
                end
            elseif AutoQuestLearner.pinnedQuestID and AutoQuestLearner.questlog[AutoQuestLearner.pinnedQuestID] then
                targetQuestID = AutoQuestLearner.pinnedQuestID
            else
                local watchedIDs = {}
                for qid, entry in pairs(AutoQuestLearner.questlog) do
                    if entry.state and string.find(entry.state, "^track") then
                        table.insert(watchedIDs, qid)
                    end
                end
                if table.getn(watchedIDs) == 1 then
                    targetQuestID = watchedIDs[1]
                else
                    print("|cff00ff00AutoQuestLearner:|r Not sure which quest you mean.")
                    print("  Either pin one first (Alt+Right-Click it in the tracker) and run |cffffcc00/aql chain|r again,")
                    print("  or specify it directly: |cffffcc00/aql chain <part of quest name>|r")
                end
            end

            if targetQuestID then
                targetTitle = AutoQuestLearner.questlog[targetQuestID].title
                -- The chain data is keyed by this addon's bundled
                -- numeric quest IDs specifically -- questlog keys can
                -- be a title string instead (same alias reasoning used
                -- throughout this addon), so resolve a real numeric ID
                -- via GetQuestIDs() when the questlog key itself isn't
                -- already one.
                local numericID = tonumber(targetQuestID)
                if not numericID then
                    local qlogid = AutoQuestLearner.questlog[targetQuestID].qlogid
                    local resolved = qlogid and AutoQuestLearner.db and AutoQuestLearner.db:GetQuestIDs(qlogid)
                    numericID = resolved and resolved[1] and tonumber(resolved[1])
                end

                local nextQuestID = numericID and AutoQuestLearnerQuestChain[numericID]
                if not nextQuestID then
                    print("|cff00ff00AutoQuestLearner:|r \"" .. tostring(targetTitle) .. "\" -- no known follow-up quest in this addon's data. (Might genuinely be a one-off, or just not covered by this dataset.)")
                else
                    local nextLoc = AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][nextQuestID]
                    local nextTitle = nextLoc and nextLoc.T
                    if nextTitle then
                        print("|cff00ff00AutoQuestLearner:|r \"" .. tostring(targetTitle) .. "\" |cff00ccff->|r \"" .. nextTitle .. "\"")
                    else
                        print("|cff00ff00AutoQuestLearner:|r \"" .. tostring(targetTitle) .. "\" leads to a known quest ID, but its name isn't in this addon's data.")
                    end
                end
            end
        end
    elseif msg == "zone" then
        if not (AutoQuestLearner.db and AutoQuestLearner.db.GetZoneCompletion) then
            print("|cff00ff00AutoQuestLearner:|r Database module not loaded.")
        else
            local total, done, incompleteTitles, mapID = AutoQuestLearner.db:GetZoneCompletion()
            local zoneName = (AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
                and AutoQuestLearnerData.zones["loc"][mapID]) or "this zone"
            if total == 0 then
                print(string.format("|cff00ff00AutoQuestLearner:|r No known quests for %s in the bundled database.", zoneName))
            else
                local pct = math.floor(done / total * 100)
                print(string.format("|cff00ff00AutoQuestLearner:|r %s: %d/%d known quests done (%d%%)",
                    zoneName, done, total, pct))
                if table.getn(incompleteTitles) > 0 then
                    print("  Remaining (up to 15 shown):")
                    for _, title in pairs(incompleteTitles) do
                        print("    - " .. title)
                    end
                end
                print("  |cff888888Counts quests whose giver is known to be in this zone -- not every quest ever available here, just what's in this addon's bundled+learned database.|r")
            end
        end
    elseif msg == "route" then
        if not AutoQuestLearner_PlanRoute then
            print("|cff00ff00AutoQuestLearner:|r Route planner not loaded.")
        else
            local route = AutoQuestLearner_PlanRoute()
            if not route then
                print("|cff00ff00AutoQuestLearner:|r Couldn't determine your position or quest log right now.")
            elseif table.getn(route) == 0 then
                print("|cff00ff00AutoQuestLearner:|r No quests with a known location in this zone right now -- nothing to route.")
            else
                print(string.format("|cff00ff00AutoQuestLearner:|r Suggested order (%d stop%s, this zone only):",
                    table.getn(route), table.getn(route) == 1 and "" or "s"))
                for i, stop in ipairs(route) do
                    local label = stop.name and (stop.title .. " -- " .. stop.name) or stop.title
                    local chainHint = ""
                    if stop.chainNext then
                        chainHint = (type(stop.chainNext) == "string")
                            and (" |cff00ccff-> leads to " .. stop.chainNext .. "|r")
                            or " |cff00ccff-> leads to another quest|r"
                    end
                    -- Same distance unit the arrow itself already
                    -- displays (raw zone-percentage points, not yards --
                    -- there's no fixed yards-per-point ratio across
                    -- zones of different physical sizes, so showing a
                    -- converted number would mean fabricating a
                    -- conversion factor with no way to verify it).
                    print(string.format("  %d. %s (Distance: %.1f)%s", i, label, stop.distFromPrev, chainHint))
                end
                print("  |cff888888Straight-line order, greedy nearest-stop routing -- doesn't account for terrain, walls, or actual walking paths. Distance is the same unit the arrow shows.|r")
            end
        end
    elseif msg == "perfdebug" then
        if not AutoQuestLearner_PerfDebug then
            print("|cff00ff00AutoQuestLearner:|r Not loaded yet.")
        elseif AutoQuestLearner_PerfDebug.active then
            print("|cff00ff00AutoQuestLearner:|r Already running -- wait for the current window to finish.")
        else
            local ok = pcall(debugprofilestop)
            if not ok then
                print("|cff00ff00AutoQuestLearner:|r debugprofilestop() isn't available on this client -- can't measure timing this way. The disable-and-compare FPS test from /aql perf is the fallback.")
            else
                AutoQuestLearner_PerfDebug.totals = {}
                AutoQuestLearner_PerfDebug.calls = {}
                AutoQuestLearner_PerfDebug.active = true
                print("|cff00ff00AutoQuestLearner:|r Timing for 10 seconds -- move around and quest normally, don't just stand still (this measures real usage, not idle state).")
                local dbgFrame = CreateFrame("Frame")
                local dbgElapsed = 0
                dbgFrame:SetScript("OnUpdate", function(self, e)
                    dbgElapsed = dbgElapsed + (e or 0)
                    if dbgElapsed < 10 then return end
                    self:SetScript("OnUpdate", nil)
                    AutoQuestLearner_PerfDebug.active = false
                    local totals = AutoQuestLearner_PerfDebug.totals
                    local calls = AutoQuestLearner_PerfDebug.calls
                    local names = {}
                    for k in pairs(totals) do table.insert(names, k) end
                    table.sort(names, function(a, b) return totals[a] > totals[b] end)
                    print("|cff00ff00AutoQuestLearner:|r Results (10 second window, real time spent per function):")
                    if table.getn(names) == 0 then
                        print("  Nothing measured -- none of the instrumented functions ran during this window.")
                    else
                        for _, name in pairs(names) do
                            print(string.format("  %s: %.1f ms total over %d call(s) (%.2f ms avg)",
                                name, totals[name], calls[name] or 0, totals[name] / (calls[name] or 1)))
                        end
                        print("  For reference: 16.7ms budget per frame at 60fps, 33ms at 30fps -- a function's TOTAL here versus that budget shows roughly how much it could be costing.")
                    end
                end)
            end
        end
    elseif msg == "tracker" then
        if AutoQuestLearnerTracker then
            if AutoQuestLearnerTracker:IsShown() then
                AutoQuestLearnerTracker:Hide()
                print("|cff00ff00AutoQuestLearner:|r Tracker hidden.")
            else
                AutoQuestLearnerTracker:Show()
                print("|cff00ff00AutoQuestLearner:|r Tracker shown.")
            end
        else
            print("|cff00ff00AutoQuestLearner:|r Tracker module not loaded.")
        end
    elseif msg == "blizztracker" then
        if AutoQuestLearnerDB.config.hideblizzardtracker == "0" then
            AutoQuestLearnerDB.config.hideblizzardtracker = "1"
            print("|cff00ff00AutoQuestLearner:|r Blizzard's default quest tracker hidden.")
        else
            AutoQuestLearnerDB.config.hideblizzardtracker = "0"
            print("|cff00ff00AutoQuestLearner:|r Blizzard's default quest tracker restored.")
        end
        AutoQuestLearner_UpdateBlizzardTrackerVisibility()
    elseif msg == "unpin" then
        if AutoQuestLearner.pinnedQuestID then
            print("|cff00ff00AutoQuestLearner:|r Unpinned. Arrow back to auto-select.")
            AutoQuestLearner.pinnedQuestID = nil
        else
            print("|cff00ff00AutoQuestLearner:|r No quest is currently pinned.")
        end
    elseif msg == "clusterdebug" then
        AutoQuestLearner_ClusterDebug = not AutoQuestLearner_ClusterDebug
        print("|cff00ff00AutoQuestLearner:|r Cluster merge debug " .. (AutoQuestLearner_ClusterDebug and "enabled -- open the world map to see it" or "disabled") .. ".")
    elseif msg == "export" then
        local exportString = AutoQuestLearner_ExportLearnedLocations()
        StaticPopupDialogs["AUTOQUESTLEARNER_EXPORTCOPY"].data = exportString
        local dialog = StaticPopup_Show("AUTOQUESTLEARNER_EXPORTCOPY")
        if dialog then
            _G[dialog:GetName().."Button1"]:ClearAllPoints()
            _G[dialog:GetName().."Button1"]:SetPoint("BOTTOM", dialog, "BOTTOM", 0, 16)
            _G[dialog:GetName().."WideEditBox"]:SetScript('OnTextChanged', StaticPopup_EditBoxOnTextChanged)
            dialog:SetWidth(420)
        end
    elseif msg == "import" then
        StaticPopup_Show("AUTOQUESTLEARNER_IMPORTPASTE")
    elseif msg == "sync" then
        print("|cff00ff00AutoQuestLearner:|r Location sync status")
        print("  Share with Party/Raid: " .. (AutoQuestLearnerDB.config.syncParty == "1" and "|cff00ff00on|r" or "|cffff5555off|r"))
        print("  Share with Guild: " .. (AutoQuestLearnerDB.config.syncGuild == "1" and "|cff00ff00on|r" or "|cffff5555off|r"))
        print("  Locations received this session: " .. tostring(syncStats.received))
        print("  Actually new (applied to your database): " .. tostring(syncStats.applied))
        print("  (Toggle in /aql config -- \"Share Newly-Learned Locations with...\")")
    elseif msg == "suggestzone" then
        -- Suggests which zone(s) to level in next, based on the
        -- player's current level -- computed entirely from this
        -- addon's own bundled quest database (level ranges, giver
        -- locations), not derived from any external guide's routing.
        --
        -- Reuses the same filtering this addon already trusts for
        -- "available quest" suggestions (completion check, gating,
        -- faction, class/Ascension-custom opt-outs) rather than a
        -- separate, looser pass -- a quest that wouldn't actually be
        -- offered right now shouldn't count toward a zone's score.
        --
        -- Deliberately counts ONLY quests whose giver has real,
        -- known coordinate data -- a quest we merely know exists,
        -- with no location for it at all, can't be attributed to any
        -- specific zone in the first place, so it can't meaningfully
        -- contribute to one. This is what naturally prioritizes zones
        -- with good coverage: a zone padded with "quest exists, no
        -- location known" entries simply won't accumulate a score
        -- from them, the same way a zone genuinely light on quests
        -- wouldn't.
        local playerLevel = UnitLevel("player")
        local playerFaction = UnitFactionGroup and UnitFactionGroup("player")
        local learned = GetLearnedDB()
        local zoneCounts = {}

        for questID, questData in pairs(AutoQuestLearnerData.quests["data"]) do
            local questLoc = AutoQuestLearnerData.quests["loc"][questID]
            if questLoc then
                local shouldSkip = AutoQuestLearner_IsDeprecatedQuestTitle(questLoc.T)
                local raceField = AutoQuestLearner_GetEffectiveRaceField(questID, questData)
                if not shouldSkip and AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction) then
                    shouldSkip = true
                end
                if not shouldSkip and not AutoQuestLearner_HasRequiredSkill(questData["skill"], questID) then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearnerDB.config.trackAscensionQuests ~= "1"
                    and AutoQuestLearner_IsAscensionCustomQuest and AutoQuestLearner_IsAscensionCustomQuest(questID) then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearnerDB.config.trackClassQuests ~= "1"
                    and AutoQuestLearnerClassRestrictions and AutoQuestLearnerClassRestrictions[questID] then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearnerQuestReputation and AutoQuestLearnerQuestReputation[questID]
                    and not AutoQuestLearner_HasRequiredReputation(AutoQuestLearnerQuestReputation[questID]) then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearnerDB.pvpRequired and AutoQuestLearnerDB.pvpRequired[questID]
                    and not (UnitIsPVP and UnitIsPVP("player")) then
                    shouldSkip = true
                end

                local minLevel = questData["min"] or 0
                local questLevel = questData["lvl"] or minLevel
                -- Same window philosophy as the existing high/low-level
                -- filters, but not gated behind those toggles here --
                -- this command is specifically about "what's actually
                -- appropriate right now", so it always applies a
                -- sensible window regardless of the separate arrow-
                -- suggestion settings.
                if not shouldSkip and (questLevel > playerLevel + 3 or questLevel < playerLevel - 5) then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearner_IsQuestCompleted(questID, questLoc.T) then
                    shouldSkip = true
                end
                if not shouldSkip and not AutoQuestLearner_MeetsQuestGating(questID) then
                    shouldSkip = true
                end
                if not shouldSkip and AutoQuestLearner.questlog and
                    (AutoQuestLearner.questlog[questID] or (questLoc.T and AutoQuestLearner.questlog[questLoc.T])) then
                    shouldSkip = true
                end

                if not shouldSkip and questData["start"] then
                    -- A quest can have multiple valid giver locations
                    -- (e.g. one per faction hub) -- count it once per
                    -- DISTINCT zone it's known to be pickable in, not
                    -- once per individual coordinate, so a giver with
                    -- many spawn points in one zone doesn't inflate
                    -- that zone's score relative to its actual quest
                    -- variety.
                    local zonesForThisQuest = {}
                    local function collectZones(idSet, dataTable)
                        if not idSet then return end
                        for _, id in pairs(idSet) do
                            local entryData = dataTable[id]
                            if entryData and entryData["coords"] then
                                for _, coord in pairs(entryData["coords"]) do
                                    zonesForThisQuest[coord[3]] = true
                                end
                            end
                        end
                    end
                    collectZones(questData["start"]["U"], AutoQuestLearnerData.units["data"])
                    collectZones(questData["start"]["O"], AutoQuestLearnerData.objects["data"])

                    -- Zone-based faction fallback only matters when
                    -- the quest had no explicit race field at all (see
                    -- FACTION_EXCLUSIVE_ZONES above) -- an explicit
                    -- race field was already handled by the shouldSkip
                    -- check earlier and applies regardless of zone.
                    if not raceField or raceField == 0 then
                        for zoneID in pairs(zonesForThisQuest) do
                            if AutoQuestLearner_IsWrongFactionQuest(nil, playerFaction, zoneID) then
                                zonesForThisQuest[zoneID] = nil
                            end
                        end
                    end

                    -- BUGFIX: confirmed real -- personally-learned
                    -- giver/turn-in locations weren't being considered
                    -- at all here, only the static bundled database.
                    -- A quest whose only known location is something
                    -- YOU learned (not in the bundled data at all)
                    -- would previously count toward zero zones, even
                    -- though the arrow itself would happily guide you
                    -- there using exactly that data. Learned data is
                    -- account-wide, so this reflects everything learned
                    -- by every character, not just whichever one is
                    -- currently logged in.
                    local learnedEntry = GetLearnedQuestEntry(learned, questID, questLoc.T)
                    if learnedEntry then
                        if learnedEntry.giver and learnedEntry.giver.mapID then
                            zonesForThisQuest[learnedEntry.giver.mapID] = true
                        end
                        if learnedEntry.turnin and learnedEntry.turnin.mapID then
                            zonesForThisQuest[learnedEntry.turnin.mapID] = true
                        end
                    end

                    for zoneID in pairs(zonesForThisQuest) do
                        zoneCounts[zoneID] = (zoneCounts[zoneID] or 0) + 1
                    end
                end
            end
        end

        -- FEATURE (per user request): rank primarily by the canonical
        -- guide-derived zone list (CANONICAL_LEVELING_ZONES, above)
        -- instead of purely by this addon's own known-location quest
        -- count -- a zone that's genuinely the "correct" leveling zone
        -- for this level/race/faction should win even if this addon's
        -- coordinate coverage happens to be slightly better in some
        -- other zone. The known-quest count computed above (zoneCounts)
        -- is kept as a per-zone coverage figure shown alongside each
        -- suggestion, and as a tiebreaker between equally-ranked guide
        -- entries, and the OLD pure-count ranking is kept as a fallback
        -- for anything the guide table doesn't cover at all (e.g.
        -- levels beyond 70, or Ascension-specific custom leveling
        -- ranges the static list has no knowledge of).
        local _, playerEnglishRace = UnitRace("player")

        local guideMatches = {}
        for _, z in ipairs(CANONICAL_LEVELING_ZONES) do
            local mapID, minLvl, maxLvl, faction, race, tier = z[1], z[2], z[3], z[4], z[5], z[6]
            local factionOK = (not faction) or (faction == playerFaction)
            local raceOK = (not race) or (race == playerEnglishRace)
            -- A small +/-2 tolerance window lets this suggest the NEXT
            -- zone slightly early or the CURRENT one slightly late,
            -- matching how these guides are actually used in practice
            -- (nobody stops questing exactly at the listed cutoff).
            local inWindow = playerLevel >= (minLvl - 2) and playerLevel <= (maxLvl + 2)
            if factionOK and raceOK and inWindow then
                local exactFit = playerLevel >= minLvl and playerLevel <= maxLvl
                table.insert(guideMatches, {
                    zoneID = mapID,
                    tier = tier,
                    exactFit = exactFit,
                    count = zoneCounts[mapID] or 0,
                    minLvl = minLvl,
                    maxLvl = maxLvl,
                })
            end
        end

        if table.getn(guideMatches) > 0 then
            table.sort(guideMatches, function(a, b)
                if a.tier ~= b.tier then return a.tier < b.tier end
                if a.exactFit ~= b.exactFit then return a.exactFit end
                return a.count > b.count
            end)
            print("|cff00ff00AutoQuestLearner:|r Suggested zones for a level " .. playerLevel .. " " ..
                tostring(playerFaction or "character") .. " (based on standard leveling-zone progression):")
            local shown, seen = 0, {}
            for _, entry in ipairs(guideMatches) do
                if shown >= 5 then break end
                if not seen[entry.zoneID] then
                    seen[entry.zoneID] = true
                    local zoneName = (AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
                        and AutoQuestLearnerData.zones["loc"][entry.zoneID]) or ("Zone " .. tostring(entry.zoneID))
                    local coverage = entry.count > 0
                        and string.format("%d known quest(s) in our database", entry.count)
                        or "no known-location quests in our database yet -- the arrow may have limited coverage here"
                    print(string.format("  %d. %s (levels %d-%d) -- %s", shown + 1, zoneName, entry.minLvl, entry.maxLvl, coverage))
                    shown = shown + 1
                end
            end
        else
            -- Fallback: no canonical guide entry covers this level (or
            -- this level/faction/race combination) at all -- fall back
            -- to the original known-location-quest-count ranking so
            -- higher-level/custom-content characters still get a real
            -- answer instead of nothing.
            local ranked = {}
            for zoneID, count in pairs(zoneCounts) do
                table.insert(ranked, { zoneID = zoneID, count = count })
            end
            table.sort(ranked, function(a, b) return a.count > b.count end)

            if table.getn(ranked) == 0 then
                print("|cff00ff00AutoQuestLearner:|r No level-appropriate, available quests with known locations found anywhere in the bundled database right now.")
            else
                print("|cff00ff00AutoQuestLearner:|r No standard leveling-zone guide data for level " .. playerLevel ..
                    " -- falling back to known-location quest count:")
                local shown = 0
                for _, entry in ipairs(ranked) do
                    if shown >= 5 then break end
                    local zoneName = (AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"]
                        and AutoQuestLearnerData.zones["loc"][entry.zoneID]) or ("Zone " .. tostring(entry.zoneID))
                    print(string.format("  %d. %s -- %d known quest(s)", shown + 1, zoneName, entry.count))
                    shown = shown + 1
                end
            end
        end
    elseif msg == "learnedstats" then
        PrintLearnedStats()
    elseif msg == "learnedstatsauto" then
        AutoQuestLearnerDB.config.learnedStatsOnLogin = (AutoQuestLearnerDB.config.learnedStatsOnLogin == "0") and "1" or "0"
        print("|cff00ff00AutoQuestLearner:|r Automatic learned-stats display on login/reload " ..
            (AutoQuestLearnerDB.config.learnedStatsOnLogin == "0" and "disabled" or "enabled") .. ".")
    elseif msg == "calibrate" or string.find(msg, "^calibrate ") then
        print("|cff00ff00AutoQuestLearner:|r Minimap calibration status")
        AutoQuestLearnerDB.calibratedMinimap = AutoQuestLearnerDB.calibratedMinimap or {}
        AutoQuestLearnerDB.autoDetectedBadZones = AutoQuestLearnerDB.autoDetectedBadZones or {}
        AutoQuestLearnerDB.calibrationVerified = AutoQuestLearnerDB.calibrationVerified or {}
        if string.find(msg, "^calibrate reset") then
            local rawZone = AutoQuestLearnerMap and AutoQuestLearnerMap:GetMapID(nil, nil, true)
            local isTarget = rawZone and (STARTING_ZONE_TARGETS[rawZone] or AutoQuestLearnerDB.autoDetectedBadZones[rawZone])
            if isTarget then
                AutoQuestLearnerDB.calibratedMinimap[rawZone] = nil
                calibSamples[rawZone] = nil
                print("  Reset calibration for your current zone -- it'll start measuring again as you move.")
            elseif rawZone then
                AutoQuestLearnerDB.calibrationVerified[rawZone] = nil
                calibSamples[rawZone] = nil
                print("  Your current zone wasn't flagged as needing calibration -- cleared its 'verified good' status so it'll be sanity-checked again.")
            end
        else
            for rawID in pairs(STARTING_ZONE_TARGETS) do
                local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"] and AutoQuestLearnerData.zones["loc"][rawID]
                local done = AutoQuestLearnerDB.calibratedMinimap[rawID]
                if done then
                    print(string.format("  %s (id %s): calibrated -- %.0f x %.0f yards", tostring(zoneName or rawID), tostring(rawID), done[1], done[2]))
                else
                    local s = calibSamples[rawID]
                    local w = s and table.getn(s.widths) or 0
                    local h = s and table.getn(s.heights) or 0
                    local dbc = AutoQuestLearnerStartingZoneDimensions and AutoQuestLearnerStartingZoneDimensions[rawID]
                    local interim = dbc and string.format(" (using a %.0f x %.0f estimate in the meantime)", dbc[1], dbc[2]) or ""
                    print(string.format("  %s (id %s): not yet fully calibrated -- %d/%d width samples, %d/%d height samples%s",
                        tostring(zoneName or rawID), tostring(rawID), w, MIN_CALIBRATION_SAMPLES, h, MIN_CALIBRATION_SAMPLES, interim))
                end
            end
            local autoCount = 0
            for rawID in pairs(AutoQuestLearnerDB.autoDetectedBadZones) do
                autoCount = autoCount + 1
                local zoneName = AutoQuestLearnerData.zones and AutoQuestLearnerData.zones["loc"] and AutoQuestLearnerData.zones["loc"][rawID]
                local done = AutoQuestLearnerDB.calibratedMinimap[rawID]
                if done then
                    print(string.format("  [auto-detected] %s (id %s): calibrated -- %.0f x %.0f yards", tostring(zoneName or rawID), tostring(rawID), done[1], done[2]))
                else
                    local s = calibSamples[rawID]
                    local w = s and table.getn(s.widths) or 0
                    local h = s and table.getn(s.heights) or 0
                    print(string.format("  [auto-detected] %s (id %s): not yet calibrated -- %d/%d width samples, %d/%d height samples",
                        tostring(zoneName or rawID), tostring(rawID), w, MIN_CALIBRATION_SAMPLES, h, MIN_CALIBRATION_SAMPLES))
                end
            end
            local verifiedCount = 0
            for _ in pairs(AutoQuestLearnerDB.calibrationVerified) do verifiedCount = verifiedCount + 1 end
            print(string.format("  Auto-detection: %d zone(s) found needing calibration beyond the known 6, %d zone(s) sanity-checked as fine.", autoCount, verifiedCount))
            print("  (Use '/aql calibrate reset' while standing in a flagged zone to re-measure it.)")
        end
    elseif msg == "questitems" then
        print("|cff00ff00AutoQuestLearner:|r Quest item panel diagnostics")
        print("  config enabled: " .. tostring(AutoQuestLearnerDB.config.questitembuttons))
        print("  InCombatLockdown(): " .. tostring(InCombatLockdown and InCombatLockdown()))
        if not GetNumQuestWatches then
            print("  GetNumQuestWatches API not available on this client")
        else
            local numWatches = GetNumQuestWatches()
            print("  GetNumQuestWatches(): " .. tostring(numWatches))
            for i = 1, numWatches do
                local questIndex = GetQuestIndexForWatch(i)
                if questIndex then
                    local qtitle = GetQuestLogTitle(questIndex)
                    local link, item, charges = GetQuestLogSpecialItemInfo(questIndex)
                    print(string.format("    watch %d: [%s] questIndex=%s -- item=%s",
                        i, tostring(qtitle), tostring(questIndex), tostring(item)))
                else
                    print("    watch " .. i .. ": GetQuestIndexForWatch returned nil")
                end
            end
        end
        print("  Forcing a fresh update...")
        AutoQuestLearner_UpdateQuestItemButtons()
        print("  Last error: " .. tostring(questItemButtonsLastError))
        print("  Panel shown: " .. tostring(AutoQuestLearnerQuestItemPanel and AutoQuestLearnerQuestItemPanel:IsShown()))
        if AutoQuestLearnerQuestItemPanel then
            local point, _, _, x, y = AutoQuestLearnerQuestItemPanel:GetPoint()
            print("  Panel position: point=" .. tostring(point) .. " x=" .. tostring(x) .. " y=" .. tostring(y))
        end
        print("  (Shift-drag the panel to move it anywhere on screen)")
    elseif msg == "opendb" or string.find(msg, "^opendb ") then
        -- Opens the Ascension Database page for a quest, using the
        -- same client-provided function QuestLink uses
        -- (OpenAscensionDBURL) -- this isn't the addon fetching data,
        -- it's telling the OS to open a browser tab, same as clicking
        -- a hyperlink. Nothing comes back into the addon; your browser
        -- renders the actual page (which sidesteps that site's heavy
        -- JavaScript rendering entirely).
        -- NOTE: named "opendb" rather than "db" because "db" was
        -- already taken by the learned-database-stats command above.
        if not OpenAscensionDBURL then
            print("|cffff0000AutoQuestLearner:|r This client doesn't provide OpenAscensionDBURL -- can't open the database from here.")
        else
            local explicitID = string.match(msg, "^opendb%s+(%d+)$")
            local questID = explicitID and tonumber(explicitID)
            if not questID then
                local selection = GetQuestLogSelection and GetQuestLogSelection()
                if selection and selection > 0 then
                    questID = select(9, GetQuestLogTitle(selection))
                end
            end
            if questID then
                OpenAscensionDBURL("?quest=" .. questID)
            else
                print("|cffff0000AutoQuestLearner:|r No quest selected in your quest log, and no quest ID given.")
                print("  Usage: /aql opendb (with a quest selected/open in your quest log), or /aql opendb 641 (a specific quest ID)")
            end
        end
    elseif msg == "arrow" then
        print("|cff00ff00AutoQuestLearner:|r Arrow diagnostics")
        print("  Pinned quest ID: " .. tostring(AutoQuestLearner.pinnedQuestID) .. " (nil = auto-select mode)")
        print("  navArrow setting: " .. tostring(AutoQuestLearnerDB.config.navArrow))
        print("  Arrow frame alpha: " .. tostring(AutoQuestLearner.arrow and AutoQuestLearner.arrow:GetAlpha()) ..
            " (0 = invisible, 1 = visible)")
        if AutoQuestLearner.arrow then
            local cx, cy = AutoQuestLearner.arrow:GetCenter()
            print("  Arrow screen position (center): x=" .. tostring(cx) .. " y=" .. tostring(cy) ..
                " (nil means the frame has never been laid out at all)")
            print("  Arrow size: " .. tostring(AutoQuestLearner.arrow:GetWidth()) .. "x" .. tostring(AutoQuestLearner.arrow:GetHeight()))
            print("  Arrow strata: " .. tostring(AutoQuestLearner.arrow:GetFrameStrata()))
            print("  Arrow model texture set: " .. tostring(AutoQuestLearner.arrow.model and AutoQuestLearner.arrow.model:GetTexture()))
        end
        local ok, loc, title, npcName = pcall(FindClosestQuestDestination)
        local px, py, pz = GetPlayerPos()
        local heightReason = ""
        if not pz then
            if not UnitPosition then
                heightReason = " (UnitPosition doesn't exist on this server at all -- likely stripped server-side, common anti-cheat measure on private servers)"
            else
                local callOK, _, _, testZ = pcall(UnitPosition, "player")
                heightReason = " (UnitPosition exists but " .. (callOK and ("returned nil -- " .. tostring(testZ)) or "errored when called") .. ")"
            end
        end
        print("  Your position: x=" .. tostring(px) .. " y=" .. tostring(py) .. " mapID=" .. tostring(GetCurrentMap()) ..
            " z=" .. tostring(pz) .. heightReason)
        if not ok then
            print("  |cffff0000FindClosestQuestDestination() errored:|r " .. tostring(loc))
        elseif not loc then
            print("  FindClosestQuestDestination() found no candidate (nothing known in current zone for your active quests).")
        else
            print("  Closest destination: " .. tostring(title) .. (npcName and (" -- " .. npcName) or ""))
            print("  Location: x=" .. tostring(loc.x) .. " y=" .. tostring(loc.y) .. " mapID=" .. tostring(loc.mapID) ..
                " z=" .. tostring(loc.z))
            print("  Current zone mapID: " .. tostring(GetCurrentMap()))
            if pz and loc.z then
                local diff = loc.z - pz
                print(string.format("  Height difference: %.1f yards (%s) -- %s",
                    math.abs(diff), diff > 0 and "target is above you" or "target is below you",
                    math.abs(diff) > 10 and "|cffff8800likely a different floor|r" or "probably the same floor"))
            end
        end

        -- Per-quest breakdown: exactly why each active quest does or
        -- doesn't have a usable destination right now.
        print("  |cffffcc00Per-quest breakdown:|r")
        local currentZone = GetCurrentMap()
        local learned = GetLearnedDB()
        if AutoQuestLearner.questlog then
            for questID, logData in pairs(AutoQuestLearner.questlog) do
                local questTitle = logData.title or ("Quest " .. tostring(questID))
                local staticQuest = AutoQuestLearnerData.quests["data"][questID]
                local questEntry = GetLearnedQuestEntry(learned, questID, questTitle)

                local hasStatic = staticQuest and (staticQuest["end"] or staticQuest["obj"]) and true or false
                local staticCoordCount, staticCoordInZone = 0, 0
                if staticQuest then
                    local function countIDs(idSet, idType)
                        if not idSet then return end
                        for _, id in pairs(idSet) do
                            local data = idType == "U" and AutoQuestLearnerData.units["data"][id]
                                or idType == "O" and AutoQuestLearnerData.objects["data"][id]
                                or idType == "A" and AutoQuestLearnerData.areatrigger["data"][id]
                            if data and data["coords"] then
                                for _, c in pairs(data["coords"]) do
                                    staticCoordCount = staticCoordCount + 1
                                    if c[3] == currentZone then
                                        staticCoordInZone = staticCoordInZone + 1
                                    end
                                end
                            end
                        end
                    end
                    if staticQuest["end"] then
                        countIDs(staticQuest["end"]["U"], "U")
                        countIDs(staticQuest["end"]["O"], "O")
                    end
                    if staticQuest["obj"] then
                        countIDs(staticQuest["obj"]["U"], "U")
                        countIDs(staticQuest["obj"]["O"], "O")
                        countIDs(staticQuest["obj"]["A"], "A")
                        if staticQuest["obj"]["I"] and AutoQuestLearner_ResolveItemSources then
                            for _, itemID in pairs(staticQuest["obj"]["I"]) do
                                local sources = AutoQuestLearner_ResolveItemSources(itemID)
                                for _, src in pairs(sources) do
                                    countIDs({ src.id }, src.type)
                                end
                            end
                        end
                    end
                end

                local hasLearned = (questEntry and (questEntry.giver or questEntry.turnin)) and true or false
                local diagObjectives = GetLearnedObjectives(learned, questID, questTitle)
                local hasLearnedObj = diagObjectives and next(diagObjectives) and true or false

                print(string.format("    [%s] questID=%s -- static: %s (coords: %d total, %d in this zone) | learned giver/turnin: %s | learned objectives: %s",
                    questTitle, tostring(questID), tostring(hasStatic), staticCoordCount, staticCoordInZone, tostring(hasLearned), tostring(hasLearnedObj)))

                -- Print the actual learned spawn coordinates (not just
                -- whether they exist) so a wrong learned location can be
                -- told apart from the priority logic failing to use it.
                if diagObjectives then
                    for objIndex, obj in pairs(diagObjectives) do
                        local spawns = obj.spawns or {}
                        local shown = 0
                        for _, spawn in pairs(spawns) do
                            shown = shown + 1
                            if shown <= 5 then
                                print(string.format("        objIndex=%s spawn: x=%.1f y=%.1f mapID=%s%s",
                                    tostring(objIndex), spawn.x, spawn.y, tostring(spawn.mapID),
                                    spawn.mapID == currentZone and "" or "  |cffff8800(different zone!)|r"))
                            end
                        end
                        if shown > 5 then
                            print(string.format("        ... and %d more spawn(s) for objIndex=%s", shown - 5, tostring(objIndex)))
                        end
                    end
                end
            end
        end
    elseif string.match(msg, "^why$") or string.match(msg, "^why%s+%d+$") then
        local explicitID = string.match(msg, "^why%s+(%d+)$")
        local questID = explicitID and tonumber(explicitID)
        if not questID then
            local selection = GetQuestLogSelection and GetQuestLogSelection()
            if selection and selection > 0 then
                questID = select(9, GetQuestLogTitle(selection))
            end
        end
        if not questID then
            print("|cffff0000AutoQuestLearner:|r No quest selected in your quest log, and no quest ID given.")
            print("  Usage: /aql why (with a quest selected/open in your quest log), or /aql why 8466 (a specific quest ID)")
        else
            local questLoc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
            local questTitle = questLoc and questLoc.T or ("Quest " .. tostring(questID))
            print("|cff00ff00AutoQuestLearner:|r Gating breakdown for [" .. questID .. "] " .. questTitle)

            local function describeQuest(id)
                local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][id]
                local title = loc and loc.T or ("Quest " .. tostring(id))
                local completed = AutoQuestLearner_IsQuestCompleted(id, loc and loc.T)
                local repeatableSeen = AutoQuestLearnerDB.repeatable and (AutoQuestLearnerDB.repeatable[id] or (loc and loc.T and AutoQuestLearnerDB.repeatable[loc.T])) and true or false
                local repeatableFlagged = AutoQuestLearnerQuestExFlags and AutoQuestLearnerQuestExFlags[id]
                    and bit.band(AutoQuestLearnerQuestExFlags[id], 1) ~= 0
                local viaServer = serverCompletedQuests[id] and true or false
                local viaHistoryID = AutoQuestLearnerDB.history and AutoQuestLearnerDB.history[id] and true or false
                local viaHistoryTitle = AutoQuestLearnerDB.history and loc and loc.T and AutoQuestLearnerDB.history[loc.T] and true or false
                return string.format("[%s] %s -- completed=%s (server=%s, history-by-id=%s, history-by-title=%s, seen-repeatable=%s, flagged-repeatable=%s)",
                    tostring(id), title, tostring(completed), tostring(viaServer), tostring(viaHistoryID), tostring(viaHistoryTitle),
                    tostring(repeatableSeen), tostring(repeatableFlagged))
            end

            local prereqIDs = AutoQuestLearner_GetQuestPrerequisites and AutoQuestLearner_GetQuestPrerequisites(questID)
            if prereqIDs and table.getn(prereqIDs) > 0 then
                print("  AND-prerequisites (ALL must be complete):")
                for _, prereqID in ipairs(prereqIDs) do
                    print("    " .. describeQuest(prereqID))
                end
            else
                print("  AND-prerequisites: none known.")
            end

            local preGroup = AutoQuestLearnerQuestPreGroup and AutoQuestLearnerQuestPreGroup[questID]
            if preGroup then
                print("  OR-prerequisite group (ANY ONE must be complete):")
                for _, altID in ipairs(preGroup) do
                    print("    " .. describeQuest(altID))
                end
            else
                print("  OR-prerequisite group: none known.")
            end

            local parentID = AutoQuestLearnerQuestParent and AutoQuestLearnerQuestParent[questID]
            if parentID then
                local inLog = AutoQuestLearner.questlog and AutoQuestLearner.questlog[parentID] and true or false
                print("  Requires parent quest active in log: " .. describeQuest(parentID) .. " -- currently in your log: " .. tostring(inLog))
            else
                print("  Parent-active requirement: none known.")
            end

            local exclGroup = AutoQuestLearnerQuestExcl and AutoQuestLearnerQuestExcl[questID]
            if exclGroup then
                print("  Mutually-exclusive with:")
                for _, otherID in ipairs(exclGroup) do
                    if otherID ~= questID then
                        local inLog = AutoQuestLearner.questlog and AutoQuestLearner.questlog[otherID] and true or false
                        print("    " .. describeQuest(otherID) .. " -- currently in your log: " .. tostring(inLog))
                    end
                end
            else
                print("  Exclusion group: none known.")
            end

            local staticQuest = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["data"] and AutoQuestLearnerData.quests["data"][questID]
            if staticQuest and staticQuest["obj"] and staticQuest["obj"]["I"] then
                print("  Requires item in hand (objective): itemID=" .. tostring(staticQuest["obj"]["I"][1]))
            end

            local finalResult = AutoQuestLearner_MeetsQuestGating and AutoQuestLearner_MeetsQuestGating(questID)
            print("  |cffffcc00Final MeetsQuestGating() result:|r " .. tostring(finalResult) .. (finalResult and " (would show as available)" or " (blocked, would NOT show as available)"))
            if AutoQuestLearnerDB.knownUnavailable and AutoQuestLearnerDB.knownUnavailable[questID] then
                print("  |cffff8800Note:|r flagged as known-unavailable from a real gossip-window mismatch -- see /aql unavailable")
            end
        end
    elseif msg == "unavailable" or string.match(msg, "^unavailable%s") then
        local arg = string.match(msg, "^unavailable%s+(.*)$")
        if arg == "clear" then
            local count = 0
            if AutoQuestLearnerDB.knownUnavailable then
                for _ in pairs(AutoQuestLearnerDB.knownUnavailable) do count = count + 1 end
            end
            AutoQuestLearnerDB.knownUnavailable = {}
            AutoQuestLearner.updateQuestGivers = true
            print("|cff00ff00AutoQuestLearner:|r Cleared " .. count .. " known-unavailable flag(s). They'll be re-suggested and re-checked against gossip again.")
        elseif arg and string.match(arg, "^clear%s+%d+$") then
            local clearID = tonumber(string.match(arg, "^clear%s+(%d+)$"))
            if AutoQuestLearnerDB.knownUnavailable and AutoQuestLearnerDB.knownUnavailable[clearID] then
                AutoQuestLearnerDB.knownUnavailable[clearID] = nil
                AutoQuestLearner.updateQuestGivers = true
                print("|cff00ff00AutoQuestLearner:|r Cleared quest " .. clearID .. " from the known-unavailable list.")
            else
                print("|cff00ff00AutoQuestLearner:|r Quest " .. clearID .. " wasn't flagged.")
            end
        else
            local any = false
            print("|cff00ff00AutoQuestLearner:|r Quests flagged as known-unavailable (gossip didn't actually offer them despite passing our checks):")
            if AutoQuestLearnerDB.knownUnavailable then
                for id in pairs(AutoQuestLearnerDB.knownUnavailable) do
                    any = true
                    local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][id]
                    print("  [" .. id .. "] " .. (loc and loc.T or "unknown title"))
                end
            end
            if not any then
                print("  (none yet)")
            end
            print("  Usage: /aql unavailable clear (clear all) or /aql unavailable clear <questID> (clear one)")
        end
    elseif msg == "missing" then
        -- No WoW addon API can check "is there an NPC near this world
        -- coordinate" from a distance -- the only way this addon ever
        -- learns anything about a giver is from the player actually
        -- targeting/interacting with it. The gossip-mismatch check
        -- (knownUnavailable, elsewhere) already catches "the NPC exists
        -- but doesn't actually offer this quest" -- but that needs a
        -- gossip window to open at all, which never happens if the NPC
        -- genuinely isn't spawned here. This is the manual counterpart
        -- for exactly that case: reuses GetDisplayedAvailableQuestID
        -- (same exact-on-screen-text read the sleep/wake race fix
        -- uses) so whatever gets flagged is guaranteed to match what's
        -- actually on screen, and reuses knownUnavailable itself since
        -- the downstream effect -- stop suggesting this quest here --
        -- is identical either way.
        local questID = GetDisplayedAvailableQuestID()
        if not questID then
            print("|cffff0000AutoQuestLearner:|r The arrow isn't currently pointing at an available (not-yet-picked-up) quest -- /aql missing only applies to quest givers right now.")
        else
            AutoQuestLearnerDB.knownUnavailable = AutoQuestLearnerDB.knownUnavailable or {}
            local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
            if AutoQuestLearnerDB.knownUnavailable[questID] then
                print("|cff00ff00AutoQuestLearner:|r [" .. questID .. "] " .. (loc and loc.T or "that quest") .. " was already flagged as not actually available here.")
            else
                AutoQuestLearnerDB.knownUnavailable[questID] = true
                AutoQuestLearner.updateQuestGivers = true
                print("|cff00ff00AutoQuestLearner:|r Got it -- [" .. questID .. "] " .. (loc and loc.T or "that quest") ..
                    " noted as not actually here. Won't be suggested at this spot again until |cff00ccff/aql unavailable clear " .. questID .. "|r.")
            end
        end
    elseif msg == "floor up" or msg == "floor down" or msg == "floor clear" then
        local direction = string.match(msg, "^floor%s+(.*)$")
        local key = AutoQuestLearner.currentFloorHintKey
        local groupKey = AutoQuestLearner.currentFloorHintGroupKey
        if not key then
            print("|cffff0000AutoQuestLearner:|r You need to be standing right on an unresolved pin for this to mean anything -- the arrow isn't currently sitting on a target within range.")
        elseif direction == "clear" then
            local cleared = false
            if groupKey and AutoQuestLearnerDB.floorHintGroups and AutoQuestLearnerDB.floorHintGroups[groupKey] then
                AutoQuestLearnerDB.floorHintGroups[groupKey] = nil
                cleared = true
            end
            if AutoQuestLearnerDB.floorHints and AutoQuestLearnerDB.floorHints[key] then
                AutoQuestLearnerDB.floorHints[key] = nil
                cleared = true
            end
            print(cleared and "|cff00ff00AutoQuestLearner:|r Cleared the floor hint for this spot." or "|cff00ff00AutoQuestLearner:|r No floor hint was set for this spot.")
        elseif groupKey then
            AutoQuestLearnerDB.floorHintGroups = AutoQuestLearnerDB.floorHintGroups or {}
            AutoQuestLearnerDB.floorHintGroups[groupKey] = direction
            local questID = AutoQuestLearner.currentFloorHintQuestID
            local objIndex = AutoQuestLearner.currentFloorHintObjIndex
            local learned = GetLearnedDB and GetLearnedDB()
            local spawnCount = 0
            if learned and learned.objectives and learned.objectives[questID] and learned.objectives[questID][objIndex] then
                spawnCount = table.getn(learned.objectives[questID][objIndex].spawns or {})
            end
            print(string.format(
                "|cff00ff00AutoQuestLearner:|r Got it -- applied to this whole objective's spawn cluster (%d known spot%s). Any of them resolving to \"stuck on the pin\" will now tell you to go %s.",
                spawnCount, spawnCount == 1 and "" or "s", direction))
        else
            AutoQuestLearnerDB.floorHints = AutoQuestLearnerDB.floorHints or {}
            AutoQuestLearnerDB.floorHints[key] = direction
            print("|cff00ff00AutoQuestLearner:|r Got it -- next time the arrow brings you to this exact spot, it'll tell you to go " .. direction .. " instead of just guessing.")
        end
    elseif msg == "pvprequired" or string.match(msg, "^pvprequired%s") then
        local arg = string.match(msg, "^pvprequired%s+(.*)$")
        if arg == "clear" then
            local count = 0
            if AutoQuestLearnerDB.pvpRequired then
                for _ in pairs(AutoQuestLearnerDB.pvpRequired) do count = count + 1 end
            end
            AutoQuestLearnerDB.pvpRequired = {}
            print("|cff00ff00AutoQuestLearner:|r Cleared " .. count .. " PvP-required flag(s).")
        elseif arg and string.match(arg, "^clear%s+%d+$") then
            local clearID = tonumber(string.match(arg, "^clear%s+(%d+)$"))
            if AutoQuestLearnerDB.pvpRequired and AutoQuestLearnerDB.pvpRequired[clearID] then
                AutoQuestLearnerDB.pvpRequired[clearID] = nil
                print("|cff00ff00AutoQuestLearner:|r Cleared quest " .. clearID .. " from the PvP-required list.")
            else
                print("|cff00ff00AutoQuestLearner:|r Quest " .. clearID .. " wasn't flagged.")
            end
        else
            local any = false
            print("|cff00ff00AutoQuestLearner:|r Quests flagged as needing PvP flag (learned from the game's own error message):")
            if AutoQuestLearnerDB.pvpRequired then
                for id in pairs(AutoQuestLearnerDB.pvpRequired) do
                    any = true
                    local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][id]
                    print("  [" .. id .. "] " .. (loc and loc.T or "unknown title"))
                end
            end
            if not any then
                print("  (none yet)")
            end
            print("  Currently PvP flagged: " .. tostring(UnitIsPVP and UnitIsPVP("player") or false))
            print("  Usage: /aql pvprequired clear (clear all) or /aql pvprequired clear <questID> (clear one)")
        end
    elseif msg == "reprequired" or string.match(msg, "^reprequired%s") then
        local arg = string.match(msg, "^reprequired%s+(.*)$")
        if arg == "clear" then
            local count = 0
            if AutoQuestLearnerDB.repRequired then
                for _ in pairs(AutoQuestLearnerDB.repRequired) do count = count + 1 end
            end
            AutoQuestLearnerDB.repRequired = {}
            print("|cff00ff00AutoQuestLearner:|r Cleared " .. count .. " reputation-required flag(s).")
        elseif arg and string.match(arg, "^clear%s+%d+$") then
            local clearID = tonumber(string.match(arg, "^clear%s+(%d+)$"))
            if AutoQuestLearnerDB.repRequired and AutoQuestLearnerDB.repRequired[clearID] then
                AutoQuestLearnerDB.repRequired[clearID] = nil
                print("|cff00ff00AutoQuestLearner:|r Cleared quest " .. clearID .. " from the reputation-required list.")
            else
                print("|cff00ff00AutoQuestLearner:|r Quest " .. clearID .. " wasn't flagged.")
            end
        else
            local any = false
            print("|cff00ff00AutoQuestLearner:|r Quests flagged as needing more reputation (learned from the game's own error message):")
            if AutoQuestLearnerDB.repRequired then
                for id in pairs(AutoQuestLearnerDB.repRequired) do
                    any = true
                    local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][id]
                    print("  [" .. id .. "] " .. (loc and loc.T or "unknown title"))
                end
            end
            if not any then
                print("  (none yet)")
            end
            print("  Usage: /aql reprequired clear (clear all) or /aql reprequired clear <questID> (clear one, once you've earned enough standing)")
        end
    elseif msg == "sleep" or msg == "sleep list" or string.match(msg, "^sleep%s+%d+$") then
        local explicitID = string.match(msg, "^sleep%s+(%d+)$")
        if msg == "sleep list" then
            local any = false
            print("|cff00ff00AutoQuestLearner:|r Sleeping quests (won't be suggested on any character):")
            if AutoQuestLearnerDB.snoozed then
                for id in pairs(AutoQuestLearnerDB.snoozed) do
                    any = true
                    local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][id]
                    print("  [" .. id .. "] " .. (loc and loc.T or "unknown title"))
                end
            end
            if not any then print("  (none)") end
        else
            local questID = explicitID and tonumber(explicitID)
            if not questID then
                questID = GetDisplayedAvailableQuestID()
            end
            if not questID then
                print("|cffff0000AutoQuestLearner:|r The arrow isn't currently pointing at an available (not-yet-picked-up) quest. Give an ID instead: /aql sleep <questID>")
            else
                AutoQuestLearnerDB.snoozed = AutoQuestLearnerDB.snoozed or {}
                AutoQuestLearnerDB.snoozed[questID] = true
                AutoQuestLearner.updateQuestGivers = true
                local loc = AutoQuestLearnerData.quests and AutoQuestLearnerData.quests["loc"] and AutoQuestLearnerData.quests["loc"][questID]
                print("|cff00ff00AutoQuestLearner:|r [" .. questID .. "] " .. (loc and loc.T or "that quest") ..
                    " won't be suggested on this or any other character until you run |cff00ccff/aql wake " .. questID .. "|r.")
            end
        end
    elseif msg == "wake" or msg == "wake all" or string.match(msg, "^wake%s+%d+$") then
        local arg = string.match(msg, "^wake%s+(.*)$")
        if arg == "all" then
            local count = 0
            if AutoQuestLearnerDB.snoozed then
                for _ in pairs(AutoQuestLearnerDB.snoozed) do count = count + 1 end
            end
            AutoQuestLearnerDB.snoozed = {}
            AutoQuestLearner.updateQuestGivers = true
            print("|cff00ff00AutoQuestLearner:|r Woke up " .. count .. " sleeping quest(s).")
        else
            local questID = arg and tonumber(arg) or GetDisplayedAvailableQuestID() or arrowCachedQuestID
            if not questID then
                print("|cffff0000AutoQuestLearner:|r No quest ID given, and the arrow isn't pointing at one right now. Try /aql wake <questID> or /aql wake all.")
            elseif AutoQuestLearnerDB.snoozed and AutoQuestLearnerDB.snoozed[questID] then
                AutoQuestLearnerDB.snoozed[questID] = nil
                AutoQuestLearner.updateQuestGivers = true
                print("|cff00ff00AutoQuestLearner:|r [" .. questID .. "] woken up -- back to being suggested normally.")
            else
                print("|cff00ff00AutoQuestLearner:|r [" .. questID .. "] wasn't asleep.")
            end
        end
    elseif msg == "availrange" or string.match(msg, "^availrange%s") then
        local arg = string.match(msg, "^availrange%s+(.*)$")
        if arg and tonumber(arg) then
            AutoQuestLearnerDB.config.availableQuestRadius = tostring(tonumber(arg))
            print("|cff00ff00AutoQuestLearner:|r Available-quest search radius set to " .. arg .. ".")
        else
            local current = AutoQuestLearnerDB.config.availableQuestRadius or "20 (default)"
            print("|cff00ff00AutoQuestLearner:|r Current available-quest search radius: " .. current ..
                " -- /aql availrange <number> to change it (same 0-100 zone-percentage scale used everywhere else in this addon; smaller = arrow only picks up available quests very close by, larger = will trek further across the zone for one).")
        end
    elseif msg == "availrangeactive" or string.match(msg, "^availrangeactive%s") then
        local arg = string.match(msg, "^availrangeactive%s+(.*)$")
        if arg and tonumber(arg) then
            AutoQuestLearnerDB.config.availableQuestRadiusWhileActive = tostring(tonumber(arg))
            print("|cff00ff00AutoQuestLearner:|r Available-quest radius WHILE actively pursuing another quest set to " .. arg .. ".")
        else
            local current = AutoQuestLearnerDB.config.availableQuestRadiusWhileActive or "5 (default)"
            print("|cff00ff00AutoQuestLearner:|r Current available-quest radius while actively pursuing another quest: " .. current ..
                " -- /aql availrangeactive <number> to change it. This is the tighter radius used specifically when you already have a real, in-progress objective to head toward -- keeps an unrelated available quest's pickup from winning just for being marginally closer, unless it's genuinely on the way.")
        end
    elseif msg == "autochecknpc" then
        -- Removed, same as /aql checknpc itself (see that command) --
        -- confirmed via a real in-game taint error that calling a
        -- protected function like RunMacroText for targeting commands
        -- from addon Lua code isn't a safe execution path here,
        -- regardless of what triggers it (timer, slash command, or
        -- macro -- all three were considered and none are safe).
        print("|cffff8800AutoQuestLearner:|r This command was removed along with /aql checknpc -- both caused real taint errors in testing. Calling WoW's protected targeting functions from addon code isn't something that can be made safe here, regardless of what triggers it.")
    elseif msg == "trackascension" then
        AutoQuestLearnerDB.config.trackAscensionQuests = (AutoQuestLearnerDB.config.trackAscensionQuests == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Ascension-custom quests " ..
            (AutoQuestLearnerDB.config.trackAscensionQuests == "1" and "WILL now be suggested for pickup" or "will NOT be suggested for pickup") .. ".")
    elseif msg == "checknpc" or string.match(msg, "^checknpc%s") then
        -- Removed -- confirmed via a real in-game taint error
        -- ("AddOn 'AutoQuestLearner' tainted the call of the secure
        -- function 'RunMacroText()'"), reproduced when triggered via a
        -- macro, that calling a protected function like RunMacroText
        -- for targeting commands (/tar, /focus) from addon-defined Lua
        -- code isn't a safe execution path in WoW's security model --
        -- regardless of what triggers it. An earlier version of this
        -- note assumed a slash command (as opposed to a background
        -- timer) would be safe since it's a genuine player action; that
        -- assumption was wrong, and real testing is what caught it.
        -- Nothing else in this addon calls RunMacroText or touches
        -- target/focus, so this doesn't affect anything else here.
        print("|cffff8800AutoQuestLearner:|r This command was removed -- it caused a real taint error in testing regardless of how it was triggered (typed directly or via macro). Calling WoW's protected targeting functions from addon code isn't something that can be made safe here.")
    elseif msg == "trackclassquests" then
        AutoQuestLearnerDB.config.trackClassQuests = (AutoQuestLearnerDB.config.trackClassQuests == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Class-restricted quests " ..
            (AutoQuestLearnerDB.config.trackClassQuests == "1" and "WILL now be suggested for pickup" or "will NOT be suggested for pickup") .. ".")
    elseif msg == "zonenudge" then
        AutoQuestLearnerDB.config.zoneNudge = (AutoQuestLearnerDB.config.zoneNudge == "0") and "1" or "0"
        print("|cff00ff00AutoQuestLearner:|r Zone-completion nudge " ..
            (AutoQuestLearnerDB.config.zoneNudge == "0" and "disabled" or "enabled") .. ".")
    elseif msg == "announceparty" then
        AutoQuestLearnerDB.config.announcePartyChat = (AutoQuestLearnerDB.config.announcePartyChat == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Party chat quest announcements " ..
            (AutoQuestLearnerDB.config.announcePartyChat == "1" and "ON." or "OFF."))
    elseif msg == "announcepartyprogress" then
        AutoQuestLearnerDB.config.announcePartyProgress = (AutoQuestLearnerDB.config.announcePartyProgress == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Party chat kill/loot progress announcements " ..
            (AutoQuestLearnerDB.config.announcePartyProgress == "1" and "ON." or "OFF."))
    elseif msg == "questitemtooltip" then
        AutoQuestLearnerDB.config.questItemTooltip = (AutoQuestLearnerDB.config.questItemTooltip == "0") and "1" or "0"
        print("|cff00ff00AutoQuestLearner:|r Quest progress on item tooltips " ..
            (AutoQuestLearnerDB.config.questItemTooltip == "0" and "disabled" or "enabled") .. ".")
    elseif msg == "zonefilter" then
        if AutoQuestLearnerDB.config.trackerzonefilter == "1" then
            AutoQuestLearnerDB.config.trackerzonefilter = "0"
            print("|cff00ff00AutoQuestLearner:|r Tracker zone filter disabled -- showing quests from every zone again.")
        else
            AutoQuestLearnerDB.config.trackerzonefilter = "1"
            print("|cff00ff00AutoQuestLearner:|r Tracker zone filter enabled -- only showing quests for your current zone (plus anything pinned, plus anything we don't have location data for at all).")
        end
        if AutoQuestLearnerTracker and AutoQuestLearnerTracker.Reset then
            AutoQuestLearnerTracker.Reset()
        end
    elseif msg == "map" then
        if AutoQuestLearnerMap then
            AutoQuestLearnerMap:UpdateNodes()
            print("|cff00ff00AutoQuestLearner:|r Map nodes updated.")
        else
            print("|cff00ff00AutoQuestLearner:|r Map module not loaded.")
        end
    elseif msg == "debug" then
        PrintDebug()
    elseif msg == "debuglog" then
        -- BUGFIX: confirmed real -- AutoQuestLearner:Debug(), used
        -- throughout this addon for internal diagnostic logging, has
        -- always been gated behind AutoQuestLearnerDB.config.debug --
        -- a flag that was never settable by anything at all (not this
        -- command, which does something different, not the config
        -- panel, not the defaults table). Every debug log call in the
        -- entire addon has silently done nothing since it was written.
        -- Separate command name since /aql debug already does
        -- something else useful (a one-time diagnostic snapshot).
        AutoQuestLearnerDB.config.debug = (AutoQuestLearnerDB.config.debug == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Debug logging " ..
            (AutoQuestLearnerDB.config.debug == "1" and "ON -- internal diagnostic messages will now print to chat." or "OFF."))
    elseif msg == "mem" or msg == "memory" then
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        local kb = GetAddOnMemoryUsage and GetAddOnMemoryUsage("AutoQuestLearner") or 0
        print(string.format("|cff00ff00AutoQuestLearner:|r Memory: %.1f MB (%.0f KB). /aql gc to collect.", kb / 1024, kb))
    elseif msg == "gc" then
        local before = (GetAddOnMemoryUsage and (UpdateAddOnMemoryUsage() or true) and GetAddOnMemoryUsage("AutoQuestLearner")) or 0
        if AutoQuestLearnerMap and AutoQuestLearnerMap.PruneInactiveZoneNodes then
            local keep = AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
            AutoQuestLearnerMap:PruneInactiveZoneNodes(keep)
        end
        if collectgarbage then collectgarbage("collect") end
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        local after = GetAddOnMemoryUsage and GetAddOnMemoryUsage("AutoQuestLearner") or 0
        print(string.format("|cff00ff00AutoQuestLearner:|r GC done. %.1f MB -> %.1f MB.", before / 1024, after / 1024))
        if AutoQuestLearnerMap and AutoQuestLearnerMap.UpdateNodes then
            AutoQuestLearnerMap:UpdateNodes()
        end
    elseif msg == "lock" then
        -- BUGFIX: confirmed real -- the tracker's lock feature has
        -- never been reachable by any command, checkbox, or mechanism;
        -- the tracker has always been unlocked regardless of intent.
        AutoQuestLearnerDB.config.lock = (AutoQuestLearnerDB.config.lock == "1") and "0" or "1"
        print("|cff00ff00AutoQuestLearner:|r Tracker " ..
            (AutoQuestLearnerDB.config.lock == "1" and "locked (can't be dragged or resized)." or "unlocked."))
    else
        print("|cff00ff00AutoQuestLearner:|r Unknown command. Use /aql for config or /aql status for help.")
    end
end

------------------------------------------------------------
-- Events
------------------------------------------------------------
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("QUEST_GREETING")
frame:RegisterEvent("GOSSIP_SHOW")
frame:RegisterEvent("QUEST_DETAIL")
frame:RegisterEvent("QUEST_PROGRESS")
frame:RegisterEvent("QUEST_COMPLETE")
frame:RegisterEvent("QUEST_FINISHED")
frame:RegisterEvent("GOSSIP_CLOSED")

-- The proximity-scan ticker is a separate, dedicated frame so its
-- OnUpdate / OnInterval logic doesn't run on every game event (and so
-- it can be paused cleanly by setting its script to nil without
-- touching the main event frame).
local proximityFrame = CreateFrame("Frame")
local lastProximityScan = 0
local function ProximityTicker(self, elapsed)
    EnsureSettings()
    if not AutoQuestLearnerDB.settings.enableProximityScan then return end
    local interval = AutoQuestLearnerDB.settings.proximityInterval or 10
    local now = GetTime()
    if now - lastProximityScan < interval then return end
    lastProximityScan = now
    ProximityScan()
end
proximityFrame:SetScript("OnUpdate", ProximityTicker)

-- GOSSIP_CLOSED is interesting: when the player closes the gossip
-- window, the gossip data is wiped. We use it as a hint to re-process
-- what was on screen the next time a quest event fires (which is the
-- normal sequence: open gossip -> click a quest -> see QUEST_DETAIL).
-- So this event mostly just acts as a "you closed it" bookend; the
-- real work happens in QUEST_GREETING / GOSSIP_SHOW.
local lastGossipHadQuests = false

frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        -- Nothing to do; the .toc dependency ensures RexxarDB Lite is
        -- already bootstrapped by the time we get here.

    elseif event == "PLAYER_LOGIN" then
        EnsureSettings()
        GetChar() -- ensure per-character table exists
        MaybeAutoImportPfQuest()
        MergeCommunitySeed()
        BackfillObjectiveTargetIDs()
        if AutoQuestLearnerDB.config.learnedStatsOnLogin ~= "0" then
            PrintLearnedStats()
        end
        print("|cff00ff00AutoQuestLearner:|r Loaded. Compiled, merged, and maintained by |cffffcc00Ezinagro|r.")

    elseif event == "QUEST_GREETING" then
        -- Multi-quest greeting window is now showing. Wait one frame for
        -- the client to populate GetGossipAvailableQuests() etc., then
        -- learn from it. (In practice the data is populated before this
        -- event returns, but a defer is cheap insurance against
        -- frame-order quirks on slower clients.)
        local f = CreateFrame("Frame")
        f:SetScript("OnUpdate", function(self)
            self:SetScript("OnUpdate", nil)
            LearnFromGossip()
            lastGossipHadQuests = true
        end)

    elseif event == "GOSSIP_SHOW" then
        local f = CreateFrame("Frame")
        f:SetScript("OnUpdate", function(self)
            self:SetScript("OnUpdate", nil)
            LearnFromGossip()
            lastGossipHadQuests = true
        end)

    elseif event == "QUEST_DETAIL" then
        -- "About to accept" dialog.
        LearnFromQuestEvent("detail")

    elseif event == "QUEST_PROGRESS" then
        -- Active quest, progress window.
        LearnFromQuestEvent("progress")

    elseif event == "QUEST_COMPLETE" then
        -- About to turn in.
        LearnFromQuestEvent("complete")

    elseif event == "QUEST_FINISHED" then
        -- Fired after a quest is accepted or turned in. Useful for
        -- "accept" — combined with our event listeners above, by the
        -- time QUEST_FINISHED fires we've already learned the location
        -- via QUEST_DETAIL (accept) or QUEST_COMPLETE (turn-in), so
        -- this is just a no-op confirmation hook for future
        -- enhancements (e.g. learning turn-in NPC's name).

    elseif event == "GOSSIP_CLOSED" then
        lastGossipHadQuests = false

    elseif event == "PLAYER_TARGET_CHANGED" then
        -- New target acquired: opportunistically try the proximity scan
        -- (which is a no-op unless the target has quest relationships).
        -- Don't go through the timer — when the user clicks a new target,
        -- checking immediately is the right behavior.
        ProximityScan()
    end
end)

-- Expose functions for UI buttons
AutoQuestLearner.ProximityScan = ProximityScan
AutoQuestLearner.LearnFromGossip = LearnFromGossip
AutoQuestLearner.PrintStatus = PrintStatus

-- Quest item tooltip progress: hovering an item that's a quest
-- objective (in bags, on the ground, a vendor, anywhere GameTooltip
-- shows an item) adds a line showing which quest needs it and current
-- progress, colored red/green by completion. Purely informational --
-- GameTooltip:HookScript("OnTooltipSetItem", ...) is a standard, safe
-- UI hook used by hundreds of addons, and everything here is read-only
-- quest log querying, no protected functions of any kind.
--
-- Unlike a fixed-position display, this shows up wherever you're
-- already looking (bags, loot window, vendor, the ground), which is
-- exactly when "do I need this?" is the actual question -- and unlike
-- the single-match version this is based on, this shows EVERY quest
-- that needs the item, not just the first one found, since more than
-- one active quest can legitimately want the same item.
local function GetQuestItemProgressLines(itemName)
    local lines = {}
    local entries = GetNumQuestLogEntries()
    for i = 1, entries do
        local title = GetQuestLogTitle(i)
        if title then
            local num = GetNumQuestLeaderBoards(i)
            if num and num > 0 then
                for j = 1, num do
                    local text, objectiveType = GetQuestLogLeaderBoard(j, i)
                    if objectiveType == "item" and text then
                        local questItemName = string.match(text, "^(.-):")
                        if questItemName == itemName then
                            table.insert(lines, { title = title, progress = text })
                        end
                    end
                end
            end
        end
    end
    return lines
end

-- Resolve item name -> itemID via bundled loc table (best-effort).
local function AQL_FindItemIDByName(itemName)
    if not itemName or not AutoQuestLearnerData or not AutoQuestLearnerData.items then return nil end
    local loc = AutoQuestLearnerData.items["loc"]
    if not loc then return nil end
    local lower = string.lower(itemName)
    for id, entry in pairs(loc) do
        local n = type(entry) == "table" and (entry.T or entry[1]) or entry
        if n and string.lower(n) == lower then
            return id
        end
    end
    return nil
end

local function AQL_GetDropRateLine(itemName)
    if AutoQuestLearnerDB.config.tooltipDropRate == "0" then return nil end
    local itemID = AQL_FindItemIDByName(itemName)
    if not itemID then return nil end
    local data = AutoQuestLearnerData.items["data"] and AutoQuestLearnerData.items["data"][itemID]
    if not data or not data["U"] then return nil end
    local bestRate, bestID = 0, nil
    local count = 0
    for unitID, rate in pairs(data["U"]) do
        count = count + 1
        local r = tonumber(rate) or 0
        if r > bestRate then
            bestRate = r
            bestID = unitID
        end
    end
    if not bestID or bestRate <= 0 then return nil end
    local npcName = AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(bestID)
    local pct = bestRate
    if pct <= 1 then pct = pct * 100 end -- rates stored as fraction or percent
    if pct > 100 then pct = bestRate end
    local line = string.format("Drop: ~%.1f%%", pct)
    if npcName then
        line = line .. " (" .. npcName
        if count > 1 then line = line .. string.format(", +%d sources", count - 1) end
        line = line .. ")"
    end
    return line
end

GameTooltip:HookScript("OnTooltipSetItem", function(self)
    if AutoQuestLearnerDB.config.questItemTooltip == "0"
        and AutoQuestLearnerDB.config.tooltipDropRate == "0" then
        return
    end
    local itemName = self:GetItem()
    if not itemName then return end
    local added = false
    if AutoQuestLearnerDB.config.questItemTooltip ~= "0" then
        local matches = GetQuestItemProgressLines(itemName)
        if table.getn(matches) > 0 then
            self:AddLine(" ")
            added = true
            for _, m in pairs(matches) do
                local current, needed = string.match(m.progress, "(%d+)%s*/%s*(%d+)")
                local color = "|cffff0000"
                if current and needed and tonumber(current) >= tonumber(needed) then
                    color = "|cff00ff00"
                end
                self:AddLine("|cffffff00! Quest:|r |cffffffff" .. m.title .. "|r")
                self:AddLine(color .. m.progress .. "|r")
            end
        end
    end
    if AutoQuestLearnerDB.config.tooltipDropRate ~= "0" then
        local dropLine = AQL_GetDropRateLine(itemName)
        if dropLine then
            if not added then self:AddLine(" ") end
            self:AddLine("|cff00ff99AQL|r " .. dropLine, 0.7, 0.85, 0.7)
        end
    end
    self:Show()
end)

------------------------------------------------------------
-- Optional auto-accept / auto-turn-in (off by default)
-- Also advances QUEST_PROGRESS / QUEST_COMPLETE dialogs and,
-- when multiple rewards exist, picks the highest vendor-value
-- choice (fallback: quality + item level).
------------------------------------------------------------
local function AQL_QuestRewardScore(choiceIndex)
    local link = GetQuestItemLink and GetQuestItemLink("choice", choiceIndex)
    if not link then return 0 end
    -- GetItemInfo: on some 3.3.5 builds sellPrice is the 11th return.
    local name, _, quality, ilvl, _, _, _, _, _, _, sellPrice = GetItemInfo(link)
    if (not sellPrice or sellPrice == 0) and GetSellValue then
        local ok, v = pcall(GetSellValue, link)
        if ok and type(v) == "number" then sellPrice = v end
    end
    if sellPrice and sellPrice > 0 then
        return sellPrice
    end
    -- Fallback when sell price unknown: prefer higher quality, then ilvl
    return (quality or 0) * 100000 + (ilvl or 0)
end

local function AQL_AutoCompleteQuestReward()
    if not GetQuestReward then return end
    local choices = (GetNumQuestChoices and GetNumQuestChoices()) or 0
    if choices <= 0 then
        GetQuestReward()
        return
    end
    if choices == 1 then
        GetQuestReward(1)
        return
    end
    local bestIdx, bestScore = 1, -1
    for i = 1, choices do
        local score = AQL_QuestRewardScore(i)
        if score > bestScore then
            bestScore = score
            bestIdx = i
        end
    end
    GetQuestReward(bestIdx)
end

local autoQuestFrame = CreateFrame("Frame")
autoQuestFrame:RegisterEvent("GOSSIP_SHOW")
autoQuestFrame:RegisterEvent("QUEST_GREETING")
autoQuestFrame:RegisterEvent("QUEST_DETAIL")
autoQuestFrame:RegisterEvent("QUEST_PROGRESS")
autoQuestFrame:RegisterEvent("QUEST_COMPLETE")
autoQuestFrame:SetScript("OnEvent", function(self, event)
    local cfg = AutoQuestLearnerDB and AutoQuestLearnerDB.config
    if not cfg then return end

    if event == "GOSSIP_SHOW" then
        -- Turn-ins first so a finished quest is not skipped for a new accept.
        if cfg.autoTurnIn == "1" and GetNumGossipActiveQuests and SelectGossipActiveQuest then
            local n = GetNumGossipActiveQuests() or 0
            if n >= 1 then
                -- API returns title, level, isTrivial, isDaily, isRepeatable per quest (5 fields).
                -- When completable state is unknown, take the first active entry.
                SelectGossipActiveQuest(1)
            end
        end
        if cfg.autoAccept == "1" and GetNumGossipAvailableQuests and SelectGossipAvailableQuest then
            local n = GetNumGossipAvailableQuests() or 0
            if n >= 1 then
                SelectGossipAvailableQuest(1)
            end
        end
    elseif event == "QUEST_GREETING" then
        -- Classic "quest list" dialog (no gossip frame)
        if cfg.autoTurnIn == "1" and GetNumActiveQuests and SelectActiveQuest then
            local n = GetNumActiveQuests() or 0
            if n >= 1 then
                SelectActiveQuest(1)
            end
        end
        if cfg.autoAccept == "1" and GetNumAvailableQuests and SelectAvailableQuest then
            local n = GetNumAvailableQuests() or 0
            if n >= 1 then
                SelectAvailableQuest(1)
            end
        end
    elseif event == "QUEST_DETAIL" then
        if cfg.autoAccept == "1" and AcceptQuest then
            AcceptQuest()
        end
    elseif event == "QUEST_PROGRESS" then
        if cfg.autoTurnIn == "1" and IsQuestCompletable and IsQuestCompletable() and CompleteQuest then
            CompleteQuest()
        end
    elseif event == "QUEST_COMPLETE" then
        if cfg.autoTurnIn == "1" then
            AQL_AutoCompleteQuestReward()
        end
    end
end)

------------------------------------------------------------
-- Townsfolk map pins (flight / vendor / repair / inn)
-- Lightweight: current zone only, name-heuristic + learned merchants.
------------------------------------------------------------
local TOWNSFOLK_PATTERNS = {
    flight = { "flight master", "gryphon master", "wyvern master", "wind rider", "bat handler", "hippogryph", "dragonhawk", "flightmeister", "flugmeister" },
    vendor = { "merchant", "vendor", "trader", "quartermaster", "goods", "supplies", "general goods" },
    repair = { "repair", "armorer", "weaponsmith", "blacksmith", "armor vendor" },
    inn = { "innkeeper", "innkeeper", "hostel", "tavern" },
}

local function AQL_NameMatchesKind(name, kind)
    if not name then return false end
    local lower = string.lower(name)
    local list = TOWNSFOLK_PATTERNS[kind]
    if not list then return false end
    for _, pat in ipairs(list) do
        if string.find(lower, pat, 1, true) then return true end
    end
    return false
end

local function AQL_RefreshTownsfolkPins()
    if not AutoQuestLearnerMap or not AutoQuestLearnerMap.DeleteNode or not AutoQuestLearnerMap.AddNode then return end
    AutoQuestLearnerMap:DeleteNode("AQLTOWNSFOLK")
    local cfg = AutoQuestLearnerDB and AutoQuestLearnerDB.config
    if not cfg then return end
    local any = cfg.townsfolkFlight == "1" or cfg.townsfolkVendor == "1"
        or cfg.townsfolkRepair == "1" or cfg.townsfolkInn == "1"
    if not any then return end

    local mapID = AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap() or nil
    if not mapID then return end

    local units = AutoQuestLearnerData and AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"]
    if not units then return end

    local textures = {
        flight = "Interface\\AddOns\\AutoQuestLearner\\img\\icon_vendor",
        vendor = "Interface\\AddOns\\AutoQuestLearner\\img\\icon_vendor",
        repair = "Interface\\AddOns\\AutoQuestLearner\\img\\icon_vendor",
        inn = "Interface\\AddOns\\AutoQuestLearner\\img\\icon_vendor",
    }
    local kinds = {
        { key = "townsfolkFlight", kind = "flight", title = "Flight Master" },
        { key = "townsfolkVendor", kind = "vendor", title = "Vendor" },
        { key = "townsfolkRepair", kind = "repair", title = "Repair" },
        { key = "townsfolkInn", kind = "inn", title = "Innkeeper" },
    }

    for unitID, data in pairs(units) do
        if data and data["coords"] then
            local name = AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(unitID) or tostring(unitID)
            for _, k in ipairs(kinds) do
                if cfg[k.key] == "1" and AQL_NameMatchesKind(name, k.kind) then
                    for _, coord in pairs(data["coords"]) do
                        if coord[3] == mapID and coord[1] and coord[2] then
                            AutoQuestLearnerMap:AddNode({
                                addon = "AQLTOWNSFOLK",
                                zone = mapID,
                                x = coord[1],
                                y = coord[2],
                                title = k.title,
                                spawn = name,
                                texture = textures[k.kind],
                                layer = 5,
                            })
                        end
                    end
                end
            end
        end
    end

    -- Also plot merchants/innkeepers the player has personally visited
    local seen = AutoQuestLearnerDB.townsfolkSeen
    if seen then
        for _, entry in pairs(seen) do
            if entry.mapID == mapID and entry.x and entry.y and entry.kind then
                local enabled = (entry.kind == "flight" and cfg.townsfolkFlight == "1")
                    or (entry.kind == "vendor" and cfg.townsfolkVendor == "1")
                    or (entry.kind == "repair" and cfg.townsfolkRepair == "1")
                    or (entry.kind == "inn" and cfg.townsfolkInn == "1")
                if enabled then
                    AutoQuestLearnerMap:AddNode({
                        addon = "AQLTOWNSFOLK",
                        zone = mapID,
                        x = entry.x,
                        y = entry.y,
                        title = entry.kind,
                        spawn = entry.name or entry.kind,
                        texture = textures[entry.kind] or textures.vendor,
                        layer = 5,
                    })
                end
            end
        end
    end

    if AutoQuestLearnerMap.UpdateNodes then
        AutoQuestLearnerMap:UpdateNodes()
    end
end

local function AQL_RememberTownsfolk(kind)
    if not kind then return end
    if not UnitExists("target") or UnitIsPlayer("target") then return end
    local x, y = GetPlayerPos and GetPlayerPos() or nil
    local mapID = AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap() or nil
    if not x or not mapID then return end
    AutoQuestLearnerDB.townsfolkSeen = AutoQuestLearnerDB.townsfolkSeen or {}
    local name = UnitName("target") or kind
    local key = tostring(mapID) .. ":" .. string.lower(name) .. ":" .. kind
    AutoQuestLearnerDB.townsfolkSeen[key] = {
        x = x, y = y, mapID = mapID, name = name, kind = kind,
    }
end

local townsfolkFrame = CreateFrame("Frame")
townsfolkFrame:RegisterEvent("MERCHANT_SHOW")
townsfolkFrame:RegisterEvent("TAXIMAP_OPENED")
townsfolkFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
townsfolkFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
townsfolkFrame:SetScript("OnEvent", function(self, event)
    if event == "MERCHANT_SHOW" then
        local canRepair = CanMerchantRepair and CanMerchantRepair()
        AQL_RememberTownsfolk(canRepair and "repair" or "vendor")
        AQL_RefreshTownsfolkPins()
    elseif event == "TAXIMAP_OPENED" then
        AQL_RememberTownsfolk("flight")
        AQL_RefreshTownsfolkPins()
    else
        AQL_RefreshTownsfolkPins()
    end
end)

-- Refresh townsfolk when config toggles change via a short poll of map opens
if WorldMapFrame then
    WorldMapFrame:HookScript("OnShow", function()
        AQL_RefreshTownsfolkPins()
    end)
end


-- Ensure static DB + learned spawns are on the map after login / reload.
-- (Empty map after restart: quest queue hadn't re-run SearchQuestID yet.)
local _spawnBoot = CreateFrame("Frame")
_spawnBoot:RegisterEvent("PLAYER_ENTERING_WORLD")
_spawnBoot:SetScript("OnEvent", function(self)
  local t = 0
  self:SetScript("OnUpdate", function(self, elapsed)
    t = t + (elapsed or 0)
    if t < 1.5 then return end
    self:SetScript("OnUpdate", nil)
    if not AutoQuestLearner or not AutoQuestLearner.questlog then return end
    -- Queue a full redraw of every log quest from the static DB
    for questid, data in pairs(AutoQuestLearner.questlog) do
      if data and data.qlogid then
        local meta = { addon = "AUTOQUESTLEARNER", qlogid = data.qlogid }
        if AutoQuestLearner.db and AutoQuestLearner.db.SearchQuestID then
          pcall(function()
            AutoQuestLearner.db:SearchQuestID(questid, meta)
          end)
        end
      end
    end
    if AutoQuestLearner_ReplayLearnedLocations then
      pcall(AutoQuestLearner_ReplayLearnedLocations, nil, { force = true })
    end
    if AutoQuestLearnerMap and AutoQuestLearnerMap.UpdateNodes then
      AutoQuestLearnerMap._mmForceRebuild = true
      pcall(function() AutoQuestLearnerMap:UpdateNodes() end)
      if AutoQuestLearnerMap.UpdateMinimap then
        pcall(function() AutoQuestLearnerMap:UpdateMinimap() end)
      end
    end
  end)
end)


-- When the arrow switches tracked quest, spread work across frames
-- (delete → search → map) so one switch does not hitch the client.
local _learnedTrackFrame = CreateFrame("Frame")
local _lastLearnedTrack = nil
local _trackSwitchPhase = 0
local _trackSwitchCur = nil
local _trackSwitchPrev = nil
_learnedTrackFrame:SetScript("OnUpdate", function(self, elapsed)
  self._t = (self._t or 0) + (elapsed or 0)
  if self._t < 0.4 then return end
  self._t = 0

  -- Multi-phase switch in progress
  if _trackSwitchPhase > 0 then
    local cur, prev = _trackSwitchCur, _trackSwitchPrev
    if _trackSwitchPhase == 1 then
      if prev and AutoQuestLearnerMap then
        if AutoQuestLearnerMap.DeleteObjectiveNodes then
          pcall(function() AutoQuestLearnerMap:DeleteObjectiveNodes("AUTOQUESTLEARNER", prev) end)
        end
        if AutoQuestLearnerMap.DeleteNodeByQuestID then
          pcall(function() AutoQuestLearnerMap:DeleteNodeByQuestID("AUTOQUESTLEARNER", prev) end)
        end
      end
      _trackSwitchPhase = 2
      return
    elseif _trackSwitchPhase == 2 then
      if cur and AutoQuestLearner.db and AutoQuestLearner.db.SearchQuestID
          and AutoQuestLearner.questlog and AutoQuestLearner.questlog[cur] then
        local data = AutoQuestLearner.questlog[cur]
        pcall(function()
          AutoQuestLearner.db:SearchQuestID(cur, { addon = "AUTOQUESTLEARNER", qlogid = data.qlogid })
        end)
      end
      if cur and AutoQuestLearner_ReplayLearnedLocations then
        pcall(AutoQuestLearner_ReplayLearnedLocations, cur, { force = true, skipStatic = true })
      end
      _trackSwitchPhase = 3
      return
    else
      if AutoQuestLearnerMap then
        AutoQuestLearnerMap._mmForceRebuild = true
        if AutoQuestLearnerMap.UpdateNodes then
          pcall(function() AutoQuestLearnerMap:UpdateNodes() end)
        end
      end
      _trackSwitchPhase = 0
      _trackSwitchCur, _trackSwitchPrev = nil, nil
      return
    end
  end

  if not AutoQuestLearner_GetTrackedQuestID then return end
  local cur = AutoQuestLearner_GetTrackedQuestID()
  if cur == _lastLearnedTrack then return end
  _trackSwitchPrev = _lastLearnedTrack
  _trackSwitchCur = cur
  _lastLearnedTrack = cur
  _trackSwitchPhase = 1
end)
