-- AutoQuestLearner: persistent world-map "!" (available) and "?" (ready to
-- turn in) markers, drawn the way Questie does it: pooled icons, redrawn
-- synchronously on every map event, no throttling.
local ICON = "Interface\\AddOns\\AutoQuestLearner\\img\\"
AutoQuestLearnerMarkers = { pool = {}, shown = 0 }
local M = AutoQuestLearnerMarkers

local function Cfg() return (AutoQuestLearnerDB and AutoQuestLearnerDB.config) or {} end

local function GetPin(i)
  local p = M.pool[i]
  if p then return p end
  p = CreateFrame("Button", "AQLMapMarker" .. i, WorldMapButton)
  p:SetFrameLevel(WorldMapButton:GetFrameLevel() + 20)
  p.tex = p:CreateTexture(nil, "OVERLAY")
  p.tex:SetAllPoints(p)
  p:EnableMouse(true)
  p:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetFrameStrata("TOOLTIP")
    local cx, cy = self:GetCenter()
    local first = true
    for _, o in ipairs(M.pool) do
      if o:IsShown() then
        local ox, oy = o:GetCenter()
        if ox and cx and math.abs(ox - cx) < 14 and math.abs(oy - cy) < 14 then
          local tag = o.kind == "turnin" and "|cff66ff66(turn in)|r" or "|cffffff00(available)|r"
          if first then
            GameTooltip:SetText(tostring(o.title or "Quest") .. " " .. tag, 1, 1, 1)
            first = false
          else
            GameTooltip:AddLine(tostring(o.title or "Quest") .. " " .. tag, 1, 1, 1)
          end
          if o.name then GameTooltip:AddLine("  " .. o.name, 0.7, 0.7, 0.7) end
        end
      end
    end
    GameTooltip:Show()
  end)
  p:SetScript("OnLeave", function() GameTooltip:Hide() end)
  M.pool[i] = p
  return p
end

local function HideAll()
  for _, p in ipairs(M.pool) do p:Hide() end
  M.shown = 0
end

-- Titles currently in the real quest log (the addon's own copy can lag a
-- moment behind accept / abandon / turn-in events).
local function LiveLogTitles()
  local t = {}
  for i = 1, (GetNumQuestLogEntries and GetNumQuestLogEntries() or 0) do
    local title, _, _, _, isHeader = GetQuestLogTitle(i)
    if title and not isHeader then t[title] = true end
  end
  return t
end

function M:Refresh()
  if not WorldMapFrame or not WorldMapFrame:IsVisible() or not WorldMapButton then return end
  HideAll()
  if not AutoQuestLearnerDB or not AutoQuestLearnerDB.config then return end
  if GetCurrentMapZone() == 0 then return end
  local map = AutoQuestLearnerMap and AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
  if not map then return end
  local w, h = WorldMapButton:GetWidth(), WorldMapButton:GetHeight()
  if not w or w < 10 then return end
  local pct = tonumber(Cfg().questMarkerSize) or 100
  local size = math.floor(24 * pct / 100 + 0.5)
  local live = LiveLogTitles()
  local n = 0
  local function place(x, y, tex, kind, title, name)
    if not x or not y or x < 1 or x > 99 or y < 1 or y > 99 then return end
    n = n + 1
    local p = GetPin(n)
    p:SetWidth(size); p:SetHeight(size)
    p.tex:SetTexture(tex)
    p.kind, p.title, p.name = kind, (title and string.gsub(title, "%s*%(available%)", "") or title), name
    p:ClearAllPoints()
    p:SetPoint("CENTER", WorldMapButton, "TOPLEFT", x / 100 * w, -y / 100 * h)
    p:Show()
  end

  if Cfg().worldMapAvailable ~= "0" then
    local fn = AutoQuestLearner_GetAvailableGiversForMap
    if fn then
      local ok, list = pcall(fn, map)
      if ok and type(list) == "table" then
        for _, c in pairs(list) do
          if c.x and c.y and c.questid and (tostring(c.mapID) == tostring(map)) then
            local inlog = AutoQuestLearner.questlog and (AutoQuestLearner.questlog[c.questid]
              or AutoQuestLearner.questlog[tonumber(c.questid)])
            local skip = AutoQuestLearner_NotPickupQuest and AutoQuestLearner_NotPickupQuest(c.questid)
            local bare = c.title and string.gsub(c.title, "%s*%(available%)", "")
            if bare and live[bare] then skip = true end
            if AutoQuestLearner_IsQuestCompleted and AutoQuestLearner_IsQuestCompleted(c.questid, bare) then skip = true end
            if not inlog and not skip then
              place(c.x, c.y, ICON .. "available_c", "avail", c.title, c.name)
            end
          end
        end
      end
    end
  end
  if AutoQuestLearner_GetTurnInsForMap then
    local ok, list = pcall(AutoQuestLearner_GetTurnInsForMap, map)
    if ok and type(list) == "table" then
      for _, t in ipairs(list) do
        if live[t.title] then
          place(t.x, t.y, ICON .. "complete_c", "turnin", t.title)
        end
      end
    end
  end
  M.shown = n
end

local function SafeRefresh() pcall(M.Refresh, M) end

local f = CreateFrame("Frame")
for _, e in ipairs({ "WORLD_MAP_UPDATE", "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED_INDOORS",
    "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_TURNED_IN", "QUEST_ACCEPTED" }) do
  pcall(f.RegisterEvent, f, e)
end
local pend = {}
f:SetScript("OnEvent", function(self, event)
  if event == "QUEST_LOG_UPDATE" or event == "QUEST_TURNED_IN" or event == "QUEST_ACCEPTED" then
    AutoQuestLearner_WorldGiverCache = {}
    local now = GetTime()
    pend = { now + 0.3, now + 1.2, now + 3 }
  end
  SafeRefresh()
end)

-- Questie hooks the map's own quest-drawing; so do we, plus OnShow.
if WorldMapFrame_DisplayQuests then hooksecurefunc("WorldMapFrame_DisplayQuests", SafeRefresh) end
if WorldMapFrame then
  WorldMapFrame:HookScript("OnShow", SafeRefresh)
  WorldMapFrame:HookScript("OnHide", HideAll)
end
-- Safety net: while the map is open, re-assert pins if something hid them.
local acc = 0
f:SetScript("OnUpdate", function(self, el)
  if pend[1] and GetTime() >= pend[1] then
    table.remove(pend, 1)
    AutoQuestLearner_WorldGiverCache = {}
    SafeRefresh()
  end
  acc = acc + el
  if acc < 0.5 then return end
  acc = 0
  if WorldMapFrame and WorldMapFrame:IsVisible() and GetCurrentMapZone() ~= 0 and M.shown == 0 then
    SafeRefresh()
  end
end)
