-- AutoQuestLearner: persistent world-map "!" (available) and "?" (ready to
-- turn in) markers, drawn the way Questie does it: pooled icons, redrawn
-- synchronously on every map event, no throttling.
local ICON = "Interface\\AddOns\\AutoQuestLearner\\img\\"
AutoQuestLearnerMarkers = { pool = {}, shown = 0 }
local M = AutoQuestLearnerMarkers

local function Cfg() return (AutoQuestLearnerDB and AutoQuestLearnerDB.config) or {} end

local function GetPin(i)
  local p = M.pool[i]
  if p then return p end
  p = CreateFrame("Button", "AQLMapMarker" .. i, WorldMapButton)
  p:SetFrameLevel(WorldMapButton:GetFrameLevel() + 20)
  p.tex = p:CreateTexture(nil, "OVERLAY")
  p.tex:SetAllPoints(p)
  p:EnableMouse(true)
  p:SetFrameStrata("FULLSCREEN_DIALOG")
  p:SetScript("OnEnter", function(self) M.ShowTip(self) end)
  p:SetScript("OnLeave", function() M.HideTip() end)
  M.pool[i] = p
  return p
end

-- Own tooltip frame, a child of the map itself, so nothing about the
-- enlarged / fullscreen map can hide it or draw over it.
local function TipFrame()
  if M.tip then return M.tip end
  local t = CreateFrame("Frame", "AQLMapMarkerTip", WorldMapButton)
  t:SetFrameStrata("TOOLTIP")
  t:SetFrameLevel(200)
  t:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 14,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
  })
  t:SetBackdropColor(0, 0, 0, 0.92)
  t:SetBackdropBorderColor(0.8, 0.8, 0.8, 1)
  t.text = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  t.text:SetPoint("TOPLEFT", t, "TOPLEFT", 8, -8)
  t.text:SetJustifyH("LEFT")
  t:EnableMouse(false)
  t:Hide()
  M.tip = t
  return t
end

function M.ShowTip(self)
  M.hover = self
  local t = TipFrame()
  local cx, cy = self:GetCenter()
  local lines = {}
  for _, o in ipairs(M.pool) do
    if o:IsShown() then
      local ox, oy = o:GetCenter()
      if ox and cx and math.abs(ox - cx) < 14 and math.abs(oy - cy) < 14 then
        local tag = o.kind == "turnin" and "|cff66ff66(turn in)|r" or "|cffffff00(available)|r"
        table.insert(lines, "|cffffffff" .. tostring(o.title or "Quest") .. "|r " .. tag)
        if o.name then table.insert(lines, "|cffb3b3b3   " .. o.name .. "|r") end
      end
    end
  end
  t.text:SetText(table.concat(lines, "\n"))
  t:SetWidth(t.text:GetStringWidth() + 16)
  t:SetHeight(t.text:GetStringHeight() + 16)
  t:ClearAllPoints()
  -- Keep it inside the map: flip to the left of the pin near the right edge.
  local right = WorldMapButton:GetRight() or 0
  if (self:GetRight() or 0) + t:GetWidth() + 10 > right then
    t:SetPoint("BOTTOMRIGHT", self, "TOPLEFT", -2, 2)
  else
    t:SetPoint("BOTTOMLEFT", self, "TOPRIGHT", 2, 2)
  end
  t:Show()
end

function M.HideTip()
  M.hover = nil
  if M.tip then M.tip:Hide() end
end

-- Fullscreen map mode lets other map frames swallow the mouse, so the pins'
-- own OnEnter never fires there. Track the cursor ourselves as well.
function M.CheckHover()
  if not WorldMapFrame or not WorldMapFrame:IsVisible() then return end
  local x, y = GetCursorPosition()
  local hit
  for _, o in ipairs(M.pool) do
    if o:IsShown() then
      local sc = o:GetEffectiveScale()
      local l, r, t, b = o:GetLeft(), o:GetRight(), o:GetTop(), o:GetBottom()
      if l and sc and sc > 0 then
        local mx, my = x / sc, y / sc
        if mx >= l - 3 and mx <= r + 3 and my >= b - 3 and my <= t + 3 then hit = o break end
      end
    end
  end
  if hit then
    if M.hover ~= hit or not (M.tip and M.tip:IsShown()) then M.ShowTip(hit) end
  elseif M.hover then
    M.HideTip()
  end
end

local function HideAll()
  M.hover = nil
  if M.tip then M.tip:Hide() end
  for _, p in ipairs(M.pool) do p:Hide() end
  M.shown = 0
end

-- Titles currently in the real quest log (the addon's own copy can lag a
-- moment behind accept / abandon / turn-in events).
local function LiveLogTitles()
  local t = {}
  for i = 1, (GetNumQuestLogEntries and GetNumQuestLogEntries() or 0) do
    local title, _, _, _, isHeader = GetQuestLogTitle(i)
    if title and not isHeader then t[title] = true end
  end
  return t
end

function M:Refresh()
  if not WorldMapFrame or not WorldMapFrame:IsVisible() or not WorldMapButton then return end
  HideAll()
  if not AutoQuestLearnerDB or not AutoQuestLearnerDB.config then return end
  if GetCurrentMapZone() == 0 then return end
  local map = AutoQuestLearnerMap and AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone())
  if not map then return end
  local w, h = WorldMapButton:GetWidth(), WorldMapButton:GetHeight()
  if not w or w < 10 then return end
  local pct = tonumber(Cfg().questMarkerSize) or 100
  local size = math.floor(24 * pct / 100 + 0.5)
  local live = LiveLogTitles()
  local n = 0
  local function place(x, y, tex, kind, title, name)
    if not x or not y or x < 1 or x > 99 or y < 1 or y > 99 then return end
    n = n + 1
    local p = GetPin(n)
    p:SetWidth(size); p:SetHeight(size)
    p.tex:SetTexture(tex)
    p.kind, p.title, p.name = kind, (title and string.gsub(title, "%s*%(available%)", "") or title), name
    p:ClearAllPoints()
    p:SetPoint("CENTER", WorldMapButton, "TOPLEFT", x / 100 * w, -y / 100 * h)
    p:Show()
  end

  if Cfg().worldMapAvailable ~= "0" then
    local fn = AutoQuestLearner_GetAvailableGiversForMap
    if fn then
      local ok, list = pcall(fn, map)
      if ok and type(list) == "table" then
        for _, c in pairs(list) do
          if c.x and c.y and c.questid and (tostring(c.mapID) == tostring(map)) then
            local inlog = AutoQuestLearner.questlog and (AutoQuestLearner.questlog[c.questid]
              or AutoQuestLearner.questlog[tonumber(c.questid)])
            local skip = AutoQuestLearner_NotPickupQuest and AutoQuestLearner_NotPickupQuest(c.questid)
            local bare = c.title and string.gsub(c.title, "%s*%(available%)", "")
            if bare and live[bare] then skip = true end
            if AutoQuestLearner_IsQuestCompleted and AutoQuestLearner_IsQuestCompleted(c.questid, bare) then skip = true end
            if not inlog and not skip then
              place(c.x, c.y, ICON .. "available_c", "avail", c.title, c.name)
            end
          end
        end
      end
    end
  end
  if AutoQuestLearner_GetTurnInsForMap then
    local ok, list = pcall(AutoQuestLearner_GetTurnInsForMap, map)
    if ok and type(list) == "table" then
      for _, t in ipairs(list) do
        if live[t.title] then
          place(t.x, t.y, ICON .. "complete_c", "turnin", t.title)
        end
      end
    end
  end
  M.shown = n
end

local function SafeRefresh() pcall(M.Refresh, M) end

local f = CreateFrame("Frame")
for _, e in ipairs({ "WORLD_MAP_UPDATE", "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED_INDOORS",
    "PLAYER_ENTERING_WORLD", "QUEST_LOG_UPDATE", "QUEST_TURNED_IN", "QUEST_ACCEPTED", "QUEST_QUERY_COMPLETE" }) do
  pcall(f.RegisterEvent, f, e)
end
local pend = {}
f:SetScript("OnEvent", function(self, event)
  if event == "QUEST_LOG_UPDATE" or event == "QUEST_TURNED_IN" or event == "QUEST_ACCEPTED" or event == "QUEST_QUERY_COMPLETE" then
    AutoQuestLearner_WorldGiverCache = {}
    local now = GetTime()
    pend = { now + 0.3, now + 1.2, now + 3 }
  end
  SafeRefresh()
end)

-- Questie hooks the map's own quest-drawing; so do we, plus OnShow.
if WorldMapFrame_DisplayQuests then hooksecurefunc("WorldMapFrame_DisplayQuests", SafeRefresh) end
if WorldMapFrame then
  -- Ask the server which quests this character has finished (at most once a
  -- minute) so completed quests never show a "!" -- the reply refreshes us.
  local lastQuery = 0
  WorldMapFrame:HookScript("OnShow", function()
    local now = GetTime()
    if QueryQuestsCompleted and now - lastQuery > 60 then
      lastQuery = now
      pcall(QueryQuestsCompleted)
    end
    SafeRefresh()
  end)
  WorldMapFrame:HookScript("OnHide", HideAll)
end
-- Safety net: while the map is open, re-assert pins if something hid them.
local acc, hacc = 0, 0
f:SetScript("OnUpdate", function(self, el)
  hacc = hacc + el
  if hacc >= 0.05 then hacc = 0; pcall(M.CheckHover) end
  if pend[1] and GetTime() >= pend[1] then
    table.remove(pend, 1)
    AutoQuestLearner_WorldGiverCache = {}
    SafeRefresh()
  end
  acc = acc + el
  if acc < 0.5 then return end
  acc = 0
  if WorldMapFrame and WorldMapFrame:IsVisible() and GetCurrentMapZone() ~= 0 and M.shown == 0 then
    SafeRefresh()
  end
end)

-- /aqlmaptip: prints what the hover check sees (for fullscreen-map problems).
SLASH_AQLMAPTIP1 = "/aqlmaptip"
SlashCmdList["AQLMAPTIP"] = function()
  local x, y = GetCursorPosition()
  print(string.format("AQL maptip: cursor %.0f,%.0f  mapscale %.2f  mapVisible=%s  pins=%d",
    x, y, WorldMapButton and WorldMapButton:GetEffectiveScale() or 0,
    tostring(WorldMapFrame and WorldMapFrame:IsVisible()), M.shown or 0))
  for i, o in ipairs(M.pool) do
    if o:IsShown() and i <= 4 then
      local sc = o:GetEffectiveScale()
      print(string.format("  pin %d scale %.2f rect L%.0f R%.0f B%.0f T%.0f  cursor(in pin units) %.0f,%.0f  strata %s",
        i, sc, o:GetLeft() or 0, o:GetRight() or 0, o:GetBottom() or 0, o:GetTop() or 0, x / sc, y / sc, o:GetFrameStrata()))
    end
  end
end
