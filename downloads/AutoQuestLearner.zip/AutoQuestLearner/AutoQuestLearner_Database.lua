-- AutoQuestLearner Database Module
-- Integrates quest data from pfQuest and pfQuest-ascension

AutoQuestLearner = AutoQuestLearner or CreateFrame("Frame")

-- AutoQuestLearnerData holds the copied pfQuest/pfQuest-ascension database
-- (quests, units, objects, items, zones). This is intentionally a PLAIN
-- Lua global, NOT listed in the .toc as a SavedVariable. It is rebuilt
-- from pfDB every session. Previously this data was stored inside
-- AutoQuestLearnerDB (which IS a SavedVariable), which meant the entire
-- pfQuest world database was being written to and re-parsed from your
-- WTF SavedVariables file on every login/logout. That file could grow to
-- many megabytes as a single Lua table literal, which exceeds the WoW
-- client's Lua compiler limits and produces the
-- "memory allocation error: block too big" crash on login.
AutoQuestLearnerData = AutoQuestLearnerData or {}


------------------------------------------------------------
-- ID -> consistent RGB color (SearchQuestID runs from this file)
------------------------------------------------------------
do
  local AQL_ID_COLOR_PALETTE = {
    { 1.00, 0.25, 0.25 }, -- red
    { 0.25, 1.00, 0.30 }, -- green
    { 0.30, 0.55, 1.00 }, -- blue
    { 1.00, 0.85, 0.15 }, -- yellow
    { 1.00, 0.55, 0.10 }, -- orange
    { 0.15, 0.90, 0.90 }, -- cyan
    { 1.00, 0.40, 0.75 }, -- pink
    { 0.70, 0.40, 1.00 }, -- purple
    { 0.50, 1.00, 0.50 }, -- light green
    { 1.00, 0.70, 0.40 }, -- peach
  }
  function AutoQuestLearner_IDColor(id)
    local numericID = 0
    if type(id) == "number" then
      numericID = id
    elseif type(id) == "string" then
      for i = 1, string.len(id) do
        numericID = (numericID * 31 + string.byte(id, i)) % 2147483647
      end
    end
    local n = table.getn(AQL_ID_COLOR_PALETTE)
    local c = AQL_ID_COLOR_PALETTE[(numericID % n) + 1]
    return c[1], c[2], c[3]
  end
  function AutoQuestLearner_IDColorTable(id)
    local r, g, b = AutoQuestLearner_IDColor(id)
    return { r, g, b }
  end
end


------------------------------------------------------------
-- GetQuestLogTitle compat wrapper
--
-- CRITICAL: on vanilla (client build <= 11200), GetQuestLogTitle
-- returns 6 values: title, level, tag, header, collapsed, complete.
-- On TBC/WotLK-family clients (which this one is — Interface 30300),
-- it returns 9 values instead, with "suggestedGroup" inserted as the
-- 4th value: title, level, tag, suggestedGroup, header, collapsed,
-- complete, daily, questID.
--
-- Every call site in this addon previously called GetQuestLogTitle()
-- directly using the vanilla-style 6-value destructuring, which reads
-- "suggestedGroup" into what it thinks is "header". suggestedGroup is
-- 0 for ordinary solo quests — and 0 is TRUTHY in Lua — so
-- "if title and not header then" was silently false for literally
-- every normal quest, causing the entire quest tracker (and anything
-- else that scans the quest log) to see nothing at all. This mirrors
-- a fix pfQuest itself has to apply for the exact same reason (see
-- pfQuest's compat/client.lua, pfQuestCompat.GetQuestLogTitle).
------------------------------------------------------------
local _, _, _, aqlClientBuild = GetBuildInfo()
aqlClientBuild = aqlClientBuild or 11200

function AutoQuestLearner_GetQuestLogTitle(id)
  local title, level, tag, group, header, collapsed, complete, daily, questID
  if aqlClientBuild <= 11200 then -- vanilla
    title, level, tag, header, collapsed, complete = GetQuestLogTitle(id)
  else -- tbc & wotlk
    title, level, tag, group, header, collapsed, complete, daily, questID = GetQuestLogTitle(id)
  end
  return title, level, tag, header, collapsed, complete, daily, questID
end

local function EnsureDatabaseTables()
  AutoQuestLearnerDB = AutoQuestLearnerDB or {}
  AutoQuestLearnerDB.config = AutoQuestLearnerDB.config or {}
  AutoQuestLearnerDB.history = AutoQuestLearnerDB.history or {}
  AutoQuestLearnerDB.repeatable = AutoQuestLearnerDB.repeatable or {}
  AutoQuestLearnerDB.colors = AutoQuestLearnerDB.colors or {}

  -- One-time cleanup: strip any previously-persisted database copy out
  -- of the SavedVariable so it stops bloating the file going forward.
  AutoQuestLearnerData.quests = nil
  AutoQuestLearnerData.units = nil
  AutoQuestLearnerData.objects = nil
  AutoQuestLearnerData.items = nil
  AutoQuestLearnerData.zones = nil
  AutoQuestLearnerData.refloot = nil
  AutoQuestLearnerData.areatrigger = nil

  AutoQuestLearnerData.quests = AutoQuestLearnerData.quests or {}
  AutoQuestLearnerData.units = AutoQuestLearnerData.units or {}
  AutoQuestLearnerData.objects = AutoQuestLearnerData.objects or {}
  AutoQuestLearnerData.items = AutoQuestLearnerData.items or {}
  AutoQuestLearnerData.zones = AutoQuestLearnerData.zones or {}
  AutoQuestLearnerData.refloot = AutoQuestLearnerData.refloot or {}
  AutoQuestLearnerData.areatrigger = AutoQuestLearnerData.areatrigger or {}

  -- Initialize database tables
  AutoQuestLearnerData.quests["data"] = AutoQuestLearnerData.quests["data"] or {}
  AutoQuestLearnerData.quests["loc"] = AutoQuestLearnerData.quests["loc"] or {}
  AutoQuestLearnerData.units["data"] = AutoQuestLearnerData.units["data"] or {}
  AutoQuestLearnerData.objects["data"] = AutoQuestLearnerData.objects["data"] or {}
  AutoQuestLearnerData.items["data"] = AutoQuestLearnerData.items["data"] or {}
  AutoQuestLearnerData.items["loc"] = AutoQuestLearnerData.items["loc"] or {}
  AutoQuestLearnerData.zones["loc"] = AutoQuestLearnerData.zones["loc"] or {}
  AutoQuestLearnerData.refloot["data"] = AutoQuestLearnerData.refloot["data"] or {}
  AutoQuestLearnerData.areatrigger["data"] = AutoQuestLearnerData.areatrigger["data"] or {}
end

EnsureDatabaseTables()

AutoQuestLearnerDatabase = {}

-- Merges a newly-loaded item-drop entry into the existing one. Item
-- entries map source-type keys ("U"=unit drop chances, "O"=object loot
-- chances, "R"=reference loot template pointers, "V"=vendor sale info)
-- to their own sub-tables -- union those instead of one replacing the
-- other, same reasoning as MergeQuestEntry/MergeSpawnEntry above.
-- Merges a newly-loaded unit/object entry into the existing one rather
-- than overwriting it outright. Different community databases (pfQuest,
-- Questie-X Ascension, a real pfQuest installation if present) each
-- independently recorded their own subset of real spawn sightings for
-- the same NPC/object -- a plain overwrite means whichever source loads
-- last wins completely, silently discarding every coordinate the other
-- source(s) had that it didn't. Unioning (deduped by near-identical
-- x/y/zone) gives the fullest possible coverage from everything bundled.
local function MergeSpawnEntry(existing, incoming)
  -- Some bundled sources (e.g. items-tbc.lua) use a bare string like
  -- "_" as a lightweight placeholder for "exists but nothing useful
  -- here" instead of an empty table -- treat that the same as absent.
  if type(existing) ~= "table" then existing = nil end
  if type(incoming) ~= "table" then incoming = nil end
  if not existing then return incoming end
  if not incoming then return existing end

  local merged = {}
  for k, v in pairs(existing) do merged[k] = v end
  -- Fill in any fields the existing entry is missing.
  for k, v in pairs(incoming) do
    if merged[k] == nil then merged[k] = v end
  end

  merged["coords"] = {}
  for _, c in pairs(existing["coords"] or {}) do
    table.insert(merged["coords"], c)
  end
  for _, c in pairs(incoming["coords"] or {}) do
    local isDupe = false
    for _, existingCoord in pairs(merged["coords"]) do
      if existingCoord[3] == c[3]
          and math.abs(existingCoord[1] - c[1]) < 0.1
          and math.abs(existingCoord[2] - c[2]) < 0.1 then
        isDupe = true
        break
      end
    end
    if not isDupe then
      table.insert(merged["coords"], c)
    end
  end

  return merged
end

-- Merges a newly-loaded quest entry into the existing one, field by field,
-- instead of overwriting the whole record. Quest sources vary in
-- completeness, so a plain overwrite could mean a quest ID present in
-- both sources loses its objective data whenever the sparser source is
-- merged last. For "start"/"end"/"obj", each sub-table maps a type key
-- ("U"=unit, "O"=object, "I"=item, "A"=areatrigger) to a list of IDs --
-- those lists are unioned rather than one replacing the other, so a
-- quest that's genuinely differently sourced in two databases (e.g.
-- different NPC IDs recorded for the same objective) keeps both.
local function MergeQuestEntry(existing, incoming)
  if type(existing) ~= "table" then existing = nil end
  if type(incoming) ~= "table" then incoming = nil end
  if not existing then return incoming end
  if not incoming then return existing end

  local merged = {}
  for k, v in pairs(existing) do merged[k] = v end
  for k, v in pairs(incoming) do
    if merged[k] == nil then merged[k] = v end
  end

  for _, field in pairs({ "start", "end", "obj" }) do
    local a = existing[field]
    local b = incoming[field]
    if a or b then
      local mergedField = {}
      for _, sub in pairs({ "U", "O", "I", "A" }) do
        local listA = a and a[sub]
        local listB = b and b[sub]
        if listA or listB then
          local seen = {}
          local combined = {}
          for _, id in pairs(listA or {}) do
            if not seen[id] then
              seen[id] = true
              table.insert(combined, id)
            end
          end
          for _, id in pairs(listB or {}) do
            if not seen[id] then
              seen[id] = true
              table.insert(combined, id)
            end
          end
          mergedField[sub] = combined
        end
      end
      merged[field] = mergedField
    end
  end

  return merged
end

local function MergeItemEntry(existing, incoming)
  if type(existing) ~= "table" then existing = nil end
  if type(incoming) ~= "table" then incoming = nil end
  if not existing then return incoming end
  if not incoming then return existing end

  local merged = {}
  for k, v in pairs(existing) do merged[k] = v end

  for _, sub in pairs({ "U", "O", "R", "V" }) do
    local a = existing[sub]
    local b = incoming[sub]
    if a or b then
      local combined = {}
      if a then for k, v in pairs(a) do combined[k] = v end end
      if b then for k, v in pairs(b) do if combined[k] == nil then combined[k] = v end end end
      merged[sub] = combined
    end
  end

  return merged
end

-- Load pfQuest data if available. Checks BOTH this addon's own bundled
-- snapshot (kept under distinct "-aqlbundled" keys, see bundled-db/*.lua
-- headers) AND the standard pfQuest keys a real pfQuest installation
-- would use, merging whichever are present via the same field-level
-- union logic used everywhere else in this file -- rather than one
-- silently overwriting the other depending on load order. Previously
-- this addon's own bundled quests.lua/units.lua/etc used the exact same
-- pfDB keys real pfQuest uses, and being a direct table-literal
-- assignment (not a merge), whichever loaded last completely replaced
-- whatever the other had already written -- meaning a real pfQuest
-- installation's own (potentially newer/more complete) data could get
-- silently discarded the moment this addon's own bundled snapshot
-- loaded afterward, with no combination of the two at all.
local function LoadPfQuestData()
  if not pfDB then return false end

  -- FEATURE (per user request): locale-aware name/description loading.
  -- The bundled data always includes a complete enUS baseline (kept as
  -- distinct "enUS"/"enUS-aqlbundled" keys below), and additionally
  -- overlays the CLIENT's own locale on top of it when available
  -- (translated quest/NPC/zone/item names sourced from ClassicCodex's
  -- community database, covering every locale Ascension itself
  -- supports except Czech, which doesn't appear to exist in any
  -- community database -- Blizzard never officially localized to it
  -- either). Listed AFTER the enUS keys in every key-list below so a
  -- locale entry properly overwrites the enUS baseline wherever the
  -- locale data actually covers that ID, while any ID the locale data
  -- DOESN'T cover simply keeps showing its enUS text instead of coming
  -- up blank -- graceful per-entry fallback rather than an all-or-
  -- nothing file-level choice. On an enUS client this is a harmless
  -- no-op (the same keys just get checked twice).
  local clientLocale = GetLocale and GetLocale() or "enUS"
  local locKeys = { "enUS", "enUS-tbc", "enUS-aqlbundled", "enUS-tbc-aqlbundled", clientLocale, clientLocale .. "-tbc" }

  -- Quests: vanilla + TBC, from both a real pfQuest install (if
  -- present) and this addon's own bundled snapshot.
  if pfDB["quests"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled" }) do
      if pfDB["quests"][key] then
        for k, v in pairs(pfDB["quests"][key]) do
          AutoQuestLearnerData.quests["data"][k] = MergeQuestEntry(AutoQuestLearnerData.quests["data"][k], v)
        end
      end
    end
    for _, key in pairs(locKeys) do
      if pfDB["quests"][key] then
        for k, v in pairs(pfDB["quests"][key]) do
          -- enUS name tables are flat [id]="Title" (unlike the
          -- Ascension/Questie-derived "loc-questiex" tables, which are
          -- [id]={["T"]="Title"}) -- normalize to the {["T"]=...} shape
          -- this addon expects everywhere else.
          AutoQuestLearnerData.quests["loc"][k] = type(v) == "table" and v or { ["T"] = v }
        end
      end
    end
  end

  -- Real, documented corrections from the cmangos project's own
  -- changelog (see bundled-db/ascension/cmangos-quest-fixes.lua for the
  -- full reasoning) -- applied last, after every quest data source has
  -- merged, so these corrections always win regardless of load order.
  if AutoQuestLearnerQuestFieldFixes then
    for questID, fixes in pairs(AutoQuestLearnerQuestFieldFixes) do
      if AutoQuestLearnerData.quests["data"][questID] then
        for field, value in pairs(fixes) do
          AutoQuestLearnerData.quests["data"][questID][field] = value
        end
      end
    end
  end

  -- Units: coords (vanilla + TBC) and names.
  if pfDB["units"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled", "data-aqlbundled2" }) do
      if pfDB["units"][key] then
        for k, v in pairs(pfDB["units"][key]) do
          AutoQuestLearnerData.units["data"][k] = MergeSpawnEntry(AutoQuestLearnerData.units["data"][k], v)
        end
      end
    end
    AutoQuestLearnerData.units["loc"] = AutoQuestLearnerData.units["loc"] or {}
    for _, key in pairs(locKeys) do
      if pfDB["units"][key] then
        for k, v in pairs(pfDB["units"][key]) do
          AutoQuestLearnerData.units["loc"][k] = v
        end
      end
    end
    -- DBC missing names are held in pfDB["units"]["enUS-dbc-missing"] (chunked
    -- files). Merge is DEFERRED to after login (see AutoQuestLearner_StartDbcNameMerge)
    -- so the 90k+ entry table does not hitch ADDON_LOADED / InitializeDatabase.
  end

  -- Objects: coords (vanilla + TBC) and names.
  if pfDB["objects"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled" }) do
      if pfDB["objects"][key] then
        for k, v in pairs(pfDB["objects"][key]) do
          AutoQuestLearnerData.objects["data"][k] = MergeSpawnEntry(AutoQuestLearnerData.objects["data"][k], v)
        end
      end
    end
    AutoQuestLearnerData.objects["loc"] = AutoQuestLearnerData.objects["loc"] or {}
    for _, key in pairs(locKeys) do
      if pfDB["objects"][key] then
        for k, v in pairs(pfDB["objects"][key]) do
          AutoQuestLearnerData.objects["loc"][k] = v
        end
      end
    end
  end

  -- Items: drop-source data (vanilla + TBC), needed to resolve
  -- item-collection quest objectives ("obj"["I"]) to real kill/interact
  -- locations via ResolveItemSources() below.
  if pfDB["items"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled" }) do
      if pfDB["items"][key] then
        for k, v in pairs(pfDB["items"][key]) do
          AutoQuestLearnerData.items["data"][k] = MergeItemEntry(AutoQuestLearnerData.items["data"][k], v)
        end
      end
    end
    for _, key in pairs(locKeys) do
      if pfDB["items"][key] then
        for k, v in pairs(pfDB["items"][key]) do
          AutoQuestLearnerData.items["loc"][k] = v
        end
      end
    end
  end

  -- Reference loot data (item ID -> shared loot-template ID -> actual
  -- NPC/object sources) -- some items don't list their sources
  -- directly and only point at a reference template via
  -- items["data"][id]["R"], which this table resolves.

  -- Imported coords from db.ascension.gg (tools/ascension_coord_importer.py)
  if pfDB["quests"] and pfDB["quests"]["data-imported"] then
    AutoQuestLearnerData.quests = AutoQuestLearnerData.quests or {}
    AutoQuestLearnerData.quests["data"] = AutoQuestLearnerData.quests["data"] or {}
    for k, v in pairs(pfDB["quests"]["data-imported"]) do
      local cur = AutoQuestLearnerData.quests["data"][k]
      if not cur then
        AutoQuestLearnerData.quests["data"][k] = v
      else
        -- Prefer imported start/end when present
        if v["start"] then cur["start"] = v["start"] end
        if v["end"] then cur["end"] = v["end"] end
        if v["obj"] and not cur["obj"] then cur["obj"] = v["obj"] end
        if v["lvl"] and not cur["lvl"] then cur["lvl"] = v["lvl"] end
      end
    end
  end
  if pfDB["quests"] and pfDB["quests"]["loc-imported"] then
    AutoQuestLearnerData.quests = AutoQuestLearnerData.quests or {}
    AutoQuestLearnerData.quests["loc"] = AutoQuestLearnerData.quests["loc"] or {}
    for k, v in pairs(pfDB["quests"]["loc-imported"]) do
      if not AutoQuestLearnerData.quests["loc"][k] then
        AutoQuestLearnerData.quests["loc"][k] = v
      end
    end
  end
  if pfDB["units"] and pfDB["units"]["data-imported"] then
    AutoQuestLearnerData.units = AutoQuestLearnerData.units or {}
    AutoQuestLearnerData.units["data"] = AutoQuestLearnerData.units["data"] or {}
    for k, v in pairs(pfDB["units"]["data-imported"]) do
      -- Imported coords overwrite wrong classic pins (e.g. Melrache)
      AutoQuestLearnerData.units["data"][k] = v
    end
  end
  if pfDB["units"] and pfDB["units"]["loc-imported"] then
    AutoQuestLearnerData.units = AutoQuestLearnerData.units or {}
    AutoQuestLearnerData.units["loc"] = AutoQuestLearnerData.units["loc"] or {}
    for k, v in pairs(pfDB["units"]["loc-imported"]) do
      AutoQuestLearnerData.units["loc"][k] = v
    end
  end
  if pfDB["objects"] and pfDB["objects"]["data-imported"] then
    AutoQuestLearnerData.objects = AutoQuestLearnerData.objects or {}
    AutoQuestLearnerData.objects["data"] = AutoQuestLearnerData.objects["data"] or {}
    for k, v in pairs(pfDB["objects"]["data-imported"]) do
      AutoQuestLearnerData.objects["data"][k] = v
    end
  end
  if pfDB["objects"] and pfDB["objects"]["loc-imported"] then
    AutoQuestLearnerData.objects = AutoQuestLearnerData.objects or {}
    AutoQuestLearnerData.objects["loc"] = AutoQuestLearnerData.objects["loc"] or {}
    for k, v in pairs(pfDB["objects"]["loc-imported"]) do
      AutoQuestLearnerData.objects["loc"][k] = v
    end
  end

  if pfDB["refloot"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled" }) do
      if pfDB["refloot"][key] then
        for k, v in pairs(pfDB["refloot"][key]) do
          AutoQuestLearnerData.refloot["data"][k] = MergeItemEntry(AutoQuestLearnerData.refloot["data"][k], v)
        end
      end
    end
  end

  -- Areatrigger coordinates (vanilla + TBC) -- needed to resolve
  -- "Find X nearby" style quest objectives ("obj"["A"]), which point at
  -- a trigger zone/radius rather than a specific NPC or object.
  if pfDB["areatrigger"] then
    for _, key in pairs({ "data", "data-tbc", "data-aqlbundled", "data-tbc-aqlbundled" }) do
      if pfDB["areatrigger"][key] then
        for k, v in pairs(pfDB["areatrigger"][key]) do
          AutoQuestLearnerData.areatrigger["data"][k] = MergeSpawnEntry(AutoQuestLearnerData.areatrigger["data"][k], v)
        end
      end
    end
  end

  -- Zone names (vanilla + TBC).
  if pfDB["zones"] then
    for _, key in pairs(locKeys) do
      if pfDB["zones"][key] then
        for k, v in pairs(pfDB["zones"][key]) do
          AutoQuestLearnerData.zones["loc"][k] = v
        end
      end
    end
  end

  -- Minimap zone dimensions (vanilla + TBC) -- AutoQuestLearnerMap's
  -- minimap pin placement (and the minimap route line) needs a zone's
  -- physical width/height in yards to convert a world coordinate into
  -- a position on the round minimap texture. Without this table
  -- populated, UpdateMinimap() bails out immediately for every zone
  -- (mapWidth/mapHeight read as 0), meaning nothing has ever rendered
  -- on the minimap at all -- not a clusters-specific issue, a total
  -- minimap outage that just happened to be first noticed via missing
  -- clusters. AutoQuestLearnerDB.minimap (not AutoQuestLearnerData) is
  -- intentional here -- AutoQuestLearner_Map.lua reads it directly from
  -- the SavedVariable table, not from AutoQuestLearnerData.
  AutoQuestLearnerDB.minimap = AutoQuestLearnerDB.minimap or {}
  if pfDB["minimap"] then
    for k, v in pairs(pfDB["minimap"]) do
      AutoQuestLearnerDB.minimap[k] = v
    end
  end
  if pfDB["minimap-tbc"] then
    for k, v in pairs(pfDB["minimap-tbc"]) do
      AutoQuestLearnerDB.minimap[k] = v
    end
  end

  return true
end

local function LoadAscensionData()
  -- WotLK content deliberately not bundled/merged -- vanilla + TBC only.
  local unitSources = { "data-ascension", "data-questiex", "data-coa", "data-addressbook" }
  local unitLocSources = { "loc-questiex" }
  local objectSources = { "data-questiex" }
  local objectLocSources = { "loc-questiex" }
  local questSources = { "data-ascension", "data-questiex", "data-questiex-obj", "data-worlddb", "data-wcq", "data-questie2", "data-livesourced" }
  local questLocSources = { "loc-questiex", "loc-livesourced" }

  if pfDB and pfDB["units"] then
    for _, key in pairs(unitSources) do
      if pfDB["units"][key] then
        for k, v in pairs(pfDB["units"][key]) do
          AutoQuestLearnerData.units["data"][k] = MergeSpawnEntry(AutoQuestLearnerData.units["data"][k], v)
        end
      end
    end
    for _, key in pairs(unitLocSources) do
      if pfDB["units"][key] then
        for k, v in pairs(pfDB["units"][key]) do
          AutoQuestLearnerData.units["loc"] = AutoQuestLearnerData.units["loc"] or {}
          AutoQuestLearnerData.units["loc"][k] = v
        end
      end
    end
  end

  if pfDB and pfDB["objects"] then
    for _, key in pairs(objectSources) do
      if pfDB["objects"][key] then
        for k, v in pairs(pfDB["objects"][key]) do
          AutoQuestLearnerData.objects["data"][k] = MergeSpawnEntry(AutoQuestLearnerData.objects["data"][k], v)
        end
      end
    end
    for _, key in pairs(objectLocSources) do
      if pfDB["objects"][key] then
        for k, v in pairs(pfDB["objects"][key]) do
          AutoQuestLearnerData.objects["loc"] = AutoQuestLearnerData.objects["loc"] or {}
          AutoQuestLearnerData.objects["loc"][k] = v
        end
      end
    end
  end

  if pfDB and pfDB["quests"] then
    for _, key in pairs(questSources) do
      if pfDB["quests"][key] then
        for k, v in pairs(pfDB["quests"][key]) do
          AutoQuestLearnerData.quests["data"][k] = MergeQuestEntry(AutoQuestLearnerData.quests["data"][k], v)
        end
      end
    end
    for _, key in pairs(questLocSources) do
      if pfDB["quests"][key] then
        for k, v in pairs(pfDB["quests"][key]) do
          AutoQuestLearnerData.quests["loc"][k] = v
        end
      end
    end
  end

  return true
end

-- Format quest text (handles special formatting codes)
function AutoQuestLearnerDatabase:FormatQuestText(text)
  if not text then return "" end
  
  -- Remove color codes and formatting
  text = string.gsub(text, "|c%x%x%x%x%x%x%x%x", "")
  text = string.gsub(text, "|r", "")
  text = string.gsub(text, "|n", "\n")
  text = string.gsub(text, "\239\188\154", ":")
  
  return text
end

-- Get quest IDs by quest log index
function AutoQuestLearnerDatabase:GetQuestIDs(qlogid)
  if not qlogid then return nil end

  -- Most reliable: pull the quest ID directly out of the quest's own
  -- hyperlink. This works without any external database at all — it's
  -- exactly how pfQuest itself resolves quest log entries to IDs (see
  -- pfQuest's database.lua, pfDatabase:GetQuestIDs).
  if GetQuestLink then
    local questLink = GetQuestLink(qlogid)
    if questLink then
      local _, _, id = strfind(questLink, "|c.*|Hquest:([%d]+):([%-]?[%d]+)|h%[(.*)%]|h|r")
      if id then return { tonumber(id) } end
    end
  end

  local title, level, tag, header, collapsed, complete = AutoQuestLearner_GetQuestLogTitle(qlogid)
  if not title or header then return nil end

  -- Search for quest ID by title in our database. Duplicate titles are
  -- common (faction-mirrored quests, multi-stage chains that reuse the
  -- same title at every step -- e.g. "Call of Water" alone spans 20
  -- different quest IDs in the bundled database), so this collects
  -- EVERY matching ID rather than returning whichever one pairs()
  -- happens to iterate to first (which isn't even deterministic between
  -- game sessions). When there's more than one candidate, the quest's
  -- displayed level (always available from the log itself) is used to
  -- pick the one whose bundled level range actually fits -- a cheap,
  -- effective disambiguator for exactly this case, though not a
  -- guarantee for same-title/same-level quests (rare).
  local matches = {}
  for id, data in pairs(AutoQuestLearnerData.quests["loc"]) do
    if data.T == title then
      table.insert(matches, id)
    end
  end

  if table.getn(matches) == 1 then
    return matches
  elseif table.getn(matches) > 1 then
    if level then
      for _, id in pairs(matches) do
        local qdata = AutoQuestLearnerData.quests["data"][id]
        if qdata and (qdata["lvl"] == level or qdata["min"] == level) then
          return { id }
        end
      end
    end
    -- No level match (or no level info) -- fall back to the first
    -- candidate rather than nothing, but this is the ambiguous case;
    -- learned location data may end up attributed to the wrong ID
    -- among the same-titled group.
    return { matches[1] }
  end
  
  -- Return title as fallback if not found in database
  return { title }
end

-- Get quest IDs by name
function AutoQuestLearnerDatabase:GetIDByName(name, type)
  local ids = {}
  type = type or "quests"
  
  if not name or not AutoQuestLearnerData[type] or not AutoQuestLearnerData[type]["loc"] then
    return ids
  end

  local nameLower = string.lower(name)
  for id, data in pairs(AutoQuestLearnerData[type]["loc"]) do
    local t = data and data.T
    if t then
      if t == name then
        table.insert(ids, id)
      else
        -- Case-insensitive exact match (leaderboard "Gordunni Shaman" vs DB)
        if string.lower(t) == nameLower then
          table.insert(ids, id)
        end
      end
    end
  end
  
  return ids
end

-- Search quests for the map system
-- Plots every known spawn coordinate for a single unit, object, or
-- areatrigger ID as a map/minimap node tied to a quest. pfDB's real
-- structure stores start/end/objective targets as plain arrays of IDs
-- keyed by "U" (units), "O" (objects), "I" (items), or "A"
-- (areatrigger) -- e.g. quests["data"][id]["start"]["U"] = {npcID1,
-- npcID2}. Items have no coordinates of their own (they don't spawn
-- anywhere, only their sources do -- see ResolveItemSources), so only
-- "U", "O", and "A" produce map nodes directly.
local function MapAddNode(meta)
  if AutoQuestLearnerMap and AutoQuestLearnerMap.AddNode then
    AutoQuestLearnerMap:AddNode(meta)
  end
end

local function AddSpawnNode(maps, meta, questID, questLoc, questData, idType, id, texture, vertex, roleLabel, singleOnly, isObjective)
  if not AutoQuestLearnerMap or not AutoQuestLearnerMap.AddNode then return end
  local data
  if idType == "U" then
    data = AutoQuestLearnerData.units["data"][id]
  elseif idType == "O" then
    data = AutoQuestLearnerData.objects["data"][id]
  elseif idType == "A" then
    data = AutoQuestLearnerData.areatrigger["data"][id]
  end
  if not data or not data["coords"] then return end

  -- Dedupe near-identical rows in the spawn table (merged vanilla/TBC
  -- lists often list the same point twice). Resulting pin count ≈ unique
  -- entries in the unit/object spawn table for this ID.
  local DEDUPE = 0.35 -- map %
  local unique = {}
  for _, coord in pairs(data["coords"]) do
    local mapID = coord[3]
    local x, y = tonumber(coord[1]), tonumber(coord[2])
    if mapID and mapID > 0 and x and y then
      local keep = true
      for _, u in ipairs(unique) do
        if u.mapID == mapID then
          local dx, dy = u.x - x, u.y - y
          if (dx * dx + dy * dy) < (DEDUPE * DEDUPE) then
            keep = false
            break
          end
        end
      end
      if keep then
        table.insert(unique, { x = x, y = y, mapID = mapID })
      end
    end
  end

  for _, coord in ipairs(unique) do
    local mapID = coord.mapID
    maps[mapID] = maps[mapID] or {}

    MapAddNode({
      addon = meta.addon or "AUTOQUESTLEARNER",
      title = questLoc.T or ("Quest " .. questID),
      zone = mapID,
      x = coord.x,
      y = coord.y,
      spawn = (idType == "U" and AutoQuestLearner_GetUnitName(id))
          or (idType == "O" and AutoQuestLearner_GetObjectName(id))
          or (idType == "A" and "Search area")
          or (roleLabel .. " " .. id),
      texture = texture,
      vertex = vertex or { 0.3, 0.8, 0.4 },
      questid = questID,
      qlvl = questData["lvl"],
      qmin = questData["min"],
      isObjective = isObjective,
      cluster = false, -- spawn rings (not cluster badges)
      objectiveSourceType = (idType == "U" and "unit") or (idType == "O" and "object") or nil,
      highlightKey = tostring(id),
      sourceId = id,
    })

    if singleOnly then return end
  end
end

-- Resolves an item ID to its actual kill/interact drop sources, using
-- pfQuest's own items+refloot database structure: an item's direct
-- "U"(nit)/"O"(bject) sources, plus any indirect sources reached via a
-- shared reference loot template ("R", used when many similar mobs
-- share one loot table rather than each having their own entry).
--
-- This is what lets an item-collection quest ("Collect 8 Witchwing
-- Talons") resolve to actual NPC spawn points. Without it, that entire
-- (very common) quest type showed zero objective nodes -- there's no
-- NPC/object ID directly attached to the quest, only an item
-- requirement, and this addon had no item-drop database at all to
-- cross-reference it against until now.
local function ResolveItemSources(itemID)
  local sources = {}
  local itemData = AutoQuestLearnerData.items and AutoQuestLearnerData.items["data"]
      and AutoQuestLearnerData.items["data"][itemID]
  if not itemData then return sources end

  local function addFrom(tbl, typ)
    if not tbl then return end
    for id, rate in pairs(tbl) do
      table.insert(sources, { type = typ, id = id, rate = tonumber(rate) or 0 })
    end
  end

  addFrom(itemData["U"], "U")
  addFrom(itemData["O"], "O")
  if itemData["R"] then
    for refID in pairs(itemData["R"]) do
      local refData = AutoQuestLearnerData.refloot and AutoQuestLearnerData.refloot["data"]
          and AutoQuestLearnerData.refloot["data"][refID]
      if refData then
        addFrom(refData["U"], "U")
        addFrom(refData["O"], "O")
      end
    end
  end

  if table.getn(sources) == 0 then return sources end

  -- ---- Source quality filter -----------------------------------------
  -- Bundled item tables (especially TBC merges) often attach junk
  -- unit sources at tiny rates, or mark dozens of unrelated NPCs at
  -- ~100% for the same quest item. Drawing all of those as "this
  -- quest's spawn cluster" is wrong (e.g. Clam Bait / Soft-shelled
  -- Clam Meat showing Drysnap Crawler / Slitherblade packs).
  --
  -- Rules:
  -- 1) Prefer real object sources (clams, chests, etc.) when present.
  -- 2) Drop bulk ~100% unit lists (6+ different NPCs all >= 90%) —
  --    that pattern is almost never a real single-item drop table.
  -- 3) When a high-rate source exists, drop negligible rates (<5%,
  --    or <10% of the best rate).
  local maxRate, hasStrongObject, highUnitCount = 0, false, 0
  for _, s in pairs(sources) do
    if (s.rate or 0) > maxRate then maxRate = s.rate end
    if s.type == "O" and (s.rate or 0) >= 50 then hasStrongObject = true end
    if s.type == "U" and (s.rate or 0) >= 90 then highUnitCount = highUnitCount + 1 end
  end

  local filtered = {}
  local bulkFakeUnits = highUnitCount >= 6
  for _, s in pairs(sources) do
    local rate = s.rate or 0
    if s.type == "O" then
      table.insert(filtered, s)
    elseif bulkFakeUnits and rate >= 90 then
      -- skip fake 100%-everywhere unit rows
    elseif hasStrongObject and rate < 10 then
      -- object is the real source; ignore tiny incidental mob drops
    elseif maxRate >= 20 and rate < math.max(5, maxRate * 0.1) then
      -- negligible vs best source
    else
      table.insert(filtered, s)
    end
  end

  if table.getn(filtered) > 0 then
    sources = filtered
  else
    -- Prefer objects only rather than a map full of wrong mobs
    local onlyObj = {}
    for _, s in pairs(sources) do
      if s.type == "O" then table.insert(onlyObj, s) end
    end
    if table.getn(onlyObj) > 0 then
      sources = onlyObj
    elseif bulkFakeUnits then
      -- e.g. Soft-shelled Clam Meat with 10+ NPCs all at 100%: no
      -- trustworthy unit source — better show nothing than Drysnaps.
      sources = {}
    end
  end

  return sources
end

-- Looks up a unit or object's display name from AutoQuestLearnerData's
-- "loc" tables. Handles both formats that data can arrive in: a bare
-- string (pfQuest's own enUS/units.lua, enUS/objects.lua) or a
-- {["T"]="Name"} table (Questie-derived sources, matching the quest
-- title table's own shape). Used to make the arrow and map node
-- tooltips say the actual NPC/object name ("Turn in to Cliffwatcher
-- Longhorn") instead of just the quest title with a generic suffix.
function AutoQuestLearner_GetUnitName(id)
  local v = AutoQuestLearnerData.units and AutoQuestLearnerData.units["loc"] and AutoQuestLearnerData.units["loc"][id]
  if type(v) == "string" then return v end
  if type(v) == "table" and v["T"] then return v["T"] end
  return nil
end

function AutoQuestLearner_GetObjectName(id)
  local v = AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["loc"] and AutoQuestLearnerData.objects["loc"][id]
  if type(v) == "string" then return v end
  if type(v) == "table" and v["T"] then return v["T"] end
  return nil
end

function AutoQuestLearner_GetItemName(id)
  local v = AutoQuestLearnerData.items and AutoQuestLearnerData.items["loc"] and AutoQuestLearnerData.items["loc"][id]
  if type(v) == "string" and v ~= "_" then return v end
  if type(v) == "table" and v["T"] and v["T"] ~= "_" then return v["T"] end
  return nil
end


function AutoQuestLearner_ResolveItemSources(itemID)
  return ResolveItemSources(itemID)
end

function AutoQuestLearnerDatabase:SearchQuestID(questID, meta, maps)
  if not questID then return maps or {} end
  if not meta then meta = {} end
  if not maps then maps = {} end
  
  -- Get quest data
  local questData = AutoQuestLearnerData.quests["data"][questID]
  local questLoc = AutoQuestLearnerData.quests["loc"][questID]
  
  if not questData or not questLoc then return maps end

  local showSingleMarkers = AutoQuestLearnerDB.config.nodestyle ~= "spawn"

  -- Quest start (where you pick it up): pfQuest's own icon for this is
  -- "available_c" -- the muted/grey "!" mark, used regardless of
  -- whether the quest is in your log yet (matches pfQuest's
  -- SearchQuestID exactly: this branch only ever runs when
  -- meta["qlogid"] is NOT set, i.e. before it's in your log). No
  -- vertex-color override, matching pfQuest -- the icon's own baked-in
  -- color carries the meaning, tinting it would just look wrong.
  -- BUGFIX: if we've personally confirmed the giver's location for this
  -- quest, that learned node (drawn separately by DrawLearnedNode in
  -- AutoQuestLearner.lua) already covers it -- skip the static one
  -- entirely instead of drawing both. Ascension is a private server
  -- with its own custom NPC placements, so the bundled static database
  -- (converted from vanilla/WotLK sources) is frequently just wrong
  -- here; showing both pins meant the wrong static one was still
  -- sitting on the map right alongside the correct learned one.
  local learnedEntry = AutoQuestLearner_GetLearnedQuestEntry
      and AutoQuestLearnerDB.learned
      and AutoQuestLearner_GetLearnedQuestEntry(AutoQuestLearnerDB.learned, questID, questLoc and questLoc.T)
  local hasLearnedGiver = learnedEntry and learnedEntry.giver and learnedEntry.giver.mapID
  local hasLearnedTurnin = learnedEntry and learnedEntry.turnin and learnedEntry.turnin.mapID

  if showSingleMarkers and questData["start"] and not meta["qlogid"] and not hasLearnedGiver then
    if questData["start"]["U"] then
      for _, npcID in pairs(questData["start"]["U"]) do
        AddSpawnNode(maps, meta, questID, questLoc, questData, "U", npcID,
          "Interface\\AddOns\\AutoQuestLearner\\img\\node", { 1, 1, 1 }, "NPC")
      end
    end
    if questData["start"]["O"] then
      for _, objID in pairs(questData["start"]["O"]) do
        AddSpawnNode(maps, meta, questID, questLoc, questData, "O", objID,
          "Interface\\AddOns\\AutoQuestLearner\\img\\node", { 1, 1, 1 }, "Object")
      end
    end
  end

  -- Quest end (where you turn it in): pfQuest uses "complete" (bright
  -- "?") while the quest still has incomplete objectives, and
  -- "complete_c" (the alternate state) once it's actually ready to hand
  -- in -- same convention pfQuest itself uses, replicated here.
  --
  -- NOTE: pfQuest's own completion check falls back to treating
  -- GetNumQuestLeaderBoards(qlogid) == 0 as "complete", which is NOT
  -- used here -- that heuristic is unreliable on this client (a
  -- leaderboard that hasn't finished loading yet also reads as 0,
  -- which previously caused real incomplete quests to be misreported).
  -- Instead this cross-checks every individual leaderboard entry, the
  -- same fix already applied to the arrow's own completion detection.
  if showSingleMarkers and questData["end"] and not hasLearnedTurnin then
    local endTexture = "Interface\\AddOns\\AutoQuestLearner\\img\\node"
    if meta["qlogid"] then
      local _, _, _, _, _, isComplete = AutoQuestLearner_GetQuestLogTitle(meta["qlogid"])
      if not isComplete then
        local numObjectives = GetNumQuestLeaderBoards(meta["qlogid"])
        if numObjectives and numObjectives > 0 then
          isComplete = true
          for i = 1, numObjectives do
            local _, _, objDone = GetQuestLogLeaderBoard(i, meta["qlogid"])
            if not objDone then
              isComplete = false
              break
            end
          end
        end
      end
      endTexture = isComplete
          and "Interface\\AddOns\\AutoQuestLearner\\img\\node"
          or "Interface\\AddOns\\AutoQuestLearner\\img\\complete"
    end

    if questData["end"]["U"] then
      for _, npcID in pairs(questData["end"]["U"]) do
        AddSpawnNode(maps, meta, questID, questLoc, questData, "U", npcID,
          endTexture, { 1, 1, 1 }, "NPC")
      end
    end
    if questData["end"]["O"] then
      for _, objID in pairs(questData["end"]["O"]) do
        AddSpawnNode(maps, meta, questID, questLoc, questData, "O", objID,
          endTexture, { 1, 1, 1 }, "Object")
      end
    end
  end

  -- Quest objectives: kill/interact targets. In cluster mode this
  -- plots every known spawn point for the required mob or object as
  -- its own node (the "cloud of dots" style); in simple mode it plots
  -- just one representative marker per mob/object instead.
  --
  -- Plain colored circles instead of pfQuest's node_ring/cluster_misc
  -- icon assets (a sword badge for kill targets, a cog/gear badge for
  -- object/misc targets) -- readable at a glance without needing to
  -- squint at which tiny symbol is baked into each dot.
  --
  -- Colored per specific target ID (the exact NPC/object/areatrigger),
  -- not just per objective type -- a quest asking for parts from 4
  -- different creatures would otherwise show all 4 creatures' spawn
  -- clouds in one indistinguishable color. Reuses the same ID->color
  -- hash AutoQuestLearner.lua's learned-objective clusters use
  -- (AutoQuestLearner_IDColor), so a given NPC gets a consistent color
  -- whether its spawn points came from the static database or from
  -- your own play.
  -- combined/spawn: one pin per unique spawn-table coordinate (not badges
  -- stacked on top — that overpopulated clusters 2×).
  -- simple: one representative marker per NPC/object id.
  local style = AutoQuestLearnerDB.config.nodestyle or "spawn"
  local useSpawnDots = style ~= "simple"
  local useClusterIcons = style == "simple"
  local useClusters = useSpawnDots
  local objTexture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"

  -- Skip any sub-objective that's already individually done, by name --
  -- same approach as FindClosestQuestDestination/DrawStaticObjectiveClusters.
  -- Without this, this function (used on quest state-change reloads and
  -- the manual "Show" tracker button) could redraw an already-culled
  -- finished sub-objective's dots right back.
  local doneObjectiveTexts = {}
  local qlogid = AutoQuestLearner.questlog and AutoQuestLearner.questlog[questID] and AutoQuestLearner.questlog[questID].qlogid
  if qlogid then
    local numObjectives = GetNumQuestLeaderBoards(qlogid)
    if numObjectives and numObjectives > 0 then
      for oi = 1, numObjectives do
        local otext, _, odone = GetQuestLogLeaderBoard(oi, qlogid)
        if odone and otext then
          local label = string.match(otext, "^(.-)%s*:?%s*%d") or otext
          table.insert(doneObjectiveTexts, string.lower(label))
        end
      end
    end
  end
  local function isAlreadyDone(name)
    if not name or table.getn(doneObjectiveTexts) == 0 then return false end
    local nameLower = string.lower(name)
    nameLower = string.gsub(nameLower, "%s+slain$", "")
    nameLower = string.gsub(nameLower, "%s+killed$", "")
    for _, doneText in pairs(doneObjectiveTexts) do
      local d = string.gsub(doneText, "%s+slain$", "")
      d = string.gsub(d, "%s+killed$", "")
      if d == nameLower or string.find(d, nameLower, 1, true) == 1
          or string.find(nameLower, d, 1, true) == 1 then
        local last = string.match(nameLower, "(%S+)$") or nameLower
        if string.len(last) >= 4 and string.find(d, last, 1, true) then
          return true
        end
      end
    end
    return false
  end

  -- Static objective clusters are shown alongside any learned data,
  -- not replaced by it -- this pass is for visual/area context on the
  -- map (showing everywhere the mob/object is known to possibly be),
  -- while the ARROW's target selection (FindClosestQuestDestination in
  -- AutoQuestLearner.lua) is what actually needs to trust learned data
  -- exclusively for navigation. Those are different jobs: suppressing
  -- static data here too meant a single learned point replaced what
  -- used to be a rich cluster of dozens of static dots, so nearly
  -- every quest with any learned data at all appeared to lose most of
  -- its cluster.
  if questData["obj"] then
    local function coordsFor(idType, id)
      local data
      if idType == "U" then
        data = AutoQuestLearnerData.units and AutoQuestLearnerData.units["data"] and AutoQuestLearnerData.units["data"][id]
      elseif idType == "O" then
        data = AutoQuestLearnerData.objects and AutoQuestLearnerData.objects["data"] and AutoQuestLearnerData.objects["data"][id]
      end
      local byMap = {}
      if data and data.coords then
        for _, c in pairs(data.coords) do
          local mapID = c[3]
          if mapID and mapID > 0 then
            byMap[mapID] = byMap[mapID] or {}
            table.insert(byMap[mapID], { c[1], c[2] })
          end
        end
      end
      return byMap
    end

    local function drawSource(idType, id, label, isLootObjective)
      if useSpawnDots then
        -- Sword = kill (obj U). Bag = loot-from-kill (item) or world object (O).
        local tex
        if isLootObjective or idType == "O" then
          tex = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"
        else
          tex = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring"
        end
        AddSpawnNode(maps, meta, questID, questLoc, questData, idType, id,
          tex, AutoQuestLearner_IDColorTable(id),
          (idType == "U" and "NPC") or (idType == "O" and "Object") or "Area",
          not useClusters, true)
      end
      if useClusterIcons and AutoQuestLearner_DrawClusterBadge then
        local byMap = coordsFor(idType, id)
        local st = (isLootObjective or idType == "O") and "loot" or "unit"
        for mapID, coords in pairs(byMap) do
          AutoQuestLearner_DrawClusterBadge(questID, questLoc.T or ("Quest " .. questID),
            label, id, st, mapID, coords)
        end
      end
    end

    if questData["obj"]["U"] then
      for _, npcID in pairs(questData["obj"]["U"]) do
        if not isAlreadyDone(AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(npcID)) then
          drawSource("U", npcID, AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(npcID))
        end
      end
    end
    if questData["obj"]["O"] then
      for _, objID in pairs(questData["obj"]["O"]) do
        if not isAlreadyDone(AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(objID)) then
          drawSource("O", objID, AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(objID))
        end
      end
    end
    if questData["obj"]["I"] then
      for _, itemID in pairs(questData["obj"]["I"]) do
        local itemName = AutoQuestLearner_GetItemName and AutoQuestLearner_GetItemName(itemID)
        if not isAlreadyDone(itemName) then
          local sources = ResolveItemSources(itemID)
          for _, src in pairs(sources) do
            local srcName = itemName
                or (src.type == "U" and AutoQuestLearner_GetUnitName and AutoQuestLearner_GetUnitName(src.id))
                or (AutoQuestLearner_GetObjectName and AutoQuestLearner_GetObjectName(src.id))
            if not isAlreadyDone(srcName) then
              drawSource(src.type, src.id, srcName, true)  -- item objective = bag (loot from kill)
            end
          end
        end
      end
    end
    if questData["obj"]["A"] then
      for _, triggerID in pairs(questData["obj"]["A"]) do
        if not isAlreadyDone("search area") then
          if useSpawnDots then
            AddSpawnNode(maps, meta, questID, questLoc, questData, "A", triggerID,
              objTexture, AutoQuestLearner_IDColorTable(triggerID), "Area", not useClusters, true)
          end
        end
      end
    end
  end

  return maps
end

-- PERFFIX (confirmed via /aql perfdebug: 35.7ms for this function in a
-- single call, over 2 full frames at 60fps, causing a real visible
-- stutter on quest-progress events): SearchQuests used to walk the
-- ENTIRE bundled quest database (6600+ entries) on every call,
-- including every start-NPC/object's every coordinate anywhere in the
-- game world, just to throw away everything not in the player's
-- current zone. It's triggered off QUEST_LOG_UPDATE/QUEST_FINISHED
-- (see the "updateQuestGivers" flag in AutoQuestLearner_Quest.lua),
-- which fires during ordinary loot/kill quest-progress updates, not
-- just accept/turn-in -- so this full-database walk could run mid-
-- combat, right when a frame hitch is most noticeable.
--
-- Fix: precompute, once, a static mapID -> {questID, ...} index of
-- which quests have a giver (real NPC/object coordinate, or the
-- RXPGuides fallback location if no real coordinate exists in that
-- zone -- same "not foundGiverInZone" condition SearchQuests itself
-- used) in each zone. The bundled database is immutable at runtime,
-- so this only needs to be built once, lazily, on first use, and
-- reused for the rest of the session. SearchQuests then only visits
-- the (usually a few dozen) quests actually relevant to the current
-- zone instead of all 6600+, while applying the exact same
-- per-player filters (level/faction/reputation/prereqs/etc.) it
-- always did.
--
-- PERFFIX: this same index-build now also produces a second,
-- REAL-COORDINATE-ONLY variant (no RXP fallback) for GetZoneCompletion
-- to use below -- confirmed via /aql perfdebug that GetZoneCompletion
-- was NOT actually the on-demand-only command its own old comment
-- claimed: the "zone completion nudge" feature (enabled by default,
-- see zoneNudgeFrame in AutoQuestLearner.lua) polls it automatically
-- every 30 seconds during normal play, meaning the exact same
-- full-6600+-quest-database walk SearchQuests had was ALSO silently
-- running on a timer this whole time. Building both index variants in
-- one pass here (rather than a second, separate walk) keeps this a
-- single one-time cost either way.
local zoneQuestIndex = nil
local zoneQuestIndexRealOnly = nil

local function AutoQuestLearner_BuildZoneQuestIndex()
  local index = {}
  local realOnlyIndex = {}
  local function addToZone(zoneMapID, questID)
    if not zoneMapID then return end
    index[zoneMapID] = index[zoneMapID] or {}
    index[zoneMapID][questID] = true
  end
  local function addToRealOnlyZone(zoneMapID, questID)
    if not zoneMapID then return end
    realOnlyIndex[zoneMapID] = realOnlyIndex[zoneMapID] or {}
    realOnlyIndex[zoneMapID][questID] = true
  end

  for questID, questData in pairs(AutoQuestLearnerData.quests["data"]) do
    if questData["start"] then
      local realZones = {}
      if questData["start"]["U"] then
        for _, npcID in pairs(questData["start"]["U"]) do
          local npcData = AutoQuestLearnerData.units["data"][npcID]
          if npcData and npcData["coords"] then
            for _, coord in pairs(npcData["coords"]) do
              if coord[3] then
                realZones[coord[3]] = true
                addToZone(coord[3], questID)
                addToRealOnlyZone(coord[3], questID)
              end
            end
          end
        end
      end
      if questData["start"]["O"] then
        for _, objID in pairs(questData["start"]["O"]) do
          local objData = AutoQuestLearnerData.objects["data"][objID]
          if objData and objData["coords"] then
            for _, coord in pairs(objData["coords"]) do
              if coord[3] then
                realZones[coord[3]] = true
                addToZone(coord[3], questID)
                addToRealOnlyZone(coord[3], questID)
              end
            end
          end
        end
      end
      -- RXP fallback contributes a zone only where there's no real
      -- coordinate already, mirroring SearchQuests' own
      -- "not foundGiverInZone" fallback condition exactly. Deliberately
      -- NOT added to realOnlyIndex -- GetZoneCompletion's original
      -- logic only ever checked real start coordinates, never the RXP
      -- fallback, and this preserves that exactly rather than changing
      -- what counts toward zone completion.
      local numericQuestID = tonumber(questID)
      local rxpGive = numericQuestID and AutoQuestLearnerRXPAccept and AutoQuestLearnerRXPAccept[numericQuestID]
      if rxpGive and rxpGive[3] and not realZones[rxpGive[3]] then
        addToZone(rxpGive[3], questID)
      end
    end
  end

  return index, realOnlyIndex
end

-- Search for available quests (quest givers)
function AutoQuestLearnerDatabase:SearchQuests(meta)
  if not meta then meta = {} end
  
  local playerLevel = UnitLevel("player")
  local mapID = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap())
      or (AutoQuestLearnerMap and AutoQuestLearnerMap.GetMapID and AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone()))

  -- BUGFIX: this function completely rebuilds the current zone's set
  -- of quest-giver nodes every time it runs (it iterates the ENTIRE
  -- quest database each call, gated only by config/level/faction/etc
  -- filters) -- but never cleared out the PREVIOUS run's nodes first.
  -- A node that was eligible on one pass but not the next (e.g. a
  -- quest whose real objective got resolved to a different zone after
  -- this ran) had no way to ever disappear, since nothing here ever
  -- called DeleteNode. This runs independently of and more frequently
  -- than the quest-accept/turn-in cleanup elsewhere (every few seconds
  -- via the "updateQuestGivers" timer), so it could keep silently
  -- re-introducing stale nodes even after that other cleanup ran.
  --
  -- Scoped narrowly to this function's OWN nodes only (identified by
  -- their vertex={0,1,0} signature, unique to the "start" nodes added
  -- below) rather than clearing the whole zone -- this function only
  -- ever adds "start"/giver nodes, never objective/"end" nodes, so a
  -- blanket wipe would delete objective nodes added by the separate
  -- SearchQuestID system without this function ever re-adding them.
  if AutoQuestLearnerMap and AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"]
      and AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"][mapID] then
    for coords, node in pairs(AutoQuestLearnerMap.nodes["AUTOQUESTLEARNER"][mapID]) do
      for title, tab in pairs(node) do
        if tab.vertex and tab.vertex[1] == 0 and tab.vertex[2] == 1 and tab.vertex[3] == 0 then
          node[title] = nil
        end
      end
    end
  end

  -- BUGFIX: this never filtered by faction at all -- a Horde player
  -- could see Alliance-only quest givers (and vice versa) shown as
  -- "available" on their map, most likely to actually be noticed in
  -- contested/shared zones where both factions' content coexists.
  -- Uses the shared bitwise check (AutoQuestLearner_IsWrongFactionQuest
  -- in AutoQuestLearner.lua) -- a plain fixed-value comparison here
  -- previously only caught quests restricted to an entire faction's
  -- combined race set, missing single-race restrictions like
  -- Draenei-only or Night Elf-only.
  local playerFaction = UnitFactionGroup and UnitFactionGroup("player")

  -- PERFFIX: build the static zone index once (see comment above this
  -- function), then only iterate the quests actually relevant to the
  -- current zone instead of the entire 6600+ entry database. See
  -- AutoQuestLearner_BuildZoneQuestIndex's comment for the full
  -- explanation -- this is what turned a confirmed ~35ms stutter into
  -- a sub-millisecond scan.
  if not zoneQuestIndex then
    zoneQuestIndex, zoneQuestIndexRealOnly = AutoQuestLearner_BuildZoneQuestIndex()
  end

  -- Search through only this zone's candidate quests
  for questID in pairs(zoneQuestIndex[mapID] or {}) do
    local questData = AutoQuestLearnerData.quests["data"][questID]
    local questLoc = questData and AutoQuestLearnerData.quests["loc"][questID]
    if questLoc then
      -- Skip internal/deprecated entries (OLD/BETA/UNUSED/FLAG/[Not
      -- Used] prefixes) baked into the bundled database -- see
      -- AutoQuestLearner_IsDeprecatedQuestTitle's own comment in
      -- AutoQuestLearner.lua for the full count/explanation.
      local shouldSkip = AutoQuestLearner_IsDeprecatedQuestTitle and AutoQuestLearner_IsDeprecatedQuestTitle(questLoc.T)
      if not shouldSkip and AutoQuestLearner_IsServerQuest and not AutoQuestLearner_IsServerQuest(questID) then
        shouldSkip = true
      end
      local raceField = AutoQuestLearner_GetEffectiveRaceField and AutoQuestLearner_GetEffectiveRaceField(questID, questData) or questData["race"]
      if not shouldSkip and AutoQuestLearner_IsWrongFactionQuest and AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction) then
        shouldSkip = true
      end
      -- Profession-gated quests shouldn't be suggested to a player who
      -- doesn't have the required profession (see the matching
      -- check/comment in RefreshAvailableGiverCache in
      -- AutoQuestLearner.lua for the full explanation).
      if not shouldSkip and AutoQuestLearner_HasRequiredSkill and not AutoQuestLearner_HasRequiredSkill(questData["skill"], questID) then
        shouldSkip = true
      end
      -- "Use item on object" quests shouldn't be suggested as
      -- available if you don't have the required item (see the
      -- matching check/comment in RefreshAvailableGiverCache in
      -- AutoQuestLearner.lua for the full explanation).
      if not shouldSkip and questData["start"] and questData["start"]["O"] and questData["end"] and questData["end"]["O"]
          and questData["start"]["O"][1] == questData["end"]["O"][1]
          and questData["obj"] and questData["obj"]["I"] and questData["obj"]["I"][1] then
        local requiredItemID = questData["obj"]["I"][1]
        if GetItemCount and GetItemCount(requiredItemID) == 0 then
          shouldSkip = true
        end
      end
      -- Class-restricted quests shouldn't be suggested to a player of
      -- the wrong class (see the matching check/comment in
      -- RefreshAvailableGiverCache in AutoQuestLearner.lua).
      if not shouldSkip and AutoQuestLearnerClassRestrictions and AutoQuestLearnerClassRestrictions[questID]
          and AutoQuestLearner_HasRequiredClass and not AutoQuestLearner_HasRequiredClass(AutoQuestLearnerClassRestrictions[questID]) then
        shouldSkip = true
      end
      -- Reputation-gated quests shouldn't be suggested if the player
      -- doesn't meet the requirement (see the matching check/comment
      -- in RefreshAvailableGiverCache in AutoQuestLearner.lua).
      if not shouldSkip and AutoQuestLearnerQuestReputation and AutoQuestLearnerQuestReputation[questID]
          and AutoQuestLearner_HasRequiredReputation and not AutoQuestLearner_HasRequiredReputation(AutoQuestLearnerQuestReputation[questID]) then
        shouldSkip = true
      end
      
      -- Check if quest is appropriate for player level
      local minLevel = questData["min"] or 0
      local questLevel = questData["lvl"] or minLevel
      
      -- Cannot take the quest yet — min level gate (independent of
      -- grey/green display toggles).
      if not shouldSkip and minLevel > (playerLevel + 1) then
        shouldSkip = true
      end

      -- Skip if too high level
      if not shouldSkip and AutoQuestLearnerDB.config.showhighlevel == "0" and questLevel > playerLevel + 3 then
        shouldSkip = true
      end
      
      -- Skip if too low level
      if not shouldSkip and AutoQuestLearnerDB.config.showlowlevel == "0" and questLevel < playerLevel - 5 then
        shouldSkip = true
      end
      
      -- Check if already completed, using the server's actual
      -- completion history (via QueryQuestsCompleted/GetQuestsCompleted
      -- in AutoQuestLearner.lua) rather than only this addon's own
      -- history table, which has no record of anything completed
      -- before this addon was installed/updated -- that gap made
      -- long-since-finished quests keep showing as "available"
      -- forever. Falls back to the addon's own history (checked by
      -- both numeric quest ID and title text, for the same alias
      -- reasons as elsewhere) if the server API isn't available.
      if not shouldSkip and AutoQuestLearner_IsQuestCompleted and AutoQuestLearner_IsQuestCompleted(questID, questLoc.T) then
        shouldSkip = true
      end

      -- Skip quests gated behind an incomplete prerequisite, an
      -- unsatisfied OR-group, a required parent quest not currently
      -- active, or a completed/active mutually-exclusive alternative
      -- (see AutoQuestLearner_MeetsQuestGating's own comment in
      -- AutoQuestLearner.lua for the full breakdown).
      if not shouldSkip and AutoQuestLearner_MeetsQuestGating and not AutoQuestLearner_MeetsQuestGating(questID) then
        shouldSkip = true
      end
      
      -- Check if currently in quest log (same alias reasoning as above
      -- -- AutoQuestLearner.questlog can be keyed by title instead of
      -- numeric ID for the same reason).
      if not shouldSkip and AutoQuestLearner.questlog and
          (AutoQuestLearner.questlog[questID] or (questLoc.T and AutoQuestLearner.questlog[questLoc.T])) then
        if AutoQuestLearnerDB.config.currentquestgivers == "0" then
          shouldSkip = true
        end
      end
      
      if not shouldSkip and questData["start"] then
        -- Quest givers, current-zone only (pfDB's real "U"/"O" array
        -- structure -- see SearchQuestID for details).
        local foundGiverInZone = false
        if questData["start"]["U"] then
          for _, npcID in pairs(questData["start"]["U"]) do
            local npcData = AutoQuestLearnerData.units["data"][npcID]
            if npcData and npcData["coords"] then
              for _, coord in pairs(npcData["coords"]) do
                local npcMapID = coord[3]
                if npcMapID == mapID then
                  foundGiverInZone = true
                  MapAddNode({
                    addon = "AUTOQUESTLEARNER",
                    title = questLoc.T or ("Quest " .. questID),
                    zone = mapID,
                    x = coord[1],
                    y = coord[2],
                    spawn = npcData["name"] or ("NPC " .. npcID),
                    texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring",
                    vertex = { 0, 1, 0 },
                    questid = questID,
                    qlvl = questLevel,
                    qmin = minLevel,
                  })
                end
              end
            end
          end
        end
        if questData["start"]["O"] then
          for _, objID in pairs(questData["start"]["O"]) do
            local objData = AutoQuestLearnerData.objects["data"][objID]
            if objData and objData["coords"] then
              for _, coord in pairs(objData["coords"]) do
                local objMapID = coord[3]
                if objMapID == mapID then
                  foundGiverInZone = true
                  MapAddNode({
                    addon = "AUTOQUESTLEARNER",
                    title = questLoc.T or ("Quest " .. questID),
                    zone = mapID,
                    x = coord[1],
                    y = coord[2],
                    spawn = objData["name"] or ("Object " .. objID),
                    texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring",
                    vertex = { 0, 1, 0 },
                    questid = questID,
                    qlvl = questLevel,
                    qmin = minLevel,
                  })
                end
              end
            end
          end
        end
        -- Fallback: precise quest-giver coordinate from RXPGuides (see
        -- bundled-db/rxp-coords.lua), only used when no NPC/object
        -- match was found in this zone at all -- avoids duplicate pins
        -- for quests we already have good data for, while still
        -- covering ones where our own start-NPC data doesn't resolve.
        if not foundGiverInZone then
          local numericQuestID3 = tonumber(questID)
          local rxpGive = numericQuestID3 and AutoQuestLearnerRXPAccept and AutoQuestLearnerRXPAccept[numericQuestID3]
          if rxpGive and rxpGive[3] == mapID then
            MapAddNode({
              addon = "AUTOQUESTLEARNER",
              title = questLoc.T or ("Quest " .. questID),
              zone = mapID,
              x = rxpGive[1],
              y = rxpGive[2],
              spawn = "Quest Giver",
              texture = "Interface\\AddOns\\AutoQuestLearner\\img\\node_ring",
              vertex = { 0, 1, 0 },
              questid = questID,
              qlvl = questLevel,
              qmin = minLevel,
            })
          end
        end
      end
    end
  end
end

-- Build quest description for tooltips
function AutoQuestLearnerDatabase:BuildQuestDescription(meta)
  if not meta then return {} end
  
  local desc = {}
  
  if meta.questid and AutoQuestLearnerData.quests["loc"][meta.questid] then
    local questLoc = AutoQuestLearnerData.quests["loc"][meta.questid]
    local questData = AutoQuestLearnerData.quests["data"][meta.questid]
    
    desc.quest = questLoc.T or ""
    desc.qlvl = questData and questData["lvl"]
    desc.qmin = questData and questData["min"]
  end
  
  if meta.spawn then
    desc.spawn = meta.spawn
  end
  
  return desc
end

-- Get best map for displaying quest
function AutoQuestLearnerDatabase:GetBestMap(maps)
  if not maps then return nil end
  
  -- Prefer current map
  local currentMap = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap())
      or (AutoQuestLearnerMap and AutoQuestLearnerMap.GetMapID and AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone()))
  if maps[currentMap] then
    return currentMap
  end
  
  -- Otherwise return first available map
  for mapID, _ in pairs(maps) do
    return mapID
  end
  
  return nil
end

-- Release bundled pfDB source tables after they have been merged into
-- AutoQuestLearnerData. Without this, every quest/unit/item table lives
-- twice in memory (pfDB + AutoQuestLearnerData) and roughly doubles usage.
local function FreeBundledSourceData(keepDbcMissing)
  if not pfDB then return end
  local function wipeTree(t)
    if type(t) ~= "table" then return end
    for k in pairs(t) do
      t[k] = nil
    end
  end
  for _, cat in pairs({ "quests", "units", "objects", "items", "refloot", "areatrigger", "zones" }) do
    if pfDB[cat] then
      if keepDbcMissing and cat == "units" and pfDB[cat]["enUS-dbc-missing"] then
        local keep = pfDB[cat]["enUS-dbc-missing"]
        wipeTree(pfDB[cat])
        pfDB[cat]["enUS-dbc-missing"] = keep
      else
        wipeTree(pfDB[cat])
        pfDB[cat] = nil
      end
    end
  end
  if pfDB["minimap"] then wipeTree(pfDB["minimap"]); pfDB["minimap"] = nil end
  if pfDB["minimap-tbc"] then wipeTree(pfDB["minimap-tbc"]); pfDB["minimap-tbc"] = nil end
  -- Drop empty root if nothing left
  if not keepDbcMissing then
    pfDB = nil
    _G.pfDB = nil
  end
  if collectgarbage then
    collectgarbage("step", 400)
  end
end

-- Initialize database on load
local function InitializeDatabase()
  EnsureDatabaseTables()
  LoadPfQuestData()

  -- Snapshot which quest IDs are known from real vanilla/TBC content
  -- BEFORE the Ascension-specific merge runs, so anything that shows
  -- up ONLY afterward is confirmed Ascension-custom, not just
  -- supplementary data layered onto a real quest. Used by
  -- AutoQuestLearner_IsAscensionCustomQuest, elsewhere.
  AutoQuestLearnerAscensionOnlyQuestIDs = {}
  local preAscensionQuestIDs = {}
  if AutoQuestLearnerData.quests["data"] then
    for questID in pairs(AutoQuestLearnerData.quests["data"]) do
      preAscensionQuestIDs[questID] = true
    end
  end

  LoadAscensionData()

  if AutoQuestLearnerData.quests["data"] then
    for questID in pairs(AutoQuestLearnerData.quests["data"]) do
      if not preAscensionQuestIDs[questID] then
        AutoQuestLearnerAscensionOnlyQuestIDs[questID] = true
      end
    end
  end
  
  -- Mark database as localized
  AutoQuestLearnerDB.localized = true

  -- Free bundled source tables (keep DBC-missing names until background merge finishes)
  if pfDB and pfDB["units"] and pfDB["units"]["enUS-dbc-missing"] then
    FreeBundledSourceData(true)
  else
    FreeBundledSourceData(false)
  end

  -- NOTE: table.getn()/# only give a meaningful count on a sequential
  -- array (1, 2, 3, ...). AutoQuestLearnerData.quests["data"] is keyed
  -- by sparse quest IDs (9, 233, 580168, ...), so table.getn() on it
  -- always returned 0 regardless of how many quests actually loaded --
  -- this was purely a cosmetic bug in this print statement, not a sign
  -- the database failed to load.
  local questCount, unitCount, objectCount = 0, 0, 0
  for _ in pairs(AutoQuestLearnerData.quests["data"]) do questCount = questCount + 1 end
  for _ in pairs(AutoQuestLearnerData.units["data"]) do unitCount = unitCount + 1 end
  for _ in pairs(AutoQuestLearnerData.objects["data"]) do objectCount = objectCount + 1 end

  print("|cff00ff00AutoQuestLearner|r loading complete:")
  print("  |cffaaaaaaDatabase:|r " .. questCount .. " quests, " .. unitCount ..
        " NPCs, " .. objectCount .. " objects (bundled + pfQuest, if present)")

  local learnedQuestCount, learnedObjCount = 0, 0
  if AutoQuestLearnerDB.learned then
    if AutoQuestLearnerDB.learned.quests then
      for _ in pairs(AutoQuestLearnerDB.learned.quests) do learnedQuestCount = learnedQuestCount + 1 end
    end
    if AutoQuestLearnerDB.learned.objectives then
      for _, objectives in pairs(AutoQuestLearnerDB.learned.objectives) do
        for _, obj in pairs(objectives) do
          learnedObjCount = learnedObjCount + table.getn(obj.spawns or {})
        end
      end
    end
  end
  print("  |cffaaaaaaYour learned data:|r " .. learnedQuestCount .. " quests, " ..
        learnedObjCount .. " objective spawn points (shared across all your characters)")
  print("  |cffaaaaaaSource:|r bundled starter database (pfQuest + Questie-X data), automatically merged with a separately-installed pfQuest if you also have one")
  print("  Run |cffffcc00/aql debug|r or |cffffcc00/aql arrow|r any time for a live status check.")
end

-- Register for addon loaded to initialize database
local dbFrame = CreateFrame("Frame")
dbFrame:RegisterEvent("ADDON_LOADED")
dbFrame:SetScript("OnEvent", function()
  if arg1 == "AutoQuestLearner" then
    InitializeDatabase()
  end
end)

-- Make globally available
AutoQuestLearner = AutoQuestLearner or CreateFrame("Frame")
AutoQuestLearner.db = AutoQuestLearnerDatabase

-- Timing instrumentation for the "available quest givers" scan --
-- iterates the entire bundled quest database (6600+ entries) and is a
-- strong candidate for being the actual expensive operation, separate
-- from the map/minimap drawing instrumented in AutoQuestLearner_Map.lua.
-- NOTE: this table is defined idempotently here rather than only in
-- Map.lua, since Database.lua loads BEFORE Map.lua per the .toc --
-- checking for it without also being able to create it here would have
-- silently skipped this wrapper entirely.
AutoQuestLearner_PerfDebug = AutoQuestLearner_PerfDebug or { active = false, totals = {}, calls = {} }
local originalSearchQuests = AutoQuestLearnerDatabase.SearchQuests
AutoQuestLearnerDatabase.SearchQuests = function(self, ...)
  if not AutoQuestLearner_PerfDebug.active then
    return originalSearchQuests(self, ...)
  end
  local ok, startTime = pcall(debugprofilestop)
  if not ok then
    return originalSearchQuests(self, ...)
  end
  local a, b, c = originalSearchQuests(self, ...)
  local elapsed = debugprofilestop() - startTime
  AutoQuestLearner_PerfDebug.totals["SearchQuests"] = (AutoQuestLearner_PerfDebug.totals["SearchQuests"] or 0) + elapsed
  AutoQuestLearner_PerfDebug.calls["SearchQuests"] = (AutoQuestLearner_PerfDebug.calls["SearchQuests"] or 0) + 1
  return a, b, c
end

-- Zone completion tracking ("X/Y known quests done in this zone").
--
-- Counts every bundled quest whose START (giver) NPC/object has a
-- coordinate in the player's current zone -- the same definition of
-- "quest belongs to this zone" that SearchQuests already uses for the
-- available-quest-givers feature above, reused here for consistency
-- rather than inventing a different rule. A quest counts as "done" if
-- it's in AutoQuestLearnerDB.history, checked with the same
-- numeric-ID-or-title alias tolerance used everywhere else in this
-- addon (completion can get recorded under either form depending on
-- how the quest was resolved at turn-in time).
--
-- PERFFIX (confirmed via /aql perfdebug, same investigation as the
-- SearchQuests fix above): this function's own comment used to claim
-- it was "intentionally an on-demand command (/aql zone), not
-- something polled continuously" -- that assumption turned out to be
-- stale. The "zone completion nudge" feature (zoneNudgeFrame in
-- AutoQuestLearner.lua, enabled by default) polls this automatically
-- every 30 seconds during normal play, meaning the exact same
-- full-6600+-quest-database walk SearchQuests had was quietly running
-- on a timer the whole time too. Fixed the same way: use the
-- REAL-COORDINATE-ONLY zone index built once by
-- AutoQuestLearner_BuildZoneQuestIndex (see its comment above)
-- instead of walking every quest in the bundled database on every
-- call. Deliberately uses the real-only variant, NOT the RXP-inclusive
-- one SearchQuests uses -- this function's original logic never
-- consulted the RXP fallback, only real start coordinates, so this
-- preserves that behavior exactly rather than silently counting more
-- quests toward zone completion than before.
function AutoQuestLearnerDatabase:GetZoneCompletion()
  local mapID = (AutoQuestLearner_GetCurrentMap and AutoQuestLearner_GetCurrentMap())
      or (AutoQuestLearnerMap and AutoQuestLearnerMap.GetMapID and AutoQuestLearnerMap:GetMapID(GetCurrentMapContinent(), GetCurrentMapZone()))

  -- Faction filtering: a quest whose "race" field is exclusively the
  -- OPPOSITE faction's combined race bitmask should never count toward
  -- this character's zone completion -- they can never accept or
  -- complete it, so including it just inflates the "remaining" count
  -- with quests that were never actually available. Values verified
  -- directly against the real bundled data (not assumed): summing each
  -- faction's individual race bits gives exactly the two most frequent
  -- values found in a scan of the actual database. 77/178 are the
  -- vanilla-only values; TBC adds Draenei/Blood Elf, giving 1101/690.
  -- Faction check uses the shared bitwise test
  -- (AutoQuestLearner_IsWrongFactionQuest in AutoQuestLearner.lua) --
  -- see its own comment for why a plain fixed-value comparison misses
  -- single-race restrictions.
  local playerFaction = UnitFactionGroup and UnitFactionGroup("player")

  if not zoneQuestIndex then
    zoneQuestIndex, zoneQuestIndexRealOnly = AutoQuestLearner_BuildZoneQuestIndex()
  end

  local total, done = 0, 0
  local incompleteTitles = {}

  for questID in pairs(zoneQuestIndexRealOnly[mapID] or {}) do
    local questData = AutoQuestLearnerData.quests["data"][questID]
    local questLoc = questData and AutoQuestLearnerData.quests["loc"][questID]
    if questLoc and questData and questData["start"] then
      local raceField = AutoQuestLearner_GetEffectiveRaceField and AutoQuestLearner_GetEffectiveRaceField(questID, questData) or questData["race"]
      local wrongFaction = AutoQuestLearner_IsWrongFactionQuest and AutoQuestLearner_IsWrongFactionQuest(raceField, playerFaction)

      if not wrongFaction then
        total = total + 1
        local isDone = AutoQuestLearner_IsQuestCompleted and AutoQuestLearner_IsQuestCompleted(questID, questLoc.T)
        if isDone then
          done = done + 1
        elseif questLoc.T and table.getn(incompleteTitles) < 15 then
          table.insert(incompleteTitles, questLoc.T)
        end
      end
    end
  end

  return total, done, incompleteTitles, mapID
end


------------------------------------------------------------
-- Deferred DBC unit-name merge (performance)
--
-- Chunk files populate pfDB["units"]["enUS-dbc-missing"] at parse time.
-- Merging into AutoQuestLearnerData.units["loc"] runs AFTER login,
-- a few thousand entries per frame, then the holding table is freed.
------------------------------------------------------------
local DBC_MERGE_PER_FRAME = 3000
local dbcMergeFrame = nil
local dbcMergeNextKey = nil  -- continuation key for next(t, k)
local dbcMergeStarted = false
local dbcMergeAdded = 0
local dbcMergeSource = nil

local function DbcNameMerge_OnUpdate()
  if not dbcMergeSource then
    if dbcMergeFrame then dbcMergeFrame:SetScript("OnUpdate", nil) end
    return
  end

  AutoQuestLearnerData = AutoQuestLearnerData or {}
  AutoQuestLearnerData.units = AutoQuestLearnerData.units or {}
  AutoQuestLearnerData.units["loc"] = AutoQuestLearnerData.units["loc"] or {}
  local loc = AutoQuestLearnerData.units["loc"]

  local budget = DBC_MERGE_PER_FRAME
  local k, v = dbcMergeNextKey, nil
  while budget > 0 do
    k, v = next(dbcMergeSource, k)
    if k == nil then
      -- Finished
      dbcMergeFrame:SetScript("OnUpdate", nil)
      dbcMergeSource = nil
      dbcMergeNextKey = nil
      if pfDB and pfDB["units"] then
        pfDB["units"]["enUS-dbc-missing"] = nil
      end
      -- All merges done -- drop remaining source data and GC
      FreeBundledSourceData(false)
      if AutoQuestLearnerDB and AutoQuestLearnerDB.config and AutoQuestLearnerDB.config.debug then
        print("|cff00ff00AutoQuestLearner|r DBC name merge done: +" .. dbcMergeAdded .. " names (background)")
      end
      return
    end
    if loc[k] == nil and v then
      loc[k] = v
      dbcMergeAdded = dbcMergeAdded + 1
    end
    dbcMergeNextKey = k
    budget = budget - 1
  end
end

function AutoQuestLearner_StartDbcNameMerge()
  if dbcMergeStarted then return end
  if not pfDB or not pfDB["units"] or not pfDB["units"]["enUS-dbc-missing"] then
    return
  end
  dbcMergeStarted = true
  dbcMergeSource = pfDB["units"]["enUS-dbc-missing"]
  dbcMergeNextKey = nil
  dbcMergeAdded = 0
  if not dbcMergeFrame then
    dbcMergeFrame = CreateFrame("Frame")
  end
  dbcMergeFrame:SetScript("OnUpdate", DbcNameMerge_OnUpdate)
end

-- Start after the player is in the world (not during ADDON_LOADED).
-- Prefer AceTimer when Ace3 is embedded; fall back to OnUpdate delay.
local dbcMergeEventFrame = CreateFrame("Frame")
dbcMergeEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
dbcMergeEventFrame:SetScript("OnEvent", function()
  dbcMergeEventFrame:UnregisterEvent("PLAYER_ENTERING_WORLD")
  local function start()
    AutoQuestLearner_StartDbcNameMerge()
  end
  if AutoQuestLearnerAce and AutoQuestLearnerAce.ScheduleTimer then
    AutoQuestLearnerAce:ScheduleTimer(start, 0.5)
  else
    local delay = CreateFrame("Frame")
    local elapsed = 0
    delay:SetScript("OnUpdate", function()
      elapsed = elapsed + (arg1 or 0)
      if elapsed >= 0.5 then
        delay:SetScript("OnUpdate", nil)
        start()
      end
    end)
  end
end)
